<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package URL_Password_Protector
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$table_name = $wpdb->prefix . 'url_protector';
// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

delete_option( 'upp_admin_bypass' );
