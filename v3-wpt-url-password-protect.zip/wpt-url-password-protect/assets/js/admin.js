jQuery( function ( $ ) {
	const urlForm = $( '#upp-add-url-form' );
	const urlId = $( '#url_id' );
	const urlSlug = $( '#url_slug' );
	const password = $( '#password' );
	const formTitle = $( '#form_title' );
	const message = $( '#form_message' );
	const saveButton = $( '#upp-save-button' );
	const cancelButton = $( '#upp-cancle-button' );
	const container = $( '.upp-admin-container' );
	const passwordHelp = $( '#upp-password-help' );
	const defaultHelp = passwordHelp.length ? passwordHelp.text() : '';

	function i18n( key, fallback ) {
		if ( typeof upp_ajax !== 'undefined' && upp_ajax.i18n && upp_ajax.i18n[ key ] ) {
			return upp_ajax.i18n[ key ];
		}
		return fallback;
	}

	function showNotice( msg, isError ) {
		$( '.upp_notice' ).remove();
		const notice = $( '<div class="upp-notice upp_notice"></div>' ).text( msg ).prependTo( container );
		if ( isError ) {
			notice.addClass( 'upp-error' );
		}
		setTimeout( function () {
			notice.fadeOut( 300, function () {
				$( this ).remove();
			} );
		}, 5000 );
	}

	function resetForm() {
		if ( urlForm.length && urlForm[ 0 ] ) {
			urlForm[ 0 ].reset();
		}
		urlId.val( '' );
		urlSlug.val( '' );
		password.val( '' );
		password.removeAttr( 'placeholder' );
		formTitle.val( '' );
		message.val( '' );
		saveButton.text( i18n( 'save_url', 'Save rule' ) );
		cancelButton.hide();
		if ( passwordHelp.length ) {
			passwordHelp.text( defaultHelp );
		}
	}

	urlForm.on( 'submit', function ( e ) {
		e.preventDefault();

		const id = String( urlId.val() || '' ).trim();
		const pw = String( password.val() || '' );

		if ( ! id && ! pw.trim() ) {
			showNotice( i18n( 'password_required', 'Password is required for new rules.' ), true );
			return;
		}

		urlForm.addClass( 'upp-loading' );

		const data = {
			action: 'upp_save_url',
			nonce: upp_ajax.nonce,
			urlId: id,
			urlSlug: urlSlug.val(),
			urlPassword: pw,
			formTitle: formTitle.val(),
			formMessage: message.val(),
		};

		$.post( upp_ajax.ajax_url, data )
			.done( function ( response ) {
				urlForm.removeClass( 'upp-loading' );
				if ( response.success ) {
					if ( response.data && response.data.nonce ) {
						upp_ajax.nonce = response.data.nonce;
					}
					showNotice( response.data.message );
					resetForm();
					window.location.reload();
				} else {
					const err = response.data && response.data.message ? response.data.message : i18n( 'generic_error', 'Something went wrong.' );
					showNotice( err, true );
				}
			} )
			.fail( function () {
				urlForm.removeClass( 'upp-loading' );
				showNotice( i18n( 'network_error', 'A network error occurred. Please try again.' ), true );
			} );
	} );

	$( document ).on( 'click', '.upp-edit-url', function ( e ) {
		e.preventDefault();

		const row = $( this );
		const id = row.data( 'id' );
		const slug = row.data( 'url-slug' );
		const title = row.data( 'form-title' );
		const msg = row.data( 'message' );

		urlId.val( id );
		urlSlug.val( slug );
		password.val( '' );
		password.attr( 'placeholder', i18n( 'password_placeholder', 'Leave blank to keep the current password' ) );
		formTitle.val( title );
		message.val( msg );
		saveButton.text( i18n( 'update_url', 'Update URL' ) );
		cancelButton.show();

		if ( passwordHelp.length ) {
			passwordHelp.text( i18n( 'password_placeholder', 'Leave blank to keep the current password' ) );
		}

		$( 'html, body' ).animate(
			{
				scrollTop: urlForm.offset().top - 50,
			},
			400
		);
	} );

	cancelButton.on( 'click', function ( e ) {
		e.preventDefault();
		resetForm();
	} );

	$( document ).on( 'click', '.upp-delete-url', function ( e ) {
		e.preventDefault();
		const urlRowId = $( this ).data( 'id' );
		const row = $( this ).closest( 'tr' );

		if ( ! window.confirm( i18n( 'delete_confirm', 'Delete this protected URL rule?' ) ) ) {
			return;
		}

		row.addClass( 'upp-loading' );

		const payload = {
			action: 'upp_delete_link',
			nonce: upp_ajax.nonce,
			url_id: urlRowId,
		};

		$.post( upp_ajax.ajax_url, payload )
			.done( function ( response ) {
				row.removeClass( 'upp-loading' );
				if ( response.success ) {
					if ( response.data && response.data.nonce ) {
						upp_ajax.nonce = response.data.nonce;
					}
					showNotice( response.data.message );
					row.fadeOut( 300, function () {
						$( this ).remove();
						if ( $( 'table tbody tr' ).length === 0 ) {
							window.location.reload();
						}
					} );
				} else {
					const err = response.data && response.data.message ? response.data.message : i18n( 'generic_error', 'Something went wrong.' );
					showNotice( err, true );
				}
			} )
			.fail( function () {
				row.removeClass( 'upp-loading' );
				showNotice( i18n( 'network_error', 'A network error occurred. Please try again.' ), true );
			} );
	} );

	$( '.tablenav-pages .current-page' ).on( 'keydown', function ( e ) {
		if ( e.which !== 13 ) {
			return;
		}
		e.preventDefault();
		const page = parseInt( $( this ).val(), 10 );
		const maxPage = parseInt( $( '.total-pages' ).text(), 10 );

		if ( isNaN( page ) || page < 1 || page > maxPage ) {
			window.alert( i18n( 'invalid_page', 'Please enter a valid page number.' ) );
			return;
		}

		const params = new URLSearchParams( window.location.search );
		const searchParam = params.get( 'upp_search' ) || '';
		const searchQuery = searchParam ? '&upp_search=' + encodeURIComponent( searchParam ) : '';

		window.location.href = 'admin.php?page=url-protector&paged=' + page + searchQuery;
	} );
} );
