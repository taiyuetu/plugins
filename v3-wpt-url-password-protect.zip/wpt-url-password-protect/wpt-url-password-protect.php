<?php
/**
 * Plugin Name: WPT URL Password Protect
 * Plugin URI: https://wpdev.com.cn
 * Description: Password-protect specific URL paths on your WordPress site.
 * Author: Wp Tutor
 * Version: 1.0.2
 * Text Domain: url-password-protector
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package URL_Password_Protector
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'URL_PASSWORD_PROTECTOR_VERSION', '1.0.2' );
define( 'URL_PASSWORD_PROTECTOR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'URL_PASSWORD_PROTECTOR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'URL_PASSWORD_PROTECTOR_TEXT_DOMAIN', 'url-password-protector' );

class URL_Password_Protector {
	// class 单一初始化 
	
	protected static $_instance = null; 

	// 主要初始化
	
	public static function instance() {
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	//constructor 
	
	public function __construct() {
		register_activation_hook( __FILE__, array( $this, 'activate' ) );

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		add_action( 'wp_ajax_upp_save_url', array( $this, 'save_url' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'wp_ajax_upp_delete_link', array( $this, 'delete_link' ) );

		add_action( 'wp_loaded', array( $this, 'handle_protected_urls' ), 1 );
	}

	/**
	 * Load plugin text domain for translations.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			URL_PASSWORD_PROTECTOR_TEXT_DOMAIN,
			false,
			dirname( plugin_basename( __FILE__ ) ) . '/languages'
		);
	}


	public function activate()
	{
		global $wpdb;

		//创建表 
		$table_name = $wpdb->prefix . 'url_protector';

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			url_slug varchar(255) NOT NULL,
			password varchar(255) NOT NULL,
			form_title varchar(255) NOT NULL,
			message varchar(255) NOT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY url_slug (url_slug)
		) $charset_collate;";

		require_once (ABSPATH . 'wp-admin/includes/upgrade.php');

		dbDelta($sql);
	}


	public function enqueue_admin_scripts( $hook ) {
		$allowed_hooks = array(
			'toplevel_page_url-protector',
			'url-protector_page_upp-settings',
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) ) {
			return;
		}

		wp_enqueue_style( 'upp-admin-css', URL_PASSWORD_PROTECTOR_PLUGIN_URL . 'assets/css/admin.css', array(), URL_PASSWORD_PROTECTOR_VERSION );
		wp_enqueue_script(
			'upp-admin-js',
			URL_PASSWORD_PROTECTOR_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			URL_PASSWORD_PROTECTOR_VERSION,
			true
		);

		wp_localize_script(
			'upp-admin-js',
			'upp_ajax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'upp_nonce' ),
				'i18n'     => array(
					'save_url'               => __( 'Save rule', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'update_url'             => __( 'Update rule', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'password_placeholder'   => __( 'Leave blank to keep the current password', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'password_required'      => __( 'Password is required for new rules.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'delete_confirm'         => __( 'Delete this protected URL rule?', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'invalid_page'           => __( 'Please enter a valid page number.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'generic_error'          => __( 'Something went wrong.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'network_error'          => __( 'A network error occurred. Please try again.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				),
			)
		);
	}

	public function handle_protected_urls() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return;
		}

		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			return;
		}

		if ( is_feed() ) {
			return;
		}

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'UPP current URL: ' . $this->get_current_url() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		$admin_bypass = get_option( 'upp_admin_bypass', 'yes' );
		if ( 'yes' === $admin_bypass && current_user_can( 'manage_options' ) ) {
			return;
		}

		$all_protected_urls = $this->get_all_urls();

		$current_url  = urldecode( $this->get_current_url() );
		$current_path = parse_url( $current_url, PHP_URL_PATH );
		$current_path = is_string( $current_path ) ? trim( $current_path, '/' ) : '';

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'UPP current path: ' . $current_path ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		$current_path = $this->normalize_request_path( $current_path );

		foreach ( $all_protected_urls as $url_data ) {
			if ( empty( $url_data->url_slug ) ) {
				continue;
			}

			$protected_slug = trim( $url_data->url_slug, '/' );

			if ( ! $this->is_path_protected( $current_path, $protected_slug ) ) {
				continue;
			}

			$cookie_name   = $this->get_protection_cookie_name( $protected_slug );
			$cookie_ok     = isset( $_COOKIE[ $cookie_name ] ) && is_string( $_COOKIE[ $cookie_name ] );
			$expected_hash = $this->get_auth_cookie_value( (int) $url_data->id, (string) $url_data->password );

			if ( $cookie_ok && hash_equals( $expected_hash, (string) wp_unslash( $_COOKIE[ $cookie_name ] ) ) ) {
				continue;
			}

			if (
				isset( $_POST['url_password_protector_submit'], $_POST['url_password_protector_password'], $_POST['upp_form_nonce'] )
				&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['upp_form_nonce'] ) ), 'upp_unlock_' . (int) $url_data->id )
			) {
				$password = isset( $_POST['url_password_protector_password'] ) ? wp_unslash( $_POST['url_password_protector_password'] ) : '';
				$password = is_string( $password ) ? $password : '';

				if ( $this->verify_rule_password( $password, $url_data ) ) {
					$this->maybe_upgrade_stored_password( (int) $url_data->id, $password, $url_data->password );

					$url_data = $this->get_url( (int) $url_data->id );
					if ( ! $url_data ) {
						return;
					}

					$cookie_value = $this->get_auth_cookie_value( (int) $url_data->id, (string) $url_data->password );

					setcookie(
						$cookie_name,
						$cookie_value,
						time() + ( 30 * DAY_IN_SECONDS ),
						COOKIEPATH,
						COOKIE_DOMAIN,
						is_ssl(),
						true
					);

					wp_safe_redirect( esc_url_raw( $this->get_current_url() ) );
					exit;
				}
			}

			$this->display_password_form( $url_data, $this->password_form_had_invalid_attempt( $url_data ) );
			exit;
		}
	}

	private function display_password_form( $url_data, $incorrect_password = false ) {
		$title   = ! empty( $url_data->form_title ) ? $url_data->form_title : __( 'Protected Content', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN );
		$message = ! empty( $url_data->message ) ? $url_data->message : __( 'This content is password protected. Please enter the password to view it.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN );

		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php echo esc_html( $title ); ?> &ndash; <?php bloginfo( 'name' ); ?></title>
			<?php wp_head(); ?>
			<style>
				body {
					font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
					background-color: #f1f1f1;
					color: #444;
					display: flex;
					align-items: center;
					justify-content: center;
					min-height: 100vh;
					margin: 0;
					padding: 20px;
				}

				.password-form-container {
					background-color: #fff;
					border-radius: 5px;
					box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
					padding: 40px;
					max-width: 500px;
					width: 100%;
				}

				.password-form-container h1 {
					margin-top: 0;
					margin-bottom: 20px;
					font-size: 24px;
					color: #23282d;
					text-align: center;
				}

				.password-form-container p {
					margin-bottom: 20px;
				}

				.password-form {
					display: flex;
					flex-direction: column;
				}

				.password-form input[type="password"] {
					padding: 10px;
					border: 1px solid #ddd;
					border-radius: 3px;
					margin-bottom: 15px;
				}

				.password-form input[type="submit"] {
					background-color: #0073aa;
					color: #fff;
					border: none;
					border-radius: 3px;
					padding: 10px 15px;
					cursor: pointer;
				}

				.password-form input[type="submit"]:hover {
					background-color: #005c8a;
				}

				.incorrect-password {
					color: #d63638;
					margin-bottom: 15px;
				}

				.back-to-home {
					text-align: center;
					margin-top: 20px;
				}

				.back-to-home a {
					color: #0073aa;
					text-decoration: none;
				}

				.back-to-home a:hover {
					text-decoration: underline;
				}

				.login-link {
					text-align: center;
					margin-top: 15px;
					font-size: 14px;
				}

				.login-link a {
					color: #0073aa;
					text-decoration: none;
				}

				.login-link a:hover {
					text-decoration: underline;
				}
			</style>
		</head>
		<body>
			<div class="password-form-container">
				<h1><?php echo esc_html( $title ); ?></h1>
				<div class="password-form-content">
					<p><?php echo wp_kses_post( $message ); ?></p>

					<?php if ( $incorrect_password ) : ?>
						<p class="incorrect-password"><?php esc_html_e( 'Incorrect password. Please try again.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></p>
					<?php endif; ?>

					<form class="password-form" method="post" action="">
						<?php wp_nonce_field( 'upp_unlock_' . (int) $url_data->id, 'upp_form_nonce', true, true ); ?>
						<input type="password" name="url_password_protector_password" placeholder="<?php esc_attr_e( 'Enter password', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>" required autocomplete="current-password" autofocus>
						<input type="submit" name="url_password_protector_submit" value="<?php esc_attr_e( 'Submit', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>">
					</form>

					<?php if ( ! is_user_logged_in() ) : ?>
						<div class="login-link">
							<a href="<?php echo esc_url( wp_login_url( $this->get_current_url() ) ); ?>"><?php esc_html_e( 'Log in (site users)', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></a>
						</div>
					<?php endif; ?>

					<div class="back-to-home">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to home', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></a>
					</div>
				</div>
			</div>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
	}

	/**
	 * Whether the last POST was a failed unlock attempt for this rule.
	 *
	 * @param object $url_data Row from DB.
	 * @return bool
	 */
	private function password_form_had_invalid_attempt( $url_data ) {
		if ( ! isset( $_POST['url_password_protector_submit'], $_POST['upp_form_nonce'] ) ) {
			return false;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['upp_form_nonce'] ) ), 'upp_unlock_' . (int) $url_data->id ) ) {
			return false;
		}

		$password = isset( $_POST['url_password_protector_password'] ) ? wp_unslash( $_POST['url_password_protector_password'] ) : '';
		$password = is_string( $password ) ? $password : '';

		return ! $this->verify_rule_password( $password, $url_data );
	}

	/**
	 * Verify submitted password against stored value (WordPress hash or legacy plaintext).
	 *
	 * @param string $plain    Submitted password.
	 * @param object $url_data Row from DB.
	 * @return bool
	 */
	private function verify_rule_password( $plain, $url_data ) {
		$plain = trim( (string) $plain );

		if ( '' === $plain ) {
			return false;
		}

		$stored = (string) $url_data->password;

		if ( $this->password_is_wp_hash( $stored ) ) {
			return wp_check_password( $plain, $stored );
		}

		return hash_equals( $stored, $plain );
	}

	/**
	 * Detect WordPress-style password hashes.
	 *
	 * @param string $stored Stored password column.
	 * @return bool
	 */
	private function password_is_wp_hash( $stored ) {
		if ( ! is_string( $stored ) || '' === $stored ) {
			return false;
		}

		return (
			0 === strpos( $stored, '$P$' )
			|| 0 === strpos( $stored, '$2y$' )
			|| 0 === strpos( $stored, '$2a$' )
			|| 0 === strpos( $stored, '$2b$' )
		);
	}

	/**
	 * Upgrade legacy plaintext passwords to wp_hash_password after a successful login.
	 *
	 * @param int    $id         Rule ID.
	 * @param string $plain      Plain password (just verified).
	 * @param string $old_stored Previous DB value.
	 */
	private function maybe_upgrade_stored_password( $id, $plain, $old_stored ) {
		if ( $this->password_is_wp_hash( (string) $old_stored ) ) {
			return;
		}

		$plain = trim( (string) $plain );

		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		$wpdb->update(
			$table_name,
			array( 'password' => wp_hash_password( $plain ) ),
			array( 'id' => (int) $id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Cookie value bound to rule ID and stored password hash (no plaintext in cookie).
	 *
	 * @param int    $row_id                 Rule ID.
	 * @param string $stored_password_field  DB password column (hash or legacy).
	 * @return string
	 */
	private function get_auth_cookie_value( $row_id, $stored_password_field ) {
		return hash_hmac( 'sha256', (string) (int) $row_id . '|' . $stored_password_field, wp_salt( 'upp_cookie' ) );
	}

	public function get_current_url() {
		if ( ! isset( $_SERVER['HTTP_HOST'], $_SERVER['REQUEST_URI'] ) ) {
			return home_url( '/' );
		}

		$host = sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) );
		$uri  = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );

		return ( is_ssl() ? 'https://' : 'http://' ) . $host . $uri;
	}

	/**
	 * Check if a path matches the protected path exactly or based on wildcard.
	 *
	 * @param string $current_path   The current URL path to check.
	 * @param string $protected_path The protected URL path pattern.
	 * @return bool True if protected, false otherwise.
	 */
	private function is_path_protected( $current_path, $protected_path ) {
		$current_path   = trim( (string) $current_path, '/' );
		$protected_path = trim( (string) $protected_path, '/' );

		if ( $current_path === $protected_path ) {
			return true;
		}

		if ( strlen( $protected_path ) >= 2 && substr( $protected_path, -2 ) === '/*' ) {
			$base_path = rtrim( substr( $protected_path, 0, -2 ), '/' );

			return $current_path === $base_path || 0 === strpos( $current_path, $base_path . '/' );
		}

		return false;
	}

	/**
	 * Cookie name for a protected slug (stable for the slug string).
	 *
	 * @param string $slug URL slug.
	 * @return string
	 */
	private function get_protection_cookie_name( $slug ) {
		return 'url_password_protector_' . md5( trim( $slug, '/' ) );
	}

	/**
	 * Strip WordPress subdirectory prefix from the request path so rules match stored slugs.
	 *
	 * @param string $current_path Path without leading/trailing slashes.
	 * @return string
	 */
	private function normalize_request_path( $current_path ) {
		$home_path = parse_url( home_url( '/' ), PHP_URL_PATH );
		$home_path = is_string( $home_path ) ? trim( $home_path, '/' ) : '';

		if ( '' === $home_path ) {
			return $current_path;
		}

		if ( $current_path === $home_path ) {
			return '';
		}

		if ( '' !== $current_path && 0 === strpos( $current_path, $home_path . '/' ) ) {
			return substr( $current_path, strlen( $home_path ) + 1 );
		}

		return $current_path;
	}

	public function delete_link() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'upp_nonce' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to do this.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		$url_id = isset( $_POST['url_id'] ) ? (int) $_POST['url_id'] : 0;

		if ( $url_id <= 0 ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid URL ID.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		$result = $wpdb->delete( $table_name, array( 'id' => $url_id ), array( '%d' ) );

		if ( false !== $result && $result > 0 ) {
			wp_send_json_success(
				array(
					'message' => __( 'URL deleted successfully.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					'nonce'   => wp_create_nonce( 'upp_nonce' ),
				)
			);
		}

		$db_error = $wpdb->last_error;
		if ( $db_error ) {
			error_log( 'UPP delete failed: ' . $db_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		wp_send_json_error(
			array(
				'message' => __( 'Could not delete the URL rule.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			)
		);
	}

	/**
	 * Sanitize admin bypass checkbox value.
	 *
	 * @param mixed $value Raw value.
	 * @return string 'yes'|'no'
	 */
	public function sanitize_admin_bypass( $value ) {
		return ( 'yes' === $value ) ? 'yes' : 'no';
	}

	public function register_settings() {
		register_setting(
			'url_password_settings',
			'upp_admin_bypass',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_admin_bypass' ),
				'default'           => 'yes',
			)
		);
	}

	public function add_admin_menu() {
		add_menu_page(
			__( 'URL Password Protect', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			__( 'URL Password Protect', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			'manage_options',
			'url-protector',
			array( $this, 'admin_page' ),
			'dashicons-lock',
			58
		);

		add_submenu_page(
			'url-protector',
			__( 'URL Password Protect — Rules', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			__( 'Protected URLs', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			'manage_options',
			'url-protector',
			array( $this, 'admin_page' )
		);

		add_submenu_page(
			'url-protector',
			__( 'URL Password Protect — Settings', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			__( 'Settings', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
			'manage_options',
			'upp-settings',
			array( $this, 'admin_page_settings' )
		);
	}

	public function admin_page_settings() {
		$admin_bypass = get_option( 'upp_admin_bypass', 'yes' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'URL Password Protect — Settings', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></h1>
			<form action="options.php" method="post">
				<?php
				settings_fields( 'url_password_settings' );
				settings_errors();
				?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="upp_admin_bypass"><?php esc_html_e( 'Administrator bypass', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<input type="hidden" name="upp_admin_bypass" value="no" />
							<label>
								<input type="checkbox" name="upp_admin_bypass" id="upp_admin_bypass" value="yes" <?php checked( 'yes', $admin_bypass ); ?> />
								<?php esc_html_e( 'Allow users who can manage options to view protected URLs without entering a password.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>
							</label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
	private function get_all_urls()
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		return $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
	}

	private function get_filtered_urls( $search = '', $page = 1, $per_page = 10 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		$where  = '';
		$search = sanitize_text_field( (string) $search );

		if ( '' !== $search ) {
			$like  = '%' . $wpdb->esc_like( $search ) . '%';
			$where = $wpdb->prepare(
				' WHERE url_slug LIKE %s OR password LIKE %s OR form_title LIKE %s OR message LIKE %s',
				$like,
				$like,
				$like,
				$like
			);
		}

		$total_query = "SELECT COUNT(*) FROM {$table_name}{$where}";
		$total       = (int) $wpdb->get_var( $total_query );

		$page     = max( 1, (int) $page );
		$per_page = max( 1, min( 100, (int) $per_page ) );
		$offset   = ( $page - 1 ) * $per_page;

		$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 0;

		$sql = $wpdb->prepare(
			"SELECT * FROM {$table_name}{$where} ORDER BY created_at DESC LIMIT %d OFFSET %d",
			$per_page,
			$offset
		);

		$results = $wpdb->get_results( $sql );

		return array(
			'urls'  => $results,
			'total' => $total,
			'pages' => $total_pages,
		);
	}

	public function admin_page() {
		$search         = isset( $_GET['upp_search'] ) ? sanitize_text_field( wp_unslash( $_GET['upp_search'] ) ) : '';
		$current_page   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$per_page       = 20;
		$urls_data      = $this->get_filtered_urls( $search, $current_page, $per_page );
		$protected_urls = $urls_data['urls'];
		$total_pages    = $urls_data['pages'];
		$total_urls     = $urls_data['total'];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'URL Password Protect', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></h1>
			<div class="upp-admin-container">
				<div class="upp-admin-section">
					<h2><?php esc_html_e( 'Add protected URL', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></h2>
					<form id="upp-add-url-form">
						<input type="hidden" name="url_id" id="url_id" value="">

						<div class="form-group">
							<label for="url_slug"><?php esc_html_e( 'URL path (slug)', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
							<input type="text" id="url_slug" name="url_slug" required autocomplete="off">
							<p class="description">
								<?php esc_html_e( 'Use the path without the domain, e.g. "go/special". To protect everything under a prefix, end with "/*" (e.g. "go/*").', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>
							</p>
						</div>

						<div class="form-group">
							<label for="password"><?php esc_html_e( 'Password', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
							<input type="password" id="password" name="password" autocomplete="new-password">
							<p class="description" id="upp-password-help"><?php esc_html_e( 'Required for new rules. When editing, leave blank to keep the current password.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></p>
						</div>

						<div class="form-group">
							<label for="form_title"><?php esc_html_e( 'Gate title (optional)', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
							<input type="text" id="form_title" name="form_title">
						</div>

						<div class="form-group">
							<label for="form_message"><?php esc_html_e( 'Gate message (optional)', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
							<input type="text" id="form_message" name="form_message">
						</div>

						<div class="form-group">
							<button type="submit" class="button button-primary" id="upp-save-button"><?php esc_html_e( 'Save rule', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></button>
							<button type="button" class="button" id="upp-cancle-button" style="display: none;"><?php esc_html_e( 'Cancel', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></button>
						</div>
					</form>
				</div>

				<div class="upp-admin-section">
					<h2><?php esc_html_e( 'Protected URLs', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></h2>
					<div class="upp-search-box">
						<form method="get">
							<input type="hidden" name="page" value="url-protector">
							<input type="search" name="upp_search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search…', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>">
							<input type="submit" class="button" value="<?php esc_attr_e( 'Search', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?>">
							<?php if ( '' !== $search ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=url-protector' ) ); ?>" class="button"><?php esc_html_e( 'Clear', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></a>
							<?php endif; ?>
						</form>
					</div>

					<?php if ( $total_urls > 0 ) : ?>
						<div class="tablenav top">
							<div class="tablenav-pages">
								<span class="displaying-num"><?php echo (int) $total_urls; ?> <?php esc_html_e( 'items', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></span>
								<?php if ( $total_pages > 1 ) : ?>
									<span class="pagination-links">
										<?php
										if ( $current_page > 1 ) :
											$first_page = add_query_arg( array( 'paged' => 1, 'upp_search' => $search ) );
											echo '<a class="first-page button" href="' . esc_url( $first_page ) . '"><span class="screen-reader-text">' . esc_html__( 'First page', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ) . '</span><span aria-hidden="true">&laquo;</span></a>';
										else :
											echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&laquo;</span>';
										endif;

										if ( $current_page > 1 ) :
											$prev_page = add_query_arg( array( 'paged' => $current_page - 1, 'upp_search' => $search ) );
											echo '<a class="prev-page button" href="' . esc_url( $prev_page ) . '"><span class="screen-reader-text">' . esc_html__( 'Previous page', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ) . '</span><span aria-hidden="true">&lsaquo;</span></a>';
										else :
											echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&lsaquo;</span>';
										endif;
										?>
										<span class="paging-input">
											<label for="current-page-selector" class="screen-reader-text"><?php esc_html_e( 'Current page', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></label>
											<input class="current-page" id="current-page-selector" type="text" name="paged" value="<?php echo esc_attr( (string) $current_page ); ?>" size="3" aria-describedby="table-paging">
											<span class="tablenav-paging-text"> <?php esc_html_e( 'of', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?> <span class="total-pages"><?php echo (int) $total_pages; ?></span></span>
										</span>
										<?php
										if ( $current_page < $total_pages ) :
											$next_page = add_query_arg( array( 'paged' => $current_page + 1, 'upp_search' => $search ) );
											echo '<a class="next-page button" href="' . esc_url( $next_page ) . '"><span class="screen-reader-text">' . esc_html__( 'Next page', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ) . '</span><span aria-hidden="true">&rsaquo;</span></a>';
										else :
											echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&rsaquo;</span>';
										endif;

										if ( $current_page < $total_pages ) :
											$last_page = add_query_arg( array( 'paged' => $total_pages, 'upp_search' => $search ) );
											echo '<a class="last-page button" href="' . esc_url( $last_page ) . '"><span class="screen-reader-text">' . esc_html__( 'Last page', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ) . '</span><span aria-hidden="true">&raquo;</span></a>';
										else :
											echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&raquo;</span>';
										endif;
										?>
									</span>
								<?php endif; ?>
							</div>
						</div>
					<?php endif; ?>

					<?php if ( empty( $protected_urls ) ) : ?>
						<p><?php esc_html_e( 'No rules found.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></p>
					<?php else : ?>
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'URL', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
									<th scope="col"><?php esc_html_e( 'Password', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
									<th scope="col"><?php esc_html_e( 'Title', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
									<th scope="col"><?php esc_html_e( 'Message', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
									<th scope="col"><?php esc_html_e( 'Created', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
									<th scope="col"><?php esc_html_e( 'Actions', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $protected_urls as $protected_url ) : ?>
									<tr data-id="<?php echo esc_attr( (string) $protected_url->id ); ?>">
										<td><?php echo esc_url( home_url( '/' . ltrim( (string) $protected_url->url_slug, '/' ) ) ); ?></td>
										<td><span aria-hidden="true">********</span><span class="screen-reader-text"><?php esc_html_e( 'Hidden', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></span></td>
										<td><?php echo esc_html( (string) $protected_url->form_title ); ?></td>
										<td><?php echo esc_html( (string) $protected_url->message ); ?></td>
										<td><?php echo esc_html( (string) $protected_url->created_at ); ?></td>
										<td>
											<a href="#" class="upp-edit-url"
												data-id="<?php echo esc_attr( (string) $protected_url->id ); ?>"
												data-url-slug="<?php echo esc_attr( (string) $protected_url->url_slug ); ?>"
												data-form-title="<?php echo esc_attr( (string) $protected_url->form_title ); ?>"
												data-message="<?php echo esc_attr( (string) $protected_url->message ); ?>"
												data-password-is-hash="<?php echo esc_attr( $this->password_is_wp_hash( (string) $protected_url->password ) ? '1' : '0' ); ?>"
											><?php esc_html_e( 'Edit', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></a>
											&nbsp;|&nbsp;
											<a href="#" class="upp-delete-url" data-id="<?php echo esc_attr( (string) $protected_url->id ); ?>"><?php esc_html_e( 'Delete', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ); ?></a>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}


	public function save_url() {
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'upp_nonce' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to do this.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		$url_id       = isset( $_POST['urlId'] ) ? (int) $_POST['urlId'] : 0;
		$url_slug     = isset( $_POST['urlSlug'] ) ? sanitize_text_field( wp_unslash( $_POST['urlSlug'] ) ) : '';
		$url_password = isset( $_POST['urlPassword'] ) ? wp_unslash( $_POST['urlPassword'] ) : '';
		$url_password = is_string( $url_password ) ? $url_password : '';
		$form_title   = isset( $_POST['formTitle'] ) ? sanitize_text_field( wp_unslash( $_POST['formTitle'] ) ) : '';
		$form_message = isset( $_POST['formMessage'] ) ? sanitize_text_field( wp_unslash( $_POST['formMessage'] ) ) : '';

		$url_slug   = trim( $url_slug );
		$pw_trimmed = trim( (string) $url_password );

		if ( '' === $url_slug ) {
			wp_send_json_error(
				array(
					'message' => __( 'URL path is required.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		if ( $url_id <= 0 && '' === $pw_trimmed ) {
			wp_send_json_error(
				array(
					'message' => __( 'Password is required for new rules.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		$existing_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table_name} WHERE url_slug = %s AND id != %d",
				$url_slug,
				$url_id
			)
		);

		if ( $existing_id ) {
			wp_send_json_error(
				array(
					'message' => __( 'That path is already protected. Use a different slug.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
				)
			);
		}

		$data = array(
			'url_slug'   => $url_slug,
			'form_title' => $form_title,
			'message'    => $form_message,
		);

		if ( ! ( $url_id > 0 && '' === $pw_trimmed ) ) {
			$data['password'] = wp_hash_password( $pw_trimmed );
		}

		if ( $url_id > 0 ) {
			$formats = array();
			foreach ( array_keys( $data ) as $column ) {
				$formats[] = '%s';
			}

			$updated = $wpdb->update(
				$table_name,
				$data,
				array( 'id' => $url_id ),
				$formats,
				array( '%d' )
			);

			if ( false === $updated ) {
				wp_send_json_error(
					array(
						'message' => __( 'Could not update the rule.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					)
				);
			}

			$message = __( 'Rule updated successfully.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN );
		} else {
			$inserted = $wpdb->insert(
				$table_name,
				$data,
				array( '%s', '%s', '%s', '%s' )
			);

			if ( ! $inserted ) {
				wp_send_json_error(
					array(
						'message' => __( 'Could not create the rule.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN ),
					)
				);
			}

			$url_id  = (int) $wpdb->insert_id;
			$message = __( 'Rule created successfully.', URL_PASSWORD_PROTECTOR_TEXT_DOMAIN );
		}

		$url = $this->get_url( $url_id );

		wp_send_json_success(
			array(
				'message' => $message,
				'url'     => $url,
				'nonce'   => wp_create_nonce( 'upp_nonce' ),
			)
		);
	}

	private function get_url($id_or_slug,$by = 'id')
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'url_protector';

		if ($by === 'id') {
			return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d",$id_or_slug));
		} else {
			return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE url_slug = %s",$id_or_slug));
		}
	}


}


//实例化插件

function URL_Password_Protector() {
	return URL_Password_Protector::instance();
}


//全局化向后兼容 

$GLOBALS['url_password_protector'] = URL_Password_Protector();