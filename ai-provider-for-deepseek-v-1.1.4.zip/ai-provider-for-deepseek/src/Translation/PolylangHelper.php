<?php
/**
 * This file contains the definition of the PolylangHelper class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\Translation;

/**
 * Utility class for interacting with the Polylang plugin.
 *
 * All public methods are safe to call regardless of whether Polylang is active;
 * they return sensible defaults (empty arrays / empty strings) when Polylang
 * functions are unavailable.
 *
 * @since 1.1.0
 */
class PolylangHelper {

	/**
	 * Check whether Polylang is currently active.
	 *
	 * @since  1.1.0
	 * @return bool
	 */
	public static function isActive(): bool {
		return function_exists( 'pll_languages_list' );
	}

	/**
	 * Return all Polylang languages as [ slug => display name ].
	 *
	 * @since  1.1.0
	 * @return array<string,string>
	 */
	public static function getLanguages(): array {
		if ( ! self::isActive() ) {
			return array();
		}

		$slugs = pll_languages_list();
		$names = pll_languages_list( array( 'fields' => 'name' ) );

		if ( ! is_array( $slugs ) || ! is_array( $names ) || count( $slugs ) !== count( $names ) ) {
			return array();
		}

		return array_combine( $slugs, $names );
	}

	/**
	 * Return the Polylang language slug assigned to a post.
	 *
	 * @since  1.1.0
	 * @param  int    $post_id WordPress post ID.
	 * @return string          Language slug, or empty string if unavailable.
	 */
	public static function getPostLanguage( int $post_id ): string {
		if ( ! self::isActive() || ! function_exists( 'pll_get_post_language' ) ) {
			return '';
		}

		$lang = pll_get_post_language( $post_id );

		return is_string( $lang ) ? $lang : '';
	}

	/**
	 * Return the human-readable name for a language slug.
	 *
	 * @since  1.1.0
	 * @param  string $slug Language slug, e.g. "fr".
	 * @return string       Display name, e.g. "French". Falls back to the slug.
	 */
	public static function getLanguageName( string $slug ): string {
		$languages = self::getLanguages();

		return isset( $languages[ $slug ] ) ? $languages[ $slug ] : $slug;
	}

	/**
	 * Create a new translated post or update the existing one, then link it
	 * to the source post in Polylang's translation table.
	 *
	 * @since  1.1.0
	 * @param  int    $source_post_id Source post ID.
	 * @param  string $target_lang    Target language slug (e.g. "fr").
	 * @param  string $title          Translated post title.
	 * @param  string $content        Translated post content (may contain HTML).
	 * @return int|\WP_Error          New or updated post ID, or WP_Error on failure.
	 */
	public static function saveTranslation( int $source_post_id, string $target_lang, string $title, string $content ) {
		$source_post = get_post( $source_post_id );

		if ( ! ( $source_post instanceof \WP_Post ) ) {
			return new \WP_Error(
				'invalid_post',
				__( 'Source post not found.', 'ai-provider-for-deepseek' )
			);
		}

		// Check for an existing translation in the target language.
		$existing_id = ( function_exists( 'pll_get_post' ) )
			? (int) pll_get_post( $source_post_id, $target_lang )
			: 0;

		if ( $existing_id > 0 ) {
			$post_id = wp_update_post(
				array(
					'ID'           => $existing_id,
					'post_title'   => $title,
					'post_content' => $content,
				),
				true
			);
		} else {
			$post_id = wp_insert_post(
				array(
					'post_title'   => $title,
					'post_content' => $content,
					'post_status'  => $source_post->post_status,
					'post_type'    => $source_post->post_type,
					'post_author'  => $source_post->post_author,
				),
				true
			);
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Assign language and wire up the translation relationship.
		if ( function_exists( 'pll_set_post_language' ) ) {
			pll_set_post_language( $post_id, $target_lang );
		}

		if ( function_exists( 'pll_get_post_translations' ) && function_exists( 'pll_save_post_translations' ) ) {
			$translations               = pll_get_post_translations( $source_post_id );
			$source_lang                = self::getPostLanguage( $source_post_id );
			if ( $source_lang ) {
				$translations[ $source_lang ] = $source_post_id;
			}
			$translations[ $target_lang ] = $post_id;
			pll_save_post_translations( $translations );
		}

		return $post_id;
	}
}
