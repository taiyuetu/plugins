<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles AJAX requests for CSV preview and batch import.
 */
class CPI_Ajax {

    public static function hooks(): void {
        add_action( 'wp_ajax_cpi_preview_csv',           [ __CLASS__, 'preview_csv' ] );
        add_action( 'wp_ajax_cpi_import_batch',          [ __CLASS__, 'import_batch' ] );
        add_action( 'wp_ajax_cpi_sync_images',           [ __CLASS__, 'sync_images' ] );
        add_action( 'wp_ajax_cpi_clear_products',                 [ __CLASS__, 'clear_products' ] );
        add_action( 'wp_ajax_cpi_get_category_options',           [ __CLASS__, 'get_category_options' ] );
        add_action( 'wp_ajax_cpi_delete_products_by_category',    [ __CLASS__, 'delete_products_by_category' ] );
        add_action( 'wp_ajax_cpi_purge_orphan_attachments',       [ __CLASS__, 'purge_orphan_attachments' ] );
        add_action( 'wp_ajax_cpi_save_settings',                  [ __CLASS__, 'save_settings' ] );
    }

    // ------------------------------------------------------------------ //
    //  Preview                                                             //
    // ------------------------------------------------------------------ //

    public static function preview_csv(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $file_path = self::get_uploaded_file();
            $parsed    = CPI_CSV_Parser::parse( $file_path );

            wp_send_json_success( [
                'total'   => count( $parsed['rows'] ),
                'errors'  => $parsed['errors'],
                'preview' => array_slice( $parsed['rows'], 0, 10 ),
                'headers' => $parsed['headers'],
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Batch Import                                                        //
    // ------------------------------------------------------------------ //

    public static function import_batch(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $duplicate = sanitize_text_field( wp_unslash( (string) ( $_POST['duplicate'] ?? 'skip' ) ) );
            if ( ! in_array( $duplicate, [ 'skip', 'update', 'duplicate' ], true ) ) {
                wp_send_json_error( [ 'message' => __( 'Invalid duplicate strategy.', 'csv-product-importer' ) ] );
            }

            $post_status = sanitize_text_field( wp_unslash( (string) ( $_POST['post_status'] ?? 'publish' ) ) );
            if ( ! in_array( $post_status, [ 'publish', 'draft', 'pending', 'private' ], true ) ) {
                wp_send_json_error( [ 'message' => __( 'Invalid post status.', 'csv-product-importer' ) ] );
            }

            $default_term_id = (int) ( $_POST['product_category'] ?? 0 );
            $offset          = max( 0, (int) ( $_POST['offset'] ?? 0 ) );
            // Accept larger batches (fewer round-trips); clamped for safety.
            $batch_size      = min( 200, max( 5, (int) ( $_POST['batch_size'] ?? 100 ) ) );

            // Give image-heavy batches room to finish.
            if ( function_exists( 'wp_raise_memory_limit' ) ) {
                wp_raise_memory_limit( 'image' );
            }
            if ( function_exists( 'set_time_limit' ) ) {
                @set_time_limit( 300 );
            }

            // The CSV was persisted server-side during Preview; only its path
            // lives in a transient and the file is re-parsed per batch. (Caching
            // the whole rows array in a transient would bloat wp_options for
            // large files.)
            $file_path = self::get_uploaded_file();
            $parsed    = CPI_CSV_Parser::parse( $file_path );

            if ( ! empty( $parsed['errors'] ) && empty( $parsed['rows'] ) ) {
                wp_send_json_error( [ 'message' => implode( ' | ', $parsed['errors'] ) ] );
            }

            $rows  = $parsed['rows'];
            $total = count( $rows );

            $stats = CPI_Importer::import_batch(
                $rows,
                $duplicate,
                $post_status,
                $offset,
                $batch_size,
                $default_term_id
            );
            $done = min( $offset + $batch_size, $total );

            if ( $done >= $total ) {
                self::cleanup_finished_import( $file_path );
            }

            wp_send_json_success( [
                'stats'    => $stats,
                'total'    => $total,
                'done'     => $done,
                'finished' => $done >= $total,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Target settings (post type / taxonomy)                              //
    // ------------------------------------------------------------------ //

    /**
     * Persist the target post type, taxonomy and category CSV column.
     */
    public static function save_settings(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $saved = CPI_Config::save( [
            'post_type'       => sanitize_text_field( wp_unslash( (string) ( $_POST['post_type'] ?? '' ) ) ),
            'taxonomy'        => sanitize_text_field( wp_unslash( (string) ( $_POST['taxonomy'] ?? '' ) ) ),
            'taxonomy_column' => sanitize_text_field( wp_unslash( (string) ( $_POST['taxonomy_column'] ?? '' ) ) ),
        ] );

        wp_send_json_success( [
            'message'  => __( 'Settings saved. Reloading…', 'csv-product-importer' ),
            'settings' => $saved,
        ] );
    }

    // ------------------------------------------------------------------ //
    //  Category options (Polylang language filter)                         //
    // ------------------------------------------------------------------ //

    public static function get_category_options(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $options = CPI_Config::get_taxonomy_term_options();

        wp_send_json_success( [ 'options' => $options ] );
    }

    // ------------------------------------------------------------------ //
    //  Clear Products                                                      //
    // ------------------------------------------------------------------ //

    public static function clear_products(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $batch_size = max( 1, min( 100, (int) ( $_POST['batch_size'] ?? 50 ) ) );
        $last_id    = max( 0, (int) ( $_POST['last_id'] ?? 0 ) );

        try {
            global $wpdb;

            $post_type = CPI_Config::post_type();

            // Safety: never mass-delete core content types. The detected default
            // falls back to 'post' when no product post type exists — without
            // this guard, one click would wipe the blog.
            $allowed_core = (array) apply_filters( 'cpi_clear_products_allowed_core_types', [] );
            if ( in_array( $post_type, [ 'post', 'page', 'attachment' ], true ) && ! in_array( $post_type, $allowed_core, true ) ) {
                wp_send_json_error( [
                    'message' => sprintf(
                        /* translators: %s: post type slug */
                        __( 'Refusing to delete all items of the "%s" post type — it is a core content type. Set the import target to a dedicated product post type first.', 'csv-product-importer' ),
                        $post_type
                    ),
                ] );
            }

            $count_key = 'cpi_clear_total_' . get_current_user_id();

            if ( 0 === $last_id ) {
                delete_transient( $count_key );
            }

            $total = (int) get_transient( $count_key );

            if ( ! $total && 0 === $last_id ) {
                $total = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s",
                    $post_type
                ) );
                set_transient( $count_key, $total, HOUR_IN_SECONDS );
            }

            $ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_type = %s
                   AND ID > %d
                 ORDER BY ID ASC
                 LIMIT %d",
                $post_type,
                $last_id,
                $batch_size
            ) );
            $ids = array_map( 'intval', $ids );

            $deleted = 0;
            $new_last = $last_id;

            if ( $ids ) {
                self::begin_bulk_delete();

                // One query for all thumbnail/gallery references in this batch.
                $attachment_map = self::preload_attachment_ids( $ids );

                foreach ( $ids as $id ) {
                    if ( self::delete_product_with_images( $id, $attachment_map[ $id ] ?? null ) ) {
                        $deleted++;
                    }
                }

                self::end_bulk_delete();

                $new_last = max( $ids );
            }

            $finished = count( $ids ) < $batch_size;

            if ( $finished ) {
                delete_transient( $count_key );
            }

            wp_send_json_success( [
                'deleted'  => $deleted,
                'total'    => $total,
                'last_id'  => $new_last,
                'finished' => $finished,
            ] );

        } catch ( \Throwable $e ) {
            self::end_bulk_delete();
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    /**
     * Delete products assigned to a product_category term (batched).
     */
    public static function delete_products_by_category(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        if ( ! CPI_Config::taxonomy_enabled() ) {
            wp_send_json_error( [ 'message' => __( 'Product category taxonomy is not available.', 'csv-product-importer' ) ] );
        }

        $term_id    = (int) ( $_POST['term_id'] ?? 0 );
        $batch_size = max( 1, min( 100, (int) ( $_POST['batch_size'] ?? 50 ) ) );

        if ( $term_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Please select a product category.', 'csv-product-importer' ) ] );
        }

        $term = get_term( $term_id, CPI_Config::taxonomy() );
        if ( ! $term || is_wp_error( $term ) ) {
            wp_send_json_error( [ 'message' => __( 'Category not found.', 'csv-product-importer' ) ] );
        }

        try {
            $tax_query = [ [
                'taxonomy'         => CPI_Config::taxonomy(),
                'field'            => 'term_id',
                'terms'            => $term_id,
                'include_children' => true,
            ] ];

            $count_key = 'cpi_delete_cat_total_' . get_current_user_id() . '_' . $term_id;

            if ( ! empty( $_POST['reset_total'] ) ) {
                delete_transient( $count_key );
            }

            $total = (int) get_transient( $count_key );

            if ( ! $total ) {
                $count_query = new WP_Query( self::products_in_category_query_args(
                    $tax_query,
                    1,
                    false
                ) );
                $total = (int) $count_query->found_posts;
                set_transient( $count_key, $total, HOUR_IN_SECONDS );
            }

            $query_args = self::products_in_category_query_args( $tax_query, $batch_size, true );
            $query      = new WP_Query( $query_args );

            $deleted = 0;

            self::begin_bulk_delete();

            $attachment_map = self::preload_attachment_ids( array_map( 'intval', $query->posts ) );

            foreach ( $query->posts as $post_id ) {
                $post_id = (int) $post_id;
                if ( self::delete_product_with_images( $post_id, $attachment_map[ $post_id ] ?? null ) ) {
                    $deleted++;
                }
            }

            self::end_bulk_delete();

            $remaining = max( 0, $total - $deleted );
            if ( $remaining > 0 && $deleted > 0 ) {
                set_transient( $count_key, $remaining, HOUR_IN_SECONDS );
            } else {
                delete_transient( $count_key );
            }

            $finished = $deleted < $batch_size || $remaining <= 0;

            wp_send_json_success( [
                'deleted'   => $deleted,
                'total'     => $total,
                'remaining' => $finished ? 0 : $remaining,
                'finished'  => $finished,
                'term_name' => $term->name,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    /**
     * WP_Query args for products in a category.
     *
     * @param array $tax_query
     * @param int   $posts_per_page
     * @param bool  $no_found_rows
     * @return array<string, mixed>
     */
    private static function products_in_category_query_args(
        array $tax_query,
        int $posts_per_page,
        bool $no_found_rows
    ): array {
        return [
            'post_type'      => CPI_Config::post_type(),
            'post_status'    => 'any',
            'posts_per_page' => $posts_per_page,
            'fields'         => 'ids',
            'no_found_rows'  => $no_found_rows,
            'tax_query'      => $tax_query,
        ];
    }

    /**
     * Purge unattached image attachments whose physical file is missing from disk.
     *
     * Only attachment posts with post_parent = 0 (unattached to any other post) and a
     * missing file are removed. Attachments whose file still exists are left untouched.
     * Runs in cursor-based batches so it is safe for large media libraries.
     */
    public static function purge_orphan_attachments(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $batch_size = max( 1, min( 200, (int) ( $_POST['batch_size'] ?? 100 ) ) );
        $last_id    = max( 0, (int) ( $_POST['last_id']    ?? 0 ) );

        try {
            global $wpdb;

            $count_key = 'cpi_orphan_total_' . get_current_user_id();

            if ( 0 === $last_id ) {
                delete_transient( $count_key );
            }

            $total = (int) get_transient( $count_key );

            if ( ! $total && 0 === $last_id ) {
                $total = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts}
                     WHERE post_type   = 'attachment'
                       AND post_parent = 0
                       AND post_mime_type LIKE %s",
                    'image/%'
                ) );
                set_transient( $count_key, max( 1, $total ), HOUR_IN_SECONDS );
            }

            $ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_type   = 'attachment'
                   AND post_parent = 0
                   AND post_mime_type LIKE %s
                   AND ID > %d
                 ORDER BY ID ASC
                 LIMIT %d",
                'image/%',
                $last_id,
                $batch_size
            ) );

            self::begin_bulk_delete();

            $deleted  = 0;
            $skipped  = 0;
            $new_last = $last_id;

            foreach ( $ids as $attach_id ) {
                $attach_id = (int) $attach_id;
                $new_last  = $attach_id;

                $file = get_attached_file( $attach_id );
                if ( ! $file || ! file_exists( $file ) ) {
                    wp_delete_attachment( $attach_id, true );
                    $deleted++;
                } else {
                    $skipped++;
                }
            }

            self::end_bulk_delete();

            $finished = count( $ids ) < $batch_size;

            if ( $finished ) {
                delete_transient( $count_key );
            }

            wp_send_json_success( [
                'deleted'  => $deleted,
                'skipped'  => $skipped,
                'total'    => $total,
                'last_id'  => $new_last,
                'finished' => $finished,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    /**
     * Delete a product post and all of its associated media attachments.
     *
     * Removes the featured image (_thumbnail_id) and every image in the
     * product_gallery meta before permanently deleting the post, so that
     * no orphaned attachments are left in the media library.
     *
     * @param int        $post_id              Product post ID.
     * @param array|null $preloaded_attachments Attachment IDs preloaded via preload_attachment_ids() (optional).
     */
    private static function delete_product_with_images( int $post_id, ?array $preloaded_attachments = null ): bool {
        if ( null === $preloaded_attachments ) {
            $attachment_ids = [];

            $thumbnail_id = (int) get_post_meta( $post_id, '_thumbnail_id', true );
            if ( $thumbnail_id > 0 ) {
                $attachment_ids[] = $thumbnail_id;
            }

            $gallery_raw = (string) get_post_meta( $post_id, CPI_Polylang_Sync::GALLERY_KEY, true );
            if ( '' !== $gallery_raw ) {
                foreach ( explode( ',', $gallery_raw ) as $gid ) {
                    $gid = (int) trim( $gid );
                    if ( $gid > 0 ) {
                        $attachment_ids[] = $gid;
                    }
                }
            }
        } else {
            $attachment_ids = $preloaded_attachments;
        }

        foreach ( array_unique( $attachment_ids ) as $attach_id ) {
            wp_delete_attachment( $attach_id, true );
        }

        return (bool) wp_delete_post( $post_id, true );
    }

    /**
     * Preload thumbnail + gallery attachment IDs for a batch of products in one query.
     *
     * @param int[] $post_ids Product post IDs.
     * @return array<int, int[]> Map of post ID => attachment IDs.
     */
    private static function preload_attachment_ids( array $post_ids ): array {
        global $wpdb;

        if ( empty( $post_ids ) ) {
            return [];
        }

        $gallery_key = CPI_Polylang_Sync::GALLERY_KEY;
        $placeholders = implode( ',', array_fill( 0, count( $post_ids ), '%d' ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_id, meta_key, meta_value
             FROM {$wpdb->postmeta}
             WHERE meta_key IN ( '_thumbnail_id', %s )
               AND post_id IN ( {$placeholders} )",
            array_merge( [ $gallery_key ], $post_ids )
        ) );

        $map = [];

        foreach ( $rows as $row ) {
            $pid = (int) $row->post_id;
            $map[ $pid ] ??= [];

            if ( '_thumbnail_id' === $row->meta_key ) {
                $map[ $pid ][] = (int) $row->meta_value;
            } else {
                foreach ( explode( ',', (string) $row->meta_value ) as $gid ) {
                    $gid = (int) trim( $gid );
                    if ( $gid > 0 ) {
                        $map[ $pid ][] = $gid;
                    }
                }
            }
        }

        return $map;
    }

    /**
     * Prepare WordPress for a mass-delete batch.
     *
     * Defers term/comment recounting (otherwise every deleted post/attachment
     * triggers an expensive recount) and suspends cache writes.
     */
    private static function begin_bulk_delete(): void {
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 300 );
        }

        wp_defer_term_counting( true );
        wp_defer_comment_counting( true );
        wp_suspend_cache_addition( true );
    }

    /**
     * Restore normal WordPress behaviour after a mass-delete batch.
     *
     * Safe to call even when begin_bulk_delete() was never invoked.
     */
    private static function end_bulk_delete(): void {
        wp_suspend_cache_addition( false );
        wp_defer_comment_counting( false );
        wp_defer_term_counting( false );
    }

    public static function sync_images(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $offset     = max( 0, (int) ( $_POST['offset'] ?? 0 ) );
            $batch_size = max( 1, min( 50, (int) ( $_POST['batch_size'] ?? 20 ) ) );

            if ( function_exists( 'wp_raise_memory_limit' ) ) {
                wp_raise_memory_limit( 'image' );
            }
            if ( function_exists( 'set_time_limit' ) ) {
                @set_time_limit( 300 );
            }

            $stats = CPI_Importer::sync_all_product_images( $offset, $batch_size );
            wp_send_json_success( $stats );
        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    private static function verify_nonce( string $action ): void {
        if ( ! check_ajax_referer( $action, 'security', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed. Please refresh the page and try again.', 'csv-product-importer' ) ], 403 );
            exit;
        }
    }

    private static function check_capability(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'csv-product-importer' ) ], 403 );
            exit;
        }
    }

    private static function get_uploaded_file(): string {
        // Use the persisted file for subsequent batch calls
        if ( empty( $_FILES['csv_file']['tmp_name'] ) ) {
            $saved = get_transient( 'cpi_upload_' . get_current_user_id() );
            if ( $saved && is_string( $saved ) && is_file( $saved ) ) {
                return $saved;
            }
            wp_send_json_error( [ 'message' => __( 'No CSV file provided. Please re-upload your file.', 'csv-product-importer' ) ] );
            exit;
        }

        $file = $_FILES['csv_file'];

        // Check for upload errors
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE   => __( 'File exceeds the upload_max_filesize directive in php.ini.', 'csv-product-importer' ),
                UPLOAD_ERR_FORM_SIZE  => __( 'File exceeds the MAX_FILE_SIZE directive in the HTML form.', 'csv-product-importer' ),
                UPLOAD_ERR_PARTIAL    => __( 'File was only partially uploaded.', 'csv-product-importer' ),
                UPLOAD_ERR_NO_FILE    => __( 'No file was uploaded.', 'csv-product-importer' ),
                UPLOAD_ERR_NO_TMP_DIR => __( 'Missing temporary folder.', 'csv-product-importer' ),
                UPLOAD_ERR_CANT_WRITE => __( 'Failed to write file to disk.', 'csv-product-importer' ),
                UPLOAD_ERR_EXTENSION  => __( 'A PHP extension stopped the file upload.', 'csv-product-importer' ),
            ];
            $msg = $upload_errors[ $file['error'] ] ?? sprintf( /* translators: %s: upload error code */ __( 'Unknown upload error (code %s).', 'csv-product-importer' ), $file['error'] );
            wp_send_json_error( [ 'message' => $msg ] );
            exit;
        }

        $ext      = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        $base_dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'cpi-imports/';
        // CSVs live in a web-protected subdirectory under an unguessable random
        // name — the uploads folder is public and product data (pricing, OEM
        // numbers…) must not be downloadable by URL.
        $dest_dir = $base_dir . 'csv/';

        // A single ZIP archive holding BOTH the CSV and an images folder.
        if ( 'zip' === $ext ) {
            return self::extract_zip_and_find_csv( $file['tmp_name'], $base_dir );
        }

        if ( 'csv' !== $ext ) {
            wp_send_json_error( [ 'message' => __( 'Only .csv or .zip files are allowed. Uploaded:', 'csv-product-importer' ) . ' ' . esc_html( $file['name'] ) ] );
            exit;
        }

        // Move to a persistent location so batch calls can reuse it
        if ( ! wp_mkdir_p( $dest_dir ) ) {
            wp_send_json_error( [ 'message' => __( 'Could not create upload directory:', 'csv-product-importer' ) . ' ' . $dest_dir ] );
            exit;
        }
        self::protect_dir( $dest_dir );
        self::delete_stored_csv();

        $dest = $dest_dir . self::random_csv_name( (string) $file['name'] );

        if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) {
            wp_send_json_error( [ 'message' => __( 'Failed to move uploaded file to:', 'csv-product-importer' ) . ' ' . $dest . '. ' . __( 'Check folder permissions.', 'csv-product-importer' ) ] );
            exit;
        }

        // Images uploaded at the same time (a separate ZIP archive and/or loose image files)
        $images_found = self::handle_images_upload( $base_dir );

        set_transient( 'cpi_upload_' . get_current_user_id(), $dest, HOUR_IN_SECONDS );
        set_transient( 'cpi_upload_images_' . get_current_user_id(), $images_found, HOUR_IN_SECONDS );

        return $dest;
    }

    /**
     * Remove the persisted upload (file + transients) once an import completes.
     */
    private static function cleanup_finished_import( string $file_path ): void {
        delete_transient( 'cpi_upload_' . get_current_user_id() );
        delete_transient( 'cpi_upload_images_' . get_current_user_id() );

        if ( ! self::is_managed_upload_path( $file_path ) ) {
            return;
        }

        $real = wp_normalize_path( (string) realpath( $file_path ) );
        if ( '' !== $real && is_file( $real ) ) {
            wp_delete_file( $real );
        }
    }

    /**
     * Whether a path points inside this plugin's managed upload directory
     * (wp-content/uploads/cpi-imports/) — only files there are ever deleted.
     */
    private static function is_managed_upload_path( string $path ): bool {
        $base = wp_normalize_path( trailingslashit( wp_upload_dir()['basedir'] ) . 'cpi-imports/' );
        $real = wp_normalize_path( (string) realpath( $path ) );

        return '' !== $real && str_starts_with( $real, $base );
    }

    /**
     * Delete a previously persisted CSV (called before storing a new one so
     * stale product files don't accumulate in uploads forever).
     */
    private static function delete_stored_csv(): void {
        $saved = get_transient( 'cpi_upload_' . get_current_user_id() );
        if ( $saved && is_string( $saved ) && self::is_managed_upload_path( $saved ) && is_file( $saved ) ) {
            wp_delete_file( $saved );
        }
    }

    /**
     * Storage name for a persisted CSV: sanitized original name plus a random
     * suffix so the file cannot be guessed by URL on servers where .htaccess
     * is ignored (nginx etc.).
     */
    private static function random_csv_name( string $original ): string {
        $info = pathinfo( sanitize_file_name( $original ) );
        $ext  = isset( $info['extension'] ) && '' !== $info['extension'] ? '.' . strtolower( $info['extension'] ) : '.csv';
        $name = sanitize_key( $info['filename'] ?? '' );

        return ( '' !== $name ? $name : 'import' ) . '-' . wp_generate_password( 12, false, false ) . $ext;
    }

    /**
     * Best-effort protection for the CSV storage directory: deny direct HTTP
     * access (Apache) and drop an index.php so directory listings never render.
     */
    private static function protect_dir( string $dir ): void {
        if ( ! is_dir( $dir ) ) {
            return;
        }

        $htaccess = trailingslashit( $dir ) . '.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            @file_put_contents(
                $htaccess,
                "Require all denied\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n"
            );
        }

        $index = trailingslashit( $dir ) . 'index.php';
        if ( ! file_exists( $index ) ) {
            @file_put_contents( $index, "<?php\n// Silence is golden.\n" );
        }
    }

    /**
     * Extract a ZIP archive and locate the CSV file inside.
     *
     * Expected ZIP layout (one of):
     *
     *   data.csv
     *   images/
     *     product-001.jpg
     *     ...
     *
     *   data/
     *     data.csv
     *     images/
     *       product-001.jpg
     *
     * Produces (flat layout so existing code works unchanged):
     *
     *   cpi-imports/csv/data-<random>.csv   (web-protected)
     *   cpi-imports/images/product-001.jpg
     */
    private static function extract_zip_and_find_csv( string $zip_path, string $dest_dir ): string {
        // Use a unique temp directory
        $tmp_root = sys_get_temp_dir() . '/cpi-extract-' . uniqid();
        wp_mkdir_p( $tmp_root );

        // Extract using best available method
        $extracted = self::extract_zip_to( $zip_path, $tmp_root );

        if ( ! $extracted ) {
            self::rrmdir( $tmp_root );
            wp_send_json_error( [ 'message' => __( 'Failed to extract ZIP file. Ensure it is a valid archive.', 'csv-product-importer' ) ] );
            exit;
        }

        // Destination paths (flat layout). CSVs live in the web-protected csv/
        // subdirectory under a random name; images stay publicly readable.
        $csv_dest_dir = $dest_dir . 'csv/';               // cpi-imports/csv/
        $images_dest  = $dest_dir . 'images/';            // cpi-imports/images/
        wp_mkdir_p( $csv_dest_dir );
        wp_mkdir_p( $images_dest );
        self::protect_dir( $csv_dest_dir );
        self::delete_stored_csv();

        // Collect all entries from the extracted tree
        $all_files = array();
        if ( is_dir( $tmp_root ) ) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $tmp_root, RecursiveDirectoryIterator::SKIP_DOTS ),
                RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ( $iterator as $entry ) {
                $rel = wp_normalize_path( str_replace( wp_normalize_path( $tmp_root ), '', $entry->getPathname() ) );
                $all_files[] = array(
                    'type' => $entry->isDir() ? 'dir' : 'file',
                    'rel'  => $rel,
                    'path' => $entry->getPathname(),
                );
            }
        }

        // --- Phase 1: Find & copy the CSV ---
        $found_csv = null;

        // Look for .csv files anywhere in the tree
        $csv_entries = array_filter(
            $all_files,
            static fn( $e ) => 'file' === $e['type'] && 'csv' === strtolower( pathinfo( $e['rel'], PATHINFO_EXTENSION ) )
        );

        // Prefer top-level CSV (shortest rel path), fallback to deepest
        usort(
            $csv_entries,
            static fn( $a, $b ) => strlen( $a['rel'] ) <=> strlen( $b['rel'] )
        );

        if ( ! empty( $csv_entries ) ) {
            $chosen = reset( $csv_entries );
            $safe_name = self::random_csv_name( $chosen['rel'] );
            $dst       = wp_normalize_path( trailingslashit( $csv_dest_dir ) . $safe_name );
            wp_mkdir_p( dirname( $dst ) );
            if ( copy( $chosen['path'], $dst ) ) {
                $found_csv = $dst;
            }
        }

        // --- Phase 2: Copy images into cpi-imports/images/ ---
        // SVG is intentionally excluded (scripts inside SVG are served
        // unfiltered — a stored-XSS risk).
        $images_found  = 0;
        $image_exts    = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif' ];
        $image_entries = [];

        // Preferred: files living inside an "images" folder
        foreach ( $all_files as $entry ) {
            if ( 'file' !== $entry['type'] ) {
                continue;
            }
            if ( 'images' === strtolower( basename( dirname( $entry['rel'] ) ) ) ) {
                $image_entries[] = $entry;
            }
        }

        // Fallback: no "images" folder — take every image file in the archive
        if ( empty( $image_entries ) ) {
            foreach ( $all_files as $entry ) {
                if ( 'file' !== $entry['type'] ) {
                    continue;
                }
                if ( in_array( strtolower( pathinfo( $entry['rel'], PATHINFO_EXTENSION ) ), $image_exts, true ) ) {
                    $image_entries[] = $entry;
                }
            }
        }

        foreach ( $image_entries as $entry ) {
            $target = $images_dest . self::safe_basename( $entry['rel'] );
            if ( copy( $entry['path'], $target ) ) {
                $images_found++;
            }
        }

        // Cleanup
        self::rrmdir( $tmp_root );

        if ( ! $found_csv || ! file_exists( $found_csv ) ) {
            wp_send_json_error( [ 'message' => __( 'No CSV file found inside the ZIP archive.', 'csv-product-importer' ) ] );
            exit;
        }

        // Store CSV path AND number of images in transient for later use
        set_transient( 'cpi_upload_' . get_current_user_id(), $found_csv, HOUR_IN_SECONDS );
        set_transient( 'cpi_upload_images_' . get_current_user_id(), $images_found, HOUR_IN_SECONDS );

        return $found_csv;
    }

    /**
     * Recursively remove a directory.
     */
    private static function rrmdir( string $dir ): void {
        if ( ! is_dir( $dir ) ) {
            return;
        }
        $items = scandir( $dir );
        if ( false === $items ) {
            return;
        }
        foreach ( $items as $item ) {
            if ( '.' === $item || '..' === $item ) {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            is_dir( $path ) ? self::rrmdir( $path ) : unlink( $path );
        }
        @rmdir( $dir );
    }

    /**
     * Get the count of images included in the last upload.
     */
    public static function get_upload_image_count(): int {
        return max( 0, (int) get_transient( 'cpi_upload_images_' . get_current_user_id() ) );
    }

    /**
     * Copy every uploaded image (a separate ZIP archive and/or loose image
     * files) into cpi-imports/images/ so the importer can pick them up.
     *
     * @return int Number of image files written.
     */
    private static function handle_images_upload( string $dest_dir ): int {
        $images_dest = trailingslashit( $dest_dir ) . 'images/';
        if ( ! wp_mkdir_p( $images_dest ) ) {
            return 0;
        }

        $count      = 0;
        $image_exts = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif' ];

        // 1) A ZIP archive containing the images folder
        if ( ! empty( $_FILES['images_zip']['tmp_name'] )
            && UPLOAD_ERR_OK === (int) ( $_FILES['images_zip']['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
            $count += self::extract_images_zip( (string) $_FILES['images_zip']['tmp_name'], $images_dest );
        }

        // 2) Loose image files selected alongside the CSV
        if ( ! empty( $_FILES['images_files']['tmp_name'] ) ) {
            $names  = (array) $_FILES['images_files']['name'];
            $tmps   = (array) $_FILES['images_files']['tmp_name'];
            $errors = (array) $_FILES['images_files']['error'];

            foreach ( $tmps as $i => $tmp ) {
                if ( UPLOAD_ERR_OK !== (int) ( $errors[ $i ] ?? UPLOAD_ERR_NO_FILE ) ) {
                    continue;
                }
                $original = (string) ( $names[ $i ] ?? '' );
                if ( ! in_array( strtolower( pathinfo( $original, PATHINFO_EXTENSION ) ), $image_exts, true ) ) {
                    continue;
                }
                $target = $images_dest . self::safe_basename( $original );
                if ( @move_uploaded_file( (string) $tmp, $target ) ) {
                    $count++;
                }
            }
        }

        return $count;
    }

    /**
     * Extract every image from a ZIP archive into the images folder,
     * flattening nested folders. Works whether or not the archive
     * contains an "images" directory.
     *
     * @return int Number of images extracted.
     */
    private static function extract_images_zip( string $zip_path, string $images_dest ): int {
        $tmp_root = sys_get_temp_dir() . '/cpi-images-' . uniqid();
        wp_mkdir_p( $tmp_root );

        if ( ! self::extract_zip_to( $zip_path, $tmp_root ) ) {
            self::rrmdir( $tmp_root );
            return 0;
        }

        $count      = 0;
        $image_exts = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif' ];

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $tmp_root, RecursiveDirectoryIterator::SKIP_DOTS )
        );

        foreach ( $iterator as $entry ) {
            if ( ! $entry->isFile() ) {
                continue;
            }
            if ( ! in_array( strtolower( $entry->getExtension() ), $image_exts, true ) ) {
                continue;
            }
            if ( copy( $entry->getPathname(), $images_dest . self::safe_basename( $entry->getFilename() ) ) ) {
                $count++;
            }
        }

        self::rrmdir( $tmp_root );
        return $count;
    }

    /**
     * Extract a ZIP file into a target directory, using ZipArchive when
     * available and falling back to the system unzip binary.
     *
     * Both paths refuse archives containing entries with path-traversal
     * (`../`), absolute Unix paths, or Windows drive prefixes (Zip Slip).
     */
    private static function extract_zip_to( string $zip_path, string $target_dir ): bool {
        if ( class_exists( 'ZipArchive' ) ) {
            $zip = new ZipArchive();
            if ( true === $zip->open( $zip_path ) ) {
                $safe = self::zip_entries_are_safe( static fn(): array => self::ziparchive_entry_names( $zip ) );

                if ( $safe ) {
                    $zip->extractTo( $target_dir );
                }
                $zip->close();

                if ( $safe ) {
                    return true;
                }
            }
        }

        $real = realpath( $zip_path );
        if ( $real && function_exists( 'exec' ) ) {
            // List entries first and refuse anything that escapes the target
            // directory before handing the archive to the system binary.
            $listing = [];
            $ret     = 1;
            @exec( 'unzip -Z1 ' . escapeshellarg( $real ) . ' 2>/dev/null', $listing, $ret );

            if ( 0 === $ret && ! self::zip_entries_are_safe( static fn(): array => $listing ) ) {
                return false;
            }

            $output = [];
            $ret    = 1;
            @exec( 'unzip -qq -o ' . escapeshellarg( $real ) . ' -d ' . escapeshellarg( $target_dir ) . ' 2>&1', $output, $ret );
            if ( 0 === $ret ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Entry names of an open ZipArchive instance.
     *
     * @return string[]
     */
    private static function ziparchive_entry_names( ZipArchive $zip ): array {
        $names = [];
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $names[] = (string) $zip->getNameIndex( $i );
        }
        return $names;
    }

    /**
     * Whether every entry name in a ZIP is safe to extract: no `../`
     * traversal, no absolute paths, no Windows drive prefixes.
     *
     * @param callable():string[] $entry_names
     */
    private static function zip_entries_are_safe( callable $entry_names ): bool {
        foreach ( $entry_names() as $entry ) {
            if ( str_contains( $entry, '../' ) || str_starts_with( $entry, '/' ) || preg_match( '#^[A-Za-z]:\\\\#', $entry ) ) {
                return false;
            }
        }
        return true;
    }

    /**
     * Path-safe basename that preserves characters WordPress normally strips
     * from filenames — parentheses in particular, because images are matched
     * to products by names like "TQB3-0001(1).jpg".
     */
    private static function safe_basename( string $name ): string {
        $name = wp_basename( str_replace( '\\', '/', $name ) );
        $name = preg_replace( '/[\x00-\x1F\x7F]/', '', (string) $name );
        $name = str_replace( [ '/', '\\', ':', '*', '?', '"', '<', '>', '|' ], '', (string) $name );
        $name = trim( (string) $name );

        return '' !== $name ? $name : 'image-' . wp_generate_password( 8, false, false );
    }
}
