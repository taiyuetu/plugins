<?php
defined( 'ABSPATH' ) || exit;

/**
 * Central configuration for CSV Product Importer Pro.
 *
 *  DEFAULT_POST_TYPE  – fallback target post type (admin-overridable)
 *  DESCRIPTION        – subtitle shown in the admin header
 *  TITLE_FORMULA      – how the post title is assembled from column values
 *  UNIQUE_KEY         – column used for duplicate detection
 *  IMAGE_KEY          – column whose value is matched against image filenames
 *  DEFAULT_TAXONOMY   – fallback taxonomy slug for category assignment
 *  DEFAULT_TAXONOMY_COLUMN – fallback CSV column with term slug, name, or ID
 *  COLUMN_LABELS      – human-readable preview table column headings
 *
 * Post type, taxonomy and the category CSV column are editable in the admin
 * "Import target" panel; the constants above are only the fallback defaults.
 *
 * All CSV column headers are automatically saved as post meta fields
 * with the same (lowercased) name. No hardcoded meta map required.
 */
class CPI_Config {

    /**
     * Default WordPress post type to import into.
     * Overridable at runtime from the plugin's Target settings panel
     * (stored in the cpi_settings option).
     */
    public const DEFAULT_POST_TYPE = 'product';

    /** Subtitle shown in the admin page header. */
    public const DESCRIPTION = 'Import products from CSV — auto title, dynamic meta fields & image matching';

    /**
     * Title assembly formula.
     *
     *  prefix    – columns joined with a space, placed first.
     *  connector – word inserted between prefix and suffix (e.g. "for").
     *              Set to '' to omit.
     *  suffix    – columns joined with a space, placed last.
     *              Set to [] to omit.
     *
     * Result: "cross_ref type for car_brand car_application"
     */
    public const TITLE_FORMULA = [
        'prefix'    => [ 'cross_ref', 'type' ],
        'connector' => 'for',
        'suffix'    => [ 'car_brand', 'car_application' ],
    ];

    /**
     * The meta key (= CSV column name) used to identify duplicate posts.
     */
    public const UNIQUE_KEY = 'product_mpn';

    /**
     * Column whose value is matched against image filenames in the
     * images folder for automatic thumbnail / gallery assignment.
     */
    public const IMAGE_KEY = 'product_mpn';

    /**
     * Default custom taxonomy used for category assignment.
     * Overridable at runtime from the Target settings panel.
     */
    public const DEFAULT_TAXONOMY = 'product_category';

    /**
     * Default CSV column for per-row category assignment.
     * Value: term slug, name, or numeric ID. Multiple terms: comma, pipe, or semicolon.
     * Overridable at runtime from the Target settings panel.
     */
    public const DEFAULT_TAXONOMY_COLUMN = 'product_category';

    /**
     * Alternate CSV column names accepted for per-row category assignment.
     * Checked when the configured taxonomy column is absent from the file.
     */
    public const TAXONOMY_COLUMN_ALIASES = [ 'product_cat' ];

    // -------------------------------------------------------------------------
    //  Runtime settings — editable from the admin "Import target" panel.
    // -------------------------------------------------------------------------

    /** wp_options key that stores the admin-editable settings. */
    public const OPTION_KEY = 'cpi_settings';

    /** Resolved settings cache. */
    private static ?array $settings = null;

    /**
     * Effective settings, merged over the auto-detected defaults.
     *
     * @return array{post_type:string, taxonomy:string, taxonomy_column:string}
     */
    public static function settings(): array {
        if ( null === self::$settings ) {
            $saved    = get_option( self::OPTION_KEY, [] );
            $defaults = self::detect_defaults();

            self::$settings = wp_parse_args( is_array( $saved ) ? $saved : [], [
                'post_type'       => $defaults['post_type'],
                'taxonomy'        => $defaults['taxonomy'],
                'taxonomy_column' => $defaults['taxonomy_column'],
            ] );
        }

        return self::$settings;
    }

    /**
     * Defaults used until (and for any field never saved in) the settings panel.
     * Falls back gracefully when the configured post type / taxonomy is missing,
     * so the plugin also works on WooCommerce or plain-post installs.
     *
     * @return array{post_type:string, taxonomy:string, taxonomy_column:string}
     */
    public static function detect_defaults(): array {
        $post_type = self::DEFAULT_POST_TYPE;
        if ( ! post_type_exists( $post_type ) ) {
            $public    = get_post_types( [ 'public' => true ], 'names' );
            $post_type = isset( $public['post'] ) ? 'post' : (string) reset( $public );
        }

        $taxonomy = self::DEFAULT_TAXONOMY;
        if ( ! taxonomy_exists( $taxonomy ) ) {
            foreach ( [ 'product_cat', 'product_category', 'category' ] as $candidate ) {
                if ( taxonomy_exists( $candidate ) ) {
                    $taxonomy = $candidate;
                    break;
                }
            }
        }

        return [
            'post_type'       => $post_type,
            'taxonomy'        => $taxonomy,
            'taxonomy_column' => self::DEFAULT_TAXONOMY_COLUMN,
        ];
    }

    /** Post type that imported rows are written to. */
    public static function post_type(): string {
        $value = (string) self::settings()['post_type'];

        return post_type_exists( $value ) ? $value : self::DEFAULT_POST_TYPE;
    }

    /** Taxonomy used for category assignment ('' disables assignment). */
    public static function taxonomy(): string {
        return (string) self::settings()['taxonomy'];
    }

    /** CSV column holding per-row category values ('' disables per-row assignment). */
    public static function taxonomy_column(): string {
        return (string) self::settings()['taxonomy_column'];
    }

    /**
     * Persist settings submitted from the admin panel.
     *
     * Values are sanitised; an unknown post type or taxonomy keeps the currently
     * effective value so a bad request cannot break the importer.
     *
     * @param  array{post_type?:string, taxonomy?:string, taxonomy_column?:string} $raw
     * @return array{post_type:string, taxonomy:string, taxonomy_column:string}
     */
    public static function save( array $raw ): array {
        $post_type = sanitize_key( (string) ( $raw['post_type'] ?? '' ) );
        if ( '' === $post_type || ! post_type_exists( $post_type ) ) {
            $post_type = self::post_type();
        }

        $taxonomy = sanitize_key( (string) ( $raw['taxonomy'] ?? '' ) );
        if ( '' !== $taxonomy && ! taxonomy_exists( $taxonomy ) ) {
            $taxonomy = self::taxonomy();
        }

        $settings = [
            'post_type'       => $post_type,
            'taxonomy'        => $taxonomy,
            'taxonomy_column' => sanitize_key( (string) ( $raw['taxonomy_column'] ?? '' ) ),
        ];

        self::$settings = $settings;
        update_option( self::OPTION_KEY, $settings );

        return $settings;
    }

    /**
     * Drop the saved overrides and fall back to the detected defaults.
     *
     * @return array{post_type:string, taxonomy:string, taxonomy_column:string}
     */
    public static function reset(): array {
        self::$settings = null;
        delete_option( self::OPTION_KEY );

        return self::settings();
    }

    /**
     * Public post types offered in the settings panel.
     *
     * @return array<int, array{slug:string, label:string}>
     */
    public static function available_post_types(): array {
        $types = get_post_types( [ 'public' => true ], 'objects' );
        unset( $types['attachment'] );

        $out = [];
        foreach ( $types as $slug => $object ) {
            $label = trim( (string) $object->labels->singular_name );
            $out[] = [
                'slug'  => (string) $slug,
                'label' => '' !== $label ? $label . ' (' . $slug . ')' : (string) $slug,
            ];
        }

        usort( $out, static fn( $a, $b ) => strcasecmp( $a['label'], $b['label'] ) );

        return $out;
    }

    /**
     * Public taxonomies offered in the settings panel, with their post types.
     *
     * @return array<int, array{slug:string, label:string, post_types:string[]}>
     */
    public static function available_taxonomies(): array {
        $taxonomies = get_taxonomies( [ 'public' => true ], 'objects' );

        $out = [];
        foreach ( $taxonomies as $slug => $object ) {
            $label = trim( (string) $object->labels->singular_name );
            $out[] = [
                'slug'       => (string) $slug,
                'label'      => '' !== $label ? $label . ' (' . $slug . ')' : (string) $slug,
                'post_types' => array_values( (array) $object->object_type ),
            ];
        }

        usort( $out, static fn( $a, $b ) => strcasecmp( $a['label'], $b['label'] ) );

        return $out;
    }

    /**
     * Post content formula.
     *
     * The post body is built as:
     *   <title>
     *   <br>Label: {column_value}
     *   <br>Label: {column_value}
     *   ...
     *
     * Each entry: [ 'label' => 'Human Label', 'column' => 'csv_column_name' ]
     * Rows whose column value is empty are omitted.
     */
    public const CONTENT_FORMULA = [
        [ 'label' => 'OEM Number',       'column' => 'oem_num' ],
        [ 'label' => 'Car Application',  'column' => 'car_application' ],
        [ 'label' => 'Diameter',         'column' => 'outer_diameter' ],
        [ 'label' => 'Weight',           'column' => 'weight' ],
    ];

    /**
     * Human-readable labels for the CSV preview table.
     * Columns not listed here fall back to the raw column name.
     */
    public const COLUMN_LABELS = [
        'type'              => 'Type',
        'product_mpn'       => 'MPN (Unique Key)',
        'oem_num'           => 'OEM #',
        'cross_ref'         => 'Cross Ref',
        'car_brand'         => 'Car Brand',
        'car_application'   => 'Application',
        'outer_diameter'    => 'Ø Diameter',
        'weight'            => 'Weight',
        'product_category' => 'Product Category',
        'product_cat'      => 'Product Category',
    ];

    // -------------------------------------------------------------------------
    // Derived helpers — read-only, driven by the constants above.
    // -------------------------------------------------------------------------

    /**
     * Returns the minimum required CSV column names.
     * Only the unique key is strictly required; title columns are optional.
     *
     * @return string[]
     */
    public static function required_headers(): array {
        return array_filter( [ self::UNIQUE_KEY ] );
    }

    /**
     * Builds a readable string representing the title formula.
     *
     * @return string
     */
    public static function title_formula_display(): string {
        $formula   = self::TITLE_FORMULA;
        $tokens    = $formula['prefix'] ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix'] ?? [];

        if ( '' !== $connector ) {
            $tokens[] = '"' . $connector . '"';
        }
        $tokens = array_merge( $tokens, $suffix );

        return implode( ' + ', $tokens );
    }

    /**
     * Column labels merged with the generated-title pseudo-column,
     * ready to pass to JavaScript.
     *
     * @return array<string,string>
     */
    public static function js_column_labels(): array {
        return array_merge(
            [ '_generated_title' => '🏷️ Generated Title' ],
            self::COLUMN_LABELS
        );
    }

    /**
     * Whether taxonomy assignment is enabled and the taxonomy exists.
     */
    public static function taxonomy_enabled(): bool {
        return '' !== self::taxonomy() && taxonomy_exists( self::taxonomy() );
    }

    /**
     * All CSV column names that may carry a per-row category value.
     *
     * @return string[]
     */
    public static function taxonomy_columns(): array {
        $column = self::taxonomy_column();

        // An empty column name means "no per-row assignment" — ignore aliases too.
        if ( '' === $column ) {
            return [];
        }

        return array_values( array_unique( array_merge(
            [ $column ],
            self::TAXONOMY_COLUMN_ALIASES
        ) ) );
    }

    /**
     * Whether a CSV column header holds category data.
     */
    public static function is_taxonomy_column( string $column ): bool {
        return in_array( strtolower( $column ), self::taxonomy_columns(), true );
    }

    /**
     * Hierarchical product_category terms for the import settings dropdown.
     *
     * @return array<int, array{id:int, name:string, depth:int}>
     */
    public static function get_taxonomy_term_options(): array {
        if ( ! self::taxonomy_enabled() ) {
            return [];
        }

        $args = [
            'taxonomy'   => self::taxonomy(),
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ];

        $terms = get_terms( $args );
        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            return [];
        }

        $by_parent = [];
        foreach ( $terms as $term ) {
            $by_parent[ (int) $term->parent ][] = $term;
        }

        $options = [];
        $walk    = static function ( int $parent_id, int $depth ) use ( &$walk, &$options, $by_parent ): void {
            foreach ( $by_parent[ $parent_id ] ?? [] as $term ) {
                $options[] = [
                    'id'    => (int) $term->term_id,
                    'name'  => $term->name,
                    'depth' => $depth,
                ];
                $walk( (int) $term->term_id, $depth + 1 );
            }
        };

        $walk( 0, 0 );
        return $options;
    }

    /**
     * Build the post_content string from a CSV row and a resolved post title.
     *
     * Format:
     *   <h2>{title}</h2>
     *   <strong>Label:</strong> {value}<br>
     *   ...
     *
     * Lines whose column value is empty are silently skipped.
     *
     * @param  array  $row   Parsed CSV row (column => value).
     * @param  string $title The resolved post title.
     * @return string        HTML-safe post content.
     */
    public static function build_post_content( array $row, string $title ): string {
        $content = '<h2>' . esc_html( $title ) . '</h2>';

        $lines = [];
        foreach ( self::CONTENT_FORMULA as $item ) {
            $value = trim( (string) ( $row[ $item['column'] ] ?? '' ) );
            if ( '' === $value ) {
                continue;
            }
            $lines[] = '<strong>' . esc_html( $item['label'] ) . ':</strong> ' . esc_html( $value );
        }

        if ( ! empty( $lines ) ) {
            $content .= implode( '<br>', $lines );
        }

        return $content;
    }
}
