<?php
defined( 'ABSPATH' ) || exit;

/**
 * Parses a CSV file into structured product rows.
 *
 * All CSV column headers become post meta keys (lowercased).
 * Only the unique-key column is strictly required.
 */
class CPI_CSV_Parser {

    /**
     * Parse the uploaded CSV file.
     *
     * @param string $file_path Absolute path to the uploaded CSV.
     * @return array{headers: string[], rows: array[], errors: string[]}
     */
    public static function parse( string $file_path ): array {
        $result = [
            'headers' => [],
            'rows'    => [],
            'errors'  => [],
        ];

        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            $result['errors'][] = __( 'File not found or not readable.', 'csv-product-importer' );
            return $result;
        }

        $handle = self::open_csv_handle( $file_path );
        if ( ! $handle ) {
            $result['errors'][] = __( 'Could not open file.', 'csv-product-importer' );
            return $result;
        }

        // Read header row
        $raw_headers = fgetcsv( $handle, 0, ',' );
        if ( empty( $raw_headers ) ) {
            $result['errors'][] = __( 'CSV file appears to be empty or malformed.', 'csv-product-importer' );
            fclose( $handle );
            return $result;
        }

        $headers = array_map(
            static fn( $h ) => trim( strtolower( self::ensure_utf8( ltrim( (string) $h, "\xEF\xBB\xBF" ) ) ) ),
            $raw_headers
        );
        $result['headers'] = $headers;

        // Only the unique-key column is strictly required
        $unique_key = strtolower( CPI_Config::UNIQUE_KEY );
        if ( ! in_array( $unique_key, $headers, true ) ) {
            $result['errors'][] = sprintf(
                __( 'Missing required column: %s', 'csv-product-importer' ),
                $unique_key
            );
            fclose( $handle );
            return $result;
        }

        $col_index = array_flip( $headers );
        $row_num   = 1;

        while ( ( $data = fgetcsv( $handle, 0, ',' ) ) !== false ) {
            $row_num++;

            // A blank CSV line comes back as [ null ] — normalise to strings first.
            $data = array_map( static fn( $v ) => (string) $v, (array) $data );

            // Skip completely empty rows
            if ( empty( array_filter( $data, static fn( $v ) => trim( $v ) !== '' ) ) ) {
                continue;
            }

            // Pad short rows
            while ( count( $data ) < count( $headers ) ) {
                $data[] = '';
            }

            $row = [];
            foreach ( $headers as $i => $key ) {
                $row[ $key ] = self::clean_value( $data[ $i ] ?? '' );
            }

            // Require the unique-key column to have a value
            if ( empty( $row[ $unique_key ] ) ) {
                $result['errors'][] = sprintf(
                    /* translators: 1: row number, 2: column name */
                    __( 'Row %1$d skipped — %2$s is empty.', 'csv-product-importer' ),
                    $row_num,
                    $unique_key
                );
                continue;
            }

            // Build the generated title from CPI_Config::TITLE_FORMULA
            $row['_generated_title'] = self::build_title( $row );
            $row['_generated_title'] = self::sanitize_title_for_import( $row['_generated_title'], $row );

            $result['rows'][] = $row;
        }

        fclose( $handle );
        return $result;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Sanitize a raw CSV cell value.
     * Strips the garbled £¬ (encoded comma) sequences that appear in some exports.
     */
    private static function clean_value( string $value ): string {
        $value = str_replace( [ "\xa3\xac", "\xc2\xa3\xc2\xac" ], "\n", $value );
        $value = self::ensure_utf8( $value );
        return trim( $value );
    }

    /**
     * Open the CSV as a UTF-8 memory stream.
     *
     * Reads the entire file, strips the BOM if present, detects the encoding
     * at the file level (far more reliable than per-value detection), converts
     * to UTF-8 when needed, and returns a seekable in-memory handle so the
     * rest of the parser can use fgetcsv() unchanged.
     *
     * Per-value encoding detection fails for Chinese CSVs because short GBK
     * byte pairs (e.g. 系 = 0xCF 0xB5) are accidentally valid UTF-8 sequences
     * (ϵ = U+03F5), so mb_check_encoding() gives a false positive and the bytes
     * are never converted. A whole-file sample eliminates those false positives.
     *
     * @return resource|false
     */
    private static function open_csv_handle( string $file_path ) {
        $raw = file_get_contents( $file_path );
        if ( false === $raw ) {
            return false;
        }

        // Strip UTF-8 BOM
        if ( str_starts_with( $raw, "\xEF\xBB\xBF" ) ) {
            $raw = substr( $raw, 3 );
        }

        $raw = self::normalise_file_to_utf8( $raw );

        $handle = fopen( 'php://memory', 'r+b' );
        if ( ! $handle ) {
            return false;
        }

        fwrite( $handle, $raw );
        rewind( $handle );

        return $handle;
    }

    /**
     * Detect the encoding of the entire file content and convert to UTF-8.
     *
     * Using the whole-file content as the detection sample is critical:
     * a larger sample dramatically reduces false positives where a non-UTF-8
     * encoding (GBK, BIG5, …) accidentally produces byte sequences that are
     * also valid UTF-8.
     */
    private static function normalise_file_to_utf8( string $content ): string {
        if ( ! function_exists( 'mb_detect_encoding' ) || ! function_exists( 'mb_convert_encoding' ) ) {
            return $content;
        }

        $detected = mb_detect_encoding(
            $content,
            [ 'UTF-8', 'GB18030', 'GBK', 'BIG5', 'Windows-1252', 'ISO-8859-1' ],
            true  // strict mode
        );

        if ( false === $detected || 'UTF-8' === $detected ) {
            return $content;
        }

        $converted = @mb_convert_encoding( $content, 'UTF-8', $detected );

        return ( is_string( $converted ) ) ? $converted : $content;
    }

    /**
     * Safety-net per-value UTF-8 coercion.
     *
     * The file-level conversion in open_csv_handle() handles the common cases.
     * This catches any stray non-UTF-8 bytes that survive (e.g. mixed-encoding
     * files where individual cells were pasted from a different source).
     */
    private static function ensure_utf8( string $value ): string {
        if ( '' === $value || mb_check_encoding( $value, 'UTF-8' ) ) {
            return $value;
        }

        if ( function_exists( 'mb_convert_encoding' ) ) {
            $converted = @mb_convert_encoding( $value, 'UTF-8', 'GB18030, GBK, BIG5, Windows-1252, ISO-8859-1' );
            if ( is_string( $converted ) && mb_check_encoding( $converted, 'UTF-8' ) ) {
                return $converted;
            }
        }

        return wp_check_invalid_utf8( $value, true );
    }

    /**
     * Ensure the stored generated title will not be emptied on wp_insert_post().
     */
    private static function sanitize_title_for_import( string $title, array $row ): string {
        $sanitized = sanitize_text_field( $title );
        if ( '' !== $sanitized ) {
            return $sanitized;
        }

        $fallback = sanitize_text_field( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? '' ) );
        if ( '' !== $fallback ) {
            return $fallback;
        }

        $stripped = trim( wp_strip_all_tags( $title ) );
        return '' !== $stripped ? mb_substr( $stripped, 0, 200 ) : $title;
    }

    /**
     * Build the post title from CPI_Config::TITLE_FORMULA.
     *
     * Formula: prefix columns joined by space, optional connector word,
     * then suffix columns joined by space.
     *
     * @param array $row Parsed CSV row (keyed by column name).
     * @return string
     */
    public static function build_title( array $row ): string {
        $formula   = CPI_Config::TITLE_FORMULA;
        $prefix    = $formula['prefix']    ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix']    ?? [];

        $prefix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $prefix )
        );
        $suffix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $suffix )
        );

        $title = implode( ' ', $prefix_parts );

        if ( ! empty( $suffix_parts ) ) {
            $suffix_str = implode( ' ', $suffix_parts );

            if ( '' !== $title && '' !== $connector ) {
                $title .= ' ' . $connector . ' ' . $suffix_str;
            } else {
                $title .= ( '' !== $title ? ' ' : '' ) . $suffix_str;
            }
        }

        return trim( $title );
    }
}
