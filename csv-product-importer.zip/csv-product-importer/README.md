# CSV Product Importer Pro

**CSV Product Importer Pro** is a high-performance WordPress plugin designed to bulk import products from CSV files into WordPress. It features dynamic column meta mapping, automated product title generation, case-insensitive image matching, taxonomy categorization, and Polylang multilingual synchronization.

---

## Key Features

- **Automated Title Assembly:** Assembles post titles on-the-fly using configurable CSV column combinations (e.g. `car_brand` + `car_application` + `type` + `cross_ref`).
- **Dynamic Post Meta Mapping:** Every CSV header (e.g., `oem_num`, `product_mpn`, `outer_diameter`, `weight`) is automatically stored as lowercased post meta. No hardcoded field mapping required.
- **Automatic Image & Gallery Matching:** Automatically scans disk storage for images matching each product's `product_mpn` and assigns featured images and product image galleries.
- **Duplicate Detection & Updates:** Checks for existing products via a unique identifier (`oem_num`). Supports skipping duplicates or updating existing products with new data.
- **Taxonomy Categorization:** Assigns products to a configurable taxonomy (default `product_category`, with `product_cat` accepted as a CSV column alias) via a default category setting or per-row CSV column values.
- **Polylang Compatibility:** Automatically integrates with Polylang to assign default languages and mirror base meta fields across translations.
- **Batch Processing via AJAX:** Imports large CSV files smoothly in configurable chunks without memory or timeout errors.
- **Admin Management Tools:** Clean all imported products, delete products by category, or purge orphaned media library attachments.

---

## 📸 How Image Matching Works

### Where to Put Uploaded Images

Place all product images on your server in the following directory:

```
wp-content/uploads/cpi-imports/images/
```

> **Note:** If the `cpi-imports/images/` directory does not exist, the plugin will create it automatically when initialized, or you can manually create the folders inside `wp-content/uploads/`.

### Image Filename Naming Conventions

Images are matched against the value in the **`product_mpn`** CSV column (case-insensitive). The plugin supports multiple sequence formats:

| Format Pattern | Example Filenames | Assigned Role |
| :--- | :--- | :--- |
| **Parentheses (Recommended)** | `TQB2-0001(1).jpg`, `TQB2-0001(2).png` | Sequence 1 = Featured Image<br>Sequence 1, 2, ... = Product Gallery |
| **Dash / Underscore Separator** | `TQB2-0001-1.jpg`, `TQB2-0001_2.jpg` | Sequence 1 = Featured Image<br>Sequence 1, 2, ... = Product Gallery |
| **Dot Separator** | `TQB2-0001.1.jpg`, `TQB2-0001.2.jpg` | Sequence 1 = Featured Image<br>Sequence 1, 2, ... = Product Gallery |
| **Single Image** | `TQB2-0001.jpg` | Featured Image & Gallery |

### Image Matching Behavior

1. **Case-Insensitive:** `tqb2-0001(1).jpg`, `TQB2-0001(1).JPG`, and `Tqb2-0001(1).jpg` all match `product_mpn` = `TQB2-0001`.
2. **Featured Image (`_thumbnail_id`):** The file with sequence number `1` or `(1)` is set as the featured thumbnail. If no sequence `1` exists, the first matched image is chosen.
3. **Product Gallery (`_product_image_gallery` / `product_gallery`):** All matching images are registered into the WordPress Media Library (if not already added) and linked to the post gallery as comma-separated attachment IDs.

---

## 📊 CSV File Format

### Minimal Required Columns

Only **`product_mpn`** is strictly required for duplicate detection and image matching. Additional columns enrich post titles, content, and metadata.

### Example CSV Structure

```csv
type,product_mpn,oem_num,cross_ref,car_brand,car_application,outer_diameter,weight,product_category
front wheel hub unit,TQB2-0001,011-1017-0300,DACF301344071L2,BAIC,Huansu S2 S3 H3 1.5L,72mm,1.2kg,wheel-hub-bearings
rear wheel hub unit,TQB2-0002,04509766AC,"512167,VKBA6588",Chrysler,Walker 2004-2008,68mm,1.4kg,wheel-hub-bearings
```

### Column Descriptions

- **`product_mpn`**: (Required) Manufacturer Part Number used for duplicate detection and matching images in `wp-content/uploads/cpi-imports/images/`.
- **`oem_num`**: Original Equipment Manufacturer number — optional, stored as post meta.
- **`car_brand`**, **`car_application`**, **`type`**, **`cross_ref`**: Used by default to construct the generated post title in the format: `cross_ref type for car_brand car_application`.
- **`product_category`** (or `product_cat`): Category slug, name, or ID for per-row categorization. Supports multiple terms separated by comma, pipe, or semicolon.
- **Any Custom Column**: Automatically saved as post meta (e.g. `outer_diameter`, `weight`).

---

## 🚀 How to Use the Plugin

### Step 1: Upload Images to the Server
Upload your product image files (e.g., `TQB2-0001(1).jpg`, `TQB2-0001(2).jpg`) into `wp-content/uploads/cpi-imports/images/` using FTP, SFTP, or your hosting file manager.

### Step 2: Access the Importer Admin Page
In your WordPress Admin Dashboard, navigate to **CSV Importer** from the sidebar menu (`toplevel_page_cpi-importer`).

### Step 3: Choose & Preview CSV File
1. Click **Choose CSV File** and select your `.csv` file.
2. The importer will parse the file and display a live preview table with detected column headers and sample data rows.

### Step 4: Pick the import target
In the **Import target** card at the top of the page choose:

- **Post type** — the post type imported rows are created as (e.g. `product`, `post`, `page`).
- **Category taxonomy** — the taxonomy used for categories, or *Disabled*. Taxonomies are filtered to those attached to the selected post type.
- **Category CSV column** — the optional CSV header holding a per-row term slug, name or ID.

Click **Save settings**. The values are stored in the `cpi_settings` option and reused by every import — no PHP editing required. The card also warns you when the saved taxonomy no longer exists on the site.

### Step 5: Configure Import Options
- **Duplicate handling:** 
  - *Skip duplicate products* (preserves existing posts matching `oem_num`).
  - *Update existing products with new data* (overwrites metadata & gallery for matching `oem_num`).
- **Default Product Category:** Choose a category to apply if a row's `product_category` CSV column is empty.

### Step 6: Run Import
Click **Start Import**. Progress will display in real time as records are imported in background batches.

---

## ⚙️ Configuration (`includes/class-cpi-config.php`)

The constants below are **fallback defaults only** — post type, taxonomy and the category CSV
column are normally set from the admin **Import target** card and stored in the `cpi_settings`
option. If a configured value is missing on the site (for example the taxonomy is not
registered), the plugin auto-detects a sensible alternative (`product_cat` → `product_category`
→ `category`) so the category tools stay available.

Developer defaults and title rules can be adjusted in [class-cpi-config.php](file:///c:/Users/Administrator/Local%20Sites/bearing/app/public/wp-content/plugins/csv-product-importer/includes/class-cpi-config.php):

```php
// Fallback target WordPress post type
public const DEFAULT_POST_TYPE = 'product';

// Unique column for duplicate checking
public const UNIQUE_KEY = 'product_mpn';

// Column matched against image filenames
public const IMAGE_KEY = 'product_mpn';

// Title formula setup
public const TITLE_FORMULA = [
    'prefix'    => [ 'cross_ref', 'type' ],
    'connector' => 'for',
    'suffix'    => [ 'car_brand', 'car_application' ],
];

// Fallback taxonomy + CSV column
public const DEFAULT_TAXONOMY        = 'product_category';
public const DEFAULT_TAXONOMY_COLUMN = 'product_category';
public const TAXONOMY_COLUMN_ALIASES = [ 'product_cat' ];
```

Reading the effective values at runtime:

```php
CPI_Config::post_type();         // active post type
CPI_Config::taxonomy();          // active taxonomy ('' = category features off)
CPI_Config::taxonomy_column();   // active CSV column ('' = per-row assignment off)
```

---

## 🛠️ Management & Danger Zone Tools

Located at the bottom of the CSV Importer admin page:

- **Delete Products by Category:** Select a product category to clear all associated imported items.
- **Purge Missing Media Records:** Clean up WordPress attachment records in the database whose physical files have been removed from disk.
- **Clear ALL Products:** Bulk delete all imported product posts and their associated image attachments.
