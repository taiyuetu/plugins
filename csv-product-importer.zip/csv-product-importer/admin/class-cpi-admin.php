<?php
defined( 'ABSPATH' ) || exit;

class CPI_Admin {

    public static function hooks(): void {
        add_action( 'admin_menu',            [ __CLASS__, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
    }

    public static function add_menu(): void {
        add_menu_page(
            __( 'CSV Importer', 'csv-product-importer' ),
            __( 'CSV Importer', 'csv-product-importer' ),
            'manage_options',
            'cpi-importer',
            [ __CLASS__, 'render_page' ],
            'dashicons-upload',
            30
        );
    }

    public static function enqueue( string $hook ): void {
        if ( $hook !== 'toplevel_page_cpi-importer' ) {
            return;
        }

        wp_enqueue_style(
            'cpi-admin',
            CPI_PLUGIN_URL . 'admin/css/admin.css',
            [],
            CPI_VERSION
        );

        wp_enqueue_script(
            'cpi-admin',
            CPI_PLUGIN_URL . 'admin/js/admin.js?v=' . CPI_VERSION,
            [ 'jquery' ],
            null,
            true
        );

        wp_localize_script( 'cpi-admin', 'CPI', [
            'ajaxurl'          => admin_url( 'admin-ajax.php' ),
            'security'         => wp_create_nonce( 'cpi_nonce' ),
            'batch_size'       => 50,
            'column_labels'    => CPI_Config::js_column_labels(),
            'i18n'             => [
                'importing'                => __( 'Importing…',              'csv-product-importer' ),
                'previewing'               => __( 'Parsing CSV…',            'csv-product-importer' ),
                'done'                     => __( 'Import complete!',        'csv-product-importer' ),
                'error'                    => __( 'An error occurred.',      'csv-product-importer' ),
                'confirm_clear'            => __( 'Delete ALL products? This cannot be undone.', 'csv-product-importer' ),
                'confirm_delete_category'  => __( 'Delete all products in "%s"? This cannot be undone.', 'csv-product-importer' ),
                'select_category'          => __( 'Please select a product category.', 'csv-product-importer' ),
                'deleting_category'        => __( 'Deleting products…', 'csv-product-importer' ),
                'confirm_purge_orphans'    => __( 'Scan media library and delete all unattached image records whose file is missing from disk? This cannot be undone.', 'csv-product-importer' ),
                'purging_orphans'          => __( 'Scanning media…', 'csv-product-importer' ),
                'syncing_images'          => __( 'Syncing images…', 'csv-product-importer' ),
                'saving_settings'          => __( 'Saving…', 'csv-product-importer' ),
                'settings_saved'           => __( 'Saved.', 'csv-product-importer' ),
            ],
        ] );
    }

    public static function render_page(): void {
        require_once CPI_PLUGIN_DIR . 'templates/admin-page.php';
    }
}
