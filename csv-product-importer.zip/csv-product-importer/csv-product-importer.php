<?php
/**
 * Plugin Name:       CSV Product Importer Pro
 * Plugin URI:        https://bootstrap.cc/plugins/csv-product-importer
 * Description:       Premium plugin to import products from CSV files with smart title generation and meta field mapping.
 * Version:           2.4.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            wptutor
 * Author URI:        https://bootstrap.cc
 * License:           GPL v2 or later
 * Text Domain:       csv-product-importer
 */

defined('ABSPATH') || exit;

define('CPI_VERSION', '2.4.0');
define('CPI_PLUGIN_FILE', __FILE__);
define('CPI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CPI_PLUGIN_URL', plugin_dir_url(__FILE__));

// Autoload includes
require_once CPI_PLUGIN_DIR . 'includes/class-cpi-config.php';
require_once CPI_PLUGIN_DIR . 'includes/class-cpi-polylang-sync.php';
require_once CPI_PLUGIN_DIR . 'includes/class-cpi-csv-parser.php';
require_once CPI_PLUGIN_DIR . 'includes/class-cpi-importer.php';
require_once CPI_PLUGIN_DIR . 'includes/class-cpi-ajax.php';
require_once CPI_PLUGIN_DIR . 'admin/class-cpi-admin.php';

/**
 * Main plugin bootstrap class.
 */
final class CSV_Product_Importer
{

    private static ?self$instance = null;

    public static function instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('init', [$this, 'init']);
        add_action('plugins_loaded', [$this, 'load_textdomain']);
        register_activation_hook(CPI_PLUGIN_FILE, [$this, 'activate']);
        register_deactivation_hook(CPI_PLUGIN_FILE, [$this, 'deactivate']);
    }

    public function init(): void
    {
        CPI_Ajax::hooks();
        CPI_Admin::hooks();
    }

    public function load_textdomain(): void
    {
        load_plugin_textdomain('csv-product-importer', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function activate(): void
    {
        flush_rewrite_rules();
    }

    public function deactivate(): void
    {
        flush_rewrite_rules();
    }
}

CSV_Product_Importer::instance();
