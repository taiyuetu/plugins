<?php
/**
 * Standalone tests for CSV Product Importer Pro's pure logic
 * (title building, CSV parsing, MPN/image filename matching).
 *
 * Usage:  php tests/run-tests.php
 *
 * No WordPress installation or PHPUnit required — the minimal WP stubs and a
 * CPI_Config constant stub below are enough to exercise the parser and the
 * importer's pure helper methods.
 */

error_reporting( E_ALL );

// ── WordPress stubs ────────────────────────────────────────────────────────
define( 'ABSPATH', __DIR__ . '/../' );

function __( $string, $domain = null ) { return $string; }
function esc_html__( $string, $domain = null ) { return $string; }
function sanitize_text_field( $str ) {
	$str = preg_replace( '/<[^>]*>/', '', (string) $str );
	$str = preg_replace( '/[\r\n\t ]+/', ' ', $str );
	return trim( $str );
}
function wp_strip_all_tags( $str ) { return trim( strip_tags( (string) $str ) ); }
function wp_check_invalid_utf8( $str, $strip = false ) { return $str; }

// Minimal CPI_Config stub: the constants and methods the tested logic reads.
class CPI_Config {
	const UNIQUE_KEY    = 'product_mpn';
	const IMAGE_KEY     = 'product_mpn';
	const TITLE_FORMULA = [
		'prefix'    => [ 'cross_ref', 'type' ],
		'connector' => 'for',
		'suffix'    => [ 'car_brand', 'car_application' ],
	];

	public static function post_type() { return 'product'; }
	public static function taxonomy() { return 'product_category'; }
	public static function taxonomy_enabled() { return false; }
	public static function is_taxonomy_column( $col ) { return false; }
}

require_once __DIR__ . '/../includes/class-cpi-csv-parser.php';
require_once __DIR__ . '/../includes/class-cpi-importer.php';

// ── Tiny assertion helpers ─────────────────────────────────────────────────
$PASS = 0;
$FAIL = 0;

function check( string $label, bool $condition ): void {
	global $PASS, $FAIL;
	if ( $condition ) {
		$PASS++;
		echo "[PASS] {$label}\n";
	} else {
		$FAIL++;
		echo "[FAIL] {$label}\n";
	}
}

function invoke_private( string $class, string $method, ...$args ) {
	$m = new ReflectionMethod( $class, $method );
	$m->setAccessible( true );
	return $m->invoke( null, ...$args );
}

function parse_content( string $content ): array {
	$tmp = tempnam( sys_get_temp_dir(), 'cpi-test-' );
	file_put_contents( $tmp, $content );
	$parsed = CPI_CSV_Parser::parse( $tmp );
	unlink( $tmp );
	return $parsed;
}

// ── CPI_CSV_Parser::build_title() ──────────────────────────────────────────
echo "\n== build_title ==\n";

$row = [ 'cross_ref' => 'CR-1', 'type' => 'Pad', 'car_brand' => 'Toyota', 'car_application' => 'Corolla' ];
check( 'full formula', CPI_CSV_Parser::build_title( $row ) === 'CR-1 Pad for Toyota Corolla' );

$row = [ 'type' => 'Pad', 'car_brand' => 'Toyota', 'car_application' => 'Corolla' ];
check( 'missing prefix column is skipped', CPI_CSV_Parser::build_title( $row ) === 'Pad for Toyota Corolla' );

$row = [ 'cross_ref' => 'CR-1', 'type' => 'Pad' ];
check( 'no suffix parts', CPI_CSV_Parser::build_title( $row ) === 'CR-1 Pad' );

$row = [ 'car_brand' => 'Toyota' ];
check( 'suffix only', CPI_CSV_Parser::build_title( $row ) === 'Toyota' );

check( 'empty row', CPI_CSV_Parser::build_title( [] ) === '' );

$row = [ 'type' => str_repeat( 'x', 300 ) ];
check( 'no double spaces inside title', strpos( CPI_CSV_Parser::build_title( [ 'type' => 'Pad', 'car_brand' => 'Toyota' ] ), '  ' ) === false );

// ── CPI_CSV_Parser::parse() ────────────────────────────────────────────────
echo "\n== parse ==\n";

$csv = "\xEF\xBB\xBF"                 // UTF-8 BOM
	. "Product_MPN,Type,Car_Brand,Car_Application\n"
	. "TQB2-0001,Pad,Toyota,Corolla\n"
	. "TQB2-0002,Cap,,\n"
	. "\n"                             // completely blank row
	. ",Pad,Toyota,Corolla\n";         // missing unique key

$parsed = parse_content( $csv );

check( 'headers lowercased & BOM stripped', $parsed['headers'] === [ 'product_mpn', 'type', 'car_brand', 'car_application' ] );
check( 'two valid rows', count( $parsed['rows'] ) === 2 );
check( 'row 1 title', $parsed['rows'][0]['_generated_title'] === 'Pad for Toyota Corolla' );
check( 'row 2 title (no suffix)', $parsed['rows'][1]['_generated_title'] === 'Cap' );
check( 'row without unique key reported', count( $parsed['errors'] ) === 1 && strpos( $parsed['errors'][0], 'Row 5' ) !== false );

// Garbled £¬ (UTF-8 mojibake of a GBK comma) becomes a newline
$parsed = parse_content( "product_mpn,type\nTQB2-0003,Pad\xC2\xA3\xC2\xACExtra\n" );
check( 'mojibake £¬ replaced with newline', isset( $parsed['rows'][0]['type'] ) && $parsed['rows'][0]['type'] === "Pad\nExtra" );

// Missing required column
$parsed = parse_content( "oem_num,type\n123,Pad\n" );
check( 'missing unique-key column errors', $parsed['rows'] === [] && strpos( implode( '', $parsed['errors'] ), 'product_mpn' ) !== false );

// Whole-file GBK detection (short GBK byte pairs that fake valid UTF-8)
if ( function_exists( 'mb_detect_encoding' ) && function_exists( 'mb_convert_encoding' ) ) {
	// 刹车片 in GBK bytes: C9 B2 B3 B5 C6 AC
	$parsed = parse_content( "product_mpn,type\nTQB2-0004,\xC9\xB2\xB3\xB5\xC6\xAC\n" );
	check( 'GBK file converted to UTF-8', isset( $parsed['rows'][0]['type'] ) && $parsed['rows'][0]['type'] === '刹车片' );
} else {
	echo "[SKIP] GBK conversion test (mbstring not available)\n";
}

// ── CPI_Importer::parse_mpn_image_sequence() ────────────────────────────────
echo "\n== parse_mpn_image_sequence ==\n";

$cases = [
	[ 'TQB2-0046(3).jpg',  'TQB2-0046',   3,  'parenthesized sequence' ],
	[ 'TQB2-0046( 1 ).jpg', 'TQB2-0046',  1,  'parenthesized with spaces' ],
	[ 'TQB2-0046_3.jpg',   'TQB2-0046',   3,  'underscore sequence' ],
	[ 'tqb2_0046-12.png',  'TQB2-0046',   12, 'case-insensitive dash sequence' ],
	[ 'TQB2 0046.jpeg',    'TQB2-0046',   1,  'exact match, mixed separators' ],
	[ 'TQB2-0046.jpg',     'TQB2-0046',   1,  'exact match' ],
	[ 'OTHER-001.jpg',     'TQB2-0046',   null, 'non-matching file' ],
	[ 'TQB2-0046-3.jpg',   'TQB2-0046-3', 1,  'MPN itself ends in dash-digits' ],
	[ 'TQB2-0046(2).jpg',  'OTHER',       null, 'paren sequence on wrong key' ],
];

foreach ( $cases as [ $filename, $key, $expected, $label ] ) {
	$actual = invoke_private( 'CPI_Importer', 'parse_mpn_image_sequence', $filename, $key );
	check( $label . ' (' . $filename . ')', $actual === $expected );
}

// ── CPI_Importer::normalize_mpn_string() ───────────────────────────────────
echo "\n== normalize_mpn_string ==\n";

check(
	'spaces/hyphens/underscores/dots collapse to single dash',
	invoke_private( 'CPI_Importer', 'normalize_mpn_string', 'TQB2 0046_test.v1' ) === 'tqb2-0046-test-v1'
);
check(
	'case-insensitive',
	invoke_private( 'CPI_Importer', 'normalize_mpn_string', 'tqb2-0046' ) === 'tqb2-0046'
);

// ── Summary ────────────────────────────────────────────────────────────────
echo "\n{$PASS} passed, {$FAIL} failed\n";
exit( $FAIL > 0 ? 1 : 0 );
