<?php
/**
 * This file contains the definition of the Settings class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\Admin;

/**
 * Manages the plugin settings page and API key storage.
 *
 * @since 1.1.0
 */
class Settings {

	const OPTION_API_KEY = 'aiprfd_deepseek_api_key';

	/**
	 * Register WordPress hooks.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'addPage' ) );
		add_action( 'admin_init', array( $this, 'registerSettings' ) );
	}

	/**
	 * Add the options page under Settings menu.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function addPage(): void {
		add_options_page(
			__( 'DeepSeek AI Provider', 'ai-provider-for-deepseek' ),
			__( 'DeepSeek AI', 'ai-provider-for-deepseek' ),
			'manage_options',
			'ai-provider-for-deepseek',
			array( $this, 'renderPage' )
		);
	}

	/**
	 * Register settings, sections, and fields.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function registerSettings(): void {
		register_setting(
			'aiprfd_settings_group',
			self::OPTION_API_KEY,
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		add_settings_section(
			'aiprfd_api_section',
			__( 'API Configuration', 'ai-provider-for-deepseek' ),
			null,
			'ai-provider-for-deepseek'
		);

		add_settings_field(
			self::OPTION_API_KEY,
			__( 'DeepSeek API Key', 'ai-provider-for-deepseek' ),
			array( $this, 'renderApiKeyField' ),
			'ai-provider-for-deepseek',
			'aiprfd_api_section'
		);
	}

	/**
	 * Render the API key input field.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function renderApiKeyField(): void {
		$value = self::getApiKey();
		printf(
			'<input type="password" id="%1$s" name="%1$s" value="%2$s" class="regular-text" autocomplete="off" />',
			esc_attr( self::OPTION_API_KEY ),
			esc_attr( $value )
		);
		printf(
			'<p class="description">%s</p>',
			sprintf(
				/* translators: %s: URL to DeepSeek platform */
				esc_html__( 'Get your API key at %s', 'ai-provider-for-deepseek' ),
				'<a href="https://platform.deepseek.com" target="_blank" rel="noopener noreferrer">platform.deepseek.com</a>'
			)
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function renderPage(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'aiprfd_settings_group' );
				do_settings_sections( 'ai-provider-for-deepseek' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Return the stored API key.
	 *
	 * @since  1.1.0
	 * @return string
	 */
	public static function getApiKey(): string {
		return (string) get_option( self::OPTION_API_KEY, '' );
	}
}
