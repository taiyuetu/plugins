<?php
/**
 * This file contains the definition of the TranslationMetaBox class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\Admin;

use Sajjad67\AiProviderForDeepSeek\Translation\PolylangHelper;
use Sajjad67\AiProviderForDeepSeek\Translation\PostTranslator;

/**
 * Adds a "DeepSeek Translation" meta box to the post editor (Classic & Block).
 *
 * The meta box lists all Polylang target languages and exposes a button that
 * triggers a REST call to translate the post via DeepSeek.
 *
 * @since 1.1.0
 */
class TranslationMetaBox {

	/**
	 * Register WordPress hooks.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function register(): void {
		add_action( 'add_meta_boxes', array( $this, 'addMetaBox' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueueAssets' ) );
	}

	/**
	 * Register the meta box for all public post types.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function addMetaBox(): void {
		if ( ! PolylangHelper::isActive() ) {
			return;
		}

		$post_types = get_post_types( array( 'public' => true ) );

		foreach ( $post_types as $post_type ) {
			add_meta_box(
				'aiprfd_translation',
				__( 'DeepSeek Translation', 'ai-provider-for-deepseek' ),
				array( $this, 'renderMetaBox' ),
				$post_type,
				'side',
				'default'
			);
		}
	}

	/**
	 * Render meta box HTML.
	 *
	 * @since  1.1.0
	 * @param  \WP_Post $post Current post object.
	 * @return void
	 */
	public function renderMetaBox( \WP_Post $post ): void {
		// AI Client availability check — requires wp_ai_client_prompt() and a
		// configured DeepSeek connector (Settings → Connectors).
		if ( ! PostTranslator::isAvailable() ) {
			$connectors_url = admin_url( 'options-general.php?page=wp-connectors' );
			echo '<p class="aiprfd-notice aiprfd-notice--warning">' .
				sprintf(
					/* translators: %s: Settings → Connectors page link */
					esc_html__( 'DeepSeek is not configured. Add your API key at %s.', 'ai-provider-for-deepseek' ),
					'<a href="' . esc_url( $connectors_url ) . '">' . esc_html__( 'Settings → Connectors', 'ai-provider-for-deepseek' ) . '</a>'
				) .
				'</p>';
			return;
		}

		$all_languages = PolylangHelper::getLanguages();
		$source_lang   = PolylangHelper::getPostLanguage( $post->ID );

		// Remove source language from target list.
		$target_languages = array();
		foreach ( $all_languages as $slug => $name ) {
			if ( $slug !== $source_lang ) {
				$target_languages[ $slug ] = $name;
			}
		}

		if ( empty( $target_languages ) ) {
			echo '<p class="aiprfd-notice">' .
				esc_html__( 'Add more languages in Polylang to enable translation.', 'ai-provider-for-deepseek' ) .
				'</p>';
			return;
		}

		if ( empty( $source_lang ) ) {
			echo '<p class="aiprfd-notice aiprfd-notice--warning">' .
				esc_html__( 'Set a language for this post in Polylang first.', 'ai-provider-for-deepseek' ) .
				'</p>';
		}
		?>
		<div id="aiprfd-translation-box" data-post-id="<?php echo esc_attr( (string) $post->ID ); ?>">

			<?php if ( ! empty( $source_lang ) && isset( $all_languages[ $source_lang ] ) ) : ?>
			<p class="aiprfd-source-lang">
				<span class="aiprfd-label"><?php esc_html_e( 'Source language', 'ai-provider-for-deepseek' ); ?></span>
				<strong><?php echo esc_html( $all_languages[ $source_lang ] ); ?></strong>
			</p>
			<?php endif; ?>

			<label class="aiprfd-label" for="aiprfd-target-lang">
				<?php esc_html_e( 'Translate to', 'ai-provider-for-deepseek' ); ?>
			</label>
			<select id="aiprfd-target-lang" name="aiprfd_target_lang" class="widefat">
				<?php foreach ( $target_languages as $slug => $name ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
				<?php endforeach; ?>
			</select>

			<p class="aiprfd-hint">
				<?php esc_html_e( 'Save the post before translating to ensure the latest content is used.', 'ai-provider-for-deepseek' ); ?>
			</p>

			<button type="button" id="aiprfd-translate-btn" class="button button-primary aiprfd-translate-btn">
				<span class="aiprfd-btn-label"><?php esc_html_e( 'Translate with DeepSeek', 'ai-provider-for-deepseek' ); ?></span>
				<span class="aiprfd-spinner" aria-hidden="true"></span>
			</button>

			<div id="aiprfd-status" role="status" aria-live="polite"></div>

		</div>
		<?php
	}

	/**
	 * Enqueue JS and CSS on post edit screens.
	 *
	 * @since  1.1.0
	 * @param  string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueueAssets( string $hook ): void {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		if ( ! PolylangHelper::isActive() ) {
			return;
		}

		$plugin_url = AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_URL;
		$version    = AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_VERSION;

		wp_enqueue_style(
			'aiprfd-translation',
			$plugin_url . 'assets/css/translation.css',
			array(),
			$version
		);

		wp_enqueue_script(
			'aiprfd-translation',
			$plugin_url . 'assets/js/translation.js',
			array(),
			$version,
			true
		);

		wp_localize_script(
			'aiprfd-translation',
			'AiprfdTranslation',
			array(
				'restUrl' => esc_url_raw( rest_url( 'ai-provider-for-deepseek/v1/translate' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'translating' => __( 'Translating… this may take up to a minute for long posts.', 'ai-provider-for-deepseek' ),
					'success'     => __( 'Translation published successfully!', 'ai-provider-for-deepseek' ),
					'updated'     => __( 'Existing translation updated!', 'ai-provider-for-deepseek' ),
					'editLink'    => __( 'Edit translated post →', 'ai-provider-for-deepseek' ),
					'error'       => __( 'Translation failed: ', 'ai-provider-for-deepseek' ),
				),
			)
		);
	}
}
