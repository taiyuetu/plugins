<?php
/**
 * This file contains the definition of the DeepSeekTextGenerationModel class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\Models;

use Sajjad67\AiProviderForDeepSeek\Provider\DeepSeekProvider;
use WordPress\AiClient\Providers\Http\DTO\Request;
use WordPress\AiClient\Providers\Http\Enums\HttpMethodEnum;
use WordPress\AiClient\Providers\OpenAiCompatibleImplementation\AbstractOpenAiCompatibleTextGenerationModel;

/**
 * Class for an DeepSeek text generation model using the OpenAI-compatible chat completions API.
 *
 * @since 1.0.0
 */
class DeepSeekTextGenerationModel extends AbstractOpenAiCompatibleTextGenerationModel {
	/**
	 * {@inheritDoc}
	 *
	 * @since  1.0.0
	 * @param  HttpMethodEnum $method  The HTTP method to use for the request.
	 * @param  string         $path    The API endpoint path (e.g., 'v1/models').
	 * @param  array          $headers Optional. Array of HTTP headers. Default empty array.
	 * @param  mixed          $data    Optional. The data to be sent in the request body. Default null.
	 * @return Request                 The constructed Request object.
	 */
	protected function createRequest( HttpMethodEnum $method, string $path, array $headers = array(), $data = null ): Request {
		return new Request(
			$method,
			DeepSeekProvider::url( $path ),
			$headers,
			$data,
			$this->getRequestOptions()
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * DeepSeek does not support the "json_schema" response format type.
	 * Always use "json_object" and rely on the system instruction / prompt
	 * context to guide the model toward the expected structure.
	 *
	 * @since  1.2.0
	 * @param  array|null $outputSchema The output schema (unused by DeepSeek).
	 * @return array                    The prepared response format parameter.
	 */
	protected function prepareResponseFormatParam( ?array $outputSchema ): array {
		return array( 'type' => 'json_object' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * DeepSeek requires the word "json" in the prompt when using
	 * response_format json_object. This override appends a JSON
	 * instruction (and the expected schema when available) to the
	 * system message so the requirement is always satisfied.
	 *
	 * @since  1.2.0
	 * @param  array $prompt The prompt messages.
	 * @return array         The prepared parameters.
	 */
	protected function prepareGenerateTextParams( array $prompt ): array {
		$params = parent::prepareGenerateTextParams( $prompt );

		if ( ! isset( $params['response_format'] ) ) {
			return $params;
		}

		$schema  = $this->getConfig()->getOutputSchema();
		$suffix  = "\n\nYou MUST respond with valid JSON.";
		if ( is_array( $schema ) ) {
			$suffix .= ' Use this exact JSON schema: ' . wp_json_encode( $schema );
		}

		$injected = false;
		foreach ( $params['messages'] as &$msg ) {
			if ( ! isset( $msg['role'] ) || 'system' !== $msg['role'] || ! isset( $msg['content'] ) ) {
				continue;
			}

			$content_str = is_array( $msg['content'] )
				? wp_json_encode( $msg['content'] )
				: $msg['content'];

			if ( stripos( $content_str, 'json' ) === false ) {
				if ( is_array( $msg['content'] ) ) {
					$msg['content'][] = array(
						'type' => 'text',
						'text' => $suffix,
					);
				} else {
					$msg['content'] .= $suffix;
				}
			}

			$injected = true;
			break;
		}
		unset( $msg );

		if ( ! $injected ) {
			array_unshift(
				$params['messages'],
				array(
					'role'    => 'system',
					'content' => trim( $suffix ),
				)
			);
		}

		return $params;
	}
}
