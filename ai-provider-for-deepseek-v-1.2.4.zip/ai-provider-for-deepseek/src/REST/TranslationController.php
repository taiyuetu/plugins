<?php
/**
 * This file contains the definition of the TranslationController class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\REST;

use Sajjad67\AiProviderForDeepSeek\Translation\PolylangHelper;
use Sajjad67\AiProviderForDeepSeek\Translation\PostTranslator;

/**
 * Registers and handles the REST API endpoint used by the translation meta box.
 *
 * Credentials are managed through WordPress's native Connectors API
 * (Settings → Connectors). This controller does not handle API keys directly.
 *
 * Endpoint: POST /wp-json/ai-provider-for-deepseek/v1/translate
 *
 * @since 1.1.0
 */
class TranslationController {

	const REST_NAMESPACE = 'ai-provider-for-deepseek/v1';
	const REST_ROUTE     = '/translate';

	/**
	 * Register WordPress hooks.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'registerRoutes' ) );
	}

	/**
	 * Register the REST route.
	 *
	 * @since  1.1.0
	 * @return void
	 */
	public function registerRoutes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'permissionCheck' ),
				'args'                => array(
					'post_id'         => array(
						'required'          => true,
						'type'              => 'integer',
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					),
					'target_language' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Permission callback — user must be able to edit posts.
	 *
	 * @since  1.1.0
	 * @return bool
	 */
	public function permissionCheck(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Handle a translation request.
	 *
	 * @since  1.1.0
	 * @param  \WP_REST_Request $request Incoming REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function handle( \WP_REST_Request $request ) {
		$post_id         = (int) $request->get_param( 'post_id' );
		$target_language = (string) $request->get_param( 'target_language' );

		// Validate post exists and user can edit it.
		$post = get_post( $post_id );
		if ( ! ( $post instanceof \WP_Post ) ) {
			return new \WP_Error( 'not_found', __( 'Post not found.', 'ai-provider-for-deepseek' ), array( 'status' => 404 ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'forbidden', __( 'You do not have permission to edit this post.', 'ai-provider-for-deepseek' ), array( 'status' => 403 ) );
		}

		// Guard: WordPress AI Client must be available with a DeepSeek model.
		if ( ! PostTranslator::isAvailable() ) {
			return new \WP_Error(
				'ai_unavailable',
				__( 'DeepSeek is not available. Please configure it at Settings → Connectors.', 'ai-provider-for-deepseek' ),
				array( 'status' => 400 )
			);
		}

		// Guard: Polylang must be active.
		if ( ! PolylangHelper::isActive() ) {
			return new \WP_Error(
				'polylang_inactive',
				__( 'Polylang is not active.', 'ai-provider-for-deepseek' ),
				array( 'status' => 400 )
			);
		}

		// Guard: source language must be set.
		$source_lang = PolylangHelper::getPostLanguage( $post_id );
		if ( empty( $source_lang ) ) {
			return new \WP_Error(
				'no_source_lang',
				__( 'This post has no language assigned in Polylang. Please set a language for it first.', 'ai-provider-for-deepseek' ),
				array( 'status' => 400 )
			);
		}

		// Guard: target language must differ from source.
		if ( $source_lang === $target_language ) {
			return new \WP_Error(
				'same_language',
				__( 'Target language must differ from the source language.', 'ai-provider-for-deepseek' ),
				array( 'status' => 400 )
			);
		}

		// Detect whether a translation already exists (used to report is_new in response).
		$existing_id = ( function_exists( 'pll_get_post' ) )
			? (int) pll_get_post( $post_id, $target_language )
			: 0;

		// Translate via WordPress AI Client → DeepSeek.
		$source_language_name = PolylangHelper::getLanguageName( $source_lang );
		$target_language_name = PolylangHelper::getLanguageName( $target_language );

		$translator = new PostTranslator();
		$result     = $translator->translate(
			$post->post_title,
			$post->post_content,
			$source_language_name,
			$target_language_name
		);

		if ( is_wp_error( $result ) ) {
			return new \WP_Error(
				$result->get_error_code(),
				$result->get_error_message(),
				array( 'status' => 500 )
			);
		}

		// Persist the translated post via Polylang.
		$new_post_id = PolylangHelper::saveTranslation(
			$post_id,
			$target_language,
			$result['title'],
			$result['content']
		);

		if ( is_wp_error( $new_post_id ) ) {
			return new \WP_Error(
				$new_post_id->get_error_code(),
				$new_post_id->get_error_message(),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'success'       => true,
				'post_id'       => $new_post_id,
				'is_new'        => ( 0 === $existing_id ),
				'language'      => $target_language_name,
				'language_slug' => $target_language,
				'edit_url'      => get_edit_post_link( $new_post_id, 'raw' ),
			)
		);
	}
}
