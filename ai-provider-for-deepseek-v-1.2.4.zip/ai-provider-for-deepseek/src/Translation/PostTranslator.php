<?php
/**
 * This file contains the definition of the PostTranslator class.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 * @author     Sajjad Hossain Sagor <sagorh672@gmail.com>
 */

declare( strict_types=1 );

namespace Sajjad67\AiProviderForDeepSeek\Translation;

use WordPress\AiClient\Providers\Http\DTO\RequestOptions;

/**
 * Translates post title and content via WordPress 7.0's native AI Client.
 *
 * Uses wp_ai_client_prompt() with a deepseek-chat model preference so the
 * request flows through the Connectors framework — satisfying the Connector
 * Approval system and letting WordPress manage credentials.
 *
 * @since 1.1.0
 */
class PostTranslator {

	/**
	 * Check whether the AI Client is available and can run a text-generation
	 * prompt via a DeepSeek model.
	 *
	 * @since  1.1.0
	 * @return bool
	 */
	public static function isAvailable(): bool {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return false;
		}

		return wp_ai_client_prompt( 'test' )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->is_supported_for_text_generation();
	}

	/**
	 * Translate a post's title and content using the WordPress AI Client.
	 *
	 * Title and content are sent together as a JSON object so both are
	 * translated in a single round-trip. HTML tags inside content are
	 * preserved; only visible text is translated.
	 *
	 * @since  1.1.0
	 * @param  string $title           Post title (plain text).
	 * @param  string $content         Post content (may contain HTML / block markup).
	 * @param  string $source_language Full language name, e.g. "English".
	 * @param  string $target_language Full language name, e.g. "French".
	 * @return array|\WP_Error         Array with 'title' and 'content' keys, or WP_Error on failure.
	 */
	public function translate( string $title, string $content, string $source_language, string $target_language ) {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new \WP_Error(
				'no_ai_client',
				__( 'The WordPress AI Client is not available on this site.', 'ai-provider-for-deepseek' )
			);
		}

		$system_instruction = sprintf(
			'You are a professional translator. ' .
			'The user will send a JSON object with "title" (plain text) and "content" (may contain HTML) keys. ' .
			'Translate both values from %1$s to %2$s. ' .
			'For "content": preserve every HTML tag, attribute, WordPress block comment, and shortcode exactly as-is — translate only visible text nodes. ' .
			'Respond with ONLY a raw JSON object in this exact format, with no markdown fences, no explanation, and no text outside the JSON: ' .
			'{"title":"...","content":"..."}',
			$source_language,
			$target_language
		);

		$user_message = wp_json_encode(
			array(
				'title'   => $title,
				'content' => $content,
			)
		);

		$raw = wp_ai_client_prompt( $user_message )
			->using_system_instruction( $system_instruction )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->using_temperature( 0.2 )
			->using_max_tokens( 8192 )
			->using_request_options(
				RequestOptions::fromArray( array( 'timeout' => 120.0 ) )
			)
			->generate_text();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$translated = $this->decodeJsonResponse( (string) $raw );

		if ( null === $translated || ! isset( $translated['title'], $translated['content'] ) ) {
			return new \WP_Error(
				'deepseek_parse_error',
				__( 'Could not parse the translation response.', 'ai-provider-for-deepseek' )
			);
		}

		return array(
			'title'   => (string) $translated['title'],
			'content' => (string) $translated['content'],
		);
	}

	/**
	 * Decode a JSON string, stripping optional markdown code-fences as a fallback.
	 *
	 * @since  1.1.0
	 * @param  string     $raw Raw string returned by the model.
	 * @return array|null      Decoded array, or null on failure.
	 */
	private function decodeJsonResponse( string $raw ): ?array {
		$decoded = json_decode( $raw, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}

		// Strip markdown code fences (```json … ``` or ``` … ```).
		$cleaned = preg_replace( '/^```(?:json)?\s*/m', '', $raw );
		$cleaned = preg_replace( '/```\s*$/m', '', (string) $cleaned );
		$decoded = json_decode( trim( (string) $cleaned ), true );

		return is_array( $decoded ) ? $decoded : null;
	}
}
