/**
 * DeepSeek Translation meta box — handles the Translate button click,
 * calls the REST endpoint, and displays the result inline.
 *
 * No jQuery dependency; works in both Classic Editor and Block Editor sidebars.
 *
 * @package Sajjad67\AiProviderForDeepSeek
 * @since   1.1.0
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var box = document.getElementById( 'aiprfd-translation-box' );
		if ( ! box ) {
			return;
		}

		var btn      = document.getElementById( 'aiprfd-translate-btn' );
		var select   = document.getElementById( 'aiprfd-target-lang' );
		var statusEl = document.getElementById( 'aiprfd-status' );
		var postId   = parseInt( box.dataset.postId, 10 );

		if ( ! btn || ! select || ! statusEl || ! postId ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			var targetLang = select.value;
			if ( ! targetLang ) {
				return;
			}

			setLoading( true );
			showStatus( 'info', AiprfdTranslation.i18n.translating );

			fetch( AiprfdTranslation.restUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce':   AiprfdTranslation.nonce,
				},
				body: JSON.stringify( {
					post_id:         postId,
					target_language: targetLang,
				} ),
			} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					if ( ! response.ok ) {
						throw new Error( data.message || response.statusText );
					}
					return data;
				} );
			} )
			.then( function ( data ) {
				var message  = data.is_new
					? AiprfdTranslation.i18n.success
					: AiprfdTranslation.i18n.updated;
				var editLink = '<a href="' + escHtml( data.edit_url ) + '" target="_blank" rel="noopener">'
					+ AiprfdTranslation.i18n.editLink
					+ '</a>';
				showStatus( 'success', message + ' ' + editLink );
			} )
			.catch( function ( err ) {
				showStatus( 'error', AiprfdTranslation.i18n.error + escHtml( err.message ) );
			} )
			.finally( function () {
				setLoading( false );
			} );
		} );

		/**
		 * Toggle the button's loading state.
		 *
		 * @param {boolean} loading
		 */
		function setLoading( loading ) {
			btn.disabled = loading;
			btn.classList.toggle( 'aiprfd-is-loading', loading );
		}

		/**
		 * Display a status message inside the meta box.
		 *
		 * @param {'info'|'success'|'error'} type
		 * @param {string}                   html  Safe HTML string.
		 */
		function showStatus( type, html ) {
			statusEl.className = 'aiprfd-status aiprfd-status--' + type;
			statusEl.innerHTML = html;
		}

		/**
		 * Minimal HTML-escape for untrusted strings.
		 *
		 * @param  {string} str
		 * @return {string}
		 */
		function escHtml( str ) {
			var d = document.createElement( 'div' );
			d.appendChild( document.createTextNode( String( str ) ) );
			return d.innerHTML;
		}
	} );
}() );
