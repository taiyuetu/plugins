<?php
/**
 * Plugin Name: Event Calendar with Booking System
 * Description: Display events with RSVP or ticket booking functionality.
 * Version: 1.1.0
 * Author: Pro WordPress Developer
 * Text Domain: ecb
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ECB_VERSION', '1.1.0');
define('ECB_DB_VERSION', '1.1');

final class EventCalendarBooking {

    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        add_action('init', array($this, 'init'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }

    public function load_textdomain() {
        load_plugin_textdomain('ecb', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function activate() {
        $this->create_tables();
        update_option('ecb_db_version', ECB_DB_VERSION);
    }

    public function deactivate() {
        // Intentionally no table drop — preserve data on deactivate.
    }

    public function init() {
        $this->maybe_upgrade_db();
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('ecb_calendar', array($this, 'display_calendar'));
        add_shortcode('ecb_event_form', array($this, 'display_event_form'));
        add_action('wp_ajax_ecb_book_event', array($this, 'handle_booking'));
        add_action('wp_ajax_nopriv_ecb_book_event', array($this, 'handle_booking'));
        add_action('wp_ajax_ecb_add_event', array($this, 'handle_add_event'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_notices', array($this, 'admin_notices'));
    }

    /**
     * Run dbDelta only when schema version changes (not on every front-end request).
     */
    public function maybe_upgrade_db() {
        $installed = get_option('ecb_db_version', '');
        if ($installed !== ECB_DB_VERSION) {
            $this->create_tables();
            update_option('ecb_db_version', ECB_DB_VERSION);
        }
    }

    public function create_tables() {
        global $wpdb;

        $events_table   = $wpdb->prefix . 'ecb_events';
        $bookings_table = $wpdb->prefix . 'ecb_bookings';
        $charset_collate = $wpdb->get_charset_collate();

        // Avoid FOREIGN KEY — many hosts still use MyISAM; dbDelta is also picky about FK syntax.
        $sql_events = "CREATE TABLE $events_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            description text,
            event_date datetime NOT NULL,
            end_date datetime NULL,
            location varchar(255),
            max_attendees int(11) DEFAULT 0,
            price decimal(10,2) DEFAULT 0.00,
            booking_type varchar(20) DEFAULT 'rsvp',
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY event_date (event_date),
            KEY status (status)
        ) $charset_collate;";

        $sql_bookings = "CREATE TABLE $bookings_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            event_id mediumint(9) NOT NULL,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20),
            tickets int(11) DEFAULT 1,
            total_amount decimal(10,2) DEFAULT 0.00,
            booking_status varchar(20) DEFAULT 'confirmed',
            booking_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY event_id (event_id),
            KEY booking_status (booking_status)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_events);
        dbDelta($sql_bookings);
    }

    private function asset_version($relative_file) {
        $path = plugin_dir_path(__FILE__) . $relative_file;
        return file_exists($path) ? (string) filemtime($path) : ECB_VERSION;
    }

    public function enqueue_scripts() {
        $css_ver = $this->asset_version('ecb-style.css');
        $js_ver  = $this->asset_version('ecb-script.js');

        wp_enqueue_style('ecb-style', plugin_dir_url(__FILE__) . 'ecb-style.css', array(), $css_ver);
        wp_enqueue_script('ecb-script', plugin_dir_url(__FILE__) . 'ecb-script.js', array('jquery'), $js_ver, true);

        wp_localize_script(
            'ecb-script',
            'ecb_ajax',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('ecb_nonce'),
                'i18n'     => array(
                    'required_fields' => __('Please fill in all required fields.', 'ecb'),
                    'generic_error'   => __('An error occurred. Please try again.', 'ecb'),
                    'event_full'      => __('Event is fully booked.', 'ecb'),
                ),
            )
        );
    }

    /**
     * Convert HTML datetime-local value to MySQL datetime in site timezone.
     *
     * @param string $value Raw value from input.
     * @return string|null  Y-m-d H:i:s or null if invalid/empty.
     */
    private function datetime_local_to_mysql($value) {
        $value = is_string($value) ? trim($value) : '';
        if ($value === '') {
            return null;
        }

        $dt = DateTime::createFromFormat('Y-m-d\TH:i', $value, wp_timezone());
        if (!$dt) {
            $dt = date_create($value, wp_timezone());
        }
        if (!$dt) {
            return null;
        }

        return $dt->format('Y-m-d H:i:s');
    }

    public function display_calendar($atts) {
        $atts = shortcode_atts(
            array(
                'limit'     => 10,
                'show_past' => 'no',
                'category'  => '',
            ),
            $atts,
            'ecb_calendar'
        );

        global $wpdb;
        $events_table   = $wpdb->prefix . 'ecb_events';
        $bookings_table = $wpdb->prefix . 'ecb_bookings';

        $where_parts = array('e.status = %s');
        $prepare_args = array('active');

        if ($atts['show_past'] === 'no') {
            $where_parts[] = 'e.event_date >= %s';
            $prepare_args[] = current_time('mysql');
        }

        $keyword = isset($atts['category']) ? sanitize_text_field($atts['category']) : '';
        if ($keyword !== '') {
            $like = '%' . $wpdb->esc_like($keyword) . '%';
            $where_parts[] = '(e.title LIKE %s OR e.description LIKE %s)';
            $prepare_args[] = $like;
            $prepare_args[] = $like;
        }

        $where_sql = 'WHERE ' . implode(' AND ', $where_parts);

        $sql = "SELECT e.*,
                   COALESCE(SUM(b.tickets), 0) AS booked_tickets
            FROM $events_table e
            LEFT JOIN $bookings_table b ON e.id = b.event_id AND b.booking_status = 'confirmed'
            $where_sql
            GROUP BY e.id
            ORDER BY e.event_date ASC
            LIMIT %d";

        $prepare_args[] = absint($atts['limit']);
        $events = $wpdb->get_results($wpdb->prepare($sql, $prepare_args));

        ob_start();
        ?>
        <div class="ecb-calendar">
            <div class="ecb-filter-bar">
                <div class="ecb-filter-group">
                    <label for="ecb-filter-type"><?php esc_html_e('Filter events:', 'ecb'); ?></label>
                    <select id="ecb-filter-type">
                        <option value=""><?php esc_html_e('All events', 'ecb'); ?></option>
                        <option value="rsvp"><?php esc_html_e('RSVP events', 'ecb'); ?></option>
                        <option value="ticket"><?php esc_html_e('Paid events', 'ecb'); ?></option>
                    </select>
                </div>
            </div>

            <?php if (empty($events)) : ?>
                <p><?php esc_html_e('No events found.', 'ecb'); ?></p>
            <?php else : ?>
                <div class="ecb-event-grid">
                    <?php foreach ($events as $event) : ?>
                        <div class="ecb-event-card" data-type="<?php echo esc_attr($event->booking_type); ?>">
                            <div class="ecb-event-title"><?php echo esc_html($event->title); ?></div>
                            <div class="ecb-event-date">
                                <?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($event->event_date))); ?>
                                <?php if (!empty($event->end_date)) : ?>
                                    – <?php echo esc_html(wp_date(get_option('time_format'), strtotime($event->end_date))); ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($event->location) : ?>
                                <div class="ecb-event-location"><?php echo esc_html($event->location); ?></div>
                            <?php endif; ?>
                            <?php if ($event->description) : ?>
                                <div class="ecb-event-description"><?php echo wp_kses_post($event->description); ?></div>
                            <?php endif; ?>
                            <?php if ((float) $event->price > 0) : ?>
                                <div class="ecb-event-price"><?php echo esc_html(sprintf(__('Price: %s', 'ecb'), wp_strip_all_tags(wc_price_compat_ecb((float) $event->price)))); ?></div>
                            <?php else : ?>
                                <div class="ecb-event-price"><?php esc_html_e('Free event', 'ecb'); ?></div>
                            <?php endif; ?>

                            <?php
                            $booked_int       = (int) $event->booked_tickets;
                            $max_int          = (int) $event->max_attendees;
                            $available_spots  = $max_int > 0 ? ($max_int - $booked_int) : PHP_INT_MAX;
                            $is_full          = $max_int > 0 && $available_spots <= 0;
                            $event_ts         = strtotime($event->event_date);
                            $is_future        = $event_ts > current_time('timestamp');
                            ?>

                            <?php if ($max_int > 0) : ?>
                                <div class="ecb-attendees-info">
                                    <?php
                                    echo esc_html(
                                        sprintf(
                                            /* translators: 1: booked count, 2: max attendees */
                                            __('%1$d / %2$d spots filled', 'ecb'),
                                            $booked_int,
                                            $max_int
                                        )
                                    );
                                    ?>
                                    <?php if ($available_spots > 0 && $available_spots !== PHP_INT_MAX) : ?>
                                        <?php echo ' ' . esc_html(sprintf(__('(%d available)', 'ecb'), $available_spots)); ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!$is_full && $is_future) : ?>
                                <form class="ecb-booking-form">
                                    <input type="hidden" name="event_id" value="<?php echo esc_attr((string) $event->id); ?>">

                                    <div class="ecb-form-group">
                                        <label for="ecb-name-<?php echo esc_attr((string) $event->id); ?>"><?php esc_html_e('Name', 'ecb'); ?> <span class="required">*</span></label>
                                        <input id="ecb-name-<?php echo esc_attr((string) $event->id); ?>" type="text" name="name" required autocomplete="name">
                                    </div>

                                    <div class="ecb-form-group">
                                        <label for="ecb-email-<?php echo esc_attr((string) $event->id); ?>"><?php esc_html_e('Email', 'ecb'); ?> <span class="required">*</span></label>
                                        <input id="ecb-email-<?php echo esc_attr((string) $event->id); ?>" type="email" name="email" required autocomplete="email">
                                    </div>

                                    <div class="ecb-form-group">
                                        <label for="ecb-phone-<?php echo esc_attr((string) $event->id); ?>"><?php esc_html_e('Phone', 'ecb'); ?></label>
                                        <input id="ecb-phone-<?php echo esc_attr((string) $event->id); ?>" type="tel" name="phone" autocomplete="tel">
                                    </div>

                                    <?php if ($event->booking_type === 'ticket') : ?>
                                        <div class="ecb-form-group">
                                            <label for="ecb-tickets-<?php echo esc_attr((string) $event->id); ?>"><?php esc_html_e('Number of tickets', 'ecb'); ?></label>
                                            <input id="ecb-tickets-<?php echo esc_attr((string) $event->id); ?>" type="number" name="tickets" value="1" min="1" max="<?php echo esc_attr((string) ($max_int > 0 ? min(50, $available_spots) : 50)); ?>">
                                        </div>
                                    <?php endif; ?>

                                    <button type="submit" class="ecb-btn ecb-btn-success">
                                        <?php echo $event->booking_type === 'rsvp' ? esc_html__('RSVP now', 'ecb') : esc_html__('Book tickets', 'ecb'); ?>
                                    </button>
                                </form>
                            <?php elseif ($is_full) : ?>
                                <div class="ecb-message" role="status"><?php esc_html_e('Event is fully booked.', 'ecb'); ?></div>
                            <?php else : ?>
                                <div class="ecb-message" role="status"><?php esc_html_e('This event has ended.', 'ecb'); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function display_event_form() {
        if (!current_user_can('manage_options')) {
            return '<p class="ecb-event-form-denied">' . esc_html__('You do not have permission to create events.', 'ecb') . '</p>';
        }

        ob_start();
        ?>
        <div class="ecb-event-form-wrap">
            <h3><?php esc_html_e('Add new event', 'ecb'); ?></h3>
            <form class="ecb-event-form" method="post">
                <div class="ecb-form-group">
                    <label for="ecb-evt-title"><?php esc_html_e('Event title', 'ecb'); ?> <span class="required">*</span></label>
                    <input id="ecb-evt-title" type="text" name="title" required maxlength="255">
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-desc"><?php esc_html_e('Description', 'ecb'); ?></label>
                    <textarea id="ecb-evt-desc" name="description" rows="4"></textarea>
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-start"><?php esc_html_e('Event date', 'ecb'); ?> <span class="required">*</span></label>
                    <input id="ecb-evt-start" type="datetime-local" name="event_date" required>
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-end"><?php esc_html_e('End date', 'ecb'); ?></label>
                    <input id="ecb-evt-end" type="datetime-local" name="end_date">
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-loc"><?php esc_html_e('Location', 'ecb'); ?></label>
                    <input id="ecb-evt-loc" type="text" name="location" maxlength="255">
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-max"><?php esc_html_e('Max attendees (0 = unlimited)', 'ecb'); ?></label>
                    <input id="ecb-evt-max" type="number" name="max_attendees" value="0" min="0">
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-price"><?php esc_html_e('Price', 'ecb'); ?></label>
                    <input id="ecb-evt-price" type="number" name="price" value="0" min="0" step="0.01">
                </div>

                <div class="ecb-form-group">
                    <label for="ecb-evt-type"><?php esc_html_e('Booking type', 'ecb'); ?></label>
                    <select id="ecb-evt-type" name="booking_type">
                        <option value="rsvp"><?php esc_html_e('RSVP (free)', 'ecb'); ?></option>
                        <option value="ticket"><?php esc_html_e('Ticket (paid)', 'ecb'); ?></option>
                    </select>
                </div>

                <button type="submit" class="ecb-btn"><?php esc_html_e('Create event', 'ecb'); ?></button>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    public function handle_booking() {
        check_ajax_referer('ecb_nonce', 'nonce');

        global $wpdb;
        $events_table   = $wpdb->prefix . 'ecb_events';
        $bookings_table = $wpdb->prefix . 'ecb_bookings';

        $event_id = isset($_POST['event_id']) ? absint($_POST['event_id']) : 0;
        $name     = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $email    = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $phone    = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $tickets  = isset($_POST['tickets']) ? absint($_POST['tickets']) : 1;

        if ($event_id <= 0 || $name === '' || !is_email($email)) {
            wp_send_json_error(array('message' => __('Please provide a valid name and email.', 'ecb')));
        }

        $event = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $events_table WHERE id = %d AND status = %s",
                $event_id,
                'active'
            )
        );

        if (!$event) {
            wp_send_json_error(array('message' => __('Event not found.', 'ecb')));
        }

        if (strtotime($event->event_date) <= current_time('timestamp')) {
            wp_send_json_error(array('message' => __('This event is no longer accepting bookings.', 'ecb')));
        }

        if ($event->booking_type === 'rsvp') {
            $tickets = 1;
        } else {
            $tickets = max(1, $tickets);
        }

        $max_int = (int) $event->max_attendees;

        if ($max_int > 0) {
            $booked_tickets = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COALESCE(SUM(tickets), 0) FROM $bookings_table WHERE event_id = %d AND booking_status = %s",
                    $event_id,
                    'confirmed'
                )
            );

            if ($booked_tickets + $tickets > $max_int) {
                wp_send_json_error(array('message' => __('Not enough spots available.', 'ecb')));
            }
        }

        $total_amount = (float) $event->price * $tickets;

        $result = $wpdb->insert(
            $bookings_table,
            array(
                'event_id'       => $event_id,
                'name'           => $name,
                'email'          => $email,
                'phone'          => $phone,
                'tickets'        => $tickets,
                'total_amount'   => $total_amount,
                'booking_status' => 'confirmed',
            ),
            array('%d', '%s', '%s', '%s', '%d', '%f', '%s')
        );

        if (!$result) {
            wp_send_json_error(array('message' => __('Booking failed. Please try again.', 'ecb')));
        }

        $new_booked = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(tickets), 0) FROM $bookings_table WHERE event_id = %d AND booking_status = %s",
                $event_id,
                'confirmed'
            )
        );

        $payload = array(
            'message' => '',
            'booked'  => $new_booked,
            'max'     => $max_int,
        );

        if ($max_int > 0) {
            $payload['spots_remaining'] = max(0, $max_int - $new_booked);
        }

        if ($event->booking_type === 'rsvp') {
            $payload['message'] = __('RSVP confirmed! Thank you.', 'ecb');
        } else {
            $payload['message'] = sprintf(
                /* translators: %s formatted price */
                __('Booking confirmed. Total: %s', 'ecb'),
                wp_strip_all_tags(wc_price_compat_ecb($total_amount))
            );
        }

        wp_send_json_success($payload);
    }

    public function handle_add_event() {
        check_ajax_referer('ecb_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to create events.', 'ecb')), 403);
        }

        global $wpdb;
        $events_table = $wpdb->prefix . 'ecb_events';

        $title       = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
        $description = isset($_POST['description']) ? wp_kses_post(wp_unslash($_POST['description'])) : '';
        $event_raw   = isset($_POST['event_date']) ? wp_unslash($_POST['event_date']) : '';
        $end_raw     = isset($_POST['end_date']) ? wp_unslash($_POST['end_date']) : '';
        $location    = isset($_POST['location']) ? sanitize_text_field(wp_unslash($_POST['location'])) : '';
        $max_attendees = isset($_POST['max_attendees']) ? absint($_POST['max_attendees']) : 0;
        $price       = isset($_POST['price']) ? (float) $_POST['price'] : 0.0;
        $booking_type = isset($_POST['booking_type']) ? sanitize_key(wp_unslash($_POST['booking_type'])) : 'rsvp';

        if (!in_array($booking_type, array('rsvp', 'ticket'), true)) {
            $booking_type = 'rsvp';
        }

        $event_date = $this->datetime_local_to_mysql(is_string($event_raw) ? $event_raw : '');
        $end_date   = $this->datetime_local_to_mysql(is_string($end_raw) ? $end_raw : '');

        if ($title === '' || !$event_date) {
            wp_send_json_error(array('message' => __('Title and a valid event date are required.', 'ecb')));
        }

        if ($end_date && strtotime($end_date) < strtotime($event_date)) {
            wp_send_json_error(array('message' => __('End date must be after the start date.', 'ecb')));
        }

        $result = $wpdb->insert(
            $events_table,
            array(
                'title'          => $title,
                'description'    => $description,
                'event_date'     => $event_date,
                'end_date'       => $end_date ?: null,
                'location'       => $location,
                'max_attendees'  => $max_attendees,
                'price'          => $price,
                'booking_type'   => $booking_type,
                'status'         => 'active',
            ),
            array('%s', '%s', '%s', '%s', '%s', '%d', '%f', '%s', '%s')
        );

        if ($result) {
            wp_send_json_success(array('message' => __('Event created successfully.', 'ecb')));
        }

        wp_send_json_error(array('message' => __('Failed to create event. Please try again.', 'ecb')));
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Event calendar', 'ecb'),
            __('Event calendar', 'ecb'),
            'manage_options',
            'ecb-events',
            array($this, 'admin_page'),
            'dashicons-calendar-alt',
            30
        );

        add_submenu_page(
            'ecb-events',
            __('Bookings', 'ecb'),
            __('Bookings', 'ecb'),
            'manage_options',
            'ecb-bookings',
            array($this, 'bookings_page')
        );
    }

    public function admin_notices() {
        if (!isset($_GET['ecb_msg'])) {
            return;
        }
        if (!current_user_can('manage_options')) {
            return;
        }
        $msg = sanitize_key(wp_unslash($_GET['ecb_msg']));
        if ($msg === 'booking_cancelled') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Booking cancelled.', 'ecb') . '</p></div>';
        }
    }

    public function admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $wpdb;
        $events_table   = $wpdb->prefix . 'ecb_events';
        $bookings_table = $wpdb->prefix . 'ecb_bookings';

        $events = $wpdb->get_results("SELECT * FROM $events_table ORDER BY event_date DESC");
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Event calendar management', 'ecb'); ?></h1>

            <h2><?php esc_html_e('Shortcodes', 'ecb'); ?></h2>
            <p><code>[ecb_calendar]</code> — <?php esc_html_e('Display the event list and booking forms.', 'ecb'); ?></p>
            <p><code>[ecb_event_form]</code> — <?php esc_html_e('Front-end event creation (administrators only).', 'ecb'); ?></p>

            <h2><?php esc_html_e('Events', 'ecb'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Title', 'ecb'); ?></th>
                        <th><?php esc_html_e('Date', 'ecb'); ?></th>
                        <th><?php esc_html_e('Type', 'ecb'); ?></th>
                        <th><?php esc_html_e('Price', 'ecb'); ?></th>
                        <th><?php esc_html_e('Bookings', 'ecb'); ?></th>
                        <th><?php esc_html_e('Status', 'ecb'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($events as $event) : ?>
                        <?php
                        $booking_count = (int) $wpdb->get_var(
                            $wpdb->prepare(
                                "SELECT COUNT(*) FROM $bookings_table WHERE event_id = %d AND booking_status = %s",
                                $event->id,
                                'confirmed'
                            )
                        );
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($event->title); ?></strong>
                                <div class="row-actions">
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=ecb-bookings&event_id=' . absint($event->id))); ?>"><?php esc_html_e('View bookings', 'ecb'); ?></a>
                                </div>
                            </td>
                            <td><?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($event->event_date))); ?></td>
                            <td><?php echo esc_html(ucfirst($event->booking_type)); ?></td>
                            <td><?php echo esc_html(wp_strip_all_tags(wc_price_compat_ecb((float) $event->price))); ?></td>
                            <td>
                                <?php
                                echo esc_html((string) $booking_count);
                                echo $event->max_attendees ? ' / ' . esc_html((string) (int) $event->max_attendees) : '';
                                ?>
                            </td>
                            <td><?php echo esc_html(ucfirst($event->status)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function bookings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $wpdb;
        $events_table   = $wpdb->prefix . 'ecb_events';
        $bookings_table = $wpdb->prefix . 'ecb_bookings';

        $event_id = isset($_GET['event_id']) ? absint($_GET['event_id']) : 0;

        if ($event_id) {
            $event = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $events_table WHERE id = %d", $event_id)
            );

            if (!$event) {
                echo '<div class="wrap"><p>' . esc_html__('Event not found.', 'ecb') . '</p>';
                echo '<p><a href="' . esc_url(admin_url('admin.php?page=ecb-bookings')) . '">' . esc_html__('Back to all bookings', 'ecb') . '</a></p></div>';
                return;
            }

            $this->maybe_handle_booking_action_redirect($event_id);

            $bookings = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT b.*, e.title AS event_title
                     FROM $bookings_table b
                     INNER JOIN $events_table e ON b.event_id = e.id
                     WHERE b.event_id = %d
                     ORDER BY b.booking_date DESC",
                    $event_id
                )
            );

            ?>
            <div class="wrap">
                <h1><?php echo esc_html(sprintf(__('Bookings for: %s', 'ecb'), $event->title)); ?></h1>
                <p><a href="<?php echo esc_url(admin_url('admin.php?page=ecb-bookings')); ?>">&larr; <?php esc_html_e('Back to all bookings', 'ecb'); ?></a></p>

                <?php if (empty($bookings)) : ?>
                    <p><?php esc_html_e('No bookings found for this event.', 'ecb'); ?></p>
                <?php else : ?>
                    <?php $this->render_bookings_table($bookings, true); ?>
                    <div style="margin-top: 20px;">
                        <h2><?php esc_html_e('Summary', 'ecb'); ?></h2>
                        <p><?php echo esc_html(sprintf(__('Total bookings: %d', 'ecb'), count($bookings))); ?></p>
                        <p><?php echo esc_html(sprintf(__('Total revenue: %s', 'ecb'), wp_strip_all_tags(wc_price_compat_ecb(array_sum(array_map('floatval', array_column($bookings, 'total_amount'))))))); ?></p>
                        <p><?php echo esc_html(sprintf(__('Total tickets: %d', 'ecb'), array_sum(array_map('intval', array_column($bookings, 'tickets'))))); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            <?php
            return;
        }

        $this->maybe_handle_booking_action_redirect(0);

        $selected_event = isset($_GET['filter_event']) ? absint($_GET['filter_event']) : 0;

        $where_clause = '';
        $prepare_args = array();
        if ($selected_event) {
            $where_clause = 'WHERE b.event_id = %d';
            $prepare_args[] = $selected_event;
        }

        $sql = "SELECT b.*, e.title AS event_title, e.event_date
                 FROM $bookings_table b
                 INNER JOIN $events_table e ON b.event_id = e.id
                 $where_clause
                 ORDER BY b.booking_date DESC
                 LIMIT 100";

        if (!empty($prepare_args)) {
            $bookings = $wpdb->get_results($wpdb->prepare($sql, $prepare_args));
        } else {
            $bookings = $wpdb->get_results($sql);
        }

        $events = $wpdb->get_results("SELECT id, title FROM $events_table ORDER BY title ASC");

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('All bookings', 'ecb'); ?></h1>

            <div style="margin: 20px 0;">
                <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                    <input type="hidden" name="page" value="ecb-bookings">
                    <label class="screen-reader-text" for="ecb-filter-event"><?php esc_html_e('Filter by event', 'ecb'); ?></label>
                    <select id="ecb-filter-event" name="filter_event" onchange="this.form.submit()">
                        <option value="0"><?php esc_html_e('All events', 'ecb'); ?></option>
                        <?php foreach ($events as $ev) : ?>
                            <option value="<?php echo esc_attr((string) $ev->id); ?>" <?php selected($selected_event, (int) $ev->id); ?>>
                                <?php echo esc_html($ev->title); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'ecb'); ?>">
                </form>
            </div>

            <?php if (empty($bookings)) : ?>
                <p><?php esc_html_e('No bookings found.', 'ecb'); ?></p>
            <?php else : ?>
                <?php $this->render_bookings_table($bookings, false); ?>
            <?php endif; ?>

            <?php if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['booking_id'])) : ?>
                <?php $this->show_booking_detail(absint($_GET['booking_id'])); ?>
            <?php endif; ?>
        </div>

        <style>
            .booking-status-confirmed { color: #27ae60; font-weight: bold; }
            .booking-status-pending { color: #f39c12; font-weight: bold; }
            .booking-status-cancelled { color: #e74c3c; font-weight: bold; }
        </style>
        <?php
    }

    /**
     * @param object[] $bookings Rows from DB.
     * @param bool     $for_single_event Whether links should keep event_id context.
     */
    private function render_bookings_table(array $bookings, $for_single_event) {
        $base_args = array('page' => 'ecb-bookings');
        if ($for_single_event && isset($_GET['event_id'])) {
            $base_args['event_id'] = absint($_GET['event_id']);
        }

        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <?php if (!$for_single_event) : ?>
                        <th><?php esc_html_e('Event', 'ecb'); ?></th>
                    <?php endif; ?>
                    <th><?php esc_html_e('Customer', 'ecb'); ?></th>
                    <th><?php esc_html_e('Email', 'ecb'); ?></th>
                    <th><?php esc_html_e('Phone', 'ecb'); ?></th>
                    <th><?php esc_html_e('Tickets', 'ecb'); ?></th>
                    <th><?php esc_html_e('Amount', 'ecb'); ?></th>
                    <th><?php esc_html_e('Status', 'ecb'); ?></th>
                    <th><?php esc_html_e('Booking date', 'ecb'); ?></th>
                    <th><?php esc_html_e('Actions', 'ecb'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $booking) : ?>
                    <tr>
                        <?php if (!$for_single_event) : ?>
                            <td>
                                <strong><?php echo esc_html($booking->event_title); ?></strong>
                                <br><small><?php echo esc_html(wp_date(get_option('date_format'), strtotime($booking->event_date))); ?></small>
                            </td>
                        <?php endif; ?>
                        <td><?php echo esc_html($booking->name); ?></td>
                        <td><?php echo esc_html($booking->email); ?></td>
                        <td><?php echo esc_html($booking->phone); ?></td>
                        <td><?php echo esc_html((string) (int) $booking->tickets); ?></td>
                        <td><?php echo esc_html(wp_strip_all_tags(wc_price_compat_ecb((float) $booking->total_amount))); ?></td>
                        <td>
                            <span class="booking-status-<?php echo esc_attr($booking->booking_status); ?>">
                                <?php echo esc_html(ucfirst($booking->booking_status)); ?>
                            </span>
                        </td>
                        <td><?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($booking->booking_date))); ?></td>
                        <td>
                            <?php
                            $view_url = add_query_arg(
                                array_merge($base_args, array('action' => 'view', 'booking_id' => (int) $booking->id)),
                                admin_url('admin.php')
                            );
                            ?>
                            <a href="<?php echo esc_url($view_url); ?>" class="button button-small"><?php esc_html_e('View', 'ecb'); ?></a>
                            <?php if ($booking->booking_status === 'confirmed') : ?>
                                <?php
                                $cancel_url = wp_nonce_url(
                                    add_query_arg(
                                        array_merge(
                                            $base_args,
                                            array(
                                                'action'     => 'cancel',
                                                'booking_id' => (int) $booking->id,
                                            )
                                        ),
                                        admin_url('admin.php')
                                    ),
                                    'cancel_booking_' . (int) $booking->id,
                                    '_wpnonce'
                                );
                                ?>
                                <a href="<?php echo esc_url($cancel_url); ?>" class="button button-small" onclick="return confirm('<?php echo esc_js(__('Cancel this booking?', 'ecb')); ?>')"><?php esc_html_e('Cancel', 'ecb'); ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Process cancel action early and redirect (PRG) so the list reflects updates.
     *
     * @param int $context_event_id 0 when on “all bookings” screen.
     */
    private function maybe_handle_booking_action_redirect($context_event_id) {
        if (!isset($_GET['action'], $_GET['booking_id'])) {
            return;
        }

        $action = sanitize_key(wp_unslash($_GET['action']));
        if ($action !== 'cancel') {
            return;
        }

        $booking_id = absint($_GET['booking_id']);
        if ($booking_id <= 0) {
            return;
        }

        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'cancel_booking_' . $booking_id)) {
            wp_die(esc_html__('Security check failed.', 'ecb'));
        }

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'ecb'));
        }

        global $wpdb;
        $bookings_table = $wpdb->prefix . 'ecb_bookings';

        $wpdb->update(
            $bookings_table,
            array('booking_status' => 'cancelled'),
            array('id' => $booking_id),
            array('%s'),
            array('%d')
        );

        $redirect_args = array('page' => 'ecb-bookings', 'ecb_msg' => 'booking_cancelled');
        if ($context_event_id > 0) {
            $redirect_args['event_id'] = $context_event_id;
        }

        wp_safe_redirect(add_query_arg($redirect_args, admin_url('admin.php')));
        exit;
    }

    private function show_booking_detail($booking_id) {
        global $wpdb;
        $bookings_table = $wpdb->prefix . 'ecb_bookings';
        $events_table   = $wpdb->prefix . 'ecb_events';

        $booking = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT b.*, e.title AS event_title, e.event_date, e.location, e.booking_type
                 FROM $bookings_table b
                 INNER JOIN $events_table e ON b.event_id = e.id
                 WHERE b.id = %d",
                $booking_id
            )
        );

        if (!$booking) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Booking not found.', 'ecb') . '</p></div>';
            return;
        }
        ?>
        <div id="booking-detail-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 500px; width: 90%;">
                <h2><?php esc_html_e('Booking details', 'ecb'); ?></h2>

                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Booking ID', 'ecb'); ?></th>
                        <td>#<?php echo esc_html((string) (int) $booking->id); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Event', 'ecb'); ?></th>
                        <td><?php echo esc_html($booking->event_title); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Event date', 'ecb'); ?></th>
                        <td><?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($booking->event_date))); ?></td>
                    </tr>
                    <?php if ($booking->location) : ?>
                        <tr>
                            <th><?php esc_html_e('Location', 'ecb'); ?></th>
                            <td><?php echo esc_html($booking->location); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <th><?php esc_html_e('Customer name', 'ecb'); ?></th>
                        <td><?php echo esc_html($booking->name); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Email', 'ecb'); ?></th>
                        <td><?php echo esc_html($booking->email); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Phone', 'ecb'); ?></th>
                        <td><?php echo esc_html($booking->phone ? $booking->phone : __('Not provided', 'ecb')); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Tickets', 'ecb'); ?></th>
                        <td><?php echo esc_html((string) (int) $booking->tickets); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Total amount', 'ecb'); ?></th>
                        <td><?php echo esc_html(wp_strip_all_tags(wc_price_compat_ecb((float) $booking->total_amount))); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Booking type', 'ecb'); ?></th>
                        <td><?php echo esc_html(ucfirst($booking->booking_type)); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Status', 'ecb'); ?></th>
                        <td>
                            <span class="booking-status-<?php echo esc_attr($booking->booking_status); ?>">
                                <?php echo esc_html(ucfirst($booking->booking_status)); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Booking date', 'ecb'); ?></th>
                        <td><?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($booking->booking_date))); ?></td>
                    </tr>
                </table>

                <div style="margin-top: 20px; text-align: right;">
                    <?php
                    $close_url = admin_url('admin.php?page=ecb-bookings');
                    if (isset($_GET['event_id'])) {
                        $close_url = add_query_arg('event_id', absint($_GET['event_id']), $close_url);
                    }
                    ?>
                    <a href="<?php echo esc_url($close_url); ?>" class="button button-primary"><?php esc_html_e('Close', 'ecb'); ?></a>
                    <?php if ($booking->booking_status === 'confirmed') : ?>
                        <?php
                        $cancel_url = wp_nonce_url(
                            add_query_arg(
                                array(
                                    'page'       => 'ecb-bookings',
                                    'action'     => 'cancel',
                                    'booking_id' => (int) $booking->id,
                                ),
                                admin_url('admin.php')
                            ),
                            'cancel_booking_' . (int) $booking->id,
                            '_wpnonce'
                        );
                        if (isset($_GET['event_id'])) {
                            $cancel_url = add_query_arg('event_id', absint($_GET['event_id']), $cancel_url);
                        }
                        ?>
                        <a href="<?php echo esc_url($cancel_url); ?>" class="button" onclick="return confirm('<?php echo esc_js(__('Cancel this booking?', 'ecb')); ?>')"><?php esc_html_e('Cancel booking', 'ecb'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

/**
 * Format money without depending on WooCommerce.
 *
 * @param float $amount Amount.
 * @return string HTML-safe formatted price (escaped by callers where needed).
 */
function wc_price_compat_ecb($amount) {
    return function_exists('wc_price')
        ? wc_price($amount)
        : sprintf('$%s', number_format_i18n((float) $amount, 2));
}

new EventCalendarBooking();
