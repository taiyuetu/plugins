(function ($) {
    'use strict';

    function ecbClearMessages($container) {
        $container.find('.ecb-message').remove();
    }

    function ecbShowMessage($container, html, isError) {
        ecbClearMessages($container);
        var cls = isError ? 'ecb-error' : 'ecb-success';
        $container.append(
            $('<div class="ecb-message ' + cls + '" role="alert"></div>').html(html)
        );
        setTimeout(function () {
            $container.find('.ecb-message').fadeOut(400, function () {
                $(this).remove();
            });
        }, 8000);
    }

    $(document).on('submit', '.ecb-booking-form', function (e) {
        e.preventDefault();
        var $form = $(this);
        var $card = $form.closest('.ecb-event-card');
        var eventId = $form.find('input[name="event_id"]').val();
        var name = $.trim($form.find('input[name="name"]').val());
        var email = $.trim($form.find('input[name="email"]').val());
        var phone = $.trim($form.find('input[name="phone"]').val());
        var $ticketsInput = $form.find('input[name="tickets"]');
        var tickets = $ticketsInput.length ? parseInt($ticketsInput.val(), 10) : 1;
        if (isNaN(tickets) || tickets < 1) {
            tickets = 1;
        }

        if (!name || !email) {
            ecbShowMessage($form, ecb_ajax.i18n.required_fields, true);
            return;
        }

        var $btn = $form.find('button[type="submit"]');
        $btn.prop('disabled', true);

        $.ajax({
            url: ecb_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'ecb_book_event',
                nonce: ecb_ajax.nonce,
                event_id: eventId,
                name: name,
                email: email,
                phone: phone,
                tickets: tickets
            }
        })
            .done(function (response) {
                if (response.success) {
                    $form.html(
                        '<div class="ecb-message ecb-success" role="status">' +
                            $('<span/>').text(response.data.message).html() +
                            '</div>'
                    );
                    if ($card.length && response.data.max > 0 && response.data.spots_remaining !== undefined) {
                        var $info = $card.find('.ecb-attendees-info');
                        if ($info.length && response.data.booked != null && response.data.max != null) {
                            var max = parseInt(response.data.max, 10);
                            var booked = parseInt(response.data.booked, 10);
                            var avail = parseInt(response.data.spots_remaining, 10);
                            if (max > 0) {
                                $info.text(
                                    booked +
                                        '/' +
                                        max +
                                        ' spots filled' +
                                        (avail > 0 ? ' (' + avail + ' available)' : '')
                                );
                            }
                            if (avail <= 0) {
                                $card.find('.ecb-booking-form').remove();
                                if (!$card.find('.ecb-message:not(.ecb-success)').length) {
                                    $card.append(
                                        '<div class="ecb-message" role="status">' +
                                            $('<span/>').text(ecb_ajax.i18n.event_full).html() +
                                            '</div>'
                                    );
                                }
                            }
                        }
                    }
                } else {
                    ecbShowMessage(
                        $form,
                        response.data && response.data.message
                            ? response.data.message
                            : ecb_ajax.i18n.generic_error,
                        true
                    );
                }
            })
            .fail(function () {
                ecbShowMessage($form, ecb_ajax.i18n.generic_error, true);
            })
            .always(function () {
                $btn.prop('disabled', false);
            });
    });

    $(document).on('submit', 'form.ecb-event-form', function (e) {
        e.preventDefault();
        var $form = $(this);
        var $wrap = $form.closest('.ecb-event-form-wrap');
        var $target = $wrap.length ? $wrap : $form;

        ecbClearMessages($target);
        var $btn = $form.find('button[type="submit"]');
        $btn.prop('disabled', true);

        $.ajax({
            url: ecb_ajax.ajax_url,
            type: 'POST',
            data:
                $form.serialize() +
                '&action=ecb_add_event&nonce=' +
                encodeURIComponent(ecb_ajax.nonce)
        })
            .done(function (response) {
                if (response.success) {
                    $form[0].reset();
                    ecbShowMessage($target, response.data.message, false);
                } else {
                    ecbShowMessage(
                        $target,
                        response.data && response.data.message
                            ? response.data.message
                            : ecb_ajax.i18n.generic_error,
                        true
                    );
                }
            })
            .fail(function () {
                ecbShowMessage($target, ecb_ajax.i18n.generic_error, true);
            })
            .always(function () {
                $btn.prop('disabled', false);
            });
    });

    $(document).on('change', '#ecb-filter-type', function () {
        var filterValue = $(this).val();
        if (filterValue === '') {
            $('.ecb-event-card').show();
        } else {
            $('.ecb-event-card').hide();
            $('.ecb-event-card[data-type="' + filterValue + '"]').show();
        }
    });
})(jQuery);
