/**
 * DeepSeek Bulk Translate — scans for untranslated content and translates
 * items via the REST API using a small parallel worker pool (see DsapBulk.parallelLimit).
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var typeSelect    = document.getElementById( 'dsap-bulk-type' );
		var langSelect    = document.getElementById( 'dsap-bulk-lang' );
		var scanBtn       = document.getElementById( 'dsap-scan-btn' );
		var bulkBtn       = document.getElementById( 'dsap-bulk-btn' );
		var stopBtn       = document.getElementById( 'dsap-stop-btn' );
		var progressWrap  = document.getElementById( 'dsap-bulk-progress' );
		var progressFill  = document.getElementById( 'dsap-progress-fill' );
		var progressText  = document.getElementById( 'dsap-progress-text' );
		var resultsTable  = document.getElementById( 'dsap-results-table' );
		var resultsBody   = document.getElementById( 'dsap-results-body' );
		var logWrap       = document.getElementById( 'dsap-bulk-log' );
		var logEntries    = document.getElementById( 'dsap-log-entries' );

		if ( ! scanBtn || ! bulkBtn ) {
			return;
		}

		var items       = [];
		var stopped     = false;
		var running     = false;
		var completed   = 0;
		var failed      = 0;
		var nextQueueIdx = 0;
		var inFlight      = 0;

		scanBtn.addEventListener( 'click', doScan );
		bulkBtn.addEventListener( 'click', doTranslateAll );
		stopBtn.addEventListener( 'click', function () { stopped = true; } );

		function doScan() {
			var parsed = parseType();
			var lang   = langSelect.value;

			if ( ! lang ) { return; }

			items     = [];
			completed = 0;
			failed    = 0;
			stopped   = false;

			resultsBody.innerHTML = '';
			resultsTable.style.display = 'none';
			logEntries.innerHTML = '';
			logWrap.style.display = 'none';
			progressWrap.style.display = 'none';
			bulkBtn.disabled = true;

			addLog( DsapBulk.i18n.scanning );

			var perPage = 500;
			var basePath;
			if ( parsed.kind === 'post_type' ) {
				basePath = DsapBulk.restBase + '/untranslated-posts?post_type=' + encodeURIComponent( parsed.value ) + '&target_lang=' + encodeURIComponent( lang );
			} else {
				basePath = DsapBulk.restBase + '/untranslated-terms?taxonomy=' + encodeURIComponent( parsed.value ) + '&target_lang=' + encodeURIComponent( lang );
			}

			function fetchAllPages( page, accumulated ) {
				var endpoint = basePath + '&per_page=' + perPage + '&page=' + page;
				return apiFetch( endpoint ).then( function ( data ) {
					var batch = data.items || [];
					var next  = accumulated.concat( batch );
					var total = data.total;
					var hasMore;
					if ( typeof total === 'number' && total >= 0 ) {
						hasMore = page * perPage < total;
					} else {
						/* If total is missing, infer another page only when this page is full. */
						hasMore = batch.length === perPage;
					}
					if ( hasMore ) {
						return fetchAllPages( page + 1, next );
					}
					return next;
				} );
			}

			fetchAllPages( 1, [] )
			.then( function ( rawItems ) {

				rawItems.forEach( function ( item ) {
					var langs = item.missing_langs || [];
					langs.forEach( function ( ml ) {
						if ( lang && ml !== lang ) { return; }
						items.push( {
							id:          item.id || item.term_id,
							title:       item.title || item.name,
							type:        parsed.value,
							kind:        parsed.kind,
							taxonomy:    parsed.kind === 'taxonomy' ? parsed.value : '',
							source_lang: item.source_lang,
							target_lang: ml,
							status:      'pending',
						} );
					} );
				} );

				if ( items.length === 0 ) {
					addLog( DsapBulk.i18n.noItems, 'success' );
					return;
				}

				addLog( DsapBulk.i18n.found.replace( '%d', items.length ) );
				renderTable();
				bulkBtn.disabled = false;
			} )
			.catch( function ( err ) {
				addLog( 'Error: ' + err.message, 'error' );
			} );
		}

		function doTranslateAll() {
			if ( running || items.length === 0 ) { return; }

			running   = true;
			stopped   = false;
			completed = 0;
			failed    = 0;

			scanBtn.disabled  = true;
			bulkBtn.disabled  = true;
			stopBtn.style.display = '';
			progressWrap.style.display = '';
			logWrap.style.display = '';

			updateProgress();

			nextQueueIdx = 0;
			inFlight      = 0;
			pumpWorkers();
		}

		function getParallelLimit() {
			var n = parseInt( DsapBulk.parallelLimit, 10 );
			if ( ! isFinite( n ) || n < 1 ) {
				return 3;
			}
			return Math.min( n, 12 );
		}

		/**
		 * Keep up to parallelLimit translate requests in flight until the queue is empty or stopped.
		 */
		function pumpWorkers() {
			var limit = getParallelLimit();

			while ( ! stopped && inFlight < limit && nextQueueIdx < items.length ) {
				var idx = nextQueueIdx;
				nextQueueIdx++;
				inFlight++;
				runTranslateJob( idx );
			}

			if ( inFlight === 0 && ( stopped || nextQueueIdx >= items.length ) ) {
				finish();
			}
		}

		function runTranslateJob( idx ) {
			var item = items[ idx ];
			item.status = 'progress';
			updateRow( idx );
			updateProgress();

			addLog( DsapBulk.i18n.translating.replace( '%d', idx + 1 ).replace( '%d', items.length ) + ' — ' + escHtml( item.title ) );

			var endpoint, body;
			if ( item.kind === 'post_type' ) {
				endpoint = DsapBulk.restBase + '/translate-post';
				body = { post_id: item.id, target_lang: item.target_lang };
			} else {
				endpoint = DsapBulk.restBase + '/translate-term';
				body = { term_id: item.id, taxonomy: item.taxonomy, target_lang: item.target_lang };
			}

			apiFetch( endpoint, 'POST', body )
			.then( function () {
				item.status = 'success';
				completed++;
				addLog( escHtml( item.title ) + ' — ' + DsapBulk.i18n.success, 'success' );
			} )
			.catch( function ( err ) {
				item.status = 'error';
				item.error  = err.message;
				failed++;
				addLog( escHtml( item.title ) + ' — ' + err.message, 'error' );
			} )
			.finally( function () {
				inFlight--;
				updateRow( idx );
				updateProgress();
				pumpWorkers();
			} );
		}

		function finish() {
			if ( ! running ) {
				return;
			}
			running = false;
			scanBtn.disabled  = false;
			bulkBtn.disabled  = false;
			stopBtn.style.display = 'none';

			if ( stopped ) {
				addLog( DsapBulk.i18n.stopped.replace( '%d', completed ).replace( '%d', items.length ) );
			} else {
				addLog( DsapBulk.i18n.done.replace( '%d', completed ).replace( '%d', failed ), completed > 0 ? 'success' : '' );
			}
		}

		function renderTable() {
			resultsBody.innerHTML = '';
			resultsTable.style.display = '';

			items.forEach( function ( item, idx ) {
				var tr = document.createElement( 'tr' );
				tr.id = 'dsap-row-' + idx;
				tr.innerHTML =
					'<td>' + item.id + '</td>' +
					'<td>' + escHtml( item.title ) + '</td>' +
					'<td>' + escHtml( item.type ) + '</td>' +
					'<td>' + escHtml( item.source_lang ) + ' &rarr; ' + escHtml( item.target_lang ) + '</td>' +
					'<td><span class="dsap-status-badge dsap-status-badge--pending">' + DsapBulk.i18n.pending + '</span></td>';
				resultsBody.appendChild( tr );
			} );
		}

		function updateRow( idx ) {
			var item = items[ idx ];
			var tr   = document.getElementById( 'dsap-row-' + idx );
			if ( ! tr ) { return; }

			var statusCell = tr.querySelector( 'td:last-child' );
			var map = {
				pending:  { cls: 'pending',  text: DsapBulk.i18n.pending },
				progress: { cls: 'progress', text: DsapBulk.i18n.inProgress },
				success:  { cls: 'success',  text: DsapBulk.i18n.success },
				error:    { cls: 'error',    text: DsapBulk.i18n.failed + ( item.error ? ': ' + item.error : '' ) },
			};
			var s = map[ item.status ] || map.pending;
			statusCell.innerHTML = '<span class="dsap-status-badge dsap-status-badge--' + s.cls + '">' + escHtml( s.text ) + '</span>';
		}

		function updateProgress() {
			var done  = completed + failed;
			var total = items.length;
			var pct   = total > 0 ? Math.round( ( done / total ) * 100 ) : 0;

			progressFill.style.width = pct + '%';
			progressText.textContent = done + ' / ' + total + ' (' + pct + '%)';
		}

		function addLog( message, type ) {
			logWrap.style.display = '';
			var div = document.createElement( 'div' );
			div.className = 'dsap-log-entry' + ( type ? ' dsap-log-entry--' + type : '' );

			var time = new Date().toLocaleTimeString();
			div.innerHTML = '<span class="dsap-log-time">[' + time + ']</span> ' + message;

			logEntries.appendChild( div );
			logEntries.scrollTop = logEntries.scrollHeight;
		}

		function parseType() {
			var val   = typeSelect.value;
			var parts = val.split( ':' );
			return { kind: parts[0], value: parts[1] };
		}

		function apiFetch( url, method, body ) {
			var opts = {
				method:  method || 'GET',
				headers: {
					'X-WP-Nonce':   DsapBulk.nonce,
					'Content-Type': 'application/json',
				},
			};
			if ( body ) {
				opts.body = JSON.stringify( body );
			}

			return fetch( url, opts ).then( function ( res ) {
				return res.text().then( function ( text ) {
					var data = {};
					if ( text ) {
						var trimmed = text.trim();
						if ( trimmed ) {
							try {
								data = JSON.parse( trimmed );
							} catch ( parseErr ) {
								var snippet = trimmed.replace( /\s+/g, ' ' ).slice( 0, 200 );
								throw new Error(
									'HTTP ' + res.status + ' — response was not valid JSON' +
									( snippet ? ' (' + snippet + ')' : '' )
								);
							}
						}
					}
					if ( ! res.ok ) {
						throw new Error( data.message || data.code || res.statusText || ( 'HTTP ' + res.status ) );
					}
					return data;
				} );
			} );
		}

		function escHtml( str ) {
			var d = document.createElement( 'div' );
			d.appendChild( document.createTextNode( String( str || '' ) ) );
			return d.innerHTML;
		}
	} );
}() );
