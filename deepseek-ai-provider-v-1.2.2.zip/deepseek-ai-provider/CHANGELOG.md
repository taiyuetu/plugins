# Changelog

All notable changes to **DeepSeek AI Provider** are recorded in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)
where versions are tagged.

## [Unreleased]

Nothing yet.

## [1.2.2] - 2026-06-08

### Added

- Bulk translate UI runs multiple `translate-post` / `translate-term` REST requests in parallel (default **3** concurrent jobs, max **12**). Tune with the `dsap_bulk_translate_parallel_limit` filter (integer, clamped 1–12 server-side).
- Bulk scan requests every page of untranslated posts/terms (500 per request) until the full queue is loaded, not only the first page; if `total` is missing, the client keeps requesting while each page returns a full batch (500).

## [1.2.1] - 2026-06-08

### Fixed

- Bulk and term translation failing with JSON parse errors when the model returned fenced JSON, leading prose, UTF-8 issues, or DeepSeek-R1-style reasoning blocks before the JSON object.
- Term translation: added a second API attempt with a stricter “single line of minified JSON” system prompt when the first response could not be parsed.
- PHP `max_execution_time` cutting off long `translate-post` / `translate-term` REST requests mid-run (multi-chunk posts).

### Changed

- **Performance:** Replaced `wp_cache_flush()` on every Polylang save with targeted `clean_post_cache()` / `clean_term_cache()` for source and target IDs only.
- **Performance:** `getUntranslatedPosts` and `getUntranslatedTerms` now scan post/term IDs in batches (500 per query) instead of loading all IDs at once (`posts_per_page => -1` / unbounded term lists).
- **Models:** Translation calls default to `deepseek-chat` only. Use the `dsap_translation_model_preference` filter to append `deepseek-reasoner` (or other models) if needed.
- **REST:** `BulkTranslationController::translatePost` and `translateTerm` call `@set_time_limit( 0 )` after validating the post/term so long translations can finish when the host allows it.
- **Bulk UI:** `assets/js/bulk-translate.js` — `apiFetch` reads the response as text first; invalid JSON (e.g. HTML error pages) surfaces HTTP status plus a short body snippet instead of a bare parse exception.

### Added

- `decodeJsonResponse` improvements: strip reasoning blocks, extract first balanced `{...}` JSON object, decode with `JSON_INVALID_UTF8_SUBSTITUTE`, markdown fence handling.
- `dsap_translation_model_preference` filter (default: `array( 'deepseek-chat' )`) to customize the model chain for all translation API calls.
- When `WP_DEBUG` is true, term JSON parse failures log truncated raw model output to `error_log` for diagnosis.
- Polylang inactive responses for untranslated scans now return a consistent shape: `total`, `page`, `per_page`, `items` (empty array).

## [1.2.0]

### Changed

- Plugin header version set to **1.2.0** (in-repo changelog for this line did not exist until `CHANGELOG.md` was added; see **1.2.1** for the first dated technical notes).

## [1.0.0]

### Added

- Initial release.
- WordPress AI Client SDK provider registration for DeepSeek.
- Single post translation via the “DeepSeek Translation” meta box.
- Bulk translation admin page (Tools → Bulk Translate) for posts, products, custom post types, and taxonomy terms.
- Polylang integration: link translations, sync taxonomy terms and post meta, preserve featured images.
- MySQL `GET_LOCK`-based safety when saving linked translations concurrently.
- HTML / block comment / shortcode preservation during AI translation.
