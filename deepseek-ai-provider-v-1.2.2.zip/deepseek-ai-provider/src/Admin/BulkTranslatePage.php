<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Admin;

use DeepSeekAiProvider\Translation\PolylangHelper;
use DeepSeekAiProvider\Translation\PostTranslator;

/**
 * Admin page: Tools > DeepSeek Bulk Translate
 *
 * One-click bulk translation for posts, pages, products, and taxonomy terms.
 */
class BulkTranslatePage {

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'addPage' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueueAssets' ) );
	}

	public function addPage(): void {
		add_management_page(
			__( 'DeepSeek Bulk Translate', 'deepseek-ai-provider' ),
			__( 'Bulk Translate', 'deepseek-ai-provider' ),
			'manage_options',
			'dsap-bulk-translate',
			array( $this, 'renderPage' )
		);
	}

	public function renderPage(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$polylang_active = PolylangHelper::isActive();
		$ai_available    = PostTranslator::isAvailable();
		$languages       = $polylang_active ? PolylangHelper::getLanguages() : array();
		$default_lang    = $polylang_active ? PolylangHelper::getDefaultLanguage() : '';

		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );

		// Remove internal Polylang taxonomies
		$skip_tax = array( 'language', 'term_language', 'post_translations', 'term_translations' );
		foreach ( $skip_tax as $s ) {
			unset( $taxonomies[ $s ] );
		}
		?>
		<div class="wrap" id="dsap-bulk-wrap">
			<h1><?php esc_html_e( 'DeepSeek Bulk Translate', 'deepseek-ai-provider' ); ?></h1>

			<?php if ( ! $polylang_active ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'Polylang plugin is not active. Please install and activate Polylang first.', 'deepseek-ai-provider' ); ?></p></div>
				<?php return; ?>
			<?php endif; ?>

			<?php if ( ! $ai_available ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					printf(
						esc_html__( 'DeepSeek AI is not configured. Please add your API key at %s.', 'deepseek-ai-provider' ),
						'<a href="' . esc_url( admin_url( 'options-general.php?page=wp-connectors' ) ) . '">Settings &gt; Connectors</a>'
					);
					?>
				</p></div>
			<?php endif; ?>

			<div class="dsap-bulk-controls">
				<div class="dsap-control-row">
					<div class="dsap-field">
						<label for="dsap-bulk-type"><?php esc_html_e( 'Content Type', 'deepseek-ai-provider' ); ?></label>
						<select id="dsap-bulk-type" class="dsap-select">
							<optgroup label="<?php esc_attr_e( 'Post Types', 'deepseek-ai-provider' ); ?>">
								<?php foreach ( $post_types as $pt ) : ?>
									<option value="post_type:<?php echo esc_attr( $pt->name ); ?>">
										<?php echo esc_html( $pt->labels->name ); ?>
									</option>
								<?php endforeach; ?>
							</optgroup>
							<optgroup label="<?php esc_attr_e( 'Taxonomies', 'deepseek-ai-provider' ); ?>">
								<?php foreach ( $taxonomies as $tax ) : ?>
									<option value="taxonomy:<?php echo esc_attr( $tax->name ); ?>">
										<?php echo esc_html( $tax->labels->name ); ?>
									</option>
								<?php endforeach; ?>
							</optgroup>
						</select>
					</div>

					<div class="dsap-field">
						<label for="dsap-bulk-lang"><?php esc_html_e( 'Translate to', 'deepseek-ai-provider' ); ?></label>
						<select id="dsap-bulk-lang" class="dsap-select">
							<?php foreach ( $languages as $slug => $name ) : ?>
								<?php if ( $slug !== $default_lang ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
								<?php endif; ?>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="dsap-field dsap-field--actions">
						<button type="button" id="dsap-scan-btn" class="button button-secondary">
							<?php esc_html_e( 'Scan Untranslated', 'deepseek-ai-provider' ); ?>
						</button>
						<button type="button" id="dsap-bulk-btn" class="button button-primary" disabled>
							<?php esc_html_e( 'Translate All', 'deepseek-ai-provider' ); ?>
						</button>
						<button type="button" id="dsap-stop-btn" class="button button-link-delete" style="display:none;">
							<?php esc_html_e( 'Stop', 'deepseek-ai-provider' ); ?>
						</button>
					</div>
				</div>
			</div>

			<div id="dsap-bulk-progress" class="dsap-progress" style="display:none;">
				<div class="dsap-progress-bar">
					<div class="dsap-progress-fill" id="dsap-progress-fill"></div>
				</div>
				<div class="dsap-progress-text" id="dsap-progress-text"></div>
			</div>

			<div id="dsap-bulk-results" class="dsap-results">
				<table class="wp-list-table widefat fixed striped" id="dsap-results-table" style="display:none;">
					<thead>
						<tr>
							<th class="dsap-col-id"><?php esc_html_e( 'ID', 'deepseek-ai-provider' ); ?></th>
							<th class="dsap-col-title"><?php esc_html_e( 'Title / Name', 'deepseek-ai-provider' ); ?></th>
							<th class="dsap-col-type"><?php esc_html_e( 'Type', 'deepseek-ai-provider' ); ?></th>
							<th class="dsap-col-source"><?php esc_html_e( 'Source', 'deepseek-ai-provider' ); ?></th>
							<th class="dsap-col-status"><?php esc_html_e( 'Status', 'deepseek-ai-provider' ); ?></th>
						</tr>
					</thead>
					<tbody id="dsap-results-body"></tbody>
				</table>
			</div>

			<div id="dsap-bulk-log" class="dsap-log" style="display:none;">
				<h3><?php esc_html_e( 'Activity Log', 'deepseek-ai-provider' ); ?></h3>
				<div id="dsap-log-entries" class="dsap-log-entries"></div>
			</div>
		</div>
		<?php
	}

	public function enqueueAssets( string $hook ): void {
		if ( $hook !== 'tools_page_dsap-bulk-translate' ) {
			return;
		}

		wp_enqueue_style(
			'dsap-bulk',
			DSAP_PLUGIN_URL . 'assets/css/bulk-translate.css',
			array(),
			DSAP_VERSION
		);

		wp_enqueue_script(
			'dsap-bulk',
			DSAP_PLUGIN_URL . 'assets/js/bulk-translate.js',
			array(),
			DSAP_VERSION,
			true
		);

		$parallel = (int) apply_filters( 'dsap_bulk_translate_parallel_limit', 3 );
		$parallel = max( 1, min( 12, $parallel ) );

		wp_localize_script(
			'dsap-bulk',
			'DsapBulk',
			array(
				'restBase'      => esc_url_raw( rest_url( 'deepseek-ai-provider/v1/bulk' ) ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'parallelLimit' => $parallel,
				'i18n'          => array(
					'scanning'    => __( 'Scanning for untranslated content...', 'deepseek-ai-provider' ),
					'found'       => __( '%d items need translation', 'deepseek-ai-provider' ),
					'noItems'     => __( 'All content is already translated!', 'deepseek-ai-provider' ),
					'translating' => __( 'Translating %d of %d...', 'deepseek-ai-provider' ),
					'done'        => __( 'Done! %d items translated successfully, %d failed.', 'deepseek-ai-provider' ),
					'stopped'     => __( 'Stopped. %d of %d completed.', 'deepseek-ai-provider' ),
					'pending'     => __( 'Pending', 'deepseek-ai-provider' ),
					'inProgress'  => __( 'Translating...', 'deepseek-ai-provider' ),
					'success'     => __( 'Done', 'deepseek-ai-provider' ),
					'failed'      => __( 'Failed', 'deepseek-ai-provider' ),
				),
			)
		);
	}
}
