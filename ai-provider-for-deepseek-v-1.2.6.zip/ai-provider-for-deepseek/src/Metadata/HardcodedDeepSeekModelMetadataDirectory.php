<?php
/**
 * This file contains the definition of the HardcodedDeepSeekModelMetadataDirectory class.
 *
 * Used as a compatibility fallback on WordPress installations whose bundled
 * PHP AI Client SDK does not yet include AbstractOpenAiCompatibleModelMetadataDirectory.
 * Instead of making a live API call to list models, it returns a hardcoded list of
 * the two primary DeepSeek models so that the provider can register and function normally.
 *
 * @package    Sajjad67\AiProviderForDeepSeek
 * @subpackage Sajjad67\AiProviderForDeepSeek/src
 */

declare(strict_types=1);

namespace Sajjad67\AiProviderForDeepSeek\Metadata;

use WordPress\AiClient\Common\Exception\InvalidArgumentException;
use WordPress\AiClient\Messages\Enums\ModalityEnum;
use WordPress\AiClient\Providers\Contracts\ModelMetadataDirectoryInterface;
use WordPress\AiClient\Providers\Models\DTO\ModelMetadata;
use WordPress\AiClient\Providers\Models\DTO\SupportedOption;
use WordPress\AiClient\Providers\Models\Enums\CapabilityEnum;
use WordPress\AiClient\Providers\Models\Enums\OptionEnum;

/**
 * Hardcoded model metadata directory for DeepSeek.
 *
 * Returns a static list of the two primary DeepSeek models without making any
 * API requests. Used as a fallback when the WordPress AI Client SDK is too old
 * to provide AbstractOpenAiCompatibleModelMetadataDirectory.
 *
 * @since 1.2.1
 */
class HardcodedDeepSeekModelMetadataDirectory implements ModelMetadataDirectoryInterface {

	/**
	 * Cached model map, keyed by model ID.
	 *
	 * @since 1.2.1
	 * @var array<string, ModelMetadata>|null
	 */
	private ?array $models = null;

	/**
	 * Builds and returns the hardcoded model map.
	 *
	 * @since  1.2.1
	 * @return array<string, ModelMetadata>
	 */
	private function getModels(): array {
		if ( null !== $this->models ) {
			return $this->models;
		}

		$base_options = array(
			new SupportedOption( OptionEnum::systemInstruction() ),
			new SupportedOption( OptionEnum::maxTokens() ),
			new SupportedOption( OptionEnum::temperature() ),
			new SupportedOption( OptionEnum::topP() ),
			new SupportedOption( OptionEnum::stopSequences() ),
			new SupportedOption( OptionEnum::presencePenalty() ),
			new SupportedOption( OptionEnum::frequencyPenalty() ),
			new SupportedOption( OptionEnum::logprobs() ),
			new SupportedOption( OptionEnum::topLogprobs() ),
			new SupportedOption( OptionEnum::outputMimeType(), array( 'text/plain', 'application/json' ) ),
			new SupportedOption( OptionEnum::outputSchema() ),
			new SupportedOption( OptionEnum::customOptions() ),
			new SupportedOption( OptionEnum::inputModalities(), array( array( ModalityEnum::text() ) ) ),
			new SupportedOption( OptionEnum::outputModalities(), array( array( ModalityEnum::text() ) ) ),
		);

		$chat_options = array_merge(
			$base_options,
			array( new SupportedOption( OptionEnum::functionDeclarations() ) )
		);

		$capabilities = array( CapabilityEnum::textGeneration(), CapabilityEnum::chatHistory() );

		$this->models = array(
			'deepseek-chat'     => new ModelMetadata(
				'deepseek-chat',
				'DeepSeek-V3 (Chat)',
				$capabilities,
				$chat_options
			),
			'deepseek-reasoner' => new ModelMetadata(
				'deepseek-reasoner',
				'DeepSeek-R1 (Reasoner)',
				$capabilities,
				$base_options
			),
		);

		return $this->models;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since 1.2.1
	 */
	public function listModelMetadata(): array {
		return array_values( $this->getModels() );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since 1.2.1
	 */
	public function hasModelMetadata( string $modelId ): bool {
		return isset( $this->getModels()[ $modelId ] );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since  1.2.1
	 * @throws InvalidArgumentException If the model ID is not recognised.
	 */
	public function getModelMetadata( string $modelId ): ModelMetadata {
		$models = $this->getModels();

		if ( ! isset( $models[ $modelId ] ) ) {
			throw new InvalidArgumentException(
				sprintf( 'No model with ID %s was found in the DeepSeek provider.', $modelId )
			);
		}

		return $models[ $modelId ];
	}
}
