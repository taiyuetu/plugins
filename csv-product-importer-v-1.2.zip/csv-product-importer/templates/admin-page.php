<?php defined( 'ABSPATH' ) || exit; ?>

<div id="cpi-wrap">

  <!-- ── Header ── -->
  <div class="cpi-header">
    <div class="cpi-logo">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="17 8 12 3 7 8"/>
        <line x1="12" y1="3" x2="12" y2="15"/>
      </svg>
    </div>
    <div class="cpi-header-text">
      <h1><?php esc_html_e( 'CSV Product Importer', 'csv-product-importer' ); ?></h1>
      <p><?php echo esc_html( CPI_Config::DESCRIPTION ); ?></p>
    </div>
    <span class="cpi-version-badge">v<?php echo esc_html( CPI_VERSION ); ?></span>
  </div>

  <!-- ── Main ── -->
  <div class="cpi-main">

    <!-- Left column: import workflow -->
    <div class="cpi-left">

      <!-- Step 1: Upload -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <span class="cpi-step-num">1</span>
          <div>
            <h2><?php esc_html_e( 'Choose your CSV file', 'csv-product-importer' ); ?></h2>
            <p class="cpi-card-header-sub"><?php esc_html_e( 'Drag &amp; drop or click the area below to browse', 'csv-product-importer' ); ?></p>
          </div>
        </div>
        <div class="cpi-card-body">
          <div id="cpi-dropzone" class="cpi-dropzone">
            <div class="cpi-dropzone-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="12" y1="12" x2="12" y2="18"/>
                <polyline points="9 15 12 12 15 15"/>
              </svg>
            </div>
            <h3><?php esc_html_e( 'Drop your CSV file here', 'csv-product-importer' ); ?></h3>
            <p><?php esc_html_e( 'or', 'csv-product-importer' ); ?> <span class="cpi-link"><?php esc_html_e( 'browse files', 'csv-product-importer' ); ?></span></p>
          </div>
          <input type="file" id="cpi-file-input" class="cpi-file-input" accept=".csv,text/csv">
          <div id="cpi-file-selected" class="cpi-file-selected"></div>
          <div class="cpi-sample-download">
            <a href="<?php echo esc_url( CPI_PLUGIN_URL . 'sample.csv' ); ?>" download="sample-products.csv" class="cpi-btn cpi-btn-sample">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
              <?php esc_html_e( 'Download sample CSV', 'csv-product-importer' ); ?>
            </a>
            <span class="cpi-sample-hint"><?php esc_html_e( 'Not sure about the format? Use this template as a starting point.', 'csv-product-importer' ); ?></span>
          </div>
        </div>
      </div>

      <!-- Step 2: Settings -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <span class="cpi-step-num">2</span>
          <div>
            <h2><?php esc_html_e( 'Import settings', 'csv-product-importer' ); ?></h2>
            <p class="cpi-card-header-sub"><?php esc_html_e( 'Configure how duplicates and post status are handled', 'csv-product-importer' ); ?></p>
          </div>
        </div>
        <div class="cpi-card-body">
          <div class="cpi-options-grid">
            <div class="cpi-field">
              <label for="cpi-duplicate"><?php esc_html_e( 'If a product already exists', 'csv-product-importer' ); ?></label>
              <select id="cpi-duplicate">
                <option value="skip"><?php esc_html_e( 'Skip it', 'csv-product-importer' ); ?></option>
                <option value="update"><?php esc_html_e( 'Update with new data', 'csv-product-importer' ); ?></option>
                <option value="duplicate"><?php esc_html_e( 'Create a duplicate', 'csv-product-importer' ); ?></option>
              </select>
              <p class="cpi-field-hint"><?php esc_html_e( 'Matched by the unique key column.', 'csv-product-importer' ); ?></p>
            </div>
            <div class="cpi-field">
              <label for="cpi-status"><?php esc_html_e( 'Imported post status', 'csv-product-importer' ); ?></label>
              <select id="cpi-status">
                <option value="publish"><?php esc_html_e( 'Published', 'csv-product-importer' ); ?></option>
                <option value="draft"><?php esc_html_e( 'Draft', 'csv-product-importer' ); ?></option>
                <option value="pending"><?php esc_html_e( 'Pending review', 'csv-product-importer' ); ?></option>
              </select>
              <p class="cpi-field-hint"><?php esc_html_e( 'You can change this in WordPress any time.', 'csv-product-importer' ); ?></p>
            </div>

            <?php
            // Language selector — only rendered when Polylang is active
            if ( function_exists( 'pll_languages_list' ) ) :
                $pll_slugs = pll_languages_list( [ 'fields' => 'slug' ] );
                $pll_names = pll_languages_list( [ 'fields' => 'name' ] );
                $pll_langs = ! empty( $pll_slugs ) ? array_combine( $pll_slugs, $pll_names ) : [];
            ?>
            <div class="cpi-field cpi-field-language">
              <label for="cpi-language">
                <?php esc_html_e( 'Assign to language', 'csv-product-importer' ); ?>
                <span class="cpi-polylang-badge">Polylang</span>
              </label>
              <select id="cpi-language">
                <option value=""><?php esc_html_e( '— No language assignment —', 'csv-product-importer' ); ?></option>
                <?php foreach ( $pll_langs as $slug => $name ) : ?>
                  <option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
                <?php endforeach; ?>
              </select>
              <p class="cpi-field-hint"><?php esc_html_e( 'All products in this CSV will be assigned to the selected language. The same OEM number can be imported once per language.', 'csv-product-importer' ); ?></p>
            </div>
            <?php endif; ?>

            <?php if ( CPI_Config::taxonomy_enabled() ) :
                $category_options = CPI_Config::get_taxonomy_term_options();
            ?>
            <div class="cpi-field cpi-field-category">
              <label for="cpi-product-category"><?php esc_html_e( 'Default product category', 'csv-product-importer' ); ?></label>
              <select id="cpi-product-category">
                <option value=""><?php esc_html_e( '— None (use CSV column only) —', 'csv-product-importer' ); ?></option>
                <?php foreach ( $category_options as $opt ) : ?>
                  <option value="<?php echo esc_attr( (string) $opt['id'] ); ?>">
                    <?php echo esc_html( str_repeat( '— ', $opt['depth'] ) . $opt['name'] ); ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <p class="cpi-field-hint">
                <?php
                printf(
                    /* translators: %s: CSV column name */
                    esc_html__( 'Applied when the optional "%s" CSV column is empty. Per-row values in the CSV override this.', 'csv-product-importer' ),
                    esc_html( CPI_Config::TAXONOMY_COLUMN )
                );
                ?>
              </p>
            </div>
            <?php endif; ?>

          </div>
        </div>
      </div>

      <!-- Step 3: Run -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <span class="cpi-step-num">3</span>
          <div>
            <h2><?php esc_html_e( 'Preview &amp; run import', 'csv-product-importer' ); ?></h2>
            <p class="cpi-card-header-sub"><?php esc_html_e( 'Review the first rows, then start the full import', 'csv-product-importer' ); ?></p>
          </div>
        </div>
        <div class="cpi-card-body">

          <!-- Progress -->
          <div id="cpi-progress-wrap" class="cpi-progress-wrap" style="display:none">
            <div class="cpi-progress-label">
              <span id="cpi-progress-text"><?php esc_html_e( 'Ready', 'csv-product-importer' ); ?></span>
              <span id="cpi-progress-pct">0%</span>
            </div>
            <div class="cpi-progress-track">
              <div id="cpi-progress-bar" class="cpi-progress-bar"></div>
            </div>
          </div>

          <!-- Action buttons -->
          <div class="cpi-btn-row">
            <button id="cpi-btn-preview" class="cpi-btn cpi-btn-secondary" disabled>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              <?php esc_html_e( 'Preview CSV', 'csv-product-importer' ); ?>
            </button>
            <button id="cpi-btn-import" class="cpi-btn cpi-btn-primary" disabled>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="23 4 23 10 17 10"/>
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
              </svg>
              <?php esc_html_e( 'Start import', 'csv-product-importer' ); ?>
            </button>
          </div>

          <!-- Feedback -->
          <div id="cpi-result" class="cpi-result"></div>
          <div id="cpi-import-details" class="cpi-result" style="display:none"></div>

        </div>
      </div>

      <!-- Preview table (shown after Preview click) -->
      <div id="cpi-preview-section" class="cpi-preview-section">
        <div class="cpi-card">
          <div class="cpi-card-header">
            <div class="cpi-card-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <path d="M3 9h18M3 15h18M9 3v18"/>
              </svg>
            </div>
            <h2><?php esc_html_e( 'CSV preview — first 10 rows', 'csv-product-importer' ); ?></h2>
          </div>
          <div class="cpi-card-body" style="padding:0">
            <div class="cpi-table-wrap">
              <table class="cpi-table">
                <thead id="cpi-preview-thead"></thead>
                <tbody id="cpi-preview-body"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div><!-- /.cpi-left -->

    <!-- Right column: stats & reference -->
    <div class="cpi-right">

      <!-- Live stats -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <div class="cpi-card-icon">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="20" x2="18" y2="10"/>
              <line x1="12" y1="20" x2="12" y2="4"/>
              <line x1="6"  y1="20" x2="6"  y2="14"/>
            </svg>
          </div>
          <h2><?php esc_html_e( 'Import statistics', 'csv-product-importer' ); ?></h2>
        </div>
        <div class="cpi-card-body">
          <div class="cpi-stats-grid">
            <div class="cpi-stat imported">
              <div class="cpi-stat-num" id="stat-imported">0</div>
              <div class="cpi-stat-label"><?php esc_html_e( 'Imported', 'csv-product-importer' ); ?></div>
            </div>
            <div class="cpi-stat updated">
              <div class="cpi-stat-num" id="stat-updated">0</div>
              <div class="cpi-stat-label"><?php esc_html_e( 'Updated', 'csv-product-importer' ); ?></div>
            </div>
            <div class="cpi-stat skipped">
              <div class="cpi-stat-num" id="stat-skipped">0</div>
              <div class="cpi-stat-label"><?php esc_html_e( 'Skipped', 'csv-product-importer' ); ?></div>
            </div>
            <div class="cpi-stat errors">
              <div class="cpi-stat-num" id="stat-errors">0</div>
              <div class="cpi-stat-label"><?php esc_html_e( 'Errors', 'csv-product-importer' ); ?></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Title generation rule -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <div class="cpi-card-icon">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/>
              <line x1="7" y1="7" x2="7.01" y2="7"/>
            </svg>
          </div>
          <h2><?php esc_html_e( 'How titles are built', 'csv-product-importer' ); ?></h2>
        </div>
        <div class="cpi-card-body">
          <div class="cpi-rule-box">
            <?php esc_html_e( 'Each product title is auto-generated from these columns:', 'csv-product-importer' ); ?>
            <div class="cpi-rule-formula"><?php echo esc_html( CPI_Config::title_formula_display() ); ?></div>
          </div>
        </div>
      </div>

      <!-- Column reference -->
      <div class="cpi-card">
        <div class="cpi-card-header">
          <div class="cpi-card-icon">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <path d="M3 9h18M3 15h18M9 3v18"/>
            </svg>
          </div>
          <h2><?php esc_html_e( 'CSV columns', 'csv-product-importer' ); ?></h2>
        </div>
        <div class="cpi-card-body">
          <ul class="cpi-field-list">
            <?php if ( '' !== CPI_Config::TITLE_ONLY_COLUMN ) : ?>
              <li>
                <span class="cpi-col-name"><?php echo esc_html( CPI_Config::TITLE_ONLY_COLUMN ); ?></span>
                <span class="cpi-col-arrow">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </span>
                <span class="badge title-only"><?php esc_html_e( 'title only', 'csv-product-importer' ); ?></span>
              </li>
            <?php endif; ?>
            <?php foreach ( CPI_Config::META_MAP as $col => $meta_key ) : ?>
              <li>
                <span class="cpi-col-name"><?php echo esc_html( $col ); ?></span>
                <span class="cpi-col-arrow">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </span>
                <span class="badge"><?php echo esc_html( $meta_key ); ?></span>
              </li>
            <?php endforeach; ?>
            <?php if ( CPI_Config::taxonomy_enabled() && '' !== CPI_Config::TAXONOMY_COLUMN ) : ?>
              <li>
                <span class="cpi-col-name"><?php echo esc_html( CPI_Config::TAXONOMY_COLUMN ); ?></span>
                <span class="cpi-col-arrow">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </span>
                <span class="badge taxonomy"><?php echo esc_html( CPI_Config::TAXONOMY ); ?></span>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>

      <!-- Danger zone -->
      <div class="cpi-danger-zone">
        <div class="cpi-danger-title">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
          <?php esc_html_e( 'Danger zone', 'csv-product-importer' ); ?>
        </div>
        <p><?php esc_html_e( 'This permanently deletes all products imported by this plugin. It cannot be undone.', 'csv-product-importer' ); ?></p>
        <button id="cpi-btn-clear" class="cpi-btn cpi-btn-danger">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
            <path d="M10 11v6M14 11v6"/>
            <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
          </svg>
          <?php esc_html_e( 'Delete all products', 'csv-product-importer' ); ?>
        </button>
      </div>

    </div><!-- /.cpi-right -->
  </div><!-- /.cpi-main -->

</div><!-- /#cpi-wrap -->
