<?php
defined( 'ABSPATH' ) || exit;

/**
 * Parses a CSV file into structured product rows.
 *
 * Required columns and title logic are driven by CPI_Config — edit that file
 * to adapt the importer to a different product type.
 */
class CPI_CSV_Parser {

    /**
     * Parse the uploaded CSV file.
     *
     * @param string $file_path Absolute path to the uploaded CSV.
     * @return array{headers: string[], rows: array[], errors: string[]}
     */
    public static function parse( string $file_path ): array {
        $result = [
            'headers' => [],
            'rows'    => [],
            'errors'  => [],
        ];

        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            $result['errors'][] = __( 'File not found or not readable.', 'csv-product-importer' );
            return $result;
        }

        $handle = fopen( $file_path, 'r' );
        if ( ! $handle ) {
            $result['errors'][] = __( 'Could not open file.', 'csv-product-importer' );
            return $result;
        }

        // Read header row
        $raw_headers = fgetcsv( $handle, 0, ',' );
        if ( empty( $raw_headers ) ) {
            $result['errors'][] = __( 'CSV file appears to be empty or malformed.', 'csv-product-importer' );
            fclose( $handle );
            return $result;
        }

        $headers = array_map( 'trim', array_map( 'strtolower', $raw_headers ) );
        $result['headers'] = $headers;

        // Validate required headers — sourced from CPI_Config
        $missing = array_diff( CPI_Config::required_headers(), $headers );
        if ( ! empty( $missing ) ) {
            $result['errors'][] = sprintf(
                /* translators: %s: comma-separated list of missing column names */
                __( 'Missing required columns: %s', 'csv-product-importer' ),
                implode( ', ', $missing )
            );
            fclose( $handle );
            return $result;
        }

        $col_index = array_flip( $headers );
        $row_num   = 1;

        while ( ( $data = fgetcsv( $handle, 0, ',' ) ) !== false ) {
            $row_num++;

            // Skip completely empty rows
            if ( empty( array_filter( $data, static fn( $v ) => trim( $v ) !== '' ) ) ) {
                continue;
            }

            // Pad short rows
            while ( count( $data ) < count( $headers ) ) {
                $data[] = '';
            }

            $row = [];
            foreach ( $headers as $i => $key ) {
                $row[ $key ] = self::clean_value( $data[ $i ] ?? '' );
            }

            // Require the unique-key column to have a value
            $unique_key = CPI_Config::UNIQUE_KEY;
            if ( empty( $row[ $unique_key ] ) ) {
                $result['errors'][] = sprintf(
                    /* translators: 1: row number, 2: column name */
                    __( 'Row %1$d skipped — %2$s is empty.', 'csv-product-importer' ),
                    $row_num,
                    $unique_key
                );
                continue;
            }

            // Build the generated title from CPI_Config::TITLE_FORMULA
            $row['_generated_title'] = self::build_title( $row );

            $result['rows'][] = $row;
        }

        fclose( $handle );
        return $result;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Sanitize a raw CSV cell value.
     * Strips the garbled £¬ (encoded comma) sequences that appear in some exports.
     */
    private static function clean_value( string $value ): string {
        $value = str_replace( [ "\xa3\xac", "\xc2\xa3\xc2\xac" ], "\n", $value );
        return trim( $value );
    }

    /**
     * Build the post title from CPI_Config::TITLE_FORMULA.
     *
     * Formula: prefix columns joined by space, optional connector word,
     * then suffix columns joined by space.
     *
     * @param array $row Parsed CSV row (keyed by column name).
     * @return string
     */
    public static function build_title( array $row ): string {
        $formula   = CPI_Config::TITLE_FORMULA;
        $prefix    = $formula['prefix']    ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix']    ?? [];

        $prefix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $prefix )
        );
        $suffix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $suffix )
        );

        $title = implode( ' ', $prefix_parts );

        if ( ! empty( $suffix_parts ) ) {
            $suffix_str = implode( ' ', $suffix_parts );
            $title .= ( '' !== $connector ? ' ' . $connector : '' ) . ' ' . $suffix_str;
        }

        return trim( $title );
    }
}
