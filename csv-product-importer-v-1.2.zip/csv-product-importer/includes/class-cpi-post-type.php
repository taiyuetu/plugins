<?php
defined( 'ABSPATH' ) || exit;

class CPI_Post_Type {

    public static function register(): void {
        register_post_type( 'cpi_product', [
            'labels'       => [
                'name'               => __( 'Products',          'csv-product-importer' ),
                'singular_name'      => __( 'Product',           'csv-product-importer' ),
                'add_new'            => __( 'Add New',           'csv-product-importer' ),
                'add_new_item'       => __( 'Add New Product',   'csv-product-importer' ),
                'edit_item'          => __( 'Edit Product',      'csv-product-importer' ),
                'new_item'           => __( 'New Product',       'csv-product-importer' ),
                'view_item'          => __( 'View Product',      'csv-product-importer' ),
                'search_items'       => __( 'Search Products',   'csv-product-importer' ),
                'not_found'          => __( 'No products found', 'csv-product-importer' ),
                'not_found_in_trash' => __( 'No products in trash', 'csv-product-importer' ),
            ],
            'public'       => true,
            'has_archive'  => true,
            'show_in_rest' => true,
            'menu_icon'    => 'dashicons-archive',
            'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
            'rewrite'      => [ 'slug' => 'products' ],
        ] );
    }
}
