<?php
defined( 'ABSPATH' ) || exit;

/**
 * Registers and renders meta boxes for the existing 'product' post type.
 * Meta keys are the exact CSV column names (except 'type', which is title-only).
 */
class CPI_Meta_Fields {

    public static function hooks(): void {
        // add_action( 'add_meta_boxes',    [ __CLASS__, 'add_meta_boxes' ] );
        // add_action( 'save_post_product', [ __CLASS__, 'save_meta' ], 10, 2 );
    }

    public static function add_meta_boxes(): void {
        add_meta_box(
            'cpi_product_details',
            __( 'Product Details', 'csv-product-importer' ),
            [ __CLASS__, 'render_meta_box' ],
            'product',
            'normal',
            'high'
        );
    }

    public static function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'cpi_save_meta_' . $post->ID, '_cpi_nonce' );
        $fields = self::field_definitions();
        ?>
        <table class="form-table cpi-meta-table">
            <tbody>
            <?php foreach ( $fields as $field ) : ?>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr( $field['id'] ); ?>">
                            <?php echo esc_html( $field['label'] ); ?>
                        </label>
                    </th>
                    <td>
                        <?php $value = get_post_meta( $post->ID, $field['meta_key'], true ); ?>
                        <?php if ( $field['type'] === 'textarea' ) : ?>
                            <textarea
                                id="<?php echo esc_attr( $field['id'] ); ?>"
                                name="<?php echo esc_attr( $field['id'] ); ?>"
                                rows="4"
                                class="large-text"
                            ><?php echo esc_textarea( $value ); ?></textarea>
                        <?php else : ?>
                            <input
                                type="text"
                                id="<?php echo esc_attr( $field['id'] ); ?>"
                                name="<?php echo esc_attr( $field['id'] ); ?>"
                                value="<?php echo esc_attr( $value ); ?>"
                                class="regular-text"
                            />
                        <?php endif; ?>
                        <?php if ( ! empty( $field['description'] ) ) : ?>
                            <p class="description"><?php echo esc_html( $field['description'] ); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    public static function save_meta( int $post_id, WP_Post $post ): void {
        if (
            ! isset( $_POST['_cpi_nonce'] ) ||
            ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_cpi_nonce'] ) ), 'cpi_save_meta_' . $post_id )
        ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        foreach ( self::field_definitions() as $field ) {
            if ( ! isset( $_POST[ $field['id'] ] ) ) {
                continue;
            }

            $value = $field['type'] === 'textarea'
                ? sanitize_textarea_field( wp_unslash( $_POST[ $field['id'] ] ) )
                : sanitize_text_field( wp_unslash( $_POST[ $field['id'] ] ) );

            update_post_meta( $post_id, $field['meta_key'], $value );
        }
    }

    /**
     * Meta field definitions.
     * meta_key = exact CSV column header name (no prefix, no modification).
     * 'type' column is intentionally excluded — used only in the post title.
     */
    public static function field_definitions(): array {
        return [
            [
                'id'          => 'product_mpn',
                'label'       => __( 'Product MPN', 'csv-product-importer' ),
                'meta_key'    => 'product_mpn',
                'type'        => 'text',
                'description' => __( 'Manufacturer Part Number', 'csv-product-importer' ),
            ],
            [
                'id'          => 'oem_num',
                'label'       => __( 'OEM Number', 'csv-product-importer' ),
                'meta_key'    => 'oem_num',
                'type'        => 'text',
                'description' => __( 'Used in the product title', 'csv-product-importer' ),
            ],
            [
                'id'          => 'cross_ref',
                'label'       => __( 'Cross Reference', 'csv-product-importer' ),
                'meta_key'    => 'cross_ref',
                'type'        => 'textarea',
                'description' => __( 'One reference number per line', 'csv-product-importer' ),
            ],
            [
                'id'          => 'car_brand',
                'label'       => __( 'Car Brand', 'csv-product-importer' ),
                'meta_key'    => 'car_brand',
                'type'        => 'text',
                'description' => __( 'Used in the product title', 'csv-product-importer' ),
            ],
            [
                'id'          => 'car_application',
                'label'       => __( 'Car Application', 'csv-product-importer' ),
                'meta_key'    => 'car_application',
                'type'        => 'textarea',
                'description' => __( 'Compatible vehicle models', 'csv-product-importer' ),
            ],
            [
                'id'          => 'outer_diameter',
                'label'       => __( 'Outer Diameter', 'csv-product-importer' ),
                'meta_key'    => 'outer_diameter',
                'type'        => 'text',
                'description' => '',
            ],
            [
                'id'          => 'weight',
                'label'       => __( 'Weight (kg)', 'csv-product-importer' ),
                'meta_key'    => 'weight',
                'type'        => 'text',
                'description' => '',
            ],
        ];
    }
}
