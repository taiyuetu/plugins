<?php
/**
 * Legacy theme sample (not loaded by the User Points plugin).
 *
 * The paywall, points AJAX, and feed helpers were moved into the plugin
 * (`includes/post-paywall.php`, `wp-simple-points.php`). If your theme
 * `require`s this file, remove duplicate hooks to avoid double processing.
 *
 * @package legacy-sample
 */

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package wpfeed
 */
/**
 * Enqueue scripts and styles.
 */
function wpfeed_scripts() {
    wp_enqueue_style( 'wpfeed-style', get_stylesheet_uri(), array(), _S_VERSION );
    wp_style_add_data( 'wpfeed-style', 'rtl', 'replace' );

    wp_enqueue_script( 'wpfeed-navigation', get_template_directory_uri() . '/js/navigation.js', array('jquery'), _S_VERSION, true );

    wp_localize_script( 'wpfeed-navigation', 'Paywall', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'pay_to_read_nonce' ),
    ] );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'wpfeed_scripts' );

// Add to functions.php
function create_feed_sources_post_type() {
    register_post_type('feed_sources',
        array(
            'labels' => array(
                'name' => 'Feed Sources',
                'singular_name' => 'Feed Source'
            ),
            'public' => true,
            'has_archive' => false,
            'supports' => array('title', 'editor'),
            'publicly_queryable'  => false,
            'show_in_menu' => true,
        )
    );
    
    // Add meta box for feed URL
    add_action('add_meta_boxes', 'add_feed_url_meta_box');
}
add_action('init', 'create_feed_sources_post_type');

function add_feed_url_meta_box() {
    add_meta_box(
        'feed_url',
        'Feed URL',
        'feed_url_callback',
        'feed_sources'
    );
}

function feed_url_callback($post) {
    wp_nonce_field('save_feed_url', 'feed_url_nonce');
    $value = get_post_meta($post->ID, '_feed_url', true);
    echo '<input type="url" name="feed_url" value="' . esc_attr($value) . '" style="width:100%;" placeholder="https://example.com/feed" />';
}

function save_feed_url($post_id) {
    if (!isset($_POST['feed_url_nonce']) || !wp_verify_nonce($_POST['feed_url_nonce'], 'save_feed_url')) {
        return;
    }
    
    if (isset($_POST['feed_url'])) {
        update_post_meta($post_id, '_feed_url', sanitize_url($_POST['feed_url']));
    }
}
add_action('save_post', 'save_feed_url');


// Enhanced feed aggregator function with search and pagination support
function get_aggregated_feeds($limit = 10, $offset = 0, $search = '') {
    $feed_sources = get_posts(array(
        'post_type' => 'feed_sources',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
    
    $all_items = array();
    
    foreach ($feed_sources as $source) {
        $feed_url = get_post_meta($source->ID, '_feed_url', true);
        
        if (!$feed_url) continue;
        
        // Use WordPress fetch_feed function
        $feed = fetch_feed($feed_url);
        
        if (is_wp_error($feed)) continue;
        
        $maxitems = $feed->get_item_quantity(2); // Get more items for better search results
        $rss_items = $feed->get_items(0, $maxitems);
        
        foreach ($rss_items as $item) {
            // Extract image from content
            $content = $item->get_content();
            $description = $item->get_description();
            $image_url = extract_image_from_content($content, $description);
            
            $item_data = array(
                'title' => $item->get_title(),
                'link' => $item->get_link(),
                'description' => wp_trim_words(strip_tags($item->get_description()), 30),
                'content' => $content,
                'date' => $item->get_date('U'),
                'source_name' => $source->post_title,
                'author' => $item->get_author() ? $item->get_author()->get_name() : '',
                'image' => $image_url,
                'categories' => get_item_categories($item),
            );
            
            // Apply search filter
            if (!empty($search)) {
                $search_text = strtolower($search);
                $title_match = stripos($item_data['title'], $search) !== false;
                $desc_match = stripos($item_data['description'], $search) !== false;
                $source_match = stripos($item_data['source_name'], $search) !== false;
                
                if (!$title_match && !$desc_match && !$source_match) {
                    continue;
                }
            }
            
            $all_items[] = $item_data;
        }
    }
    
    // Sort by date (newest first)
    usort($all_items, function($a, $b) {
        return $b['date'] - $a['date'];
    });
    
    // Return total count and paginated items
    $total = count($all_items);
    $items = array_slice($all_items, $offset, $limit);
    
    return array(
        'items' => $items,
        'total' => $total
    );
}

// Extract image from RSS content
function extract_image_from_content($content, $description = '') {
    // First try to find image in content
    if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $content, $matches)) {
        return $matches[1];
    }
    
    // Try description
    if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $description, $matches)) {
        return $matches[1];
    }
    
    // Try to find media:thumbnail or media:content
    if (preg_match('/url=[\'"]([^\'"]+)[\'"]/', $content, $matches)) {
        if (preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $matches[1])) {
            return $matches[1];
        }
    }
    
    return '';
}

// Get item categories
function get_item_categories($item) {
    $categories = array();
    $item_categories = $item->get_categories();
    
    if ($item_categories) {
        foreach ($item_categories as $category) {
            $categories[] = $category->get_label();
        }
    }
    
    return $categories;
}

// Generate pagination links
function generate_feed_pagination($current_page, $total_items, $items_per_page, $search = '') {
    $total_pages = ceil($total_items / $items_per_page);
    
    if ($total_pages <= 1) return '';
    
    $pagination = '<div class="feed-pagination">';
    
    // Previous link
    if ($current_page > 1) {
        $prev_url = add_query_arg(array('feed_page' => $current_page - 1, 'feed_search' => $search));
        $pagination .= '<a href="' . esc_url($prev_url) . '" class="prev-page">← Previous</a>';
    }
    
    // Page numbers
    $start = max(1, $current_page - 2);
    $end = min($total_pages, $current_page + 2);
    
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $current_page) {
            $pagination .= '<span class="current-page">' . $i . '</span>';
        } else {
            $page_url = add_query_arg(array('feed_page' => $i, 'feed_search' => $search));
            $pagination .= '<a href="' . esc_url($page_url) . '">' . $i . '</a>';
        }
    }
    
    // Next link
    if ($current_page < $total_pages) {
        $next_url = add_query_arg(array('feed_page' => $current_page + 1, 'feed_search' => $search));
        $pagination .= '<a href="' . esc_url($next_url) . '" class="next-page">Next →</a>';
    }
    
    $pagination .= '</div>';
    
    return $pagination;
}


// Add these functions to your theme's functions.php

// Enhanced feed aggregator with source filtering
function get_aggregated_feeds_with_filters($limit = 10, $offset = 0, $search = '', $source_filter = '', $date_filter = '') {
    $feed_sources = get_posts(array(
        'post_type' => 'feed_sources',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
    
    $all_items = array();
    
    foreach ($feed_sources as $source) {
        // Skip if source filter is applied and doesn't match
        if ($source_filter && $source->ID != $source_filter) {
            continue;
        }
        
        $feed_url = get_post_meta($source->ID, '_feed_url', true);
        
        if (!$feed_url) continue;
        
        // Get cached feed data first
        $cached_items = get_cached_feed_items($source->ID);
        
        if (!empty($cached_items)) {
            $all_items = array_merge($all_items, $cached_items);
        } else {
            // Fallback to live fetch
            $feed = fetch_feed($feed_url);
            
            if (is_wp_error($feed)) continue;
            
            $maxitems = $feed->get_item_quantity(50);
            $rss_items = $feed->get_items(0, $maxitems);
            
            foreach ($rss_items as $item) {
                $content = $item->get_content();
                $description = $item->get_description();
                $image_url = extract_image_from_content($content, $description);
                
                $item_data = array(
                    'title' => $item->get_title(),
                    'link' => $item->get_link(),
                    'description' => wp_trim_words(strip_tags($description), 30),
                    'content' => $content,
                    'date' => $item->get_date('U'),
                    'source_name' => $source->post_title,
                    'source_id' => $source->ID,
                    'author' => $item->get_author() ? $item->get_author()->get_name() : '',
                    'image' => $image_url,
                    'categories' => get_item_categories($item),
                );
                
                $all_items[] = $item_data;
            }
        }
    }
    
    // Apply date filter
    if ($date_filter) {
        $cutoff_date = strtotime($date_filter);
        $all_items = array_filter($all_items, function($item) use ($cutoff_date) {
            return $item['date'] >= $cutoff_date;
        });
    }
    
    // Apply search filter
    if (!empty($search)) {
        $all_items = array_filter($all_items, function($item) use ($search) {
            $search_text = strtolower($search);
            $title_match = stripos($item['title'], $search) !== false;
            $desc_match = stripos($item['description'], $search) !== false;
            $source_match = stripos($item['source_name'], $search) !== false;
            $author_match = stripos($item['author'], $search) !== false;
            
            return $title_match || $desc_match || $source_match || $author_match;
        });
    }
    
    // Sort by date (newest first)
    usort($all_items, function($a, $b) {
        return $b['date'] - $a['date'];
    });
    
    // Return total count and paginated items
    $total = count($all_items);
    $items = array_slice($all_items, $offset, $limit);
    
    return array(
        'items' => $items,
        'total' => $total,
        'sources' => $feed_sources
    );
}

// Cache feed items in database for better performance
function get_cached_feed_items($source_id) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'feed_cache';
    
    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        return array();
    }
    
    $cached_items = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE source_id = %d ORDER BY feed_date DESC LIMIT 20",
        $source_id
    ));
    
    $items = array();
    foreach ($cached_items as $cached_item) {
        $items[] = array(
            'title' => $cached_item->feed_title,
            'link' => $cached_item->feed_link,
            'description' => $cached_item->feed_description,
            'date' => strtotime($cached_item->feed_date),
            'source_name' => $cached_item->source_name,
            'source_id' => $cached_item->source_id,
            'author' => isset($cached_item->author) ? $cached_item->author : '',
            'image' => isset($cached_item->image_url) ? $cached_item->image_url : '',
            'categories' => array(),
        );
    }
    
    return $items;
}

// Get feed source statistics
function get_feed_source_stats() {
    $feed_sources = get_posts(array(
        'post_type' => 'feed_sources',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
    
    $stats = array();
    
    foreach ($feed_sources as $source) {
        $feed_url = get_post_meta($source->ID, '_feed_url', true);
        
        if (!$feed_url) continue;
        
        $feed = fetch_feed($feed_url);
        
        if (is_wp_error($feed)) {
            $stats[$source->ID] = array(
                'name' => $source->post_title,
                'count' => 0,
                'status' => 'error',
                'last_updated' => 'Never'
            );
            continue;
        }
        
        $items = $feed->get_items(0, 50);
        $latest_date = '';
        
        if (!empty($items)) {
            $latest_date = $items[0]->get_date('F j, Y g:i A');
        }
        
        $stats[$source->ID] = array(
            'name' => $source->post_title,
            'count' => count($items),
            'status' => 'active',
            'last_updated' => $latest_date
        );
    }
    
    return $stats;
}

// AJAX endpoint for live search suggestions
function feed_search_suggestions() {
    check_ajax_referer('feed_search_nonce', 'nonce');
    
    $query = sanitize_text_field($_POST['query']);
    
    if (strlen($query) < 2) {
        wp_die();
    }
    
    $feeds = get_aggregated_feeds_with_filters(50, 0, $query);
    
    $suggestions = array();
    foreach ($feeds['items'] as $item) {
        $suggestions[] = array(
            'title' => $item['title'],
            'source' => $item['source_name']
        );
        
        if (count($suggestions) >= 5) break;
    }
    
    wp_send_json($suggestions);
}
add_action('wp_ajax_feed_search_suggestions', 'feed_search_suggestions');
add_action('wp_ajax_nopriv_feed_search_suggestions', 'feed_search_suggestions');

// Enqueue AJAX script
function enqueue_feed_ajax_script() {
    if (is_page_template('page-feed-collection.php')) {
        wp_enqueue_script('jquery');
        
        wp_localize_script('jquery', 'feedAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('feed_search_nonce')
        ));
    }
}
add_action('wp_enqueue_scripts', 'enqueue_feed_ajax_script');

// Add meta fields for feed sources
function add_extended_feed_meta_boxes() {
    add_meta_box(
        'feed_settings',
        'Feed Settings',
        'feed_settings_callback',
        'feed_sources',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_extended_feed_meta_boxes');

function feed_settings_callback($post) {
    wp_nonce_field('save_feed_settings', 'feed_settings_nonce');
    
    $feed_url = get_post_meta($post->ID, '_feed_url', true);
    $update_frequency = get_post_meta($post->ID, '_update_frequency', true) ?: 'hourly';
    $max_items = get_post_meta($post->ID, '_max_items', true) ?: 10;
    $feed_category = get_post_meta($post->ID, '_feed_category', true);
    
    echo '<table class="form-table">';
    
    echo '<tr>';
    echo '<th><label for="feed_url">Feed URL</label></th>';
    echo '<td><input type="url" id="feed_url" name="feed_url" value="' . esc_attr($feed_url) . '" style="width:100%;" placeholder="https://example.com/feed" /></td>';
    echo '</tr>';
    
    echo '<tr>';
    echo '<th><label for="update_frequency">Update Frequency</label></th>';
    echo '<td>';
    echo '<select id="update_frequency" name="update_frequency">';
    echo '<option value="hourly"' . selected($update_frequency, 'hourly', false) . '>Hourly</option>';
    echo '<option value="twicedaily"' . selected($update_frequency, 'twicedaily', false) . '>Twice Daily</option>';
    echo '<option value="daily"' . selected($update_frequency, 'daily', false) . '>Daily</option>';
    echo '</select>';
    echo '</td>';
    echo '</tr>';
    
    echo '<tr>';
    echo '<th><label for="max_items">Max Items to Fetch</label></th>';
    echo '<td><input type="number" id="max_items" name="max_items" value="' . esc_attr($max_items) . '" min="1" max="50" /></td>';
    echo '</tr>';
    
    echo '<tr>';
    echo '<th><label for="feed_category">Category</label></th>';
    echo '<td><input type="text" id="feed_category" name="feed_category" value="' . esc_attr($feed_category) . '" placeholder="e.g., Technology, News, etc." /></td>';
    echo '</tr>';
    
    echo '</table>';
}

function save_extended_feed_settings($post_id) {
    if (!isset($_POST['feed_settings_nonce']) || !wp_verify_nonce($_POST['feed_settings_nonce'], 'save_feed_settings')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    
    $fields = array('feed_url', 'update_frequency', 'max_items', 'feed_category');
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            $value = sanitize_text_field($_POST[$field]);
            update_post_meta($post_id, '_' . $field, $value);
        }
    }
}
add_action('save_post', 'save_extended_feed_settings');

// Export feeds as JSON
// function export_feeds_as_json() {
//     if (!current_user_can('manage_options')) {
//         wp_die('Unauthorized');
//     }
    
//     $feeds = get_aggregated_feeds_with_filters(100);
    
//     $export_data = array(
//         'exported_at' => current_time('mysql'),
//         'total_items' => $feeds['total'],
//         'items' => $feeds['items']
//     );
    
//     header('Content-Type: application/json');
//     header('Content-Disposition: attachment; filename="feed-export-' . date('Y-m-d') . '.json"');
    
//     echo json_encode($export_data, JSON_PRETTY_PRINT);
//     exit;
// }

// Add admin menu for feed management
function add_feed_management_menu() {
    add_submenu_page(
        'edit.php?post_type=feed_sources',
        'Feed Statistics',
        'Statistics',
        'manage_options',
        'feed-stats',
        'feed_stats_page'
    );
    
    // add_submenu_page(
    //     'edit.php?post_type=feed_sources',
    //     'Export Feeds',
    //     'Export',
    //     'manage_options',
    //     'export-feeds',
    //     'export_feeds_as_json'
    // );
}
add_action('admin_menu', 'add_feed_management_menu');

function feed_stats_page() {
    $stats = get_feed_source_stats();
    
    echo '<div class="wrap">';
    echo '<h1>Feed Statistics</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Feed Source</th><th>Status</th><th>Items</th><th>Last Updated</th></tr></thead>';
    echo '<tbody>';
    
    foreach ($stats as $stat) {
        $status_class = $stat['status'] === 'error' ? 'error' : 'success';
        echo '<tr>';
        echo '<td>' . esc_html($stat['name']) . '</td>';
        echo '<td><span class="' . $status_class . '">' . ucfirst($stat['status']) . '</span></td>';
        echo '<td>' . $stat['count'] . '</td>';
        echo '<td>' . esc_html($stat['last_updated']) . '</td>';
        echo '</tr>';
    }
    
    echo '</tbody></table>';
    echo '</div>';
    
    echo '<style>';
    echo '.success { color: green; font-weight: bold; }';
    echo '.error { color: red; font-weight: bold; }';
    echo '</style>';
}



//文章加密和积分扣除相关

// You should generate a strong, secret key and keep it out of version control!
if ( ! defined( 'MY_POST_SECRET_KEY' ) ) {
    define( 'MY_POST_SECRET_KEY', 'put‑a‑long‑random‑string‑here' );
}


/**
 * Encrypt a string.
 */
function my_encrypt( $plaintext ) {
    $ivlen = openssl_cipher_iv_length('AES-256-CBC');
    $iv    = openssl_random_pseudo_bytes( $ivlen );
    $ciphertext_raw = openssl_encrypt(
        $plaintext,
        'AES-256-CBC',
        MY_POST_SECRET_KEY,
        OPENSSL_RAW_DATA,
        $iv
    );
    // store IV + encrypted data, base64‑encoded
    return base64_encode( $iv . $ciphertext_raw );
}

/**
 * Decrypt a string.
 */
function my_decrypt( $ciphertext_b64 ) {
    $data = base64_decode( $ciphertext_b64 );
    $ivlen = openssl_cipher_iv_length('AES-256-CBC');
    $iv = substr( $data, 0, $ivlen );
    $ciphertext_raw = substr( $data, $ivlen );
    return openssl_decrypt(
        $ciphertext_raw,
        'AES-256-CBC',
        MY_POST_SECRET_KEY,
        OPENSSL_RAW_DATA,
        $iv
    );
}

add_action( 'save_post', function( $post_id ) {
    // only for posts (not autosaves, revisions)
    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }
    $post = get_post( $post_id );
    if ( $post->post_type !== 'post' ) {
        return;
    }

    // Encrypt and save
    $encrypted = my_encrypt( $post->post_content );
    update_post_meta( $post_id, '_encrypted_content', wp_slash( $encrypted ) );
}, 20, 1 );


add_filter( 'the_content', function( $content ) {
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }

    global $post, $current_user;
    wp_get_current_user();
    $meta = get_post_meta( $post->ID, '_encrypted_content', true );
    if ( ! $meta ) {
        // not encrypted – show raw
        return $content;
    }

    // Cost in points
    $cost = 5;

    // Track which posts user has paid for
    $paid = (array) get_user_meta( $current_user->ID, 'paid_posts', true );

    if ( in_array( $post->ID, $paid, true ) ) {
        // user paid already – decrypt and show
        return my_decrypt( $meta );
    }

    // not paid yet – show teaser + pay button
    $teaser = wp_trim_words( my_decrypt( $meta ), 40, '…' );
    $btn    = '<button id="pay-to-read" data-post="' . esc_attr( $post->ID ) . '">'
            . sprintf( 'Pay %d points to read', $cost )
            . '</button>';

    return '<div class="paywall-teaser">' . wpautop( $teaser ) . '</div>' . $btn;
}, 99 );


add_action( 'wp_ajax_pay_to_read', 'pay_to_read_cb' );
add_action( 'wp_ajax_nopriv_pay_to_read', 'pay_to_read_cb' );


function pay_to_read_cb() {
    // security
    check_ajax_referer( 'pay_to_read_nonce', 'nonce' );

    $user_id = get_current_user_id();
    $post_id = intval( $_POST['post_id'] );
    $cost    = 5;

    if ( $user_id === 0 ) {
        wp_send_json_error( array(
            'message' => 'Must be logged in.',
            'login_url' => wp_login_url( get_permalink( $post_id ) )
        ) );

    }

    if ( ! function_exists( 'get_user_points' ) || ! function_exists( 'add_user_points' ) ) {
        wp_send_json_error( 'Points system unavailable.' );
    }

    $balance = get_user_points( $user_id );
    if ( $balance < $cost ) {
        wp_send_json_error( 'Not enough points.' );
    }

    // Deduct points
    //wp_points()->subtract_points($user_id, 5, 'read posts');

    subtract_user_points($user_id, 8, 'read post');

    // Mark post as paid
    $paid = (array) get_user_meta( $user_id, 'paid_posts', true );
    $paid[] = $post_id;
    update_user_meta( $user_id, 'paid_posts', array_unique( $paid ) );

    wp_send_json_success();
}