// Enhanced Feed Collection JavaScript
// Add this to your theme's script file or enqueue it
jQuery( function($) {
    $('#pay-to-read').on('click', function(){
        var btn = $(this);
         var  pid = btn.data('post');

        $.post( Paywall.ajax_url, {
            action: 'pay_to_read',
            post_id: pid,
            nonce: Paywall.nonce
        }).done(function(res){
            if ( res.success ) {
                location.reload();
            } else {
                var msg = (typeof res.data === 'object' && res.data && res.data.message) ? res.data.message : res.data;
                if ( typeof res.data === 'object' && res.data && res.data.login_url ) {
                    if ( confirm( msg + ' Do you want to login now?' ) ) {
                        window.location.href = res.data.login_url;
                    }
                } else {
                    alert( msg );
                }
                 
            }
        }).fail(err => console.log(err.responseText));
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    // Search functionality enhancements
    const searchForm = document.querySelector('.feed-search-form');
    const searchInput = document.querySelector('.search-input');
    
    if (searchForm && searchInput) {
        // Auto-submit search with debouncing
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 3 || this.value.length === 0) {
                    searchForm.submit();
                }
            }, 500);
        });
        
        // Clear search on Escape key
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                const url = new URL(window.location);
                url.searchParams.delete('feed_search');
                url.searchParams.delete('feed_page');
                window.location.href = url.toString();
            }
        });
    }
    
    // Lazy loading for images
    const images = document.querySelectorAll('.feed-image1 img');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    
                    // Add loading animation
                    img.style.opacity = '0';
                    img.style.transition = 'opacity 0.3s';
                    
                    img.onload = function() {
                        this.style.opacity = '1';
                    };
                    
                    // Handle broken images
                    img.onerror = function() {
                        this.style.display = 'none';
                        this.closest('.feed-image').style.display = 'none';
                        
                        // Adjust grid layout for items without images
                        const feedItem = this.closest('.feed-item');
                        if (feedItem) {
                            feedItem.style.gridTemplateColumns = '1fr';
                        }
                    };
                    
                    observer.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
    
    // Smooth scroll to top after pagination
    if (window.location.search.includes('feed_page=')) {
        const feedCollection = document.querySelector('.feed-collection');
        if (feedCollection) {
            feedCollection.scrollIntoView({ behavior: 'smooth' });
        }
    }
    
    // Add loading states for links
    const readMoreLinks = document.querySelectorAll('.read-more');
    readMoreLinks.forEach(link => {
        link.addEventListener('click', function() {
            this.style.opacity = '0.7';
            this.innerHTML = this.innerHTML.replace('Read Full Article', 'Opening...');
        });
    });
    
    // Keyboard navigation for search
    document.addEventListener('keydown', function(e) {
        // Focus search with Ctrl/Cmd + K
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            searchInput?.focus();
        }
    });
    
    // Add share functionality
    function addShareButtons() {
        const feedItems = document.querySelectorAll('.feed-item');
        
        feedItems.forEach(item => {
            const actions = item.querySelector('.feed-actions');
            const title = item.querySelector('.feed-title a').textContent;
            const url = item.querySelector('.feed-title a').href;
            
            if (actions && navigator.share) {
                const shareBtn = document.createElement('button');
                shareBtn.className = 'share-button';
                shareBtn.innerHTML = `
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="18" cy="5" r="3"></circle>
                        <circle cx="6" cy="12" r="3"></circle>
                        <circle cx="18" cy="19" r="3"></circle>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                    </svg>
                    Share
                `;
                
                shareBtn.addEventListener('click', async () => {
                    try {
                        await navigator.share({
                            title: title,
                            url: url
                        });
                    } catch (err) {
                        console.log('Error sharing:', err);
                    }
                });
                
                actions.appendChild(shareBtn);
            }
        });
    }
    
    // Initialize share buttons
    addShareButtons();
    
    // Add print functionality
    function addPrintStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @media print {
                .feed-search-form,
                .feed-pagination,
                .feed-actions {
                    display: none !important;
                }
                
                .feed-item {
                    break-inside: avoid;
                    box-shadow: none;
                    border: 1px solid #ccc;
                    margin-bottom: 20px;
                }
                
                .feed-title a {
                    color: #000 !important;
                }
                
                .feed-title a:after {
                    content: " (" attr(href) ")";
                    font-size: 0.8em;
                    font-weight: normal;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    addPrintStyles();
    
    // Infinite scroll option (optional)
    function initInfiniteScroll() {
        const pagination = document.querySelector('.feed-pagination');
        const nextLink = document.querySelector('.next-page');
        
        if (!pagination || !nextLink) return;
        
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) {
                loadNextPage();
            }
        });
        
        observer.observe(pagination);
        
        async function loadNextPage() {
            if (nextLink) {
                try {
                    const response = await fetch(nextLink.href);
                    const html = await response.text();
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    
                    const newItems = doc.querySelectorAll('.feed-item');
                    const feedItems = document.querySelector('.feed-items');
                    
                    newItems.forEach(item => {
                        feedItems.appendChild(item);
                    });
                    
                    // Update pagination
                    const newPagination = doc.querySelector('.feed-pagination');
                    if (newPagination) {
                        pagination.replaceWith(newPagination);
                    } else {
                        pagination.remove();
                    }
                } catch (error) {
                    console.error('Error loading next page:', error);
                }
            }
        }
    }
    
    // Uncomment to enable infinite scroll
    // initInfiniteScroll();
});



// CSS for additional JavaScript features
const additionalCSS = `
    .share-button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        background: #28a745;
        color: white;
        border: none;
        border-radius: 6px;
        font-weight: 500;
        font-size: 14px;
        cursor: pointer;
        transition: background-color 0.3s;
        margin-left: 10px;
    }
    
    .share-button:hover {
        background: #218838;
    }
    
    .search-input:focus {
        box-shadow: 0 0 0 3px rgba(0, 115, 170, 0.1);
    }
    
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    }
    
    .loading-spinner {
        width: 40px;
        height: 40px;
        border: 4px solid #e1e5e9;
        border-top: 4px solid #0073aa;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .feed-item.loading {
        opacity: 0.5;
        pointer-events: none;
    }
    
    .search-suggestions {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #e1e5e9;
        border-top: none;
        border-radius: 0 0 8px 8px;
        max-height: 200px;
        overflow-y: auto;
        z-index: 100;
        display: none;
    }
    
    .search-suggestion {
        padding: 12px 16px;
        cursor: pointer;
        border-bottom: 1px solid #f0f0f0;
        transition: background-color 0.2s;
    }
    
    .search-suggestion:hover,
    .search-suggestion.active {
        background-color: #f8f9fa;
    }
    
    .search-suggestion:last-child {
        border-bottom: none;
    }
    
    .feed-filters {
        margin: 20px 0;
        text-align: center;
    }
    
    .filter-button {
        display: inline-block;
        padding: 6px 14px;
        margin: 0 4px 8px 0;
        background: #f8f9fa;
        color: #666;
        text-decoration: none;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.3s;
        border: 1px solid #e1e5e9;
    }
    
    .filter-button:hover,
    .filter-button.active {
        background: #0073aa;
        color: white;
        border-color: #0073aa;
    }
    
    .feed-stats {
        text-align: center;
        margin-bottom: 20px;
        color: #666;
        font-size: 14px;
    }
    
    .back-to-top {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        background: #0073aa;
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        display: none;
        align-items: center;
        justify-content: center;
        transition: all 0.3s;
        box-shadow: 0 2px 10px rgba(0, 115, 170, 0.3);
        z-index: 100;
    }
    
    .back-to-top:hover {
        background: #005a87;
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(0, 115, 170, 0.4);
    }
    
    .back-to-top.visible {
        display: flex;
    }
`;

// Add the CSS to the page
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalCSS;
document.head.appendChild(styleSheet);



