<?php
/**
 * Optional per-post paywall: teaser + AJAX unlock using points.
 *
 * @package User_Points_System
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register post meta for the block editor and REST.
 */
add_action(
    'init',
    static function () {
        register_post_meta(
            'post',
            '_wp_points_read_cost',
            array(
                'type'              => 'number',
                'single'            => true,
                'show_in_rest'      => true,
                'auth_callback'     => static function () {
                    return current_user_can('edit_posts');
                },
                'sanitize_callback' => static function ($value) {
                    $n = is_numeric($value) ? (float) $value : 0;
                    return max(0, $n);
                },
            )
        );
    }
);

/**
 * Classic editor / quick-edit meta box.
 */
add_action(
    'add_meta_boxes',
    static function () {
        add_meta_box(
            'wp_points_paywall',
            __('Points paywall', 'user-points-system'),
            'wp_points_paywall_metabox',
            'post',
            'side',
            'default'
        );
    }
);

/**
 * @param WP_Post $post Post object.
 */
function wp_points_paywall_metabox($post) {
    wp_nonce_field('wp_points_paywall_save', 'wp_points_paywall_nonce');
    $cost = get_post_meta($post->ID, '_wp_points_read_cost', true);
    if ($cost === '' || $cost === false) {
        $cost = 0;
    }
    ?>
    <p>
        <label for="wp_points_read_cost"><?php esc_html_e('Points to unlock full content (0 = disabled)', 'user-points-system'); ?></label>
    </p>
    <input type="number" min="0" step="1" id="wp_points_read_cost" name="wp_points_read_cost" value="<?php echo esc_attr((string) $cost); ?>" class="widefat" />
    <p class="description"><?php esc_html_e('Visitors see a short teaser and can pay once to read the full post.', 'user-points-system'); ?></p>
    <?php
}

add_action(
    'save_post_post',
    static function ($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!isset($_POST['wp_points_paywall_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wp_points_paywall_nonce'])), 'wp_points_paywall_save')) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if (!isset($_POST['wp_points_read_cost'])) {
            return;
        }
        $cost = max(0, (float) wp_unslash($_POST['wp_points_read_cost']));
        if ($cost > 0) {
            update_post_meta($post_id, '_wp_points_read_cost', $cost);
        } else {
            delete_post_meta($post_id, '_wp_points_read_cost');
        }
    },
    10,
    1
);

/**
 * Enqueue front-end script for the pay button.
 */
add_action(
    'wp_enqueue_scripts',
    static function () {
        if (!is_singular('post')) {
            return;
        }
        global $post;
        if (!$post instanceof WP_Post) {
            return;
        }
        $cost = (float) get_post_meta($post->ID, '_wp_points_read_cost', true);
        if ($cost <= 0) {
            return;
        }

        wp_enqueue_script(
            'wp-points-paywall',
            WP_POINTS_PLUGIN_URL . 'navigation.js',
            array('jquery'),
            '1.1.0',
            true
        );

        wp_localize_script(
            'wp-points-paywall',
            'Paywall',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('pay_to_read_nonce'),
            )
        );
    }
);

/**
 * Filter content when a paywall is enabled.
 */
add_filter(
    'the_content',
    static function ($content) {
        if (!is_singular('post') || is_admin()) {
            return $content;
        }

        if (!in_the_loop() || !is_main_query()) {
            return $content;
        }

        global $post;
        if (!$post instanceof WP_Post) {
            return $content;
        }

        if (is_preview() && current_user_can('edit_post', $post->ID)) {
            return $content;
        }

        $cost = (float) get_post_meta($post->ID, '_wp_points_read_cost', true);
        if ($cost <= 0) {
            return $content;
        }

        if (current_user_can('edit_post', $post->ID)) {
            return $content;
        }

        $user_id = get_current_user_id();
        $paid    = $user_id ? (array) get_user_meta($user_id, 'paid_posts', true) : array();
        if (in_array((int) $post->ID, array_map('intval', $paid), true)) {
            return $content;
        }

        $teaser = wp_trim_words(wp_strip_all_tags($content), 55, '…');
        $btn    = '<p><button type="button" class="button wp-points-pay-to-read" id="pay-to-read" data-post="' . esc_attr((string) $post->ID) . '" data-cost="' . esc_attr((string) $cost) . '">'
            . esc_html(
                sprintf(
                    /* translators: %s: points amount */
                    __('Pay %s points to read the full article', 'user-points-system'),
                    number_format_i18n($cost, 0)
                )
            )
            . '</button></p>';

        return '<div class="wp-points-paywall-teaser">' . wpautop(esc_html($teaser)) . '</div>' . $btn;
    },
    99
);

add_action('wp_ajax_pay_to_read', 'wp_points_pay_to_read_cb');
add_action('wp_ajax_nopriv_pay_to_read', 'wp_points_pay_to_read_cb');

/**
 * AJAX: deduct points and mark post as unlocked for the user.
 */
function wp_points_pay_to_read_cb() {
    check_ajax_referer('pay_to_read_nonce', 'nonce');

    $post_id = isset($_POST['post_id']) ? absint(wp_unslash($_POST['post_id'])) : 0;
    if (!$post_id || get_post_type($post_id) !== 'post') {
        wp_send_json_error(array('message' => __('Invalid post.', 'user-points-system')));
    }

    $cost = (float) get_post_meta($post_id, '_wp_points_read_cost', true);
    if ($cost <= 0) {
        wp_send_json_error(array('message' => __('This post is not locked.', 'user-points-system')));
    }

    $user_id = get_current_user_id();
    if ($user_id < 1) {
        wp_send_json_error(
            array(
                'message'   => __('You must be logged in to unlock this post.', 'user-points-system'),
                'login_url' => wp_login_url(get_permalink($post_id)),
            )
        );
    }

    if (!function_exists('get_user_points') || !function_exists('subtract_user_points')) {
        wp_send_json_error(array('message' => __('Points system is unavailable.', 'user-points-system')));
    }

    $paid = (array) get_user_meta($user_id, 'paid_posts', true);
    if (in_array($post_id, array_map('intval', $paid), true)) {
        wp_send_json_success(array('message' => __('Already unlocked.', 'user-points-system')));
    }

    $balance = get_user_points($user_id);
    if ($balance < $cost) {
        wp_send_json_error(array('message' => __('Not enough points.', 'user-points-system')));
    }

    $result = subtract_user_points(
        $user_id,
        $cost,
        sprintf(
            /* translators: 1: post id, 2: post title */
            __('Unlock post #%1$d: %2$s', 'user-points-system'),
            $post_id,
            get_the_title($post_id)
        ),
        'post_unlock'
    );

    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    }

    $paid[] = $post_id;
    update_user_meta($user_id, 'paid_posts', array_unique(array_map('intval', $paid)));

    wp_send_json_success(
        array(
            'new_balance' => $result,
        )
    );
}
