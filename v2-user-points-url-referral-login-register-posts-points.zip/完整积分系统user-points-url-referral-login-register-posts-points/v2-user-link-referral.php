<?php
// User Link Referral System
if (!defined('ABSPATH')) {
    exit;
}

// Generate or get existing referral code for user
function ulr_get_user_referral_code($user_id) {
    $referral_code = get_user_meta($user_id, 'ulr_referral_code', true);
    
    if (empty($referral_code)) {
        $referral_code = 'user' . $user_id . '_' . substr(md5(uniqid(rand(), true)), 0, 8);
        update_user_meta($user_id, 'ulr_referral_code', $referral_code);
    }
    
    return $referral_code;
}

// Generate referral link
function ulr_get_referral_link($user_id) {
    $referral_code = ulr_get_user_referral_code($user_id);
    return home_url('/?ref=' . $referral_code);
}

// Check for referral visits
function ulr_check_referral_visit() {
    if (isset($_GET['ref']) && !empty($_GET['ref'])) {
        $referral_code = sanitize_text_field(wp_unslash($_GET['ref']));

        // Persist for signup bonus (handled on wp_points_after_registration).
        if ($referral_code !== '') {
            setcookie(
                'wp_points_referral_code',
                $referral_code,
                time() + (30 * DAY_IN_SECONDS),
                COOKIEPATH ? COOKIEPATH : '/',
                COOKIE_DOMAIN,
                is_ssl(),
                true
            );
        }

        // Find user by referral code
        $users = get_users(array(
            'meta_key' => 'ulr_referral_code',
            'meta_value' => $referral_code,
            'number' => 1
        ));
        
        if (!empty($users)) {
            $referrer_user = $users[0];

            if (is_user_logged_in() && (int) get_current_user_id() === (int) $referrer_user->ID) {
                return;
            }

            $visitor_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
            $current_time = current_time('timestamp');
            
            // Check if this IP has visited in the last 24 hours
            $existing_visits = get_user_meta($referrer_user->ID, 'ulr_referral_visits', true);
            if (!is_array($existing_visits)) {
                $existing_visits = array();
            }
            
            $can_count = true;
            $callback_triggered = get_user_meta($referrer_user->ID, 'ulr_callback_triggered', true);

            //生产后取消注释确保同一ip 24小时执行一次
            
            // Check for duplicate visits from same IP within 24 hours
            foreach ($existing_visits as $visit) {
                if ($visit['visitor_ip'] === $visitor_ip) {
                    $visit_timestamp = strtotime($visit['visit_time']);
                    $time_diff = $current_time - $visit_timestamp;
                    
                    // If less than 24 hours (86400 seconds), don't count
                    if ($time_diff < 86400) {
                        $can_count = false;
                        break;
                    }
                }
            }
            
            if ($can_count) {
                // Store referral visit data
                $visit_data = array(
                    'referrer_id' => $referrer_user->ID,
                    'visitor_ip' => $visitor_ip,
                    'visit_time' => current_time('mysql'),
                    'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
                );
                
                $existing_visits[] = $visit_data;
                update_user_meta($referrer_user->ID, 'ulr_referral_visits', $existing_visits);
                
                // Increment visit counter
                $visit_count = get_user_meta($referrer_user->ID, 'ulr_referral_count', true);
                $visit_count = intval($visit_count) + 1;
                update_user_meta($referrer_user->ID, 'ulr_referral_count', $visit_count);

                ulr_process_referral_callback($referrer_user->ID, $visit_data);

                // Optional one-time hook (kept for backwards compatibility).
                if (!$callback_triggered) {
                    do_action('ulr_first_referral_visit_recorded', $referrer_user->ID, $visit_data);
                }
            }
        }
    }
}
add_action('init', 'ulr_check_referral_visit');

// Referral visit rewards (counter is updated in ulr_check_referral_visit).
function ulr_process_referral_callback($referrer_id, $visit_data) {
    // Visit counter is already incremented in ulr_check_referral_visit().

    if (!function_exists('add_user_points')) {
        return;
    }

    $points = (float) apply_filters('wp_points_referral_visit_reward', 2, $referrer_id, $visit_data);
    if ($points <= 0) {
        return;
    }

    $desc = sprintf(
        /* translators: %s visitor IP */
        __('Referral visit from %s', 'user-points-system'),
        isset($visit_data['visitor_ip']) ? $visit_data['visitor_ip'] : ''
    );
    add_user_points($referrer_id, $points, $desc, 'referral_visit');
    
    // Uncomment the line below for debugging
    // error_log('Referral callback triggered for user ID: ' . $referrer_id);
}

// Shortcode to display referral link  短代码
function ulr_referral_link_shortcode($atts) {
    if (!is_user_logged_in()) {
        return '<p class="ulr-error">Please log in to view your referral link.</p>';
    }
    
    $user_id = get_current_user_id();
    $referral_link = ulr_get_referral_link($user_id);
    $visit_count = get_user_meta($user_id, 'ulr_referral_count', true);
    $visit_count = intval($visit_count);
    
    ob_start();
    ?>
    <div class="ulr-referral-container">
        <h3 class="ulr-title">你的推广链接</h3>
        <div class="ulr-link-container">
            <input type="text" class="ulr-link-input" value="<?php echo esc_url($referral_link); ?>" readonly>
            <button class="ulr-copy-btn" onclick="ulrCopyLink(this)">Copy</button>
        </div>
        <p class="ulr-stats">总共访问人数: <span class="ulr-count"><?php echo $visit_count; ?></span></p>
    </div>
    
    <style>
    .ulr-referral-container {
        background: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        border: 1px solid #ddd;
        margin: 20px 0;
    }
    .ulr-title {
        margin-top: 0;
        color: #333;
        font-size: 18px;
    }
    .ulr-link-container {
        display: flex;
        gap: 10px;
        margin-bottom: 15px;
    }
    .ulr-link-input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }
    .ulr-copy-btn {
        padding: 10px 20px;
        background: #0073aa;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
    }
    .ulr-copy-btn:hover {
        background: #005a87;
    }
    .ulr-stats {
        margin-bottom: 0;
        color: #666;
        font-size: 14px;
    }
    .ulr-count {
        font-weight: bold;
        color: #0073aa;
    }
    .ulr-error {
        color: #d63638;
        background: #fcf0f1;
        padding: 10px;
        border-radius: 4px;
        border-left: 4px solid #d63638;
    }
    </style>
    
    <script>
    function ulrCopyLink(button) {
        const input = button.previousElementSibling;
        input.select();
        input.setSelectionRange(0, 99999);
        document.execCommand('copy');
        
        const originalText = button.textContent;
        button.textContent = 'Copied!';
        button.style.background = '#46b450';
        
        setTimeout(function() {
            button.textContent = originalText;
            button.style.background = '#0073aa';
        }, 2000);
    }
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('ulr_referral_link', 'ulr_referral_link_shortcode');

// Add referral link to user profile
function ulr_add_referral_to_profile($user) {
    if (!current_user_can('edit_user', $user->ID)) {
        return;
    }
    
    $referral_link = ulr_get_referral_link($user->ID);
    $visit_count = get_user_meta($user->ID, 'ulr_referral_count', true);
    $visit_count = intval($visit_count);
    ?>
    <h3>推广链接信息</h3>
    <table class="form-table">
        <tr>
            <th><label>你的推广链接</label></th>
            <td>
                <input type="text" value="<?php echo esc_url($referral_link); ?>" readonly class="regular-text" />
                <p class="description">推广这个链接去赚取积分.</p>
            </td>
        </tr>
        <tr>
            <th><label>总共访问人数</label></th>
            <td>
                <strong><?php echo $visit_count; ?></strong>
                <p class="description">访问你的推广链接的人数.</p>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'ulr_add_referral_to_profile');
add_action('edit_user_profile', 'ulr_add_referral_to_profile');
?>