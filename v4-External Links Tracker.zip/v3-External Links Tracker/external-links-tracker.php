<?php
/**
 * Plugin Name: External Links Tracker 链接跳转生成器
 * Plugin URI: https://wpdev.com.cn/external-links-tracker
 * Description: 跳转并生成无限外部链接并追踪点击.
 * Version: 1.1.0
 * Author: WP导师
 * Author URI: https://wpdev.com.cn
 * Text Domain: external-links-tracker
 * License: GPL v2 or later
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('ELT_VERSION', '1.1.0');
define('ELT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ELT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ELT_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('ELT_MAX_IMPORT_SIZE', 2097152); // 2 MB

/**
 * The core plugin class.
 */
class External_Links_Tracker {

    /**
     * Initialize the plugin.
     */
    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        add_action('init', array($this, 'init'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));

        add_action('wp_ajax_elt_save_link', array($this, 'save_link'));
        add_action('wp_ajax_elt_delete_link', array($this, 'delete_link'));
        add_action('wp_ajax_elt_reset_count', array($this, 'reset_count'));
        add_action('wp_ajax_elt_export_links', array($this, 'export_links'));
        add_action('wp_ajax_elt_import_links', array($this, 'import_links'));

        add_shortcode('external_link', array($this, 'link_shortcode'));
        add_action('template_redirect', array($this, 'process_redirect'));
    }

    /**
     * Plugin activation hook.
     */
    public function activate() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'elt_links';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            target_url varchar(2048) NOT NULL,
            click_count bigint(20) NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        $this->register_rewrite_rules();
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation hook.
     */
    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Initialize the plugin.
     */
    public function init() {
        $this->register_rewrite_rules();
        add_filter('query_vars', array($this, 'register_query_vars'));
    }

    /**
     * Register rewrite rules for tracked redirect URLs.
     */
    private function register_rewrite_rules() {
        add_rewrite_rule('^go/([^/]*)/?$', 'index.php?elt_redirect=$matches[1]', 'top');
    }

    /**
     * Load plugin text domain.
     */
    public function load_textdomain() {
        load_plugin_textdomain('external-links-tracker', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     * Register custom query vars.
     */
    public function register_query_vars($vars) {
        $vars[] = 'elt_redirect';
        return $vars;
    }

    /**
     * Validate that a target URL uses http or https.
     */
    private function is_valid_target_url($url) {
        if (empty($url)) {
            return false;
        }

        $parsed = wp_parse_url($url);

        if (empty($parsed['scheme']) || !in_array($parsed['scheme'], array('http', 'https'), true)) {
            return false;
        }

        return (bool) filter_var($url, FILTER_VALIDATE_URL);
    }

    /**
     * Detect common bot or prefetch requests.
     */
    private function should_skip_click_count() {
        if (!empty($_SERVER['HTTP_PURPOSE']) && stripos($_SERVER['HTTP_PURPOSE'], 'prefetch') !== false) {
            return true;
        }

        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return false;
        }

        $user_agent = strtolower(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])));
        $bot_patterns = array('bot', 'crawl', 'spider', 'slurp', 'mediapartners', 'facebookexternalhit');

        foreach ($bot_patterns as $pattern) {
            if (strpos($user_agent, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Add admin menu.
     */
    public function add_admin_menu() {
        add_menu_page(
            __('External Links Tracker', 'external-links-tracker'),
            __('External Links', 'external-links-tracker'),
            'manage_options',
            'external-links-tracker',
            array($this, 'admin_page'),
            'dashicons-admin-links',
            25
        );
    }

    /**
     * Enqueue admin scripts and styles.
     */
    public function enqueue_admin_scripts($hook) {
        if ('toplevel_page_external-links-tracker' !== $hook) {
            return;
        }

        wp_enqueue_style('elt-admin-css', ELT_PLUGIN_URL . 'assets/css/admin.css', array(), ELT_VERSION);
        wp_enqueue_script('elt-admin-js', ELT_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), ELT_VERSION, true);

        wp_localize_script('elt-admin-js', 'elt_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('elt_nonce'),
            'i18n'     => array(
                'save_link'           => __('Save Link', 'external-links-tracker'),
                'update_link'         => __('Update Link', 'external-links-tracker'),
                'error_generic'       => __('An error occurred. Please try again.', 'external-links-tracker'),
                'confirm_delete'      => __('Are you sure you want to delete this link? This action cannot be undone.', 'external-links-tracker'),
                'confirm_reset'       => __('Are you sure you want to reset the click count to zero?', 'external-links-tracker'),
                'copy_shortcode'      => __('Copy shortcode', 'external-links-tracker'),
                'copied'              => __('Copied!', 'external-links-tracker'),
                'exporting'           => __('Exporting...', 'external-links-tracker'),
                'export_links'        => __('Export Links', 'external-links-tracker'),
                'export_success'      => __('Links exported successfully.', 'external-links-tracker'),
                'importing'           => __('Importing...', 'external-links-tracker'),
                'import_links'        => __('Import Links', 'external-links-tracker'),
                'select_file'         => __('Please select a file to import.', 'external-links-tracker'),
                'invalid_json_file'   => __('Please select a JSON file to import.', 'external-links-tracker'),
                'search_placeholder'  => __('Search links...', 'external-links-tracker'),
                'no_search_results'   => __('No links match your search.', 'external-links-tracker'),
            ),
        ));
    }

    /**
     * Render a copy-to-clipboard button.
     */
    private function render_copy_button($text, $label) {
        ?>
        <button type="button"
                class="button button-small elt-copy-btn"
                data-copy="<?php echo esc_attr($text); ?>"
                title="<?php echo esc_attr($label); ?>">
            <?php echo esc_html($label); ?>
        </button>
        <?php
    }

    /**
     * Render admin page.
     */
    public function admin_page() {
        $links = $this->get_all_links();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('External Links Tracker', 'external-links-tracker'); ?></h1>

            <div class="elt-admin-container">
                <div class="elt-admin-section">
                    <h2><?php esc_html_e('Add New Link', 'external-links-tracker'); ?></h2>
                    <form id="elt-add-link-form">
                        <input type="hidden" name="link_id" id="link_id" value="">

                        <div class="form-group">
                            <label for="link_name"><?php esc_html_e('Link Name', 'external-links-tracker'); ?></label>
                            <input type="text" id="link_name" name="link_name" required>
                        </div>

                        <div class="form-group">
                            <label for="link_slug"><?php esc_html_e('Link Slug', 'external-links-tracker'); ?></label>
                            <input type="text" id="link_slug" name="link_slug" required>
                            <p class="description"><?php esc_html_e('Used in URL: yourdomain.com/go/slug', 'external-links-tracker'); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="target_url"><?php esc_html_e('Target URL', 'external-links-tracker'); ?></label>
                            <input type="url" id="target_url" name="target_url" required placeholder="https://">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="button button-primary" id="elt-save-button">
                                <?php esc_html_e('Save Link', 'external-links-tracker'); ?>
                            </button>
                            <button type="button" class="button" id="elt-cancel-button" style="display: none;">
                                <?php esc_html_e('Cancel', 'external-links-tracker'); ?>
                            </button>
                        </div>
                    </form>
                </div>

                <div class="elt-admin-section">
                    <div class="elt-section-header">
                        <h2><?php esc_html_e('Your Links', 'external-links-tracker'); ?></h2>
                        <?php if (!empty($links)) : ?>
                            <input type="search"
                                   id="elt-search-links"
                                   class="elt-search-input"
                                   placeholder="<?php esc_attr_e('Search links...', 'external-links-tracker'); ?>">
                        <?php endif; ?>
                    </div>

                    <?php if (empty($links)) : ?>
                        <p><?php esc_html_e('No links found. Create your first link above.', 'external-links-tracker'); ?></p>
                    <?php else : ?>
                        <p id="elt-no-search-results" class="elt-no-results" style="display: none;">
                            <?php esc_html_e('No links match your search.', 'external-links-tracker'); ?>
                        </p>
                        <table class="wp-list-table widefat fixed striped" id="elt-links-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Name', 'external-links-tracker'); ?></th>
                                    <th><?php esc_html_e('Redirect URL', 'external-links-tracker'); ?></th>
                                    <th><?php esc_html_e('Your Link', 'external-links-tracker'); ?></th>
                                    <th><?php esc_html_e('Clicks', 'external-links-tracker'); ?></th>
                                    <th><?php esc_html_e('Shortcode', 'external-links-tracker'); ?></th>
                                    <th><?php esc_html_e('Actions', 'external-links-tracker'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($links as $link) : ?>
                                    <?php
                                    $redirect_url   = home_url('go/' . $link->slug);
                                    $shortcode_id   = sprintf('[external_link id="%d"]', $link->id);
                                    $shortcode_slug = sprintf('[external_link slug="%s"]', $link->slug);
                                    $search_text    = strtolower($link->name . ' ' . $link->slug . ' ' . $link->target_url);
                                    ?>
                                    <tr data-id="<?php echo esc_attr($link->id); ?>" data-search="<?php echo esc_attr($search_text); ?>">
                                        <td><?php echo esc_html($link->name); ?></td>
                                        <td>
                                            <a href="<?php echo esc_url($link->target_url); ?>" target="_blank" rel="noopener noreferrer">
                                                <?php echo esc_html(wp_html_excerpt($link->target_url, 50, '...')); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <code class="elt-copy-text"><?php echo esc_html($redirect_url); ?></code>
                                            <?php $this->render_copy_button($redirect_url, __('Copy', 'external-links-tracker')); ?>
                                        </td>
                                        <td>
                                            <span class="elt-click-count"><?php echo esc_html(number_format_i18n($link->click_count)); ?></span>
                                            <a href="#" class="elt-reset-count" data-id="<?php echo esc_attr($link->id); ?>">
                                                <?php esc_html_e('Reset', 'external-links-tracker'); ?>
                                            </a>
                                        </td>
                                        <td class="elt-shortcode-cell">
                                            <div class="elt-shortcode-row">
                                                <code><?php echo esc_html($shortcode_id); ?></code>
                                                <?php $this->render_copy_button($shortcode_id, __('Copy', 'external-links-tracker')); ?>
                                            </div>
                                            <div class="elt-shortcode-row">
                                                <code><?php echo esc_html($shortcode_slug); ?></code>
                                                <?php $this->render_copy_button($shortcode_slug, __('Copy', 'external-links-tracker')); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="#" class="elt-edit-link"
                                               data-id="<?php echo esc_attr($link->id); ?>"
                                               data-name="<?php echo esc_attr($link->name); ?>"
                                               data-slug="<?php echo esc_attr($link->slug); ?>"
                                               data-url="<?php echo esc_attr($link->target_url); ?>">
                                                <?php esc_html_e('Edit', 'external-links-tracker'); ?>
                                            </a> |
                                            <a href="#" class="elt-delete-link" data-id="<?php echo esc_attr($link->id); ?>">
                                                <?php esc_html_e('Delete', 'external-links-tracker'); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <div class="elt-admin-section">
                    <h2><?php esc_html_e('Import / Export', 'external-links-tracker'); ?></h2>
                    <div class="elt-import-export-container">
                        <div class="elt-export">
                            <h3><?php esc_html_e('Export Links', 'external-links-tracker'); ?></h3>
                            <p><?php esc_html_e('Export all your links as a JSON file.', 'external-links-tracker'); ?></p>
                            <button type="button" class="button button-secondary" id="elt-export-button">
                                <?php esc_html_e('Export Links', 'external-links-tracker'); ?>
                            </button>
                        </div>

                        <div class="elt-import">
                            <h3><?php esc_html_e('Import Links', 'external-links-tracker'); ?></h3>
                            <p><?php esc_html_e('Import links from a JSON file.', 'external-links-tracker'); ?></p>
                            <form id="elt-import-form" enctype="multipart/form-data">
                                <input type="file" name="import_file" id="elt-import-file" accept=".json,application/json">
                                <button type="submit" class="button button-secondary" id="elt-import-button">
                                    <?php esc_html_e('Import Links', 'external-links-tracker'); ?>
                                </button>
                            </form>
                            <p class="description">
                                <?php esc_html_e('Note: Importing links with slugs that already exist will update those links.', 'external-links-tracker'); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="elt-admin-section">
                    <h2><?php esc_html_e('How to Use', 'external-links-tracker'); ?></h2>
                    <p><?php esc_html_e('Use the following methods to link to your external URLs:', 'external-links-tracker'); ?></p>

                    <ol>
                        <li>
                            <strong><?php esc_html_e('Direct Link:', 'external-links-tracker'); ?></strong>
                            <code><?php echo esc_html(home_url('go/your-slug')); ?></code>
                        </li>
                        <li>
                            <strong><?php esc_html_e('Shortcode by ID:', 'external-links-tracker'); ?></strong>
                            <code>[external_link id="123"]Link Text[/external_link]</code>
                        </li>
                        <li>
                            <strong><?php esc_html_e('Shortcode by Slug:', 'external-links-tracker'); ?></strong>
                            <code>[external_link slug="your-slug"]Link Text[/external_link]</code>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Get all links from the database.
     */
    private function get_all_links() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        return $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
    }

    /**
     * Get a link by ID or slug.
     */
    private function get_link($id_or_slug, $by = 'id') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        if ($by === 'id') {
            return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id_or_slug));
        }

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE slug = %s", $id_or_slug));
    }

    /**
     * AJAX handler to save or update a link.
     */
    public function save_link() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'elt_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'external-links-tracker')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this', 'external-links-tracker')));
        }

        $link_id    = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        $link_name  = isset($_POST['link_name']) ? sanitize_text_field(wp_unslash($_POST['link_name'])) : '';
        $link_slug  = isset($_POST['link_slug']) ? sanitize_title(wp_unslash($_POST['link_slug'])) : '';
        $target_url = isset($_POST['target_url']) ? esc_url_raw(wp_unslash($_POST['target_url'])) : '';

        if (empty($link_slug)) {
            $link_slug = 'link-' . wp_generate_password(8, false, false);
        }

        if (empty($link_name) || empty($link_slug) || empty($target_url)) {
            wp_send_json_error(array('message' => __('All fields are required', 'external-links-tracker')));
        }

        if (!$this->is_valid_target_url($target_url)) {
            wp_send_json_error(array('message' => __('Please enter a valid http or https URL.', 'external-links-tracker')));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        $existing_link = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM $table_name WHERE slug = %s AND id != %d", $link_slug, $link_id)
        );

        if ($existing_link) {
            wp_send_json_error(array('message' => __('This slug is already in use. Please choose another one.', 'external-links-tracker')));
        }

        $data = array(
            'name'       => $link_name,
            'slug'       => $link_slug,
            'target_url' => $target_url,
        );

        if ($link_id > 0) {
            $result  = $wpdb->update($table_name, $data, array('id' => $link_id), array('%s', '%s', '%s'), array('%d'));
            $message = __('Link updated successfully', 'external-links-tracker');
        } else {
            $result  = $wpdb->insert($table_name, $data, array('%s', '%s', '%s'));
            $link_id = $wpdb->insert_id;
            $message = __('Link created successfully', 'external-links-tracker');
        }

        if (false === $result) {
            wp_send_json_error(array('message' => __('Could not save the link. Please try again.', 'external-links-tracker')));
        }

        $link = $this->get_link($link_id);

        if (!$link) {
            wp_send_json_error(array('message' => __('Link saved but could not be retrieved.', 'external-links-tracker')));
        }

        wp_send_json_success(array(
            'message'          => $message,
            'link'             => $link,
            'redirect_url'     => home_url('go/' . $link->slug),
            'shortcode_id'     => sprintf('[external_link id="%d"]', $link_id),
            'shortcode_slug'   => sprintf('[external_link slug="%s"]', $link->slug),
        ));
    }

    /**
     * AJAX handler to delete a link.
     */
    public function delete_link() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'elt_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'external-links-tracker')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this', 'external-links-tracker')));
        }

        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;

        if ($link_id <= 0) {
            wp_send_json_error(array('message' => __('Invalid link ID', 'external-links-tracker')));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        $result = $wpdb->delete($table_name, array('id' => $link_id), array('%d'));

        if (false === $result) {
            wp_send_json_error(array('message' => __('Could not delete the link. Please try again.', 'external-links-tracker')));
        }

        wp_send_json_success(array('message' => __('Link deleted successfully', 'external-links-tracker')));
    }

    /**
     * AJAX handler to reset click count.
     */
    public function reset_count() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'elt_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'external-links-tracker')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this', 'external-links-tracker')));
        }

        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;

        if ($link_id <= 0) {
            wp_send_json_error(array('message' => __('Invalid link ID', 'external-links-tracker')));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        $result = $wpdb->update(
            $table_name,
            array('click_count' => 0),
            array('id' => $link_id),
            array('%d'),
            array('%d')
        );

        if (false === $result) {
            wp_send_json_error(array('message' => __('Could not reset click count. Please try again.', 'external-links-tracker')));
        }

        wp_send_json_success(array('message' => __('Click count reset successfully', 'external-links-tracker')));
    }

    /**
     * Increment click count for a link.
     */
    private function increment_click_count($link_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';

        $wpdb->query($wpdb->prepare(
            "UPDATE $table_name SET click_count = click_count + 1 WHERE id = %d",
            $link_id
        ));
    }

    /**
     * Process redirect request.
     */
    public function process_redirect() {
        $redirect_slug = get_query_var('elt_redirect');

        if (empty($redirect_slug)) {
            return;
        }

        $redirect_slug = sanitize_title($redirect_slug);
        $link          = $this->get_link($redirect_slug, 'slug');

        if ($link && $this->is_valid_target_url($link->target_url)) {
            if (!$this->should_skip_click_count()) {
                $this->increment_click_count($link->id);
            }

            // External destinations must use wp_redirect; wp_safe_redirect only allows same-host URLs.
            wp_redirect(esc_url_raw($link->target_url), 302);
            exit;
        }

        wp_safe_redirect(home_url(), 302);
        exit;
    }

    /**
     * Link shortcode handler.
     */
    public function link_shortcode($atts, $content = null) {
        $atts = shortcode_atts(array(
            'id'     => 0,
            'slug'   => '',
            'class'  => '',
            'target' => '_blank',
            'rel'    => '',
        ), $atts, 'external_link');

        $link = null;

        if (!empty($atts['id'])) {
            $link = $this->get_link(intval($atts['id']));
        } elseif (!empty($atts['slug'])) {
            $link = $this->get_link(sanitize_title($atts['slug']), 'slug');
        }

        if (!$link) {
            return '';
        }

        $redirect_url = home_url('go/' . $link->slug);
        $link_text    = $content !== null && $content !== '' ? wp_kses_post($content) : esc_html($link->name);
        $classes      = !empty($atts['class']) ? ' class="' . esc_attr($atts['class']) . '"' : '';
        $target       = !empty($atts['target']) ? ' target="' . esc_attr($atts['target']) . '"' : '';

        $rel_parts = array_filter(array_map('trim', explode(' ', $atts['rel'])));
        if ('_blank' === $atts['target']) {
            $rel_parts[] = 'noopener';
            $rel_parts[] = 'noreferrer';
        }
        $rel_parts   = array_unique($rel_parts);
        $rel_attr    = !empty($rel_parts) ? ' rel="' . esc_attr(implode(' ', $rel_parts)) . '"' : '';

        return sprintf(
            '<a href="%s"%s%s%s>%s</a>',
            esc_url($redirect_url),
            $classes,
            $target,
            $rel_attr,
            $link_text
        );
    }

    /**
     * AJAX handler to export links.
     */
    public function export_links() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'elt_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'external-links-tracker')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this', 'external-links-tracker')));
        }

        $links = $this->get_all_links();
        $export_links = array();

        foreach ($links as $link) {
            $export_links[] = array(
                'name'        => $link->name,
                'slug'        => $link->slug,
                'target_url'  => $link->target_url,
                'click_count' => (int) $link->click_count,
            );
        }

        $export_data = array(
            'plugin' => 'External Links Tracker',
            'version' => ELT_VERSION,
            'date'   => current_time('mysql'),
            'links'  => $export_links,
        );

        wp_send_json_success(array(
            'export_data' => $export_data,
            'filename'    => 'external-links-export-' . gmdate('Y-m-d') . '.json',
        ));
    }

    /**
     * AJAX handler to import links.
     */
    public function import_links() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'elt_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'external-links-tracker')));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this', 'external-links-tracker')));
        }

        if (!isset($_FILES['import_file']) || UPLOAD_ERR_OK !== (int) $_FILES['import_file']['error']) {
            wp_send_json_error(array('message' => __('No file uploaded or upload error', 'external-links-tracker')));
        }

        if (!empty($_FILES['import_file']['size']) && (int) $_FILES['import_file']['size'] > ELT_MAX_IMPORT_SIZE) {
            wp_send_json_error(array('message' => __('Import file is too large. Maximum size is 2 MB.', 'external-links-tracker')));
        }

        $file_content = file_get_contents($_FILES['import_file']['tmp_name']);

        if (empty($file_content)) {
            wp_send_json_error(array('message' => __('Empty file or could not read file content', 'external-links-tracker')));
        }

        $import_data = json_decode($file_content);

        if (JSON_ERROR_NONE !== json_last_error()) {
            wp_send_json_error(array('message' => __('Invalid JSON format', 'external-links-tracker')));
        }

        if (!isset($import_data->plugin, $import_data->links) || 'External Links Tracker' !== $import_data->plugin || !is_array($import_data->links)) {
            wp_send_json_error(array('message' => __('Invalid import file format', 'external-links-tracker')));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'elt_links';
        $imported   = 0;
        $updated    = 0;
        $skipped    = 0;

        foreach ($import_data->links as $link) {
            if (!is_object($link) || !isset($link->name, $link->slug, $link->target_url)) {
                $skipped++;
                continue;
            }

            $data = array(
                'name'        => sanitize_text_field($link->name),
                'slug'        => sanitize_title($link->slug),
                'target_url'  => esc_url_raw($link->target_url),
                'click_count' => isset($link->click_count) ? max(0, intval($link->click_count)) : 0,
            );

            if (empty($data['name']) || empty($data['slug']) || !$this->is_valid_target_url($data['target_url'])) {
                $skipped++;
                continue;
            }

            $existing_link = $this->get_link($data['slug'], 'slug');

            if ($existing_link) {
                $result = $wpdb->update(
                    $table_name,
                    $data,
                    array('id' => $existing_link->id),
                    array('%s', '%s', '%s', '%d'),
                    array('%d')
                );

                if (false !== $result) {
                    $updated++;
                } else {
                    $skipped++;
                }
            } else {
                $result = $wpdb->insert(
                    $table_name,
                    $data,
                    array('%s', '%s', '%s', '%d')
                );

                if (false !== $result) {
                    $imported++;
                } else {
                    $skipped++;
                }
            }
        }

        $message = sprintf(
            __('Import completed. %1$d imported, %2$d updated, %3$d skipped.', 'external-links-tracker'),
            $imported,
            $updated,
            $skipped
        );

        wp_send_json_success(array('message' => $message));
    }
}

// Initialize the plugin
$external_links_tracker = new External_Links_Tracker();
