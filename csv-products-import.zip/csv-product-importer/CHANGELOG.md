# Changelog

All notable changes to CSV Product Importer Pro are documented here.

## [2.3.2] – 2026-06-19

### Fixed
- **Granular directory diagnostics** — `count_disk_files()` now reports whether the images directory was found, how many total image files are in it, and sample filenames. This surfaces the exact reason images aren't matching in the import result message.

## [2.3.1] – 2026-06-19

### Fixed
- **Image matching at scale** — `find_attachments_by_mpn()` now uses a static cache so the media library is queried once per import instead of once per product. Previously, with 5,000+ images, the query ran for every product row causing massive slowdown and potential timeouts that silently prevented image assignment.
- Added `count_disk_files()` diagnostic to detect mismatches between disk files and media library registrations.
- `set_product_images()` now receives the full `$row` as a third parameter, enabling the MPN fallback chain.
- Import stats now include `disk_files_found` and per-product `missing_images` diagnostics visible in the details panel.

## [2.3.0] – 2026-06-19

### Changed
- **Unique key switched to `product_mpn`** — duplicate detection now uses the `product_mpn` column instead of `oem_num`. The `product_mpn` column is now the only required CSV column.
- **Title formula revised** — titles are now assembled as `cross_ref` + `type` + `for` + `car_brand` + `car_application` (e.g. "DACF301344071L2 front wheel hub unit for BAIC Huansu S2 S3 H3 1.5L"). The old formula was `car_brand` + `car_application` + `type` + `cross_ref` without a connector.
- **`IMAGE_KEY` now mirrors `UNIQUE_KEY`** — both default to `product_mpn`. Image matching and duplicate detection use the same column.

### Added
- **Image assignment stats in the import panel** — the right-side statistics now show **"With Images"** (how many products received image assignments) and **"Total Images"** (sum of all gallery images assigned). These update live during batch import and appear in the final success message.
- `set_product_images()` now returns `['thumbnail' => bool, 'gallery_count' => int]` for tracking.
- `persist_product_data()` returns image stats so `process_row()` and `import_batch()` can aggregate them.

### Fixed
- `update_image_assignments()` batch function retains `oem_num` fallback for backwards compatibility with older products.

## [2.1.0] – 2026-05-19

### Added
- **Post content generation** — each imported product post is now populated with a structured body built from its CSV meta fields. The format is:
  ```
  {Post Title}        ← wrapped in <h2>
  OEM Number: {oem_num}
  Car Application: {car_application}
  Diameter: {outer_diameter}
  Weight: {weight}
  ```
  Fields with no value in the CSV row are omitted automatically.
- `CPI_Config::CONTENT_FORMULA` constant — a simple array that controls which meta columns appear in the post content and their human-readable labels. Add, remove, or reorder entries without touching importer logic.
- `CPI_Config::build_post_content( array $row, string $title ): string` — static helper that assembles and HTML-escapes the post body from a CSV row.
- Post content is written on both **insert** (new products) and **update** (existing products in "update" duplicate mode).

### Changed
- Post content title is wrapped in `<h2>` tags.
- All field labels in the post content are wrapped in `<strong>` tags.

### Fixed
- **Chinese character garbling in GBK/GB2312 CSV files** — encoding detection is now performed on the entire file content rather than per cell value. Short GBK byte pairs (e.g. `系` = `0xCF 0xB5`) are accidentally valid UTF-8 sequences (`ϵ`), causing per-value `mb_check_encoding()` to return a false positive and skip conversion. Whole-file detection via `mb_detect_encoding()` in strict mode eliminates these false positives and correctly converts GBK, GB18030, BIG5, and other Chinese encodings to UTF-8 before parsing.

---

## [2.0.0] – Initial release

- Import products from CSV into a configurable WordPress post type.
- Auto-generates post titles from a configurable column formula (`TITLE_FORMULA`).
- Saves every CSV column as post meta (key = lowercased column header).
- Automatic thumbnail and gallery assignment by matching image filenames against a configurable `IMAGE_KEY` column.
- Per-row taxonomy (product category) assignment via `TAXONOMY_COLUMN`.
- Polylang integration — sets default language and pushes meta / gallery to translations.
- Batch import with configurable batch size and offset.
- Duplicate handling modes: skip, update, or allow duplicates.
- Admin UI with CSV preview, import progress, and per-batch AJAX processing.
