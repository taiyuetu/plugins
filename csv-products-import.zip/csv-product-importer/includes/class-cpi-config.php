<?php
defined( 'ABSPATH' ) || exit;

/**
 * Central configuration for CSV Product Importer Pro.
 *
 *  POST_TYPE          – target WordPress post type
 *  DESCRIPTION        – subtitle shown in the admin header
 *  TITLE_FORMULA      – how the post title is assembled from column values
 *  UNIQUE_KEY         – column used for duplicate detection
 *  IMAGE_KEY          – column whose value is matched against image filenames
 *  TAXONOMY           – custom taxonomy slug for category assignment
 *  TAXONOMY_COLUMN    – optional CSV column with term slug, name, or ID (per row)
 *  COLUMN_LABELS      – human-readable preview table column headings
 *
 * All CSV column headers are automatically saved as post meta fields
 * with the same (lowercased) name. No hardcoded meta map required.
 */
class CPI_Config {

    /** WordPress post type to import into. */
    public const POST_TYPE = 'product';

    /** Subtitle shown in the admin page header. */
    public const DESCRIPTION = 'Import products from CSV — auto title, dynamic meta fields & image matching';

    /**
     * Title assembly formula.
     *
     *  prefix    – columns joined with a space, placed first.
     *  connector – word inserted between prefix and suffix (e.g. "for").
     *              Set to '' to omit.
     *  suffix    – columns joined with a space, placed last.
     *              Set to [] to omit.
     *
     * Result: "cross_ref type for car_brand car_application"
     */
    public const TITLE_FORMULA = [
        'prefix'    => [ 'cross_ref', 'type' ],
        'connector' => 'for',
        'suffix'    => [ 'car_brand', 'car_application' ],
    ];

    /**
     * The meta key (= CSV column name) used to identify duplicate posts.
     */
    public const UNIQUE_KEY = 'product_mpn';

    /**
     * Column whose value is matched against image filenames in the
     * images folder for automatic thumbnail / gallery assignment.
     */
    public const IMAGE_KEY = 'product_mpn';

    /** Custom taxonomy used for product categories. */
    public const TAXONOMY = 'product_cat';

    /**
     * Optional CSV column for per-row category assignment.
     * Value: term slug, name, or numeric ID. Multiple terms: comma, pipe, or semicolon.
     * Set to '' to disable per-row assignment (admin default only).
     */
    public const TAXONOMY_COLUMN = 'product_cat';

    /**
     * Post content formula.
     *
     * The post body is built as:
     *   <title>
     *   <br>Label: {column_value}
     *   <br>Label: {column_value}
     *   ...
     *
     * Each entry: [ 'label' => 'Human Label', 'column' => 'csv_column_name' ]
     * Rows whose column value is empty are omitted.
     */
    public const CONTENT_FORMULA = [
        [ 'label' => 'OEM Number',       'column' => 'oem_num' ],
        [ 'label' => 'Car Application',  'column' => 'car_application' ],
        [ 'label' => 'Diameter',         'column' => 'outer_diameter' ],
        [ 'label' => 'Weight',           'column' => 'weight' ],
    ];

    /**
     * Human-readable labels for the CSV preview table.
     * Columns not listed here fall back to the raw column name.
     */
    public const COLUMN_LABELS = [
        'type'              => 'Type',
        'product_mpn'       => 'MPN',
        'product_mpn'       => 'MPN (Unique Key)',
        'oem_num'           => 'OEM #',
        'cross_ref'         => 'Cross Ref',
        'car_brand'         => 'Car Brand',
        'car_application'   => 'Application',
        'outer_diameter'    => 'Ø Diameter',
        'weight'            => 'Weight',
        'product_cat'  => 'Product Category',
    ];

    // -------------------------------------------------------------------------
    // Derived helpers — read-only, driven by the constants above.
    // -------------------------------------------------------------------------

    /**
     * Returns the minimum required CSV column names.
     * Only the unique key is strictly required; title columns are optional.
     *
     * @return string[]
     */
    public static function required_headers(): array {
        return array_filter( [ self::UNIQUE_KEY ] );
    }

    /**
     * Builds a readable string representing the title formula.
     *
     * @return string
     */
    public static function title_formula_display(): string {
        $formula   = self::TITLE_FORMULA;
        $tokens    = $formula['prefix'] ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix'] ?? [];

        if ( '' !== $connector ) {
            $tokens[] = '"' . $connector . '"';
        }
        $tokens = array_merge( $tokens, $suffix );

        return implode( ' + ', $tokens );
    }

    /**
     * Column labels merged with the generated-title pseudo-column,
     * ready to pass to JavaScript.
     *
     * @return array<string,string>
     */
    public static function js_column_labels(): array {
        return array_merge(
            [ '_generated_title' => '🏷️ Generated Title' ],
            self::COLUMN_LABELS
        );
    }

    /**
     * Whether taxonomy assignment is enabled and the taxonomy exists.
     */
    public static function taxonomy_enabled(): bool {
        return '' !== self::TAXONOMY && taxonomy_exists( self::TAXONOMY );
    }

    /**
     * Hierarchical product_category terms for the import settings dropdown.
     *
     * @return array<int, array{id:int, name:string, depth:int}>
     */
    public static function get_taxonomy_term_options(): array {
        if ( ! self::taxonomy_enabled() ) {
            return [];
        }

        $args = [
            'taxonomy'   => self::TAXONOMY,
            'hide_empty' => false,
            'orderby'    => 'name',
            'order'      => 'ASC',
        ];

        $terms = get_terms( $args );
        if ( is_wp_error( $terms ) || empty( $terms ) ) {
            return [];
        }

        $by_parent = [];
        foreach ( $terms as $term ) {
            $by_parent[ (int) $term->parent ][] = $term;
        }

        $options = [];
        $walk    = static function ( int $parent_id, int $depth ) use ( &$walk, &$options, $by_parent ): void {
            foreach ( $by_parent[ $parent_id ] ?? [] as $term ) {
                $options[] = [
                    'id'    => (int) $term->term_id,
                    'name'  => $term->name,
                    'depth' => $depth,
                ];
                $walk( (int) $term->term_id, $depth + 1 );
            }
        };

        $walk( 0, 0 );
        return $options;
    }

    /**
     * Build the post_content string from a CSV row and a resolved post title.
     *
     * Format:
     *   <h2>{title}</h2>
     *   <strong>Label:</strong> {value}<br>
     *   ...
     *
     * Lines whose column value is empty are silently skipped.
     *
     * @param  array  $row   Parsed CSV row (column => value).
     * @param  string $title The resolved post title.
     * @return string        HTML-safe post content.
     */
    public static function build_post_content( array $row, string $title ): string {
        $content = '<h2>' . esc_html( $title ) . '</h2>';

        $lines = [];
        foreach ( self::CONTENT_FORMULA as $item ) {
            $value = trim( (string) ( $row[ $item['column'] ] ?? '' ) );
            if ( '' === $value ) {
                continue;
            }
            $lines[] = '<strong>' . esc_html( $item['label'] ) . ':</strong> ' . esc_html( $value );
        }

        if ( ! empty( $lines ) ) {
            $content .= implode( '<br>', $lines );
        }

        return $content;
    }
}
