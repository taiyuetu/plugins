<?php
defined( 'ABSPATH' ) || exit;

/**
 * Polylang-aware meta storage for CSV imports.
 *
 * All meta is always written to the default (base) key — never to
 * language-suffixed keys like product_gallery_en. This ensures a
 * single canonical set of meta fields per post regardless of language.
 */
class CPI_Polylang_Sync {

    /** Meta key for product gallery. */
    public const GALLERY_KEY = 'product_gallery';

    public static function is_active(): bool {
        return function_exists( 'pll_languages_list' );
    }

    public static function default_language(): string {
        return function_exists( 'pll_default_language' ) ? (string) pll_default_language( 'slug' ) : '';
    }

    /**
     * Save ALL CSV columns as post meta using the base (non-suffixed) key.
     * Internal keys (prefixed with _) and the taxonomy column are skipped.
     */
    public static function save_row_meta( int $post_id, array $row ): void {
        $taxonomy_col = strtolower( CPI_Config::TAXONOMY_COLUMN );

        foreach ( $row as $col => $value ) {
            if ( str_starts_with( $col, '_' ) ) {
                continue;
            }
            if ( '' !== $taxonomy_col && $col === $taxonomy_col ) {
                continue;
            }

            $meta_key = strtolower( $col );
            $value    = sanitize_textarea_field( $value );
            self::write_meta( $post_id, $meta_key, $value );
        }
    }

    /**
     * Save product gallery attachment IDs (always base key).
     */
    public static function save_gallery( int $post_id, array $gallery_ids ): void {
        $gallery_ids = array_values( array_filter( array_map( 'intval', $gallery_ids ) ) );
        if ( empty( $gallery_ids ) ) {
            return;
        }

        $gallery_str = implode( ',', $gallery_ids );
        self::write_meta( $post_id, self::GALLERY_KEY, $gallery_str );
        self::write_meta( $post_id, '_product_image_gallery', $gallery_str );
    }

    /**
     * Write one meta value — always to the base key, never language-suffixed.
     */
    public static function write_meta( int $post_id, string $meta_key, string $value ): void {
        if ( '' === $meta_key || '' === $value ) {
            return;
        }

        update_post_meta( $post_id, $meta_key, $value );
    }

    /**
     * Push base meta from a default-language post to all translations.
     * Only runs when Polylang is active and post is in the default language.
     */
    public static function push_to_translations( int $post_id ): void {
        if ( ! self::is_active() ) {
            return;
        }

        if ( ! function_exists( 'pll_get_post_language' ) || ! function_exists( 'pll_get_post_translations' ) ) {
            return;
        }

        $default_lang = self::default_language();
        if ( '' === $default_lang ) {
            return;
        }

        $post_lang = pll_get_post_language( $post_id );
        if ( $post_lang !== $default_lang ) {
            return;
        }

        $translations = pll_get_post_translations( $post_id );
        if ( empty( $translations ) ) {
            return;
        }

        $all_meta = get_post_meta( $post_id );
        if ( empty( $all_meta ) ) {
            return;
        }

        foreach ( $translations as $lang => $translated_post_id ) {
            if ( (int) $translated_post_id === $post_id ) {
                continue;
            }
            foreach ( $all_meta as $key => $values ) {
                if ( str_starts_with( $key, '_' ) && ! in_array( $key, [ '_thumbnail_id', '_product_image_gallery' ], true ) ) {
                    continue;
                }
                foreach ( $values as $value ) {
                    update_post_meta( (int) $translated_post_id, $key, $value );
                }
            }
        }
    }
}
