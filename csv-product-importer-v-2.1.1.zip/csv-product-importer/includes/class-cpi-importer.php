<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles inserting / updating WordPress product posts.
 *
 * All CSV columns are saved as post meta (column name = meta key, lowercased).
 * Images are sourced from the "images" folder alongside the uploaded CSV
 * (wp-content/uploads/cpi-imports/images/) and matched to products via
 * the IMAGE_KEY column value (case-insensitive).
 */
class CPI_Importer {

    /**
     * Import a batch of parsed rows.
     *
     * @param array  $rows
     * @param string $duplicate       'skip' | 'update' | 'duplicate'
     * @param string $post_status     'publish' | 'draft' | 'pending'
     * @param int    $batch_offset
     * @param int    $batch_size
     * @param int    $default_term_id Default product_category term ID when CSV column is empty.
     *
     * @return array{imported:int, updated:int, skipped:int, error_count:int, errors:string[], skipped_messages:string[]}
     */
    public static function import_batch(
        array $rows,
        string $duplicate = 'skip',
        string $post_status = 'publish',
        int $batch_offset = 0,
        int $batch_size = 50,
        int $default_term_id = 0
    ): array {
        $stats = [
            'imported'         => 0,
            'updated'          => 0,
            'skipped'          => 0,
            'error_count'      => 0,
            'errors'           => [],
            'skipped_messages' => [],
        ];

        foreach ( array_slice( $rows, $batch_offset, $batch_size ) as $row ) {
            $result = self::process_row( $row, $duplicate, $post_status, $default_term_id );
            if ( $result['action'] === 'errors' ) {
                $stats['error_count']++;
            } else {
                $stats[ $result['action'] ]++;
            }
            if ( ! empty( $result['error'] ) ) {
                $stats['errors'][] = $result['error'];
            }
            if ( ! empty( $result['skip_message'] ) ) {
                $stats['skipped_messages'][] = $result['skip_message'];
            }
        }

        return $stats;
    }

    /**
     * Public entry point for gallery sync on a single post.
     */
    public static function sync_images_for_post( int $post_id, string $mpn ): void {
        self::set_product_images( $post_id, $mpn );
    }

    // -------------------------------------------------------------------------

    private static function process_row(
        array $row,
        string $duplicate,
        string $post_status,
        int $default_term_id = 0
    ): array {
        $unique_key = CPI_Config::UNIQUE_KEY;
        $raw_unique = trim( (string) ( $row[ $unique_key ] ?? '' ) );
        $unique_val = sanitize_text_field( $raw_unique );
        if ( '' === $unique_val && '' !== $raw_unique ) {
            $unique_val = wp_strip_all_tags( $raw_unique );
        }

        $title      = self::resolve_post_title( $row, $unique_val );
        $identifier = $unique_val ?: $title;

        $existing_id = self::find_existing( $unique_val );

        if ( $existing_id ) {
            if ( 'skip' === $duplicate ) {
                return [
                    'action'       => 'skipped',
                    'error'        => '',
                    'skip_message' => sprintf(
                        'Skipped existing product: %s (post ID %d).',
                        $identifier,
                        $existing_id
                    ),
                ];
            }

            if ( 'update' === $duplicate ) {
                $post_id = wp_update_post( [
                    'ID'           => $existing_id,
                    'post_title'   => $title,
                    'post_status'  => $post_status,
                    'post_content' => CPI_Config::build_post_content( $row, $title ),
                ], true );

                if ( is_wp_error( $post_id ) ) {
                    return [
                        'action'       => 'errors',
                        'error'        => sprintf( 'Failed updating %s: %s', $identifier, $post_id->get_error_message() ),
                        'skip_message' => '',
                    ];
                }

                self::persist_product_data( $post_id, $row, $default_term_id );
                return [ 'action' => 'updated', 'error' => '', 'skip_message' => '' ];
            }
        }

        $post_id = wp_insert_post( [
            'post_title'   => $title,
            'post_type'    => CPI_Config::POST_TYPE,
            'post_status'  => $post_status,
            'post_content' => CPI_Config::build_post_content( $row, $title ),
        ], true );

        if ( is_wp_error( $post_id ) ) {
            return [
                'action'       => 'errors',
                'error'        => sprintf( 'Failed inserting %s: %s', $identifier, $post_id->get_error_message() ),
                'skip_message' => '',
            ];
        }

        self::persist_product_data( $post_id, $row, $default_term_id );
        return [ 'action' => 'imported', 'error' => '', 'skip_message' => '' ];
    }

    /**
     * Assign language (default if Polylang active), save meta, images, taxonomy,
     * then sync to Polylang translations.
     */
    private static function persist_product_data(
        int $post_id,
        array $row,
        int $default_term_id
    ): void {
        self::set_post_language( $post_id );
        CPI_Polylang_Sync::save_row_meta( $post_id, $row );
        self::set_product_images( $post_id, $row[ CPI_Config::IMAGE_KEY ] ?? '' );
        self::assign_taxonomy( $post_id, $row, $default_term_id );
        CPI_Polylang_Sync::push_to_translations( $post_id );
    }

    /**
     * Resolve a post title that survives WordPress sanitization.
     */
    private static function resolve_post_title( array $row, string $unique_val ): string {
        $generated = trim( (string) ( $row['_generated_title'] ?? CPI_CSV_Parser::build_title( $row ) ) );

        $candidates = array_filter( [
            $generated,
            $unique_val,
            trim( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? '' ) ),
            trim( (string) ( $row['product_mpn'] ?? '' ) ),
        ], static fn( $v ) => '' !== $v );

        foreach ( $candidates as $candidate ) {
            $sanitized = sanitize_text_field( $candidate );
            if ( '' !== $sanitized ) {
                return $sanitized;
            }
        }

        foreach ( $candidates as $candidate ) {
            $stripped = trim( wp_strip_all_tags( $candidate ) );
            if ( '' !== $stripped ) {
                return mb_substr( $stripped, 0, 200 );
            }
        }

        return 'product-' . wp_generate_password( 8, false, false );
    }

    /**
     * Assign the Polylang default language to a post.
     * If Polylang is not active, does nothing.
     */
    private static function set_post_language( int $post_id ): void {
        if ( ! function_exists( 'pll_set_post_language' ) || ! function_exists( 'pll_default_language' ) ) {
            return;
        }
        $default = pll_default_language( 'slug' );
        if ( '' !== $default ) {
            pll_set_post_language( $post_id, $default );
        }
    }

    /**
     * Assign product_category terms from the CSV column or admin default.
     */
    private static function assign_taxonomy(
        int $post_id,
        array $row,
        int $default_term_id
    ): void {
        if ( ! CPI_Config::taxonomy_enabled() ) {
            return;
        }

        $col = CPI_Config::TAXONOMY_COLUMN;
        $raw = '' !== $col ? trim( (string) ( $row[ $col ] ?? '' ) ) : '';

        if ( '' !== $raw ) {
            $term_ids = self::resolve_term_ids( $raw );
        } elseif ( $default_term_id > 0 ) {
            $term_ids = [ $default_term_id ];
        } else {
            return;
        }

        $term_ids = array_values( array_filter( array_unique( array_map( 'intval', $term_ids ) ) ) );
        if ( empty( $term_ids ) ) {
            return;
        }

        wp_set_object_terms( $post_id, $term_ids, CPI_Config::TAXONOMY, false );
    }

    /**
     * @return int[]
     */
    private static function resolve_term_ids( string $raw ): array {
        $tokens = preg_split( '/[|,;]+/', $raw ) ?: [];
        $ids    = [];

        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }

            $term_id = self::resolve_single_term( $token );
            if ( $term_id > 0 ) {
                $ids[] = $term_id;
            }
        }

        return $ids;
    }

    private static function resolve_single_term( string $value ): int {
        $taxonomy = CPI_Config::TAXONOMY;

        if ( ctype_digit( $value ) ) {
            $term = get_term( (int) $value, $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                return (int) $term->term_id;
            }
            return 0;
        }

        $args = [
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'number'     => 1,
        ];

        $args['slug'] = sanitize_title( $value );
        $terms        = get_terms( $args );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            return (int) $terms[0]->term_id;
        }

        unset( $args['slug'] );
        $args['name'] = $value;
        $terms        = get_terms( $args );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            return (int) $terms[0]->term_id;
        }

        return 0;
    }

    // -------------------------------------------------------------------------
    // Image handling
    // -------------------------------------------------------------------------

    /**
     * Find matching images and assign them as thumbnail + gallery.
     *
     * Images are looked up in two places:
     *  1. The "images" folder alongside the CSV (wp-content/uploads/cpi-imports/images/)
     *  2. Already-registered attachments in the media library
     *
     * Filename matching is fully case-insensitive.
     */
    private static function set_product_images( int $post_id, string $key_value ): void {
        if ( '' === CPI_Config::IMAGE_KEY ) {
            return;
        }

        $key_value = trim( $key_value );
        if ( '' === $key_value ) {
            return;
        }

        self::maybe_register_disk_images( $key_value );

        $matched = self::find_attachments_by_mpn( $key_value );
        if ( empty( $matched ) ) {
            return;
        }

        usort( $matched, static fn( $a, $b ) => $a['sequence'] !== $b['sequence']
            ? $a['sequence'] <=> $b['sequence']
            : $a['id'] <=> $b['id']
        );

        $gallery_ids  = array_column( $matched, 'id' );
        $thumbnail_id = 0;

        foreach ( $matched as $attachment ) {
            if ( 1 === $attachment['sequence'] ) {
                $thumbnail_id = $attachment['id'];
                break;
            }
        }

        if ( ! $thumbnail_id ) {
            $thumbnail_id = $gallery_ids[0];
        }

        set_post_thumbnail( $post_id, $thumbnail_id );
        update_post_meta( $post_id, '_thumbnail_id', $thumbnail_id );

        CPI_Polylang_Sync::save_gallery( $post_id, $gallery_ids );
    }

    /**
     * Scan the images folder for files matching the MPN key and register
     * any that are not already in the WordPress media library.
     *
     * Looks in wp-content/uploads/cpi-imports/images/ (case-insensitive).
     */
    private static function maybe_register_disk_images( string $key_value ): void {
        $upload_dir  = wp_upload_dir();
        $images_dir  = trailingslashit( $upload_dir['basedir'] ) . 'cpi-imports/images/';

        if ( ! is_dir( $images_dir ) ) {
            return;
        }

        $key_lower = strtolower( $key_value );

        $files = scandir( $images_dir );
        if ( ! $files ) {
            return;
        }

        $registered = self::get_registered_filenames_for_mpn( $key_value );
        $registered_lower = array_map( 'strtolower', $registered );

        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        foreach ( $files as $filename ) {
            if ( in_array( $filename, [ '.', '..' ], true ) ) {
                continue;
            }
            if ( preg_match( '/-\d+x\d+\.[^.]+$/i', $filename ) ) {
                continue;
            }

            $name_lower = strtolower( $filename );
            if ( ! str_starts_with( $name_lower, $key_lower ) ) {
                continue;
            }

            $sequence = self::parse_mpn_image_sequence( $filename, $key_value, $key_lower );
            if ( null === $sequence ) {
                continue;
            }

            if ( in_array( $name_lower, $registered_lower, true ) ) {
                continue;
            }

            $file_path = $images_dir . $filename;
            if ( ! is_readable( $file_path ) ) {
                continue;
            }

            $filetype = wp_check_filetype( $filename );
            if ( empty( $filetype['type'] ) || ! str_starts_with( $filetype['type'], 'image/' ) ) {
                continue;
            }

            $relative_path = 'cpi-imports/images/' . $filename;

            $attachment = [
                'post_mime_type' => $filetype['type'],
                'post_title'    => preg_replace( '/\.[^.]+$/', '', $filename ),
                'post_content'  => '',
                'post_status'   => 'inherit',
            ];

            $attach_id = wp_insert_attachment( $attachment, $file_path );

            if ( is_wp_error( $attach_id ) || ! $attach_id ) {
                continue;
            }

            $metadata = wp_generate_attachment_metadata( $attach_id, $file_path );
            wp_update_attachment_metadata( $attach_id, $metadata );

            update_post_meta( $attach_id, '_wp_attached_file', $relative_path );
        }
    }

    /**
     * Returns filenames already registered under cpi-imports/images/ for the MPN.
     *
     * @return string[]
     */
    private static function get_registered_filenames_for_mpn( string $key_value ): array {
        global $wpdb;

        $like_cpi = $wpdb->esc_like( 'cpi-imports/images/' . $key_value ) . '%';
        $like_old = $wpdb->esc_like( 'products/' . $key_value ) . '%';

        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT pm.meta_value
             FROM $wpdb->postmeta pm
             INNER JOIN $wpdb->posts p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_wp_attached_file'
               AND ( pm.meta_value LIKE %s OR pm.meta_value LIKE %s )
               AND p.post_type = 'attachment'",
            $like_cpi,
            $like_old
        ) );

        return array_map( 'wp_basename', $rows );
    }

    /**
     * Find all media-library attachments whose filename matches the MPN key
     * (case-insensitive).
     *
     * @return array<int, array{id:int, sequence:int}>
     */
    private static function find_attachments_by_mpn( string $key_value ): array {
        global $wpdb;

        $like = $wpdb->esc_like( $key_value ) . '%';

        $attachments = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, pm.meta_value AS attached_file
             FROM $wpdb->posts p
             INNER JOIN $wpdb->postmeta pm
                ON pm.post_id = p.ID
               AND pm.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment'
               AND p.post_mime_type LIKE 'image/%%'
               AND LOWER(SUBSTRING_INDEX(pm.meta_value, '/', -1)) LIKE LOWER(%s)",
            $like
        ) );

        if ( empty( $attachments ) ) {
            return [];
        }

        $key_lower = strtolower( $key_value );
        $matched   = [];

        foreach ( $attachments as $attachment ) {
            $id       = (int) $attachment->ID;
            $filename = wp_basename( (string) $attachment->attached_file );
            $sequence = self::parse_mpn_image_sequence( $filename, $key_value, $key_lower );

            if ( null === $sequence ) {
                continue;
            }

            $matched[] = [
                'id'       => $id,
                'sequence' => $sequence,
            ];
        }

        return $matched;
    }

    /**
     * Parse image sequence number from filename against the MPN key.
     * All matching is case-insensitive.
     */
    private static function parse_mpn_image_sequence( string $filename, string $key_value, string $key_lower ): ?int {
        $name_lower = strtolower( $filename );

        if ( ! str_starts_with( $name_lower, $key_lower ) ) {
            return null;
        }

        $quoted = preg_quote( $key_lower, '/' );
        $ext    = '\.[^.]+$';

        $patterns = [
            '/^' . $quoted . '\((\d+)\)' . $ext . '/i',
            '/^' . $quoted . '[-_ ](\d+)' . $ext . '/i',
            '/^' . $quoted . '-(\d+)' . $ext . '/i',
            '/^' . $quoted . $ext . '/i',
        ];

        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $name_lower, $matches ) ) {
                return isset( $matches[1] ) ? (int) $matches[1] : 1;
            }
        }

        return null;
    }

    /**
     * Look up an existing post by the UNIQUE_KEY meta value.
     */
    private static function find_existing( string $value ): int {
        if ( empty( $value ) ) {
            return 0;
        }

        $unique_key = CPI_Config::UNIQUE_KEY;

        $args = [
            'post_type'      => CPI_Config::POST_TYPE,
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ [
                'key'     => $unique_key,
                'value'   => $value,
                'compare' => '=',
            ] ],
        ];

        $query = new WP_Query( $args );
        return ! empty( $query->posts ) ? (int) $query->posts[0] : 0;
    }
}
