jQuery(function ($) {
    var frame;

    $('#wp_points_download_file_pick').on('click', function (e) {
        e.preventDefault();

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: WpPointsDownloadAdmin.title,
            button: { text: WpPointsDownloadAdmin.button },
            multiple: false
        });

        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            $('#wp_points_download_file_id').val(attachment.id);
            $('#wp_points_download_file_clear').show();
            $('#wp_points_download_file_label').text(attachment.filename || attachment.title);
        });

        frame.open();
    });

    $('#wp_points_download_file_clear').on('click', function (e) {
        e.preventDefault();
        $('#wp_points_download_file_id').val('');
        $(this).hide();
        $('#wp_points_download_file_label').text(WpPointsDownloadAdmin.none);
    });
});
