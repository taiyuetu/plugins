jQuery(function ($) {
    $(document).on('click', '.wp-points-pay-to-download', function () {
        var btn = $(this);
        var downloadId = btn.data('download');

        btn.prop('disabled', true);

        $.post(WpPointsDownload.ajax_url, {
            action: 'wp_points_pay_to_download',
            download_id: downloadId,
            nonce: WpPointsDownload.nonce
        })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.download_url) {
                        window.location.href = res.data.download_url;
                        return;
                    }
                    location.reload();
                    return;
                }

                var msg =
                    typeof res.data === 'object' && res.data && res.data.message
                        ? res.data.message
                        : res.data;

                if (typeof res.data === 'object' && res.data && res.data.login_url) {
                    if (confirm(msg + ' ' + (WpPointsDownload.login_prompt || 'Do you want to log in now?'))) {
                        window.location.href = res.data.login_url;
                    }
                } else {
                    alert(msg);
                }
            })
            .fail(function (err) {
                console.log(err.responseText);
                alert('Request failed.');
            })
            .always(function () {
                btn.prop('disabled', false);
            });
    });
});
