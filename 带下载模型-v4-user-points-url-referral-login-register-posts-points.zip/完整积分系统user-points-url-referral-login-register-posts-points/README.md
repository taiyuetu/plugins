# User Points (URL referral, login, register, posts)

WordPress plugin: lightweight points ledger, admin tools, referral links, optional per-post paywall, and points-gated downloads.

## Install

1. Upload the whole plugin folder to `wp-content/plugins/`.
2. Activate **User Points (URL Referral, Login, Register, Posts)** in **Plugins** (the main file is `wp-simple-points.php`).

## Features

- **Ledger**: Table `wp_user_points_transactions` (prefix may vary) with cached `points_balance` user meta.
- **Admin**: **Points** menu for transactions, bulk updates, per-user filters; **Settings** for registration and daily login rewards.
- **Shortcodes**: `[user_points]` (own balance when logged in); admins may pass `user_id` for another user.
- **Referral**: `[ulr_referral_link]` shows link `/?ref=…`, visit stats, IP throttling (24h), points for visits (`wp_points_referral_visit_reward` filter), cookie `wp_points_referral_code` for signup bonuses.
- **Signup via referral**: After registration, new user and referrer can receive bonuses (`wp_points_referral_signup_bonus` and `wp_points_referrer_signup_reward` filters; defaults 50 / 25).
- **Posts paywall**: In the post editor sidebar, set **Points to unlock full content** (> 0). Front-end shows a teaser and button; AJAX deducts points once (`post_unlock` transaction type).
- **Downloads**: Custom post type **Downloads** (`/downloads/` archive). Set **Point cost** and attach a file via the media library. Visitors pay once to unlock; file is served through a nonce-protected URL (`download_unlock` transaction type). Plugin includes `templates/archive-wp_points_download.php` and `templates/single-wp_points_download.php` (theme can override). Shortcode: `[points_downloads count="10"]`.

## Developer helpers

- `wp_points()` — main instance.
- `get_user_points( $user_id )`
- `add_user_points( $user_id, $amount, $description, $type = 'manual' )`
- `subtract_user_points( $user_id, $amount, $description, $type = 'manual' )`
- Actions: `wp_points_balance_updated`, `wp_points_after_registration`

## Notes

- `template-functions.php` in this folder was an old **theme** sample (feeds, encryption). It is **not** loaded by the plugin. Do not copy its paywall/encrypt hooks into the theme alongside this plugin or you will get duplicate behaviour.
- `navigation.js` is enqueued from the plugin root when a post has a paywall cost set.

## Requirements

- WordPress 5.8+, PHP 7.4+.
