<?php
/**
 * Archive template for points-gated downloads.
 *
 * @package User_Points_System
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_POINTS_PLUGIN_DOWNLOAD_TEMPLATE', true);

wp_points_enqueue_download_assets();

get_header();
?>
<div class="wp-points-downloads-page wp-points-downloads-archive">
    <header class="wp-points-downloads-page-header">
        <p class="wp-points-downloads-eyebrow"><?php esc_html_e('Downloads', 'user-points-system'); ?></p>
        <h1 class="wp-points-downloads-page-title">
            <?php
            if (is_search()) {
                printf(
                    /* translators: %s: search query */
                    esc_html__('Search results for “%s”', 'user-points-system'),
                    esc_html(get_search_query())
                );
            } else {
                post_type_archive_title();
            }
            ?>
        </h1>
        <?php if (get_the_archive_description()) : ?>
            <div class="wp-points-downloads-page-description"><?php the_archive_description(); ?></div>
        <?php else : ?>
            <p class="wp-points-downloads-page-description">
                <?php esc_html_e('Browse files and unlock downloads with your points.', 'user-points-system'); ?>
            </p>
        <?php endif; ?>

        <?php if (is_user_logged_in() && function_exists('get_user_points')) : ?>
            <p class="wp-points-downloads-user-balance">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %s: point balance */
                        __('Your balance: %s points', 'user-points-system'),
                        number_format_i18n(get_user_points(get_current_user_id()), 0)
                    )
                );
                ?>
            </p>
        <?php endif; ?>
    </header>

    <?php if (have_posts()) : ?>
        <div class="wp-points-downloads-grid">
            <?php
            while (have_posts()) :
                the_post();
                wp_points_render_download_card(get_the_ID());
            endwhile;
            ?>
        </div>

        <nav class="wp-points-downloads-pagination" aria-label="<?php esc_attr_e('Downloads pagination', 'user-points-system'); ?>">
            <?php
            the_posts_pagination(
                array(
                    'mid_size'  => 2,
                    'prev_text' => __('← Previous', 'user-points-system'),
                    'next_text' => __('Next →', 'user-points-system'),
                )
            );
            ?>
        </nav>
    <?php else : ?>
        <div class="wp-points-downloads-empty">
            <p><?php esc_html_e('No downloads are available yet.', 'user-points-system'); ?></p>
        </div>
    <?php endif; ?>
</div>
<?php
get_footer();
