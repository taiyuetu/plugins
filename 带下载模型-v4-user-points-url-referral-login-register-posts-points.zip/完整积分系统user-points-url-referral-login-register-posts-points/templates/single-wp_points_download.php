<?php
/**
 * Single template for a points-gated download.
 *
 * @package User_Points_System
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_POINTS_PLUGIN_DOWNLOAD_TEMPLATE', true);

wp_points_enqueue_download_assets();

get_header();
?>
<div class="wp-points-downloads-page wp-points-downloads-single">
    <?php
    while (have_posts()) :
        the_post();
        $download_id = get_the_ID();
        $cost        = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
        $can         = wp_points_user_can_download($download_id);
        ?>
        <article id="download-<?php echo esc_attr((string) $download_id); ?>" <?php post_class('wp-points-download-article'); ?>>
            <nav class="wp-points-downloads-breadcrumb" aria-label="<?php esc_attr_e('Breadcrumb', 'user-points-system'); ?>">
                <a href="<?php echo esc_url(get_post_type_archive_link(WP_POINTS_DOWNLOAD_POST_TYPE)); ?>">
                    <?php esc_html_e('All downloads', 'user-points-system'); ?>
                </a>
                <span aria-hidden="true">/</span>
                <span><?php the_title(); ?></span>
            </nav>

            <header class="wp-points-download-single-header">
                <div class="wp-points-download-single-heading">
                    <p class="wp-points-downloads-eyebrow"><?php esc_html_e('Download', 'user-points-system'); ?></p>
                    <h1 class="wp-points-download-single-title"><?php the_title(); ?></h1>
                    <div class="wp-points-download-single-meta">
                        <?php echo wp_points_render_download_cost_badge($download_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php if ($can) : ?>
                            <span class="wp-points-downloads-badge wp-points-downloads-badge--unlocked">
                                <?php esc_html_e('Unlocked', 'user-points-system'); ?>
                            </span>
                        <?php endif; ?>
                        <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time>
                    </div>
                </div>

                <?php if (has_post_thumbnail()) : ?>
                    <div class="wp-points-download-single-thumb">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
            </header>

            <?php if (has_excerpt()) : ?>
                <p class="wp-points-download-single-excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
            <?php endif; ?>

            <?php if (get_the_content()) : ?>
                <div class="wp-points-download-single-content entry-content">
                    <?php the_content(); ?>
                </div>
            <?php endif; ?>

            <?php echo wp_points_render_download_box($download_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </article>
    <?php endwhile; ?>
</div>
<?php
get_footer();
