<?php
/**
 * Points-gated downloads custom post type.
 *
 * @package User_Points_System
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_POINTS_DOWNLOAD_POST_TYPE', 'wp_points_download');
define('WP_POINTS_DOWNLOAD_COST_META', '_wp_points_download_cost');
define('WP_POINTS_DOWNLOAD_FILE_META', '_wp_points_download_file_id');
define('WP_POINTS_PAID_DOWNLOADS_META', 'paid_downloads');
define('WP_POINTS_DOWNLOADS_ASSET_VERSION', '1.2.1');

/**
 * Register the downloads post type and meta.
 */
add_action(
    'init',
    static function () {
        register_post_type(
            WP_POINTS_DOWNLOAD_POST_TYPE,
            array(
                'labels'              => array(
                    'name'               => __('Points Downloads', 'user-points-system'),
                    'singular_name'      => __('Download', 'user-points-system'),
                    'add_new'            => __('Add Download', 'user-points-system'),
                    'add_new_item'       => __('Add New Download', 'user-points-system'),
                    'edit_item'          => __('Edit Download', 'user-points-system'),
                    'new_item'           => __('New Download', 'user-points-system'),
                    'view_item'          => __('View Download', 'user-points-system'),
                    'search_items'       => __('Search Downloads', 'user-points-system'),
                    'not_found'          => __('No downloads found.', 'user-points-system'),
                    'not_found_in_trash' => __('No downloads found in Trash.', 'user-points-system'),
                    'menu_name'          => __('Downloads', 'user-points-system'),
                ),
                'public'              => true,
                'publicly_queryable'  => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_rest'        => true,
                'has_archive'         => true,
                'rewrite'             => array('slug' => 'downloads'),
                'menu_icon'           => 'dashicons-download',
                'supports'            => array('title', 'editor', 'excerpt', 'thumbnail'),
                'capability_type'     => 'post',
            )
        );

        register_post_meta(
            WP_POINTS_DOWNLOAD_POST_TYPE,
            WP_POINTS_DOWNLOAD_COST_META,
            array(
                'type'              => 'number',
                'single'            => true,
                'show_in_rest'      => true,
                'auth_callback'     => static function () {
                    return current_user_can('edit_posts');
                },
                'sanitize_callback' => static function ($value) {
                    $n = is_numeric($value) ? (float) $value : 0;
                    return max(0, $n);
                },
            )
        );

        register_post_meta(
            WP_POINTS_DOWNLOAD_POST_TYPE,
            WP_POINTS_DOWNLOAD_FILE_META,
            array(
                'type'              => 'integer',
                'single'            => true,
                'show_in_rest'      => true,
                'auth_callback'     => static function () {
                    return current_user_can('edit_posts');
                },
                'sanitize_callback' => static function ($value) {
                    return max(0, absint($value));
                },
            )
        );
    },
    20
);

/**
 * Load plugin archive/single templates when the theme does not provide them.
 *
 * @param string $template Current template path.
 */
add_filter(
    'template_include',
    static function ($template) {
        if (is_post_type_archive(WP_POINTS_DOWNLOAD_POST_TYPE)) {
            $theme_template = locate_template(array('archive-wp_points_download.php'));
            if ($theme_template) {
                return $theme_template;
            }
            $plugin_template = WP_POINTS_PLUGIN_DIR . 'templates/archive-wp_points_download.php';
            if (is_readable($plugin_template)) {
                return $plugin_template;
            }
        }

        if (is_singular(WP_POINTS_DOWNLOAD_POST_TYPE)) {
            $theme_template = locate_template(array('single-wp_points_download.php'));
            if ($theme_template) {
                return $theme_template;
            }
            $plugin_template = WP_POINTS_PLUGIN_DIR . 'templates/single-wp_points_download.php';
            if (is_readable($plugin_template)) {
                return $plugin_template;
            }
        }

        return $template;
    },
    99
);

/**
 * Enqueue front-end styles and scripts for download pages.
 */
function wp_points_enqueue_download_assets() {
    wp_enqueue_style(
        'wp-points-downloads',
        WP_POINTS_PLUGIN_URL . 'assets/downloads.css',
        array(),
        WP_POINTS_DOWNLOADS_ASSET_VERSION
    );

    if (is_post_type_archive(WP_POINTS_DOWNLOAD_POST_TYPE)) {
        wp_enqueue_style('dashicons');
    }
}

/**
 * Render a cost badge for a download.
 *
 * @param int $download_id Download post ID.
 */
function wp_points_render_download_cost_badge($download_id) {
    $cost = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);

    if ($cost > 0) {
        return sprintf(
            '<span class="wp-points-downloads-badge wp-points-downloads-badge--paid">%s</span>',
            esc_html(
                sprintf(
                    /* translators: %s: points amount */
                    __('%s pts', 'user-points-system'),
                    number_format_i18n($cost, 0)
                )
            )
        );
    }

    return '<span class="wp-points-downloads-badge wp-points-downloads-badge--free">' . esc_html__('Free', 'user-points-system') . '</span>';
}

/**
 * Human-readable file size for a download attachment.
 *
 * @param int $download_id Download post ID.
 */
function wp_points_get_download_file_size_label($download_id) {
    $file_id = (int) get_post_meta($download_id, WP_POINTS_DOWNLOAD_FILE_META, true);
    if ($file_id < 1) {
        return '';
    }

    $file_path = get_attached_file($file_id);
    if (!$file_path || !is_readable($file_path)) {
        return '';
    }

    return size_format(filesize($file_path));
}

/**
 * Render an archive card for one download.
 *
 * @param int $download_id Download post ID.
 */
function wp_points_render_download_card($download_id) {
    $download_id = absint($download_id);
    $post        = get_post($download_id);
    if (!$post || $post->post_type !== WP_POINTS_DOWNLOAD_POST_TYPE) {
        return;
    }

    $permalink = get_permalink($download_id);
    $cost      = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
    $can       = wp_points_user_can_download($download_id);
    $file_size = wp_points_get_download_file_size_label($download_id);
    ?>
    <article class="wp-points-download-card">
        <a class="wp-points-download-card-link" href="<?php echo esc_url($permalink); ?>">
            <div class="wp-points-download-card-media">
                <?php if (has_post_thumbnail($download_id)) : ?>
                    <?php echo get_the_post_thumbnail($download_id, 'medium_large', array('class' => 'wp-points-download-card-image')); ?>
                <?php else : ?>
                    <div class="wp-points-download-card-placeholder" aria-hidden="true">
                        <span class="dashicons dashicons-download"></span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="wp-points-download-card-body">
                <div class="wp-points-download-card-badges">
                    <?php echo wp_points_render_download_cost_badge($download_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php if ($can) : ?>
                        <span class="wp-points-downloads-badge wp-points-downloads-badge--unlocked"><?php esc_html_e('Unlocked', 'user-points-system'); ?></span>
                    <?php endif; ?>
                </div>
                <h2 class="wp-points-download-card-title"><?php echo esc_html(get_the_title($download_id)); ?></h2>
                <?php if ($post->post_excerpt) : ?>
                    <p class="wp-points-download-card-excerpt"><?php echo esc_html(wp_trim_words($post->post_excerpt, 22)); ?></p>
                <?php endif; ?>
                <div class="wp-points-download-card-meta">
                    <?php if ($file_size) : ?>
                        <span><?php echo esc_html($file_size); ?></span>
                    <?php endif; ?>
                    <span><?php echo esc_html(get_the_date('', $download_id)); ?></span>
                </div>
                <span class="wp-points-download-card-action">
                    <?php
                    if ($can) {
                        esc_html_e('Download now', 'user-points-system');
                    } elseif ($cost > 0) {
                        esc_html_e('View details', 'user-points-system');
                    } else {
                        esc_html_e('Get free download', 'user-points-system');
                    }
                    ?>
                </span>
            </div>
        </a>
    </article>
    <?php
}

/**
 * Render the pay/download box for a single download.
 *
 * @param int|null $download_id Download post ID.
 */
function wp_points_render_download_box($download_id = null) {
    $download_id = $download_id ? absint($download_id) : get_the_ID();
    if (!$download_id || get_post_type($download_id) !== WP_POINTS_DOWNLOAD_POST_TYPE) {
        return '';
    }

    $file_id = (int) get_post_meta($download_id, WP_POINTS_DOWNLOAD_FILE_META, true);
    if ($file_id < 1) {
        return '<div class="wp-points-download-box wp-points-download-box--missing"><p>' . esc_html__('No download file has been configured yet.', 'user-points-system') . '</p></div>';
    }

    $cost      = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
    $can       = wp_points_user_can_download($download_id);
    $logged_in = is_user_logged_in();
    $balance   = $logged_in && function_exists('get_user_points') ? get_user_points(get_current_user_id()) : 0;
    $file_size = wp_points_get_download_file_size_label($download_id);

    ob_start();
    ?>
    <div class="wp-points-download-box" data-download="<?php echo esc_attr((string) $download_id); ?>" data-cost="<?php echo esc_attr((string) $cost); ?>">
        <?php if ($file_size) : ?>
            <p class="wp-points-download-file-size">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %s: file size */
                        __('File size: %s', 'user-points-system'),
                        $file_size
                    )
                );
                ?>
            </p>
        <?php endif; ?>

        <?php if ($can) : ?>
            <p class="wp-points-download-status"><?php esc_html_e('You can download this file.', 'user-points-system'); ?></p>
            <p>
                <a class="button wp-points-download-link" href="<?php echo esc_url(wp_points_get_download_url($download_id)); ?>">
                    <?php esc_html_e('Download file', 'user-points-system'); ?>
                </a>
            </p>
        <?php elseif ($cost > 0) : ?>
            <p class="wp-points-download-status">
                <?php
                echo esc_html(
                    sprintf(
                        /* translators: %s: points amount */
                        __('This file costs %s points.', 'user-points-system'),
                        number_format_i18n($cost, 0)
                    )
                );
                ?>
            </p>
            <?php if ($logged_in) : ?>
                <p class="wp-points-download-balance">
                    <?php
                    echo esc_html(
                        sprintf(
                            /* translators: %s: current balance */
                            __('Your balance: %s points', 'user-points-system'),
                            number_format_i18n($balance, 0)
                        )
                    );
                    ?>
                </p>
                <p>
                    <button type="button" class="button button-primary wp-points-pay-to-download" data-download="<?php echo esc_attr((string) $download_id); ?>" data-cost="<?php echo esc_attr((string) $cost); ?>">
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: %s: points amount */
                                __('Pay %s points to download', 'user-points-system'),
                                number_format_i18n($cost, 0)
                            )
                        );
                        ?>
                    </button>
                </p>
            <?php else : ?>
                <p>
                    <a class="button button-primary" href="<?php echo esc_url(wp_login_url(get_permalink($download_id))); ?>">
                        <?php esc_html_e('Log in to purchase download', 'user-points-system'); ?>
                    </a>
                </p>
            <?php endif; ?>
        <?php else : ?>
            <p>
                <a class="button wp-points-download-link" href="<?php echo esc_url(wp_points_get_download_url($download_id)); ?>">
                    <?php esc_html_e('Download file', 'user-points-system'); ?>
                </a>
            </p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Whether the plugin's own download template is rendering the page.
 */
function wp_points_is_plugin_download_template() {
    return defined('WP_POINTS_PLUGIN_DOWNLOAD_TEMPLATE') && WP_POINTS_PLUGIN_DOWNLOAD_TEMPLATE;
}

/**
 * Admin meta box for cost and file.
 */
add_action(
    'add_meta_boxes',
    static function () {
        add_meta_box(
            'wp_points_download_settings',
            __('Download settings', 'user-points-system'),
            'wp_points_download_metabox',
            WP_POINTS_DOWNLOAD_POST_TYPE,
            'normal',
            'high'
        );
    }
);

/**
 * @param WP_Post $post Post object.
 */
function wp_points_download_metabox($post) {
    wp_nonce_field('wp_points_download_save', 'wp_points_download_nonce');

    $cost    = get_post_meta($post->ID, WP_POINTS_DOWNLOAD_COST_META, true);
    $file_id = (int) get_post_meta($post->ID, WP_POINTS_DOWNLOAD_FILE_META, true);

    if ($cost === '' || $cost === false) {
        $cost = 0;
    }

    $file_name = '';
    $file_url  = '';
    if ($file_id > 0) {
        $file_name = basename(get_attached_file($file_id));
        $file_url  = wp_get_attachment_url($file_id);
    }
    ?>
    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="wp_points_download_cost"><?php esc_html_e('Point cost', 'user-points-system'); ?></label>
            </th>
            <td>
                <input type="number" min="0" step="1" id="wp_points_download_cost" name="wp_points_download_cost" value="<?php echo esc_attr((string) $cost); ?>" />
                <p class="description"><?php esc_html_e('Points required to download (0 = free for everyone).', 'user-points-system'); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Download file', 'user-points-system'); ?></th>
            <td>
                <input type="hidden" id="wp_points_download_file_id" name="wp_points_download_file_id" value="<?php echo esc_attr((string) $file_id); ?>" />
                <button type="button" class="button" id="wp_points_download_file_pick"><?php esc_html_e('Select file', 'user-points-system'); ?></button>
                <button type="button" class="button" id="wp_points_download_file_clear" <?php echo $file_id ? '' : 'style="display:none;"'; ?>><?php esc_html_e('Remove', 'user-points-system'); ?></button>
                <p id="wp_points_download_file_label" class="description">
                    <?php
                    if ($file_name) {
                        echo esc_html($file_name);
                        if ($file_url) {
                            echo ' — <a href="' . esc_url($file_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Preview', 'user-points-system') . '</a>';
                        }
                    } else {
                        esc_html_e('No file selected.', 'user-points-system');
                    }
                    ?>
                </p>
            </td>
        </tr>
    </table>
    <?php
}

add_action(
    'admin_enqueue_scripts',
    static function ($hook) {
        if (!in_array($hook, array('post.php', 'post-new.php'), true)) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== WP_POINTS_DOWNLOAD_POST_TYPE) {
            return;
        }

        wp_enqueue_media();

        wp_enqueue_script(
            'wp-points-download-admin',
            WP_POINTS_PLUGIN_URL . 'assets/download-admin.js',
            array('jquery'),
            '1.2.0',
            true
        );

        wp_localize_script(
            'wp-points-download-admin',
            'WpPointsDownloadAdmin',
            array(
                'title'  => __('Select download file', 'user-points-system'),
                'button' => __('Use this file', 'user-points-system'),
                'none'   => __('No file selected.', 'user-points-system'),
            )
        );
    }
);

add_action(
    'save_post_' . WP_POINTS_DOWNLOAD_POST_TYPE,
    static function ($post_id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!isset($_POST['wp_points_download_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wp_points_download_nonce'])), 'wp_points_download_save')) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['wp_points_download_cost'])) {
            $cost = max(0, (float) wp_unslash($_POST['wp_points_download_cost']));
            if ($cost > 0) {
                update_post_meta($post_id, WP_POINTS_DOWNLOAD_COST_META, $cost);
            } else {
                delete_post_meta($post_id, WP_POINTS_DOWNLOAD_COST_META);
            }
        }

        if (isset($_POST['wp_points_download_file_id'])) {
            $file_id = absint(wp_unslash($_POST['wp_points_download_file_id']));
            if ($file_id > 0 && get_post($file_id)) {
                update_post_meta($post_id, WP_POINTS_DOWNLOAD_FILE_META, $file_id);
            } else {
                delete_post_meta($post_id, WP_POINTS_DOWNLOAD_FILE_META);
            }
        }
    },
    10,
    1
);

/**
 * Whether the user may download this item.
 *
 * @param int      $download_id Download post ID.
 * @param int|null $user_id     User ID (defaults to current user).
 */
function wp_points_user_can_download($download_id, $user_id = null) {
    $download_id = absint($download_id);
    if (!$download_id || get_post_type($download_id) !== WP_POINTS_DOWNLOAD_POST_TYPE) {
        return false;
    }

    if (get_post_status($download_id) !== 'publish') {
        return current_user_can('edit_post', $download_id);
    }

    if (current_user_can('edit_post', $download_id)) {
        return true;
    }

    $cost = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
    if ($cost <= 0) {
        return true;
    }

    if ($user_id === null) {
        $user_id = get_current_user_id();
    }
    $user_id = absint($user_id);
    if (!$user_id) {
        return false;
    }

    $paid = (array) get_user_meta($user_id, WP_POINTS_PAID_DOWNLOADS_META, true);
    return in_array($download_id, array_map('intval', $paid), true);
}

/**
 * Build a secure download URL for a download post.
 *
 * @param int $download_id Download post ID.
 */
function wp_points_get_download_url($download_id) {
    return wp_nonce_url(
        add_query_arg(
            array(
                'wp_points_file' => absint($download_id),
            ),
            get_permalink($download_id)
        ),
        'wp_points_download_' . absint($download_id),
        '_wpnonce'
    );
}

/**
 * Serve the file when the secure URL is requested.
 */
add_action(
    'template_redirect',
    static function () {
        if (!isset($_GET['wp_points_file'])) {
            return;
        }

        $download_id = absint(wp_unslash($_GET['wp_points_file']));
        if (!$download_id || get_post_type($download_id) !== WP_POINTS_DOWNLOAD_POST_TYPE) {
            wp_die(esc_html__('Invalid download.', 'user-points-system'), '', array('response' => 404));
        }

        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wp_points_download_' . $download_id)) {
            wp_die(esc_html__('Invalid or expired download link.', 'user-points-system'), '', array('response' => 403));
        }

        if (!wp_points_user_can_download($download_id)) {
            $cost = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
            if ($cost > 0 && !is_user_logged_in()) {
                wp_safe_redirect(wp_login_url(get_permalink($download_id)));
                exit;
            }
            wp_die(esc_html__('You have not unlocked this download yet.', 'user-points-system'), '', array('response' => 403));
        }

        $file_id = (int) get_post_meta($download_id, WP_POINTS_DOWNLOAD_FILE_META, true);
        if ($file_id < 1) {
            wp_die(esc_html__('No file is attached to this download.', 'user-points-system'), '', array('response' => 404));
        }

        $file_path = get_attached_file($file_id);
        if (!$file_path || !is_readable($file_path)) {
            wp_die(esc_html__('Download file is missing.', 'user-points-system'), '', array('response' => 404));
        }

        $file_name = basename($file_path);
        $mime_type = get_post_mime_type($file_id);
        if (!$mime_type) {
            $mime_type = 'application/octet-stream';
        }

        nocache_headers();
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: attachment; filename="' . rawurlencode($file_name) . '"');
        header('Content-Length: ' . (string) filesize($file_path));
        header('X-Robots-Tag: noindex, nofollow', true);

        readfile($file_path);
        exit;
    }
);

/**
 * Append the download box on single download pages (theme fallback).
 */
function wp_points_append_download_box_to_content($content) {
    if (wp_points_is_plugin_download_template()) {
        return $content;
    }

    if (!is_singular(WP_POINTS_DOWNLOAD_POST_TYPE) || is_admin()) {
        return $content;
    }

    if (!in_the_loop() || !is_main_query()) {
        return $content;
    }

    wp_points_enqueue_download_assets();

    return $content . wp_points_render_download_box(get_the_ID());
}

add_filter('the_content', 'wp_points_append_download_box_to_content', 99);

/**
 * Front-end script for pay-to-download.
 */
add_action(
    'wp_enqueue_scripts',
    static function () {
        if (!is_singular(WP_POINTS_DOWNLOAD_POST_TYPE) && !is_post_type_archive(WP_POINTS_DOWNLOAD_POST_TYPE)) {
            return;
        }

        wp_points_enqueue_download_assets();

        if (!is_singular(WP_POINTS_DOWNLOAD_POST_TYPE)) {
            return;
        }

        global $post;
        if (!$post instanceof WP_Post) {
            return;
        }

        $cost = (float) get_post_meta($post->ID, WP_POINTS_DOWNLOAD_COST_META, true);
        if ($cost <= 0 || wp_points_user_can_download($post->ID)) {
            return;
        }

        wp_enqueue_script(
            'wp-points-downloads',
            WP_POINTS_PLUGIN_URL . 'assets/downloads.js',
            array('jquery'),
            WP_POINTS_DOWNLOADS_ASSET_VERSION,
            true
        );

        wp_localize_script(
            'wp-points-downloads',
            'WpPointsDownload',
            array(
                'ajax_url'     => admin_url('admin-ajax.php'),
                'nonce'        => wp_create_nonce('wp_points_pay_download_nonce'),
                'login_prompt' => __('Do you want to log in now?', 'user-points-system'),
            )
        );
    }
);

add_action('wp_ajax_wp_points_pay_to_download', 'wp_points_pay_to_download_cb');
add_action('wp_ajax_nopriv_wp_points_pay_to_download', 'wp_points_pay_to_download_cb');

/**
 * AJAX: deduct points and unlock download for the user.
 */
function wp_points_pay_to_download_cb() {
    check_ajax_referer('wp_points_pay_download_nonce', 'nonce');

    $download_id = isset($_POST['download_id']) ? absint(wp_unslash($_POST['download_id'])) : 0;
    if (!$download_id || get_post_type($download_id) !== WP_POINTS_DOWNLOAD_POST_TYPE) {
        wp_send_json_error(array('message' => __('Invalid download.', 'user-points-system')));
    }

    $file_id = (int) get_post_meta($download_id, WP_POINTS_DOWNLOAD_FILE_META, true);
    if ($file_id < 1) {
        wp_send_json_error(array('message' => __('No file is attached to this download.', 'user-points-system')));
    }

    $cost = (float) get_post_meta($download_id, WP_POINTS_DOWNLOAD_COST_META, true);
    if ($cost <= 0) {
        wp_send_json_success(
            array(
                'download_url' => wp_points_get_download_url($download_id),
            )
        );
    }

    $user_id = get_current_user_id();
    if ($user_id < 1) {
        wp_send_json_error(
            array(
                'message'   => __('You must be logged in to unlock this download.', 'user-points-system'),
                'login_url' => wp_login_url(get_permalink($download_id)),
            )
        );
    }

    if (!function_exists('get_user_points') || !function_exists('subtract_user_points')) {
        wp_send_json_error(array('message' => __('Points system is unavailable.', 'user-points-system')));
    }

    if (wp_points_user_can_download($download_id, $user_id)) {
        wp_send_json_success(
            array(
                'message'      => __('Already unlocked.', 'user-points-system'),
                'download_url' => wp_points_get_download_url($download_id),
            )
        );
    }

    $balance = get_user_points($user_id);
    if ($balance < $cost) {
        wp_send_json_error(array('message' => __('Not enough points.', 'user-points-system')));
    }

    $result = subtract_user_points(
        $user_id,
        $cost,
        sprintf(
            /* translators: 1: download id, 2: download title */
            __('Unlock download #%1$d: %2$s', 'user-points-system'),
            $download_id,
            get_the_title($download_id)
        ),
        'download_unlock'
    );

    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    }

    $paid   = (array) get_user_meta($user_id, WP_POINTS_PAID_DOWNLOADS_META, true);
    $paid[] = $download_id;
    update_user_meta($user_id, WP_POINTS_PAID_DOWNLOADS_META, array_unique(array_map('intval', $paid)));

    wp_send_json_success(
        array(
            'new_balance'  => $result,
            'download_url' => wp_points_get_download_url($download_id),
        )
    );
}

/**
 * Shortcode: list downloads with cost badges.
 *
 * Usage: [points_downloads count="10"]
 */
add_shortcode(
    'points_downloads',
    static function ($atts) {
        $atts = shortcode_atts(
            array(
                'count' => 10,
            ),
            $atts,
            'points_downloads'
        );

        $query = new WP_Query(
            array(
                'post_type'      => WP_POINTS_DOWNLOAD_POST_TYPE,
                'posts_per_page' => max(1, absint($atts['count'])),
                'post_status'    => 'publish',
                'orderby'        => 'date',
                'order'          => 'DESC',
            )
        );

        if (!$query->have_posts()) {
            return '<p class="wp-points-downloads-list-empty">' . esc_html__('No downloads available.', 'user-points-system') . '</p>';
        }

        ob_start();
        echo '<ul class="wp-points-downloads-list">';
        while ($query->have_posts()) {
            $query->the_post();
            $cost = (float) get_post_meta(get_the_ID(), WP_POINTS_DOWNLOAD_COST_META, true);
            echo '<li>';
            echo '<a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a>';
            if ($cost > 0) {
                echo ' <span class="wp-points-downloads-cost">' . esc_html(
                    sprintf(
                        /* translators: %s: points amount */
                        __('%s pts', 'user-points-system'),
                        number_format_i18n($cost, 0)
                    )
                ) . '</span>';
            } else {
                echo ' <span class="wp-points-downloads-cost wp-points-downloads-cost--free">' . esc_html__('Free', 'user-points-system') . '</span>';
            }
            echo '</li>';
        }
        echo '</ul>';
        wp_reset_postdata();

        wp_points_enqueue_download_assets();

        return ob_get_clean();
    }
);
