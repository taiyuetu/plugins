<?php
/**
 * Uninstall External Links Tracker.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

$table_name = $wpdb->prefix . 'elt_links';
$wpdb->query("DROP TABLE IF EXISTS {$table_name}");
