/**
 * External Links Tracker Admin JavaScript
 */
jQuery(document).ready(function($) {
    const i18n = elt_ajax.i18n || {};

    const $form = $('#elt-add-link-form');
    const $linkId = $('#link_id');
    const $linkName = $('#link_name');
    const $linkSlug = $('#link_slug');
    const $targetUrl = $('#target_url');
    const $saveButton = $('#elt-save-button');
    const $cancelButton = $('#elt-cancel-button');
    const $container = $('.elt-admin-container');

    function showNotice(message, isError = false) {
        $('.elt-notice').remove();

        const $notice = $('<div class="elt-notice"></div>')
            .text(message)
            .prependTo($container);

        if (isError) {
            $notice.addClass('elt-error');
        }

        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }

    function copyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }

        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();

        try {
            document.execCommand('copy');
            return Promise.resolve();
        } catch (error) {
            return Promise.reject(error);
        } finally {
            $temp.remove();
        }
    }

    function resetForm() {
        $form[0].reset();
        $linkId.val('');
        $saveButton.text(i18n.save_link || 'Save Link');
        $cancelButton.hide();
    }

    function generateSlugFromName(name) {
        let slug = name
            .toLowerCase()
            .replace(/[^a-z0-9\u4e00-\u9fff]+/g, '-')
            .replace(/^-+|-+$/g, '');

        if (!slug) {
            slug = 'link-' + Date.now().toString(36);
        }

        return slug;
    }

    $form.on('submit', function(e) {
        e.preventDefault();
        $form.addClass('elt-loading');

        const data = {
            action: 'elt_save_link',
            nonce: elt_ajax.nonce,
            link_id: $linkId.val(),
            link_name: $linkName.val(),
            link_slug: $linkSlug.val(),
            target_url: $targetUrl.val()
        };

        $.post(elt_ajax.ajax_url, data, function(response) {
            $form.removeClass('elt-loading');

            if (response.success) {
                showNotice(response.data.message);
                resetForm();
                location.reload();
            } else {
                showNotice(response.data.message, true);
            }
        }).fail(function() {
            $form.removeClass('elt-loading');
            showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
        });
    });

    $(document).on('click', '.elt-edit-link', function(e) {
        e.preventDefault();

        const $link = $(this);

        $linkId.val($link.data('id'));
        $linkName.val($link.data('name'));
        $linkSlug.val($link.data('slug'));
        $targetUrl.val($link.data('url'));

        $saveButton.text(i18n.update_link || 'Update Link');
        $cancelButton.show();

        $('html, body').animate({
            scrollTop: $form.offset().top - 50
        }, 500);
    });

    $cancelButton.on('click', function(e) {
        e.preventDefault();
        resetForm();
    });

    $(document).on('click', '.elt-delete-link', function(e) {
        e.preventDefault();

        const linkId = $(this).data('id');
        const $row = $(this).closest('tr');

        if (!confirm(i18n.confirm_delete || 'Are you sure you want to delete this link? This action cannot be undone.')) {
            return;
        }

        $row.addClass('elt-loading');

        $.post(elt_ajax.ajax_url, {
            action: 'elt_delete_link',
            nonce: elt_ajax.nonce,
            link_id: linkId
        }, function(response) {
            $row.removeClass('elt-loading');

            if (response.success) {
                showNotice(response.data.message);
                $row.fadeOut(300, function() {
                    $(this).remove();

                    if ($('#elt-links-table tbody tr:visible').length === 0) {
                        location.reload();
                    }
                });
            } else {
                showNotice(response.data.message, true);
            }
        }).fail(function() {
            $row.removeClass('elt-loading');
            showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
        });
    });

    $(document).on('click', '.elt-reset-count', function(e) {
        e.preventDefault();

        const linkId = $(this).data('id');
        const $clickCount = $(this).prev('.elt-click-count');

        if (!confirm(i18n.confirm_reset || 'Are you sure you want to reset the click count to zero?')) {
            return;
        }

        $clickCount.closest('td').addClass('elt-loading');

        $.post(elt_ajax.ajax_url, {
            action: 'elt_reset_count',
            nonce: elt_ajax.nonce,
            link_id: linkId
        }, function(response) {
            $clickCount.closest('td').removeClass('elt-loading');

            if (response.success) {
                showNotice(response.data.message);
                $clickCount.text('0');
            } else {
                showNotice(response.data.message, true);
            }
        }).fail(function() {
            $clickCount.closest('td').removeClass('elt-loading');
            showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
        });
    });

    $linkName.on('blur', function() {
        if ($linkSlug.val() === '') {
            $linkSlug.val(generateSlugFromName($(this).val()));
        }
    });

    $(document).on('click', '.elt-copy-btn', function(e) {
        e.preventDefault();

        const $button = $(this);
        const text = $button.data('copy');
        const originalText = $button.text();

        copyToClipboard(text).then(function() {
            $button.text(i18n.copied || 'Copied!');
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        }).catch(function() {
            showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
        });
    });

    $('#elt-search-links').on('input', function() {
        const query = $(this).val().toLowerCase().trim();
        let visibleCount = 0;

        $('#elt-links-table tbody tr').each(function() {
            const matches = !query || $(this).data('search').indexOf(query) !== -1;
            $(this).toggle(matches);

            if (matches) {
                visibleCount++;
            }
        });

        $('#elt-no-search-results').toggle(query.length > 0 && visibleCount === 0);
    });

    $('#elt-export-button').on('click', function(e) {
        e.preventDefault();

        const $button = $(this);
        const exportLabel = i18n.export_links || 'Export Links';

        $button.addClass('elt-loading').prop('disabled', true);
        $button.text(i18n.exporting || 'Exporting...');

        $.post(elt_ajax.ajax_url, {
            action: 'elt_export_links',
            nonce: elt_ajax.nonce
        }, function(response) {
            $button.removeClass('elt-loading').prop('disabled', false);
            $button.text(exportLabel);

            if (response.success) {
                const blob = new Blob([JSON.stringify(response.data.export_data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');

                a.href = url;
                a.download = response.data.filename;
                document.body.appendChild(a);
                a.click();

                setTimeout(function() {
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                }, 0);

                showNotice(i18n.export_success || 'Links exported successfully.');
            } else {
                showNotice(response.data.message, true);
            }
        }).fail(function() {
            $button.removeClass('elt-loading').prop('disabled', false);
            $button.text(exportLabel);
            showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
        });
    });

    $('#elt-import-form').on('submit', function(e) {
        e.preventDefault();

        const $importForm = $(this);
        const $fileInput = $('#elt-import-file');
        const $button = $('#elt-import-button');
        const importLabel = i18n.import_links || 'Import Links';

        if ($fileInput[0].files.length === 0) {
            showNotice(i18n.select_file || 'Please select a file to import.', true);
            return;
        }

        const fileName = $fileInput[0].files[0].name;
        const fileExt = fileName.split('.').pop().toLowerCase();

        if (fileExt !== 'json') {
            showNotice(i18n.invalid_json_file || 'Please select a JSON file to import.', true);
            return;
        }

        $button.addClass('elt-loading').prop('disabled', true);
        $button.text(i18n.importing || 'Importing...');

        const formData = new FormData();
        formData.append('action', 'elt_import_links');
        formData.append('nonce', elt_ajax.nonce);
        formData.append('import_file', $fileInput[0].files[0]);

        $.ajax({
            url: elt_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $button.removeClass('elt-loading').prop('disabled', false);
                $button.text(importLabel);

                if (response.success) {
                    showNotice(response.data.message);
                    $fileInput.val('');

                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    showNotice(response.data.message, true);
                }
            },
            error: function() {
                $button.removeClass('elt-loading').prop('disabled', false);
                $button.text(importLabel);
                showNotice(i18n.error_generic || 'An error occurred. Please try again.', true);
            }
        });
    });
});
