(function () {
	'use strict';

	function setStatus(gate, message, type) {
		var el = gate.querySelector('.hb-alipay-gate__status');
		if (!el) {
			return;
		}
		el.hidden = !message;
		el.textContent = message || '';
		el.classList.remove('is-error', 'is-pending');
		if (type) {
			el.classList.add(type);
		}
	}

	function startPay(gate) {
		if (!window.hbAlipay) {
			return;
		}

		var postId = gate.getAttribute('data-post-id');
		var btn = gate.querySelector('[data-hb-alipay-pay]');
		if (!postId || !btn) {
			return;
		}

		btn.disabled = true;
		setStatus(gate, hbAlipay.i18n.paying, 'is-pending');

		fetch(hbAlipay.restUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': hbAlipay.nonce
			},
			body: JSON.stringify({ post_id: parseInt(postId, 10) })
		})
			.then(function (res) {
				return res.json().then(function (data) {
					return { ok: res.ok, data: data };
				});
			})
			.then(function (result) {
				if (!result.ok) {
					var msg =
						(result.data && result.data.message) || hbAlipay.i18n.error;
					throw new Error(msg);
				}
				if (result.data.redirect) {
					window.location.href = result.data.redirect;
					return;
				}
				throw new Error(hbAlipay.i18n.error);
			})
			.catch(function (err) {
				btn.disabled = false;
				setStatus(gate, err.message || hbAlipay.i18n.error, 'is-error');
			});
	}

	document.addEventListener('click', function (e) {
		var btn = e.target.closest('[data-hb-alipay-pay]');
		if (!btn) {
			return;
		}
		var gate = btn.closest('.hb-alipay-gate');
		if (!gate) {
			return;
		}
		e.preventDefault();
		startPay(gate);
	});

	// Pending return notice.
	try {
		var params = new URLSearchParams(window.location.search);
		if (params.get('hb_pay') === 'pending') {
			var gate = document.querySelector('.hb-alipay-gate');
			if (gate) {
				setStatus(
					gate,
					'Payment is still processing. Refresh this page in a moment after paying.',
					'is-pending'
				);
			}
		}
	} catch (e) {
		/* ignore */
	}
})();
