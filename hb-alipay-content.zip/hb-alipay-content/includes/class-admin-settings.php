<?php

/**
 * Plugin settings admin page.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Admin_Settings
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('admin_menu', array(__CLASS__, 'menu'));
		add_action('admin_init', array(__CLASS__, 'register'));
	}

	/**
	 * Admin menu.
	 */
	public static function menu()
	{
		add_submenu_page(
			'edit.php?post_type=' . HB_ALIPAY_CONTENT_CPT,
			__('Alipay Settings', 'hb-alipay-content'),
			__('Alipay Settings', 'hb-alipay-content'),
			'manage_options',
			'hb-alipay-settings',
			array(__CLASS__, 'render')
		);
	}

	/**
	 * Register setting.
	 */
	public static function register()
	{
		register_setting(
			'hb_alipay_settings_group',
			'hb_alipay_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array(__CLASS__, 'sanitize'),
				'default'           => array(),
			)
		);
	}

	/**
	 * Sanitize settings.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize($input)
	{
		$existing = HB_Alipay_Plugin::get_settings();
		$output   = array();

		$output['app_id']           = isset($input['app_id']) ? sanitize_text_field($input['app_id']) : '';
		$output['private_key']      = isset($input['private_key']) ? trim((string) $input['private_key']) : '';
		$output['alipay_public_key'] = isset($input['alipay_public_key']) ? trim((string) $input['alipay_public_key']) : '';
		$output['sandbox']          = ! empty($input['sandbox']) ? '1' : '0';
		$output['cookie_ttl_days']  = isset($input['cookie_ttl_days']) ? max(1, absint($input['cookie_ttl_days'])) : 30;
		$output['secret']           = ! empty($existing['secret']) ? $existing['secret'] : wp_generate_password(64, true, true);

		return $output;
	}

	/**
	 * Render settings page.
	 */
	public static function render()
	{
		if (! current_user_can('manage_options')) {
			return;
		}

		$settings = HB_Alipay_Plugin::get_settings();
?>
		<div class="wrap">
			<h1><?php esc_html_e('Alipay Settings', 'hb-alipay-content'); ?></h1>
			<p><?php esc_html_e('Configure China Alipay Open Platform credentials (RSA2). Enable 电脑网站支付 and/or 手机网站支付 on your app.', 'hb-alipay-content'); ?></p>

			<form method="post" action="options.php">
				<?php settings_fields('hb_alipay_settings_group'); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="hb_app_id"><?php esc_html_e('App ID', 'hb-alipay-content'); ?></label></th>
						<td><input type="text" class="regular-text" id="hb_app_id" name="hb_alipay_settings[app_id]" value="<?php echo esc_attr($settings['app_id']); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="hb_private_key"><?php esc_html_e('Merchant private key (RSA2)', 'hb-alipay-content'); ?></label></th>
						<td>
							<textarea class="large-text code" rows="8" id="hb_private_key" name="hb_alipay_settings[private_key]"><?php echo esc_textarea($settings['private_key']); ?></textarea>
							<p class="description"><?php esc_html_e('Paste PKCS1/PKCS8 key with or without PEM headers.', 'hb-alipay-content'); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="hb_alipay_public_key"><?php esc_html_e('Alipay public key', 'hb-alipay-content'); ?></label></th>
						<td>
							<textarea class="large-text code" rows="6" id="hb_alipay_public_key" name="hb_alipay_settings[alipay_public_key]"><?php echo esc_textarea($settings['alipay_public_key']); ?></textarea>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('Sandbox mode', 'hb-alipay-content'); ?></th>
						<td>
							<label>
								<input type="checkbox" name="hb_alipay_settings[sandbox]" value="1" <?php checked($settings['sandbox'], '1'); ?> />
								<?php esc_html_e('Use Alipay sandbox gateway', 'hb-alipay-content'); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="hb_cookie_ttl"><?php esc_html_e('Unlock cookie TTL (days)', 'hb-alipay-content'); ?></label></th>
						<td><input type="number" min="1" id="hb_cookie_ttl" name="hb_alipay_settings[cookie_ttl_days]" value="<?php echo esc_attr($settings['cookie_ttl_days']); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('Notify URL', 'hb-alipay-content'); ?></th>
						<td><code><?php echo esc_html(home_url('/?hb_alipay_notify=1')); ?></code></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e('Return URL', 'hb-alipay-content'); ?></th>
						<td><code><?php echo esc_html(home_url('/?hb_alipay_return=1')); ?></code></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
<?php
	}
}
