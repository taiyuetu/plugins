<?php

/**
 * Alipay Open Platform RSA2 client.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Client
{

	/**
	 * Gateway URL.
	 *
	 * @return string
	 */
	public static function gateway()
	{
		$settings = HB_Alipay_Plugin::get_settings();
		if (! empty($settings['sandbox']) && '1' === (string) $settings['sandbox']) {
			return 'https://openapi-sandbox.dl.alipaydev.com/gateway.do';
		}
		return 'https://openapi.alipay.com/gateway.do';
	}

	/**
	 * Whether credentials are configured.
	 *
	 * @return bool
	 */
	public static function is_configured()
	{
		$settings = HB_Alipay_Plugin::get_settings();
		return ! empty($settings['app_id'])
			&& ! empty($settings['private_key'])
			&& ! empty($settings['alipay_public_key']);
	}

	/**
	 * Detect mobile user agent.
	 *
	 * @return bool
	 */
	public static function is_mobile()
	{
		if (empty($_SERVER['HTTP_USER_AGENT'])) {
			return false;
		}
		$ua = wp_unslash($_SERVER['HTTP_USER_AGENT']);
		return (bool) preg_match('/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i', $ua);
	}

	/**
	 * Normalize PEM key (add headers if missing).
	 *
	 * @param string $key  Raw key.
	 * @param string $type private|public.
	 * @return string
	 */
	public static function format_key($key, $type = 'private')
	{
		$key = trim((string) $key);
		$key = str_replace(array("\r\n", "\r"), "\n", $key);

		if (false !== strpos($key, 'BEGIN')) {
			return $key;
		}

		$key = preg_replace('/\s+/', '', $key);
		$chunks = chunk_split($key, 64, "\n");

		if ('public' === $type) {
			return "-----BEGIN PUBLIC KEY-----\n{$chunks}-----END PUBLIC KEY-----";
		}

		// Alipay apps commonly use PKCS8.
		return "-----BEGIN PRIVATE KEY-----\n{$chunks}-----END PRIVATE KEY-----";
	}

	/**
	 * Build sorted query string for signing (no URL encoding of values for sign content).
	 *
	 * @param array $params Params.
	 * @return string
	 */
	public static function build_sign_content(array $params)
	{
		ksort($params);
		$parts = array();
		foreach ($params as $k => $v) {
			if ('' === $v || null === $v) {
				continue;
			}
			// Alipay excludes sign and sign_type from the signed content.
			if ('sign' === $k || 'sign_type' === $k) {
				continue;
			}
			$parts[] = $k . '=' . $v;
		}
		return implode('&', $parts);
	}

	/**
	 * RSA2 sign.
	 *
	 * @param string $content Content to sign.
	 * @return string|WP_Error Base64 signature.
	 */
	public static function sign($content)
	{
		$settings = HB_Alipay_Plugin::get_settings();
		$raw      = trim((string) $settings['private_key']);
		$pkey     = openssl_pkey_get_private(self::format_key($raw, 'private'));
		if (! $pkey) {
			// Retry PKCS1 header style.
			$pkcs1 = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split(preg_replace('/\s+/', '', preg_replace('/-----[^-]+-----/', '', $raw)), 64, "\n") . '-----END RSA PRIVATE KEY-----';
			$pkey  = openssl_pkey_get_private($pkcs1);
		}
		if (! $pkey) {
			return new WP_Error('alipay_key', __('Invalid Alipay merchant private key.', 'hb-alipay-content'));
		}

		$signature = '';
		$ok        = openssl_sign($content, $signature, $pkey, OPENSSL_ALGO_SHA256);
		if (! $ok) {
			return new WP_Error('alipay_sign', __('Failed to sign Alipay request.', 'hb-alipay-content'));
		}

		return base64_encode($signature);
	}

	/**
	 * Verify RSA2 signature from Alipay.
	 *
	 * @param array  $params Params including sign.
	 * @param string $sign   Signature (base64). Optional if in params.
	 * @return bool
	 */
	public static function verify(array $params, $sign = '')
	{
		if ('' === $sign && isset($params['sign'])) {
			$sign = $params['sign'];
		}
		if (empty($sign)) {
			return false;
		}

		$content = self::build_sign_content($params);
		$settings = HB_Alipay_Plugin::get_settings();
		$pubkey   = openssl_pkey_get_public(self::format_key($settings['alipay_public_key'], 'public'));
		if (! $pubkey) {
			return false;
		}

		$decoded = base64_decode($sign, true);
		if (false === $decoded) {
			return false;
		}

		return 1 === openssl_verify($content, $decoded, $pubkey, OPENSSL_ALGO_SHA256);
	}

	/**
	 * Build payment redirect URL (page pay or wap pay).
	 *
	 * @param object $order Order row.
	 * @param string $subject Order subject.
	 * @return string|WP_Error
	 */
	public static function build_pay_url($order, $subject)
	{
		if (! self::is_configured()) {
			return new WP_Error('alipay_config', __('Alipay is not configured.', 'hb-alipay-content'));
		}

		$settings = HB_Alipay_Plugin::get_settings();
		$method   = self::is_mobile() ? 'alipay.trade.wap.pay' : 'alipay.trade.page.pay';

		$subject_clean = wp_strip_all_tags($subject);
		if (function_exists('mb_substr')) {
			$subject_clean = mb_substr($subject_clean, 0, 128);
		} else {
			$subject_clean = substr($subject_clean, 0, 128);
		}

		$biz = array(
			'out_trade_no' => $order->order_no,
			'total_amount' => number_format((float) $order->amount, 2, '.', ''),
			'subject'      => $subject_clean,
			'product_code' => self::is_mobile() ? 'QUICK_WAP_WAY' : 'FAST_INSTANT_TRADE_PAY',
		);

		$params = array(
			'app_id'      => $settings['app_id'],
			'method'      => $method,
			'format'      => 'JSON',
			'charset'     => 'utf-8',
			'sign_type'   => 'RSA2',
			'timestamp'   => current_time('Y-m-d H:i:s'),
			'version'     => '1.0',
			'notify_url'  => home_url('/?hb_alipay_notify=1'),
			'return_url'  => home_url('/?hb_alipay_return=1'),
			'biz_content' => wp_json_encode($biz, JSON_UNESCAPED_UNICODE),
		);

		$sign = self::sign(self::build_sign_content($params));
		if (is_wp_error($sign)) {
			return $sign;
		}
		$params['sign'] = $sign;

		return self::gateway() . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
	}

	/**
	 * Query trade status.
	 *
	 * @param string $order_no Merchant order no.
	 * @return array|WP_Error Decoded response.
	 */
	public static function query_trade($order_no)
	{
		if (! self::is_configured()) {
			return new WP_Error('alipay_config', __('Alipay is not configured.', 'hb-alipay-content'));
		}

		$settings = HB_Alipay_Plugin::get_settings();
		$biz      = array('out_trade_no' => $order_no);

		$params = array(
			'app_id'      => $settings['app_id'],
			'method'      => 'alipay.trade.query',
			'format'      => 'JSON',
			'charset'     => 'utf-8',
			'sign_type'   => 'RSA2',
			'timestamp'   => current_time('Y-m-d H:i:s'),
			'version'     => '1.0',
			'biz_content' => wp_json_encode($biz, JSON_UNESCAPED_UNICODE),
		);

		$sign = self::sign(self::build_sign_content($params));
		if (is_wp_error($sign)) {
			return $sign;
		}
		$params['sign'] = $sign;

		$response = wp_remote_post(
			self::gateway(),
			array(
				'timeout' => 30,
				'body'    => $params,
			)
		);

		if (is_wp_error($response)) {
			return $response;
		}

		$body = json_decode(wp_remote_retrieve_body($response), true);
		if (! is_array($body)) {
			return new WP_Error('alipay_query', __('Invalid Alipay query response.', 'hb-alipay-content'));
		}

		return $body;
	}
}
