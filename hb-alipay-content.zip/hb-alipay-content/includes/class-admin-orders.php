<?php

/**
 * Admin orders list.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Admin_Orders
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('admin_menu', array(__CLASS__, 'menu'));
	}

	/**
	 * Submenu under Paid Content.
	 */
	public static function menu()
	{
		add_submenu_page(
			'edit.php?post_type=' . HB_ALIPAY_CONTENT_CPT,
			__('Alipay Orders', 'hb-alipay-content'),
			__('Orders', 'hb-alipay-content'),
			'manage_options',
			'hb-alipay-orders',
			array(__CLASS__, 'render')
		);
	}

	/**
	 * Render orders table.
	 */
	public static function render()
	{
		if (! current_user_can('manage_options')) {
			return;
		}

		$page    = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$per     = 50;
		$offset  = ($page - 1) * $per;
		$orders  = HB_Alipay_Orders::list_orders($per, $offset);
		$total   = HB_Alipay_Orders::count();
		$pages   = max(1, (int) ceil($total / $per));
?>
		<div class="wrap">
			<h1><?php esc_html_e('Alipay Orders', 'hb-alipay-content'); ?></h1>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e('Order No', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Content', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Amount', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Status', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Alipay Trade No', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Created', 'hb-alipay-content'); ?></th>
						<th><?php esc_html_e('Paid', 'hb-alipay-content'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if (empty($orders)) : ?>
						<tr>
							<td colspan="7"><?php esc_html_e('No orders yet.', 'hb-alipay-content'); ?></td>
						</tr>
					<?php else : ?>
						<?php foreach ($orders as $order) : ?>
							<tr>
								<td><code><?php echo esc_html($order->order_no); ?></code></td>
								<td>
									<?php
									$title = get_the_title((int) $order->post_id);
									$link  = get_edit_post_link((int) $order->post_id);
									if ($link) {
										printf('<a href="%s">%s</a>', esc_url($link), esc_html($title ? $title : '#' . $order->post_id));
									} else {
										echo esc_html($title ? $title : '#' . $order->post_id);
									}
									?>
								</td>
								<td>¥<?php echo esc_html(number_format((float) $order->amount, 2)); ?></td>
								<td><?php echo esc_html($order->status); ?></td>
								<td><code><?php echo esc_html($order->alipay_trade_no); ?></code></td>
								<td><?php echo esc_html($order->created_at); ?></td>
								<td><?php echo esc_html($order->paid_at ? $order->paid_at : '—'); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
			<?php if ($pages > 1) : ?>
				<div class="tablenav bottom">
					<div class="tablenav-pages">
						<?php
						echo wp_kses_post(
							paginate_links(
								array(
									'base'      => add_query_arg('paged', '%#%'),
									'format'    => '',
									'current'   => $page,
									'total'     => $pages,
									'prev_text' => '&laquo;',
									'next_text' => '&raquo;',
								)
							)
						);
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>
<?php
	}
}
