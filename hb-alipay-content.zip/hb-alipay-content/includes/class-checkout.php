<?php

/**
 * Create-order REST endpoint.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Checkout
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('rest_api_init', array(__CLASS__, 'register_routes'));
	}

	/**
	 * Register REST routes.
	 */
	public static function register_routes()
	{
		register_rest_route(
			'hb-alipay/v1',
			'/create-order',
			array(
				'methods'             => 'POST',
				'callback'            => array(__CLASS__, 'create_order'),
				'permission_callback' => '__return_true',
				'args'                => array(
					'post_id' => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Simple IP rate limit.
	 *
	 * @return bool True if allowed.
	 */
	private static function rate_limit_ok()
	{
		$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
		$key = 'hb_alipay_rl_' . md5($ip);
		$count = (int) get_transient($key);
		if ($count >= 10) {
			return false;
		}
		set_transient($key, $count + 1, MINUTE_IN_SECONDS);
		return true;
	}

	/**
	 * Create order and return Alipay redirect URL.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_order(WP_REST_Request $request)
	{
		if (! self::rate_limit_ok()) {
			return new WP_Error('rate_limited', __('Too many requests. Please wait a moment.', 'hb-alipay-content'), array('status' => 429));
		}

		if (! HB_Alipay_Client::is_configured()) {
			return new WP_Error('not_configured', __('Alipay is not configured.', 'hb-alipay-content'), array('status' => 503));
		}

		$post_id = absint($request->get_param('post_id'));
		$post    = get_post($post_id);

		if (! $post || HB_ALIPAY_CONTENT_CPT !== $post->post_type || 'publish' !== $post->post_status) {
			return new WP_Error('invalid_post', __('Invalid content.', 'hb-alipay-content'), array('status' => 404));
		}

		if (! HB_Alipay_Meta::is_paywall_enabled($post_id)) {
			return new WP_Error('not_locked', __('This content does not require payment.', 'hb-alipay-content'), array('status' => 400));
		}

		if (HB_Alipay_Access::can_access($post_id)) {
			return rest_ensure_response(
				array(
					'already_unlocked' => true,
					'redirect'         => get_permalink($post_id),
				)
			);
		}

		$amount = HB_Alipay_Meta::get_amount($post_id);
		$order  = HB_Alipay_Orders::create($post_id, $amount);
		if (is_wp_error($order)) {
			return $order;
		}

		$pay_url = HB_Alipay_Client::build_pay_url($order, $post->post_title);
		if (is_wp_error($pay_url)) {
			return $pay_url;
		}

		return rest_ensure_response(
			array(
				'order_no' => $order->order_no,
				'redirect' => $pay_url,
			)
		);
	}
}
