<?php

/**
 * Cookie-based unlock access control.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Access
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_filter('the_content', array(__CLASS__, 'filter_content'), 1);
	}

	/**
	 * Cookie name for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function cookie_name($post_id)
	{
		return 'hb_unlock_' . absint($post_id);
	}

	/**
	 * Signing secret.
	 *
	 * @return string
	 */
	private static function secret()
	{
		$settings = HB_Alipay_Plugin::get_settings();
		return (string) $settings['secret'] . wp_salt('auth');
	}

	/**
	 * Cookie TTL in seconds.
	 *
	 * @return int
	 */
	public static function ttl()
	{
		$settings = HB_Alipay_Plugin::get_settings();
		$days     = isset($settings['cookie_ttl_days']) ? absint($settings['cookie_ttl_days']) : 30;
		if ($days < 1) {
			$days = 30;
		}
		return $days * DAY_IN_SECONDS;
	}

	/**
	 * Build HMAC for cookie payload.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $order_no Order no.
	 * @param int    $expiry   Expiry timestamp.
	 * @return string
	 */
	public static function sign_payload($post_id, $order_no, $expiry)
	{
		$data = absint($post_id) . '|' . $order_no . '|' . absint($expiry);
		return hash_hmac('sha256', $data, self::secret());
	}

	/**
	 * Issue unlock cookie.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $order_no Order no.
	 */
	public static function issue_cookie($post_id, $order_no)
	{
		$expiry = time() + self::ttl();
		$hmac   = self::sign_payload($post_id, $order_no, $expiry);
		$value  = $order_no . '|' . $expiry . '|' . $hmac;

		$secure = is_ssl();
		setcookie(
			self::cookie_name($post_id),
			$value,
			array(
				'expires'  => $expiry,
				'path'     => '/',
				'secure'   => $secure,
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);

		// Make available in current request.
		$_COOKIE[self::cookie_name($post_id)] = $value;
	}

	/**
	 * Parse and validate cookie value structure.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $raw     Raw cookie.
	 * @return array|false { order_no, expiry } or false.
	 */
	public static function parse_cookie($post_id, $raw)
	{
		$parts = explode('|', (string) $raw);
		if (3 !== count($parts)) {
			return false;
		}

		list($order_no, $expiry, $hmac) = $parts;
		$expiry = absint($expiry);

		if ($expiry < time()) {
			return false;
		}

		$expected = self::sign_payload($post_id, $order_no, $expiry);
		if (! hash_equals($expected, $hmac)) {
			return false;
		}

		return array(
			'order_no' => $order_no,
			'expiry'   => $expiry,
		);
	}

	/**
	 * Whether current visitor can view full content.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function can_access($post_id)
	{
		$post_id = absint($post_id);

		if (current_user_can('edit_post', $post_id)) {
			return true;
		}

		if (! HB_Alipay_Meta::is_paywall_enabled($post_id)) {
			return true;
		}

		$name = self::cookie_name($post_id);
		if (empty($_COOKIE[$name])) {
			return false;
		}

		$parsed = self::parse_cookie($post_id, wp_unslash($_COOKIE[$name]));
		if (! $parsed) {
			return false;
		}

		$order = HB_Alipay_Orders::get_by_order_no($parsed['order_no']);
		if (! $order) {
			return false;
		}

		if ((int) $order->post_id !== $post_id) {
			return false;
		}

		return HB_Alipay_Orders::STATUS_PAID === $order->status;
	}

	/**
	 * Filter the_content for locked posts.
	 *
	 * @param string $content Content.
	 * @return string
	 */
	public static function filter_content($content)
	{
		if (! is_singular(HB_ALIPAY_CONTENT_CPT) || ! in_the_loop() || ! is_main_query()) {
			return $content;
		}

		$post_id = get_the_ID();
		if (! $post_id || ! HB_Alipay_Meta::is_paywall_enabled($post_id)) {
			return $content;
		}

		if (self::can_access($post_id)) {
			return $content;
		}

		return self::render_paywall($post_id);
	}

	/**
	 * Render locked content gate.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function render_paywall($post_id)
	{
		$amount = HB_Alipay_Meta::get_amount($post_id);
		$teaser = HB_Alipay_Meta::get_teaser($post_id);
		$ready  = HB_Alipay_Client::is_configured();

		ob_start();
?>
		<div class="hb-alipay-gate" data-post-id="<?php echo esc_attr($post_id); ?>">
			<?php if ($teaser) : ?>
				<div class="hb-alipay-gate__teaser">
					<?php echo wp_kses_post(wpautop($teaser)); ?>
				</div>
			<?php endif; ?>

			<div class="hb-alipay-gate__panel">
				<p class="hb-alipay-gate__price">
					<span class="hb-alipay-gate__label"><?php esc_html_e('Unlock price', 'hb-alipay-content'); ?></span>
					<strong>¥<?php echo esc_html($amount); ?></strong>
					<span class="hb-alipay-gate__currency">CNY</span>
				</p>
				<p class="hb-alipay-gate__hint">
					<?php esc_html_e('Pay with Alipay to unlock the full content on this device.', 'hb-alipay-content'); ?>
				</p>
				<?php if ($ready) : ?>
					<button type="button" class="hb-alipay-gate__btn" data-hb-alipay-pay>
						<?php esc_html_e('Pay with Alipay to unlock', 'hb-alipay-content'); ?>
					</button>
					<p class="hb-alipay-gate__status" hidden></p>
				<?php else : ?>
					<p class="hb-alipay-gate__error">
						<?php esc_html_e('Payments are temporarily unavailable. Please check back later.', 'hb-alipay-content'); ?>
					</p>
				<?php endif; ?>
			</div>
		</div>
<?php
		return ob_get_clean();
	}
}
