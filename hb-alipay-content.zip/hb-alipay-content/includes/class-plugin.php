<?php

/**
 * Main plugin bootstrap.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Plugin
{

	/**
	 * Singleton instance.
	 *
	 * @var HB_Alipay_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return HB_Alipay_Plugin
	 */
	public static function instance()
	{
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct()
	{
		HB_Alipay_CPT::init();
		HB_Alipay_Meta::init();
		HB_Alipay_Access::init();
		HB_Alipay_Checkout::init();
		HB_Alipay_Notify::init();
		HB_Alipay_Admin_Settings::init();
		HB_Alipay_Admin_Orders::init();

		add_action('wp_enqueue_scripts', array($this, 'enqueue_front_assets'));
	}

	/**
	 * Front assets on paid_content singles.
	 */
	public function enqueue_front_assets()
	{
		if (! is_singular(HB_ALIPAY_CONTENT_CPT)) {
			return;
		}

		wp_enqueue_style(
			'hb-alipay-front',
			HB_ALIPAY_CONTENT_URL . 'assets/css/front.css',
			array(),
			HB_ALIPAY_CONTENT_VERSION
		);

		wp_enqueue_script(
			'hb-alipay-front',
			HB_ALIPAY_CONTENT_URL . 'assets/js/front.js',
			array(),
			HB_ALIPAY_CONTENT_VERSION,
			true
		);

		wp_localize_script(
			'hb-alipay-front',
			'hbAlipay',
			array(
				'restUrl' => esc_url_raw(rest_url('hb-alipay/v1/create-order')),
				'nonce'   => wp_create_nonce('wp_rest'),
				'i18n'    => array(
					'paying'  => __('Redirecting to Alipay…', 'hb-alipay-content'),
					'error'   => __('Payment could not be started. Please try again.', 'hb-alipay-content'),
				),
			)
		);
	}

	/**
	 * Get plugin settings.
	 *
	 * @return array
	 */
	public static function get_settings()
	{
		$defaults = array(
			'app_id'           => '',
			'private_key'      => '',
			'alipay_public_key' => '',
			'sandbox'          => '0',
			'cookie_ttl_days'  => 30,
			'secret'           => '',
		);

		$settings = get_option('hb_alipay_settings', array());
		if (! is_array($settings)) {
			$settings = array();
		}

		$settings = wp_parse_args($settings, $defaults);

		if (empty($settings['secret'])) {
			$settings['secret'] = wp_generate_password(64, true, true);
			update_option('hb_alipay_settings', $settings, false);
		}

		return $settings;
	}
}
