<?php

/**
 * Alipay async notify and sync return handlers.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Notify
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('init', array(__CLASS__, 'maybe_handle'), 1);
	}

	/**
	 * Route notify / return requests.
	 */
	public static function maybe_handle()
	{
		if (isset($_GET['hb_alipay_notify'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			self::handle_notify();
			exit;
		}

		if (isset($_GET['hb_alipay_return'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			self::handle_return();
			exit;
		}
	}

	/**
	 * Collect POST/GET params for Alipay.
	 *
	 * @return array
	 */
	private static function collect_params()
	{
		$params = array();
		// Prefer POST (notify), fall back to GET (return).
		$source = ! empty($_POST) ? wp_unslash($_POST) : wp_unslash($_GET); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended
		foreach ($source as $key => $value) {
			if (is_array($value)) {
				continue;
			}
			$params[sanitize_text_field($key)] = sanitize_text_field($value);
		}
		return $params;
	}

	/**
	 * Process successful payment into unlock.
	 *
	 * @param string $order_no        Merchant order no.
	 * @param string $alipay_trade_no Trade no.
	 * @param string $buyer_id        Buyer id.
	 * @return object|false Order or false.
	 */
	public static function fulfill_payment($order_no, $alipay_trade_no = '', $buyer_id = '')
	{
		$order = HB_Alipay_Orders::get_by_order_no($order_no);
		if (! $order) {
			return false;
		}

		$token      = wp_generate_password(32, false, false);
		$token_hash = hash('sha256', $token);

		HB_Alipay_Orders::mark_paid($order_no, $alipay_trade_no, $buyer_id, $token_hash);

		return HB_Alipay_Orders::get_by_order_no($order_no);
	}

	/**
	 * Async notify from Alipay.
	 */
	public static function handle_notify()
	{
		$params = self::collect_params();

		if (empty($params['out_trade_no']) || empty($params['sign'])) {
			echo 'fail';
			return;
		}

		$sign = $params['sign'];
		unset($params['sign'], $params['sign_type']);

		if (! HB_Alipay_Client::verify($params, $sign)) {
			echo 'fail';
			return;
		}

		$status = isset($params['trade_status']) ? $params['trade_status'] : '';
		if (! in_array($status, array('TRADE_SUCCESS', 'TRADE_FINISHED'), true)) {
			echo 'success';
			return;
		}

		$order_no        = $params['out_trade_no'];
		$alipay_trade_no = isset($params['trade_no']) ? $params['trade_no'] : '';
		$buyer_id        = isset($params['buyer_id']) ? $params['buyer_id'] : (isset($params['buyer_open_id']) ? $params['buyer_open_id'] : '');

		$order = HB_Alipay_Orders::get_by_order_no($order_no);
		if (! $order) {
			echo 'fail';
			return;
		}

		// Amount check.
		if (isset($params['total_amount']) && number_format((float) $params['total_amount'], 2, '.', '') !== number_format((float) $order->amount, 2, '.', '')) {
			echo 'fail';
			return;
		}

		self::fulfill_payment($order_no, $alipay_trade_no, $buyer_id);
		echo 'success';
	}

	/**
	 * Sync return from Alipay browser redirect.
	 */
	public static function handle_return()
	{
		$params = self::collect_params();
		$order_no = isset($params['out_trade_no']) ? $params['out_trade_no'] : '';

		if ($order_no && ! empty($params['sign'])) {
			$sign = $params['sign'];
			$check = $params;
			unset($check['sign'], $check['sign_type'], $check['hb_alipay_return']);
			if (HB_Alipay_Client::verify($check, $sign)) {
				// Return page may not include trade_status; query if still pending.
				$order = HB_Alipay_Orders::get_by_order_no($order_no);
				if ($order && HB_Alipay_Orders::STATUS_PAID !== $order->status) {
					self::maybe_query_and_fulfill($order_no);
				} elseif ($order && HB_Alipay_Orders::STATUS_PAID === $order->status) {
					// Already paid via notify.
				} elseif (isset($params['trade_no'])) {
					self::fulfill_payment(
						$order_no,
						$params['trade_no'],
						isset($params['buyer_id']) ? $params['buyer_id'] : ''
					);
				}
			}
		} elseif ($order_no) {
			self::maybe_query_and_fulfill($order_no);
		}

		$order = $order_no ? HB_Alipay_Orders::get_by_order_no($order_no) : null;

		if ($order && HB_Alipay_Orders::STATUS_PAID === $order->status) {
			HB_Alipay_Access::issue_cookie((int) $order->post_id, $order->order_no);
			$redirect = get_permalink((int) $order->post_id);
			wp_safe_redirect($redirect ? $redirect : home_url('/'));
			return;
		}

		// Not paid yet — send back to post with pending flag.
		if ($order) {
			$permalink = get_permalink((int) $order->post_id);
			wp_safe_redirect(add_query_arg('hb_pay', 'pending', $permalink ? $permalink : home_url('/')));
			return;
		}

		wp_safe_redirect(home_url('/'));
	}

	/**
	 * Query Alipay trade and fulfill if paid.
	 *
	 * @param string $order_no Order no.
	 */
	private static function maybe_query_and_fulfill($order_no)
	{
		$result = HB_Alipay_Client::query_trade($order_no);
		if (is_wp_error($result)) {
			return;
		}

		$response = isset($result['alipay_trade_query_response']) ? $result['alipay_trade_query_response'] : array();
		if (empty($response['code']) || '10000' !== (string) $response['code']) {
			return;
		}

		$status = isset($response['trade_status']) ? $response['trade_status'] : '';
		if (! in_array($status, array('TRADE_SUCCESS', 'TRADE_FINISHED'), true)) {
			return;
		}

		self::fulfill_payment(
			$order_no,
			isset($response['trade_no']) ? $response['trade_no'] : '',
			isset($response['buyer_user_id']) ? $response['buyer_user_id'] : ''
		);
	}
}
