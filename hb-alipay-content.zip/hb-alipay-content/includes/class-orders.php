<?php

/**
 * Orders table CRUD.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Orders
{

	const STATUS_PENDING = 'pending';
	const STATUS_PAID    = 'paid';
	const STATUS_FAILED  = 'failed';

	/**
	 * Table name with prefix.
	 *
	 * @return string
	 */
	public static function table()
	{
		global $wpdb;
		return $wpdb->prefix . 'hb_alipay_orders';
	}

	/**
	 * Create table on activation.
	 */
	public static function activate()
	{
		global $wpdb;

		$table           = self::table();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_no varchar(64) NOT NULL,
			post_id bigint(20) unsigned NOT NULL,
			amount decimal(10,2) NOT NULL DEFAULT 0.00,
			status varchar(20) NOT NULL DEFAULT 'pending',
			alipay_trade_no varchar(64) DEFAULT '',
			buyer_id varchar(64) DEFAULT '',
			unlock_token_hash varchar(64) DEFAULT '',
			created_at datetime NOT NULL,
			paid_at datetime DEFAULT NULL,
			ip varchar(45) DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY order_no (order_no),
			KEY post_id (post_id),
			KEY status (status)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);

		$settings = get_option('hb_alipay_settings', array());
		if (! is_array($settings)) {
			$settings = array();
		}
		if (empty($settings['secret'])) {
			$settings['secret'] = wp_generate_password(64, true, true);
			update_option('hb_alipay_settings', $settings, false);
		}

		// Flush rewrites after CPT is registered on next init.
		update_option('hb_alipay_flush_rewrites', '1', false);
	}

	/**
	 * Generate unique merchant order number.
	 *
	 * @return string
	 */
	public static function generate_order_no()
	{
		return 'HB' . gmdate('YmdHis') . wp_generate_password(8, false, false);
	}

	/**
	 * Insert pending order.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $amount  Amount string.
	 * @return array|WP_Error Order row or error.
	 */
	public static function create($post_id, $amount)
	{
		global $wpdb;

		$order_no = self::generate_order_no();
		$now      = current_time('mysql', true);
		$ip       = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

		$inserted = $wpdb->insert(
			self::table(),
			array(
				'order_no'   => $order_no,
				'post_id'    => absint($post_id),
				'amount'     => number_format((float) $amount, 2, '.', ''),
				'status'     => self::STATUS_PENDING,
				'created_at' => $now,
				'ip'         => $ip,
			),
			array('%s', '%d', '%s', '%s', '%s', '%s')
		);

		if (false === $inserted) {
			return new WP_Error('db_insert_failed', __('Could not create order.', 'hb-alipay-content'));
		}

		return self::get_by_order_no($order_no);
	}

	/**
	 * Get order by merchant order number.
	 *
	 * @param string $order_no Order number.
	 * @return object|null
	 */
	public static function get_by_order_no($order_no)
	{
		global $wpdb;
		$table = self::table();
		return $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM {$table} WHERE order_no = %s LIMIT 1", $order_no)
		);
	}

	/**
	 * Get order by ID.
	 *
	 * @param int $id Order ID.
	 * @return object|null
	 */
	public static function get($id)
	{
		global $wpdb;
		$table = self::table();
		return $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint($id))
		);
	}

	/**
	 * Mark order as paid.
	 *
	 * @param string $order_no        Merchant order no.
	 * @param string $alipay_trade_no Alipay trade no.
	 * @param string $buyer_id        Buyer id.
	 * @param string $token_hash      Unlock token hash.
	 * @return bool
	 */
	public static function mark_paid($order_no, $alipay_trade_no = '', $buyer_id = '', $token_hash = '')
	{
		global $wpdb;

		$order = self::get_by_order_no($order_no);
		if (! $order) {
			return false;
		}

		if (self::STATUS_PAID === $order->status) {
			return true;
		}

		$updated = $wpdb->update(
			self::table(),
			array(
				'status'            => self::STATUS_PAID,
				'alipay_trade_no'   => sanitize_text_field($alipay_trade_no),
				'buyer_id'          => sanitize_text_field($buyer_id),
				'unlock_token_hash' => sanitize_text_field($token_hash),
				'paid_at'           => current_time('mysql', true),
			),
			array('order_no' => $order_no),
			array('%s', '%s', '%s', '%s', '%s'),
			array('%s')
		);

		return false !== $updated;
	}

	/**
	 * List orders for admin.
	 *
	 * @param int $limit  Limit.
	 * @param int $offset Offset.
	 * @return array
	 */
	public static function list_orders($limit = 50, $offset = 0)
	{
		global $wpdb;
		$table = self::table();
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d",
				absint($limit),
				absint($offset)
			)
		);
	}

	/**
	 * Count orders.
	 *
	 * @return int
	 */
	public static function count()
	{
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
	}
}
