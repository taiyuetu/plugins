<?php

/**
 * Custom post type registration.
 */

defined('ABSPATH') || exit;

class HB_Alipay_CPT
{

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('init', array(__CLASS__, 'register'));
		add_action('init', array(__CLASS__, 'maybe_flush_rewrites'), 99);
	}

	/**
	 * Flush rewrite rules once after activation.
	 */
	public static function maybe_flush_rewrites()
	{
		if ('1' !== get_option('hb_alipay_flush_rewrites')) {
			return;
		}
		flush_rewrite_rules(false);
		delete_option('hb_alipay_flush_rewrites');
	}

	/**
	 * Register paid_content CPT.
	 */
	public static function register()
	{
		$labels = array(
			'name'               => __('Paid Content', 'hb-alipay-content'),
			'singular_name'      => __('Paid Content', 'hb-alipay-content'),
			'add_new'            => __('Add New', 'hb-alipay-content'),
			'add_new_item'       => __('Add New Paid Content', 'hb-alipay-content'),
			'edit_item'          => __('Edit Paid Content', 'hb-alipay-content'),
			'new_item'           => __('New Paid Content', 'hb-alipay-content'),
			'view_item'          => __('View Paid Content', 'hb-alipay-content'),
			'search_items'       => __('Search Paid Content', 'hb-alipay-content'),
			'not_found'          => __('No paid content found', 'hb-alipay-content'),
			'not_found_in_trash' => __('No paid content found in Trash', 'hb-alipay-content'),
			'menu_name'          => __('Paid Content', 'hb-alipay-content'),
			'all_items'          => __('All Paid Content', 'hb-alipay-content'),
		);

		register_post_type(
			HB_ALIPAY_CONTENT_CPT,
			array(
				'labels'              => $labels,
				'public'              => true,
				'has_archive'         => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'menu_icon'           => 'dashicons-lock',
				'menu_position'       => 25,
				'supports'            => array('title', 'editor', 'thumbnail', 'excerpt'),
				'rewrite'             => array('slug' => 'paid-content'),
				'capability_type'     => 'post',
				'exclude_from_search' => false,
			)
		);
	}
}
