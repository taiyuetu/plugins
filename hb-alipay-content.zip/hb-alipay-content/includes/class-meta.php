<?php

/**
 * Post meta box and validation.
 */

defined('ABSPATH') || exit;

class HB_Alipay_Meta
{

	const META_ENABLED  = '_hb_pay_enabled';
	const META_AMOUNT   = '_hb_pay_amount';
	const META_TEASER   = '_hb_pay_teaser';
	const META_CURRENCY = '_hb_pay_currency';

	/**
	 * Hooks.
	 */
	public static function init()
	{
		add_action('add_meta_boxes', array(__CLASS__, 'add_meta_box'));
		add_action('save_post_' . HB_ALIPAY_CONTENT_CPT, array(__CLASS__, 'save'), 10, 2);
		add_action('admin_notices', array(__CLASS__, 'admin_notices'));
		add_filter('wp_insert_post_data', array(__CLASS__, 'block_invalid_publish'), 10, 2);
	}

	/**
	 * Register meta box.
	 */
	public static function add_meta_box()
	{
		add_meta_box(
			'hb_alipay_pay_settings',
			__('Alipay Unlock Settings', 'hb-alipay-content'),
			array(__CLASS__, 'render_meta_box'),
			HB_ALIPAY_CONTENT_CPT,
			'side',
			'high'
		);
	}

	/**
	 * Render meta box.
	 *
	 * @param WP_Post $post Post.
	 */
	public static function render_meta_box($post)
	{
		wp_nonce_field('hb_alipay_meta_save', 'hb_alipay_meta_nonce');

		$enabled  = get_post_meta($post->ID, self::META_ENABLED, true);
		$amount   = get_post_meta($post->ID, self::META_AMOUNT, true);
		$teaser   = get_post_meta($post->ID, self::META_TEASER, true);
		$currency = get_post_meta($post->ID, self::META_CURRENCY, true);
		if (! $currency) {
			$currency = 'CNY';
		}
?>
		<p>
			<label>
				<input type="checkbox" name="hb_pay_enabled" value="1" <?php checked($enabled, '1'); ?> />
				<?php esc_html_e('Require Alipay payment to unlock content', 'hb-alipay-content'); ?>
			</label>
		</p>
		<p>
			<label for="hb_pay_amount"><strong><?php esc_html_e('Amount (CNY)', 'hb-alipay-content'); ?></strong></label><br />
			<input type="number" step="0.01" min="0.01" id="hb_pay_amount" name="hb_pay_amount" value="<?php echo esc_attr($amount); ?>" class="widefat" />
		</p>
		<p>
			<label for="hb_pay_currency"><strong><?php esc_html_e('Currency', 'hb-alipay-content'); ?></strong></label><br />
			<input type="text" id="hb_pay_currency" name="hb_pay_currency" value="<?php echo esc_attr($currency); ?>" class="widefat" readonly />
		</p>
		<p>
			<label for="hb_pay_teaser"><strong><?php esc_html_e('Free teaser (shown before unlock)', 'hb-alipay-content'); ?></strong></label>
			<textarea id="hb_pay_teaser" name="hb_pay_teaser" rows="5" class="widefat"><?php echo esc_textarea($teaser); ?></textarea>
		</p>
		<p class="description">
			<?php esc_html_e('The main editor content is hidden until the visitor pays.', 'hb-alipay-content'); ?>
		</p>
<?php
	}

	/**
	 * Save meta.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function save($post_id, $post)
	{
		if (! isset($_POST['hb_alipay_meta_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hb_alipay_meta_nonce'])), 'hb_alipay_meta_save')) {
			return;
		}

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		if (! current_user_can('edit_post', $post_id)) {
			return;
		}

		$enabled = isset($_POST['hb_pay_enabled']) ? '1' : '0';
		$amount  = isset($_POST['hb_pay_amount']) ? sanitize_text_field(wp_unslash($_POST['hb_pay_amount'])) : '';
		$teaser  = isset($_POST['hb_pay_teaser']) ? wp_kses_post(wp_unslash($_POST['hb_pay_teaser'])) : '';

		$amount_clean = self::normalize_amount($amount);

		update_post_meta($post_id, self::META_ENABLED, $enabled);
		update_post_meta($post_id, self::META_AMOUNT, $amount_clean);
		update_post_meta($post_id, self::META_TEASER, $teaser);
		update_post_meta($post_id, self::META_CURRENCY, 'CNY');

		if ('1' === $enabled && '' === $amount_clean) {
			set_transient('hb_alipay_meta_error_' . get_current_user_id(), __('Payment is enabled but amount is missing or invalid. Please set a valid CNY amount.', 'hb-alipay-content'), 60);
		}
	}

	/**
	 * Normalize amount to two decimal places or empty.
	 *
	 * @param string $amount Raw amount.
	 * @return string
	 */
	public static function normalize_amount($amount)
	{
		$amount = trim((string) $amount);
		if ('' === $amount || ! is_numeric($amount)) {
			return '';
		}
		$value = (float) $amount;
		if ($value <= 0) {
			return '';
		}
		return number_format($value, 2, '.', '');
	}

	/**
	 * Whether pay wall is active for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_paywall_enabled($post_id)
	{
		$enabled = get_post_meta($post_id, self::META_ENABLED, true);
		$amount  = self::normalize_amount(get_post_meta($post_id, self::META_AMOUNT, true));
		return '1' === $enabled && '' !== $amount;
	}

	/**
	 * Get amount for post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function get_amount($post_id)
	{
		return self::normalize_amount(get_post_meta($post_id, self::META_AMOUNT, true));
	}

	/**
	 * Get teaser.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function get_teaser($post_id)
	{
		return (string) get_post_meta($post_id, self::META_TEASER, true);
	}

	/**
	 * Prevent publishing when enabled without valid amount.
	 *
	 * @param array $data    Post data.
	 * @param array $postarr Raw postarr.
	 * @return array
	 */
	public static function block_invalid_publish($data, $postarr)
	{
		if (HB_ALIPAY_CONTENT_CPT !== $data['post_type']) {
			return $data;
		}

		if (! in_array($data['post_status'], array('publish', 'future'), true)) {
			return $data;
		}

		// On first insert, meta may not be in POST yet for REST; check POST when available.
		$enabled = isset($_POST['hb_pay_enabled']) ? '1' : null;
		$amount  = isset($_POST['hb_pay_amount']) ? self::normalize_amount(sanitize_text_field(wp_unslash($_POST['hb_pay_amount']))) : null;

		if (null === $enabled && ! empty($postarr['ID'])) {
			$enabled = get_post_meta($postarr['ID'], self::META_ENABLED, true);
			$amount  = self::normalize_amount(get_post_meta($postarr['ID'], self::META_AMOUNT, true));
		}

		if ('1' === $enabled && (null === $amount || '' === $amount)) {
			$data['post_status'] = 'draft';
			set_transient('hb_alipay_meta_error_' . get_current_user_id(), __('Cannot publish: Alipay unlock is enabled but amount is invalid. Saved as draft.', 'hb-alipay-content'), 60);
		}

		return $data;
	}

	/**
	 * Show validation notices.
	 */
	public static function admin_notices()
	{
		$error = get_transient('hb_alipay_meta_error_' . get_current_user_id());
		if (! $error) {
			return;
		}
		delete_transient('hb_alipay_meta_error_' . get_current_user_id());
		printf(
			'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
			esc_html($error)
		);
	}
}
