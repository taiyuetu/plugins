<?php

/**
 * Plugin Name: HB Alipay Content Unlock
 * Description: Paid content CPT unlocked via Alipay (China Open Platform). Anonymous visitors unlock with a signed cookie after payment.
 * Version: 1.0.0
 * Author: Hub Bearing
 * Text Domain: hb-alipay-content
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('HB_ALIPAY_CONTENT_VERSION', '1.0.0');
define('HB_ALIPAY_CONTENT_FILE', __FILE__);
define('HB_ALIPAY_CONTENT_PATH', plugin_dir_path(__FILE__));
define('HB_ALIPAY_CONTENT_URL', plugin_dir_url(__FILE__));
define('HB_ALIPAY_CONTENT_CPT', 'paid_content');

require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-orders.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-alipay-client.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-access.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-cpt.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-meta.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-checkout.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-notify.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-admin-settings.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-admin-orders.php';
require_once HB_ALIPAY_CONTENT_PATH . 'includes/class-plugin.php';

register_activation_hook(__FILE__, array('HB_Alipay_Orders', 'activate'));

/**
 * Bootstrap plugin.
 */
function hb_alipay_content()
{
	return HB_Alipay_Plugin::instance();
}

add_action('plugins_loaded', 'hb_alipay_content');
