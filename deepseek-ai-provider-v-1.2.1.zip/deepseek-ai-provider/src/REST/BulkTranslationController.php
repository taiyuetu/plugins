<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\REST;

use DeepSeekAiProvider\Translation\PolylangHelper;
use DeepSeekAiProvider\Translation\PostTranslator;

/**
 * REST endpoints for bulk translation of posts, products, and terms.
 *
 * GET  /wp-json/deepseek-ai-provider/v1/bulk/untranslated-posts
 * GET  /wp-json/deepseek-ai-provider/v1/bulk/untranslated-terms
 * POST /wp-json/deepseek-ai-provider/v1/bulk/translate-post
 * POST /wp-json/deepseek-ai-provider/v1/bulk/translate-term
 */
class BulkTranslationController {

	const REST_NAMESPACE = 'deepseek-ai-provider/v1';

	/**
	 * Allow long multi-chunk translations within one REST request (PHP max_execution_time).
	 */
	private function raiseTimeLimitForTranslation(): void {
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@set_time_limit( 0 );
		}
	}

	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'registerRoutes' ) );
	}

	public function registerRoutes(): void {
		$ns = self::REST_NAMESPACE;

		register_rest_route( $ns, '/bulk/untranslated-posts', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'getUntranslatedPosts' ),
			'permission_callback' => array( $this, 'permissionCheck' ),
			'args'                => array(
				'post_type'   => array( 'default' => 'post', 'sanitize_callback' => 'sanitize_text_field' ),
				'target_lang' => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
				'per_page'    => array( 'default' => 50, 'sanitize_callback' => 'absint' ),
				'page'        => array( 'default' => 1, 'sanitize_callback' => 'absint' ),
			),
		) );

		register_rest_route( $ns, '/bulk/untranslated-terms', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'getUntranslatedTerms' ),
			'permission_callback' => array( $this, 'permissionCheck' ),
			'args'                => array(
				'taxonomy'    => array( 'default' => 'category', 'sanitize_callback' => 'sanitize_text_field' ),
				'target_lang' => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
				'per_page'    => array( 'default' => 50, 'sanitize_callback' => 'absint' ),
				'page'        => array( 'default' => 1, 'sanitize_callback' => 'absint' ),
			),
		) );

		register_rest_route( $ns, '/bulk/translate-post', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'translatePost' ),
			'permission_callback' => array( $this, 'permissionCheck' ),
			'args'                => array(
				'post_id'     => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'target_lang' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( $ns, '/bulk/translate-term', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'translateTerm' ),
			'permission_callback' => array( $this, 'permissionCheck' ),
			'args'                => array(
				'term_id'     => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
				'taxonomy'    => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'target_lang' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );

		register_rest_route( $ns, '/bulk/status', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'getStatus' ),
			'permission_callback' => array( $this, 'permissionCheck' ),
		) );
	}

	public function permissionCheck(): bool {
		return current_user_can( 'edit_posts' );
	}

	public function getUntranslatedPosts( \WP_REST_Request $request ): \WP_REST_Response {
		$post_type   = $request->get_param( 'post_type' );
		$target_lang = $request->get_param( 'target_lang' );
		$per_page    = $request->get_param( 'per_page' );
		$page        = $request->get_param( 'page' );

		if ( ! PolylangHelper::isActive() ) {
			return rest_ensure_response( array( 'error' => 'Polylang is not active.' ) );
		}

		$data = PolylangHelper::getUntranslatedPosts( $post_type, $target_lang, $per_page, $page );

		return rest_ensure_response( $data );
	}

	public function getUntranslatedTerms( \WP_REST_Request $request ): \WP_REST_Response {
		$taxonomy    = $request->get_param( 'taxonomy' );
		$target_lang = $request->get_param( 'target_lang' );
		$per_page    = $request->get_param( 'per_page' );
		$page        = $request->get_param( 'page' );

		if ( ! PolylangHelper::isActive() ) {
			return rest_ensure_response( array( 'error' => 'Polylang is not active.' ) );
		}

		$data = PolylangHelper::getUntranslatedTerms( $taxonomy, $target_lang, $per_page, $page );

		return rest_ensure_response( $data );
	}

	/**
	 * Translate a single post (called sequentially from the bulk JS queue).
	 */
	public function translatePost( \WP_REST_Request $request ) {
		$post_id     = (int) $request->get_param( 'post_id' );
		$target_lang = (string) $request->get_param( 'target_lang' );

		$post = get_post( $post_id );
		if ( ! ( $post instanceof \WP_Post ) ) {
			return new \WP_Error( 'not_found', 'Post not found.', array( 'status' => 404 ) );
		}

		$this->raiseTimeLimitForTranslation();

		if ( ! PostTranslator::isAvailable() ) {
			return new \WP_Error( 'ai_unavailable', 'DeepSeek is not configured.', array( 'status' => 400 ) );
		}

		$source_lang = PolylangHelper::getPostLanguage( $post_id );
		if ( empty( $source_lang ) || $source_lang === $target_lang ) {
			return new \WP_Error( 'invalid_lang', 'Invalid source/target language pair.', array( 'status' => 400 ) );
		}

		$translator = new PostTranslator();
		$result     = $translator->translate(
			$post->post_title,
			$post->post_content,
			PolylangHelper::getLanguageName( $source_lang ),
			PolylangHelper::getLanguageName( $target_lang )
		);

		if ( is_wp_error( $result ) ) {
			return new \WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => 500 ) );
		}

		$new_post_id = PolylangHelper::saveTranslation( $post_id, $target_lang, $result['title'], $result['content'] );

		if ( is_wp_error( $new_post_id ) ) {
			return new \WP_Error( $new_post_id->get_error_code(), $new_post_id->get_error_message(), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array(
			'success' => true,
			'post_id' => $new_post_id,
			'title'   => $result['title'],
		) );
	}

	/**
	 * Translate a single term (called sequentially from the bulk JS queue).
	 */
	public function translateTerm( \WP_REST_Request $request ) {
		$term_id     = (int) $request->get_param( 'term_id' );
		$taxonomy    = (string) $request->get_param( 'taxonomy' );
		$target_lang = (string) $request->get_param( 'target_lang' );

		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error( 'not_found', 'Term not found.', array( 'status' => 404 ) );
		}

		$this->raiseTimeLimitForTranslation();

		if ( ! PostTranslator::isAvailable() ) {
			return new \WP_Error( 'ai_unavailable', 'DeepSeek is not configured.', array( 'status' => 400 ) );
		}

		$source_lang = function_exists( 'pll_get_term_language' ) ? pll_get_term_language( $term_id ) : '';
		if ( empty( $source_lang ) || $source_lang === $target_lang ) {
			return new \WP_Error( 'invalid_lang', 'Invalid source/target language pair.', array( 'status' => 400 ) );
		}

		$translator = new PostTranslator();
		$result     = $translator->translateTerm(
			$term->name,
			$term->description,
			PolylangHelper::getLanguageName( $source_lang ),
			PolylangHelper::getLanguageName( $target_lang )
		);

		if ( is_wp_error( $result ) ) {
			return new \WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => 500 ) );
		}

		$new_term_id = PolylangHelper::saveTermTranslation(
			$term_id,
			$taxonomy,
			$target_lang,
			$result['name'],
			$result['slug'],
			$result['description']
		);

		if ( is_wp_error( $new_term_id ) ) {
			return new \WP_Error( $new_term_id->get_error_code(), $new_term_id->get_error_message(), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array(
			'success' => true,
			'term_id' => $new_term_id,
			'name'    => $result['name'],
		) );
	}

	/**
	 * Translation status overview.
	 */
	public function getStatus(): \WP_REST_Response {
		if ( ! PolylangHelper::isActive() ) {
			return rest_ensure_response( array( 'error' => 'Polylang is not active.' ) );
		}

		$languages  = pll_languages_list( array( 'fields' => '' ) );
		$post_types = get_post_types( array( 'public' => true ), 'names' );
		$taxonomies = get_taxonomies( array( 'public' => true ), 'names' );

		$status = array(
			'languages'  => array_map( fn( $l ) => $l->slug, $languages ),
			'post_types' => array(),
			'taxonomies' => array(),
		);

		foreach ( $post_types as $pt ) {
			$counts = array();
			foreach ( $languages as $lang ) {
				$q = new \WP_Query( array(
					'post_type'      => $pt,
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'lang'           => $lang->slug,
					'fields'         => 'ids',
				) );
				$counts[ $lang->slug ] = $q->found_posts;
			}
			$status['post_types'][ $pt ] = $counts;
		}

		foreach ( $taxonomies as $tax ) {
			$counts = array();
			foreach ( $languages as $lang ) {
				$terms = get_terms( array(
					'taxonomy'   => $tax,
					'hide_empty' => false,
					'lang'       => $lang->slug,
					'fields'     => 'count',
				) );
				$counts[ $lang->slug ] = is_wp_error( $terms ) ? 0 : (int) $terms;
			}
			$status['taxonomies'][ $tax ] = $counts;
		}

		return rest_ensure_response( $status );
	}
}
