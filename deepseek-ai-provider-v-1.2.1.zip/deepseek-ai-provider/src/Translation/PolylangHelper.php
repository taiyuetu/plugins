<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Translation;

class PolylangHelper {

	public static function isActive(): bool {
		return function_exists( 'pll_languages_list' );
	}

	/**
	 * @return array<string,string> [ slug => display name ]
	 */
	public static function getLanguages(): array {
		if ( ! self::isActive() ) {
			return array();
		}

		$slugs = pll_languages_list();
		$names = pll_languages_list( array( 'fields' => 'name' ) );

		if ( ! is_array( $slugs ) || ! is_array( $names ) || count( $slugs ) !== count( $names ) ) {
			return array();
		}

		return array_combine( $slugs, $names );
	}

	public static function getDefaultLanguage(): string {
		if ( ! self::isActive() || ! function_exists( 'pll_default_language' ) ) {
			return '';
		}

		return (string) pll_default_language();
	}

	public static function getPostLanguage( int $post_id ): string {
		if ( ! self::isActive() || ! function_exists( 'pll_get_post_language' ) ) {
			return '';
		}

		$lang = pll_get_post_language( $post_id );

		return is_string( $lang ) ? $lang : '';
	}

	public static function getLanguageName( string $slug ): string {
		$languages = self::getLanguages();

		return isset( $languages[ $slug ] ) ? $languages[ $slug ] : $slug;
	}

	/**
	 * Create or update a translated post and link it to the source via Polylang.
	 *
	 * @return int|\WP_Error
	 */
	public static function saveTranslation( int $source_post_id, string $target_lang, string $title, string $content ) {
		$source_post = get_post( $source_post_id );

		if ( ! ( $source_post instanceof \WP_Post ) ) {
			return new \WP_Error( 'invalid_post', __( 'Source post not found.', 'deepseek-ai-provider' ) );
		}

		$existing_id = ( function_exists( 'pll_get_post' ) )
			? (int) pll_get_post( $source_post_id, $target_lang )
			: 0;

		// Check if existing is an empty stub (Polylang auto-creates these)
		if ( $existing_id > 0 ) {
			$existing_post = get_post( $existing_id );
			if ( $existing_post && empty( trim( $existing_post->post_title ) ) && empty( trim( $existing_post->post_content ) ) ) {
				// Treat as needing update
			} elseif ( $existing_post ) {
				// Genuine existing translation — update
			}
		}

		if ( $existing_id > 0 ) {
			$post_id = wp_update_post(
				array(
					'ID'           => $existing_id,
					'post_title'   => $title,
					'post_content' => $content,
					'post_status'  => $source_post->post_status,
				),
				true
			);
		} else {
			$post_id = wp_insert_post(
				array(
					'post_title'   => $title,
					'post_content' => $content,
					'post_status'  => $source_post->post_status,
					'post_type'    => $source_post->post_type,
					'post_author'  => $source_post->post_author,
					'menu_order'   => $source_post->menu_order,
				),
				true
			);
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( function_exists( 'pll_set_post_language' ) ) {
			pll_set_post_language( $post_id, $target_lang );
		}

		if ( function_exists( 'pll_get_post_translations' ) && function_exists( 'pll_save_post_translations' ) ) {
			// Race-condition-safe linking using MySQL GET_LOCK
			global $wpdb;
			$lock_name = 'dsap_post_' . $source_post_id;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->get_var( $wpdb->prepare( "SELECT GET_LOCK(%s, %d)", $lock_name, 10 ) );

			try {
				clean_post_cache( $source_post_id );
				clean_post_cache( $post_id );

				$translations                = pll_get_post_translations( $source_post_id );
				$source_lang                 = self::getPostLanguage( $source_post_id );
				if ( $source_lang ) {
					$translations[ $source_lang ] = $source_post_id;
				}
				$translations[ $target_lang ] = $post_id;
				pll_save_post_translations( $translations );
			} finally {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->query( $wpdb->prepare( "SELECT RELEASE_LOCK(%s)", $lock_name ) );
			}
		}

		// Copy featured image from source.
		$thumb_id = get_post_thumbnail_id( $source_post_id );
		if ( $thumb_id ) {
			set_post_thumbnail( $post_id, $thumb_id );
		}

		// Sync taxonomy terms.
		self::syncTaxonomyTerms( $source_post_id, $post_id, $source_post->post_type, $target_lang );

		// Sync meta fields (non-translatable ones carry over as-is).
		self::syncPostMeta( $source_post_id, $post_id );

		return $post_id;
	}

	/**
	 * Copy taxonomy terms, mapping each to its Polylang translation when available.
	 */
	protected static function syncTaxonomyTerms( int $source_post_id, int $target_post_id, string $post_type, string $target_lang ): void {
		$translatable_taxonomies = function_exists( 'pll_get_taxonomies' )
			? pll_get_taxonomies( array(), true )
			: array();

		$taxonomies = get_object_taxonomies( $post_type );

		$skip = array( 'language', 'term_language', 'post_translations', 'term_translations' );

		foreach ( $taxonomies as $taxonomy ) {
			if ( in_array( $taxonomy, $skip, true ) ) {
				continue;
			}

			$source_terms = wp_get_object_terms( $source_post_id, $taxonomy, array( 'fields' => 'ids' ) );

			if ( is_wp_error( $source_terms ) || empty( $source_terms ) ) {
				continue;
			}

			$target_term_ids = array();

			foreach ( $source_terms as $term_id ) {
				$term_id = (int) $term_id;

				if ( ! empty( $translatable_taxonomies ) && in_array( $taxonomy, $translatable_taxonomies, true ) && function_exists( 'pll_get_term' ) ) {
					$translated_term_id = (int) pll_get_term( $term_id, $target_lang );
					$target_term_ids[]  = $translated_term_id > 0 ? $translated_term_id : $term_id;
				} else {
					$target_term_ids[] = $term_id;
				}
			}

			if ( ! empty( $target_term_ids ) ) {
				wp_set_object_terms( $target_post_id, $target_term_ids, $taxonomy );
			}
		}
	}

	/**
	 * Copy all non-internal meta fields from source to target post.
	 */
	protected static function syncPostMeta( int $source_id, int $target_id ): void {
		$all_meta      = get_post_meta( $source_id );
		$skip_prefixes = array( '_edit_lock', '_edit_last', '_pll_', 'pll_', '_wp_old_slug' );

		foreach ( $all_meta as $key => $values ) {
			if ( $key === '_thumbnail_id' ) {
				continue;
			}

			$skip = false;
			foreach ( $skip_prefixes as $prefix ) {
				if ( strpos( $key, $prefix ) === 0 ) {
					$skip = true;
					break;
				}
			}
			if ( $skip ) {
				continue;
			}

			update_post_meta( $target_id, $key, maybe_unserialize( $values[0] ) );
		}
	}

	/**
	 * Save a translated term and link it via Polylang.
	 *
	 * @return int|\WP_Error
	 */
	public static function saveTermTranslation( int $source_term_id, string $taxonomy, string $target_lang, string $name, string $slug = '', string $description = '' ) {
		$source_term = get_term( $source_term_id, $taxonomy );
		if ( ! $source_term || is_wp_error( $source_term ) ) {
			return new \WP_Error( 'invalid_term', __( 'Source term not found.', 'deepseek-ai-provider' ) );
		}

		$existing_translations = function_exists( 'pll_get_term_translations' )
			? pll_get_term_translations( $source_term_id )
			: array();
		$existing_id = $existing_translations[ $target_lang ] ?? 0;

		$final_slug = ! empty( $slug )
			? sanitize_title( $slug )
			: sanitize_title( $name ) . '-' . $target_lang;

		$term_data = array(
			'description' => wp_kses_post( $description ?: $source_term->description ),
			'slug'        => $final_slug,
		);

		if ( $existing_id ) {
			$result  = wp_update_term( $existing_id, $taxonomy, $term_data );
			$term_id = $existing_id;
			$action  = 'updated';

			if ( is_wp_error( $result ) ) {
				return $result;
			}
		} else {
			$result = wp_insert_term( sanitize_text_field( $name ), $taxonomy, $term_data );

			if ( is_wp_error( $result ) ) {
				if ( $result->get_error_code() === 'term_exists' ) {
					$orphan_id = (int) $result->get_error_data();
					if ( ! $orphan_id ) {
						$existing_term = get_term_by( 'slug', $final_slug, $taxonomy );
						if ( ! $existing_term ) {
							$existing_term = get_term_by( 'name', $name, $taxonomy );
						}
						$orphan_id = $existing_term ? (int) $existing_term->term_id : 0;
					}

					if ( ! $orphan_id ) {
						return new \WP_Error( 'term_exists_unresolvable', 'Term exists but ID could not be determined.', array( 'status' => 409 ) );
					}

					wp_update_term( $orphan_id, $taxonomy, array_merge( $term_data, array( 'name' => $name ) ) );
					$term_id = $orphan_id;
					$action  = 'adopted';
				} else {
					return $result;
				}
			} else {
				$term_id = (int) $result['term_id'];
				$action  = 'created';
			}
		}

		if ( function_exists( 'pll_set_term_language' ) ) {
			pll_set_term_language( $term_id, $target_lang );
		}

		if ( function_exists( 'pll_get_term_translations' ) && function_exists( 'pll_save_term_translations' ) ) {
			global $wpdb;
			$lock_name = 'dsap_term_' . $source_term_id;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->get_var( $wpdb->prepare( "SELECT GET_LOCK(%s, %d)", $lock_name, 10 ) );

			try {
				clean_term_cache( $source_term_id, $taxonomy );
				clean_term_cache( $term_id, $taxonomy );

				$fresh = pll_get_term_translations( $source_term_id );
				$fresh[ $target_lang ] = $term_id;
				$source_lang = function_exists( 'pll_get_term_language' ) ? pll_get_term_language( $source_term_id ) : '';
				if ( $source_lang ) {
					$fresh[ $source_lang ] = $source_term_id;
				}
				pll_save_term_translations( $fresh );
			} finally {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->query( $wpdb->prepare( "SELECT RELEASE_LOCK(%s)", $lock_name ) );
			}
		}

		return $term_id;
	}

	/**
	 * Get posts that are missing translations for a given target language.
	 *
	 * @return array Array of post data with missing translations.
	 */
	public static function getUntranslatedPosts( string $post_type, string $target_lang, int $per_page = 50, int $page = 1 ): array {
		if ( ! self::isActive() || ! function_exists( 'pll_get_post_translations' ) ) {
			return array(
				'total'    => 0,
				'page'     => $page,
				'per_page' => $per_page,
				'items'    => array(),
			);
		}

		$all_langs = pll_languages_list();

		$batch_size   = 500;
		$post_offset  = 0;
		$results      = array();
		$seen         = array();

		while ( true ) {
			$post_ids = get_posts( array(
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => $batch_size,
				'offset'         => $post_offset,
				'lang'           => '',
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'fields'         => 'ids',
			) );

			if ( empty( $post_ids ) ) {
				break;
			}

			foreach ( $post_ids as $pid ) {
				$translations = pll_get_post_translations( $pid );

				// Deduplicate: only process the oldest post in each translation group
				$min_id = $pid;
				if ( ! empty( $translations ) ) {
					$valid_ids = array_filter( array_values( $translations ) );
					if ( ! empty( $valid_ids ) ) {
						$min_id = min( $valid_ids );
					}
				}
				if ( $pid != $min_id ) {
					continue;
				}
				if ( isset( $seen[ $min_id ] ) ) {
					continue;
				}
				$seen[ $min_id ] = true;

				$source_lang = pll_get_post_language( $pid );
				if ( empty( $source_lang ) ) {
					continue;
				}

				$check_langs = $target_lang ? array( $target_lang ) : $all_langs;
				$missing     = array();

				foreach ( $check_langs as $lang ) {
					if ( $lang === $source_lang ) {
						continue;
					}

					$trans_id = $translations[ $lang ] ?? 0;
					if ( $trans_id ) {
						$trans_post = get_post( $trans_id );
						if ( $trans_post && $trans_post->post_status === 'publish' ) {
							$has_content = ! empty( trim( $trans_post->post_content ) ) || ! empty( trim( $trans_post->post_title ) );
							if ( $has_content ) {
								continue;
							}
						}
					}

					$missing[] = $lang;
				}

				if ( ! empty( $missing ) ) {
					$post      = get_post( $pid );
					$results[] = array(
						'id'            => $post->ID,
						'title'         => $post->post_title,
						'post_type'     => $post->post_type,
						'source_lang'   => $source_lang,
						'missing_langs' => $missing,
					);
				}
			}

			$post_offset += count( $post_ids );
			if ( count( $post_ids ) < $batch_size ) {
				break;
			}
		}

		$offset = ( $page - 1 ) * $per_page;
		$total  = count( $results );
		$paged  = array_slice( $results, $offset, $per_page );

		return array(
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'items'    => $paged,
		);
	}

	/**
	 * Get terms missing translations.
	 */
	public static function getUntranslatedTerms( string $taxonomy, string $target_lang, int $per_page = 50, int $page = 1 ): array {
		if ( ! self::isActive() || ! function_exists( 'pll_get_term_translations' ) ) {
			return array(
				'total'    => 0,
				'page'     => $page,
				'per_page' => $per_page,
				'items'    => array(),
			);
		}

		$all_langs = pll_languages_list();

		$batch_size  = 500;
		$term_offset = 0;
		$results     = array();
		$seen        = array();

		while ( true ) {
			$term_ids = get_terms( array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'lang'       => '',
				'orderby'    => 'term_id',
				'order'      => 'ASC',
				'fields'     => 'ids',
				'number'     => $batch_size,
				'offset'     => $term_offset,
			) );

			if ( is_wp_error( $term_ids ) ) {
				break;
			}

			if ( empty( $term_ids ) ) {
				break;
			}

			foreach ( $term_ids as $tid ) {
				$translations = pll_get_term_translations( $tid );

				$min_id = $tid;
				if ( ! empty( $translations ) ) {
					$valid_ids = array_filter( array_values( $translations ) );
					if ( ! empty( $valid_ids ) ) {
						$min_id = min( $valid_ids );
					}
				}
				if ( $tid != $min_id ) {
					continue;
				}
				if ( isset( $seen[ $min_id ] ) ) {
					continue;
				}
				$seen[ $min_id ] = true;

				$source_lang = function_exists( 'pll_get_term_language' ) ? pll_get_term_language( $tid ) : '';
				if ( empty( $source_lang ) ) {
					continue;
				}

				$check_langs = $target_lang ? array( $target_lang ) : $all_langs;
				$missing     = array();

				foreach ( $check_langs as $lang ) {
					if ( $lang === $source_lang ) {
						continue;
					}

					$trans_id = $translations[ $lang ] ?? 0;
					if ( $trans_id ) {
						$trans_term = get_term( $trans_id, $taxonomy );
						if ( ! is_wp_error( $trans_term ) && ! empty( $trans_term ) ) {
							continue;
						}
					}

					$missing[] = $lang;
				}

				if ( ! empty( $missing ) ) {
					$term      = get_term( $tid, $taxonomy );
					$results[] = array(
						'term_id'       => $term->term_id,
						'name'          => $term->name,
						'slug'          => $term->slug,
						'taxonomy'      => $term->taxonomy,
						'description'   => $term->description,
						'source_lang'   => $source_lang,
						'missing_langs' => $missing,
					);
				}
			}

			$term_offset += count( $term_ids );
			if ( count( $term_ids ) < $batch_size ) {
				break;
			}
		}

		$offset = ( $page - 1 ) * $per_page;
		$total  = count( $results );
		$paged  = array_slice( $results, $offset, $per_page );

		return array(
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'items'    => $paged,
		);
	}
}
