/* global CPI, jQuery */
( function ( $ ) {
  'use strict';

  const state = {
    rows:       [],
    total:      0,
    offset:     0,
    importing:  false,
    stats:      { imported: 0, updated: 0, skipped: 0, errors: 0, images_assigned: 0, total_images: 0, disk_files_found: 0, dirs_found: 0, total_files_in_dir: 0, sample_files: [], expected_dir: '', dir_exists: false, sample_key: '' },
    messages:   { skipped: [], errors: [], missing_images: [] },
  };

  // ── DOM refs ──────────────────────────────────────────────────────────────
  const $form         = $( '#cpi-form' );
  const $dropzone     = $( '#cpi-dropzone' );
  const $fileInput    = $( '#cpi-file-input' );
  const $fileSelected = $( '#cpi-file-selected' );
  const $btnPreview   = $( '#cpi-btn-preview' );
  const $btnImport    = $( '#cpi-btn-import' );
  const $btnSyncImages       = $( '#cpi-btn-sync-images' );
  const $btnClear            = $( '#cpi-btn-clear' );
  const $btnPurgeOrphans     = $( '#cpi-btn-purge-orphans' );
  const $btnDeleteCategory    = $( '#cpi-btn-delete-category' );
  const $deleteCategorySelect = $( '#cpi-delete-category' );
  const $settingPostType      = $( '#cpi-setting-post-type' );
  const $settingTaxonomy      = $( '#cpi-setting-taxonomy' );
  const $settingTaxColumn     = $( '#cpi-setting-taxonomy-column' );
  const $btnSaveSettings      = $( '#cpi-btn-save-settings' );
  const $settingsStatus       = $( '#cpi-settings-status' );
  const $progressWrap = $( '#cpi-progress-wrap' );
  const $progressBar  = $( '#cpi-progress-bar' );
  const $progressText = $( '#cpi-progress-text' );
  const $progressPct  = $( '#cpi-progress-pct' );
  const $result       = $( '#cpi-result' );
  const $details      = $( '#cpi-import-details' );
  const $previewSec   = $( '#cpi-preview-section' );
  const $previewBody  = $( '#cpi-preview-body' );
  const $statImported       = $( '#stat-imported' );
  const $statUpdated        = $( '#stat-updated' );
  const $statSkipped        = $( '#stat-skipped' );
  const $statErrors         = $( '#stat-errors' );
  const $statImagesProducts = $( '#stat-images-products' );
  const $statImagesTotal    = $( '#stat-images-total' );

  // ── Drag & Drop ───────────────────────────────────────────────────────────
  $dropzone
    .on( 'click', () => $fileInput.trigger( 'click' ) )
    .on( 'dragover dragenter', e => {
      e.preventDefault();
      $dropzone.addClass( 'cpi-drag-over' );
    } )
    .on( 'dragleave drop', e => {
      e.preventDefault();
      $dropzone.removeClass( 'cpi-drag-over' );
      if ( e.type === 'drop' ) {
        const files = e.originalEvent.dataTransfer.files;
        if ( files && files.length ) setFiles( files );
      }
    } );

  $fileInput.on( 'change', function () {
    if ( this.files && this.files.length ) setFiles( this.files );
  } );

  // Selected files, split by role: one CSV, one images ZIP, plus loose images.
  const picked = { csv: null, zip: null, images: [] };

  function setFiles ( fileList ) {
    picked.csv    = null;
    picked.zip    = null;
    picked.images = [];

    Array.prototype.forEach.call( fileList, function ( f ) {
      const name = ( f.name || '' ).toLowerCase();

      if ( name.endsWith( '.csv' ) ) {
        if ( ! picked.csv ) picked.csv = f;
      } else if ( name.endsWith( '.zip' ) ) {
        if ( ! picked.zip ) picked.zip = f;
      } else if ( /\.(jpe?g|png|gif|webp|svg|avif)$/.test( name ) ) {
        picked.images.push( f );
      }
    } );

    renderSelected();
    hideResult();
    hideDetails();
    $previewSec.hide();
    state.rows   = [];
    state.total  = 0;
    state.offset = 0;
    resetStats();
  }

  function fileChip ( kind, text ) {
    const icons = {
      csv: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
      zip: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="15" x2="15" y2="15"/></svg>',
      img: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    };

    return '<span class="cpi-file-chip">' + ( icons[ kind ] || icons.csv ) + ' ' + escHtml( text ) + '</span>';
  }

  function renderSelected () {
    const chips = [];

    if ( picked.csv )  chips.push( fileChip( 'csv', picked.csv.name ) );
    if ( picked.zip )  chips.push( fileChip( 'zip', picked.zip.name ) );
    if ( picked.images.length ) {
      chips.push( fileChip( 'img', picked.images.length + ' image file' + ( picked.images.length > 1 ? 's' : '' ) ) );
    }

    if ( chips.length ) {
      $fileSelected.html( chips.join( '' ) ).css( 'display', 'flex' );
    } else {
      $fileSelected.hide().empty();
    }

    // A CSV, or a combined ZIP, is enough to start.
    $btnPreview.prop( 'disabled', ! ( picked.csv || picked.zip ) );
  }

  /**
   * Attach the selected files to a FormData payload.
   * A single ZIP is assumed to contain both the CSV and the images folder.
   */
  function appendFiles ( fd ) {
    if ( picked.csv ) {
      fd.append( 'csv_file', picked.csv );
    } else if ( picked.zip ) {
      fd.append( 'csv_file', picked.zip );
    }

    if ( picked.csv && picked.zip ) {
      fd.append( 'images_zip', picked.zip );
    }

    picked.images.forEach( function ( f ) {
      fd.append( 'images_files[]', f );
    } );
  }

  // ── Preview ───────────────────────────────────────────────────────────────
  $btnPreview.on( 'click', function () {
    if ( ! picked.csv && ! picked.zip ) return alert( 'Please select a CSV or ZIP file first.' );

    setBtnLoading( $btnPreview, CPI.i18n.previewing );

    const fd = new FormData();
    fd.append( 'action',   'cpi_preview_csv' );
    fd.append( 'security', CPI.security );
    appendFiles( fd );

    $.ajax( {
      url:         CPI.ajaxurl,
      type:        'POST',
      data:        fd,
      processData: false,
      contentType: false,
      success( res ) {
        clearBtnLoading( $btnPreview );

        if ( ! res.success ) {
          const msg = ( res.data && res.data.message ) ? res.data.message : JSON.stringify( res.data );
          showResult( 'error', 'Server error: ' + escHtml( msg ) );
          return;
        }

        const d = res.data;
        state.total = d.total;

        if ( d.errors && d.errors.length ) {
          showResult( 'error', 'Parse warnings:<br>' + d.errors.map( escHtml ).join( '<br>' ) );
        }

        renderPreview( d.preview, d.headers );
        $progressText.text( d.total + ' products ready to import' );
        $progressWrap.show();
        $progressBar.css( 'width', '0%' );
        $progressPct.text( '0%' );
        $btnImport.prop( 'disabled', d.total === 0 );
      },
      error( xhr, status, err ) {
        clearBtnLoading( $btnPreview );
        let detail = 'HTTP ' + xhr.status + ' — ' + escHtml( err );
        if ( xhr.responseText ) {
          // Strip any HTML tags for a cleaner message, show first 600 chars
          const plain = xhr.responseText.replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().substring( 0, 600 );
          detail += '<br><pre style="font-size:11px;white-space:pre-wrap;margin:8px 0 0;opacity:.8">' + escHtml( plain ) + '</pre>';
        }
        showResult( 'error', 'Request failed: ' + detail );
      },
    } );
  } );

  // ── Import ────────────────────────────────────────────────────────────────
  $btnImport.on( 'click', function () {
    if ( state.importing ) return;

    state.importing = true;
    state.offset    = 0;
    resetStats();
    hideResult();
    hideDetails();

    setBtnLoading( $btnImport, CPI.i18n.importing );
    $btnPreview.prop( 'disabled', true );
    $progressWrap.show();

    runBatch();
  } );

  function runBatch () {
    const duplicate  = $( '#cpi-duplicate' ).val();
    const postStatus = $( '#cpi-status' ).val();
    const productCategory  = $( '#cpi-product-category' ).val() || '';

    const fd = new FormData();
    fd.append( 'action',             'cpi_import_batch' );
    fd.append( 'security',           CPI.security );
    fd.append( 'duplicate',          duplicate );
    fd.append( 'post_status',        postStatus );
    fd.append( 'product_category',   productCategory );
    fd.append( 'offset',      state.offset );
    fd.append( 'batch_size',  CPI.batch_size );

    if ( state.offset === 0 ) {
      appendFiles( fd );
    }

    $.ajax( {
      url:         CPI.ajaxurl,
      type:        'POST',
      data:        fd,
      processData: false,
      contentType: false,
      success( res ) {
        if ( ! res.success ) {
          const msg = ( res.data && res.data.message ) ? res.data.message : JSON.stringify( res.data );
          finishImport( false, escHtml( msg ) );
          return;
        }

        const d = res.data;
        state.stats.imported        += d.stats.imported;
        state.stats.updated         += d.stats.updated;
        state.stats.skipped         += d.stats.skipped;
        state.stats.errors          += d.stats.error_count;
        state.stats.images_assigned += ( d.stats.images_assigned || 0 );
        state.stats.total_images    += ( d.stats.total_images    || 0 );
        state.stats.disk_files_found   += ( d.stats.disk_files_found || 0 );
        state.stats.dirs_found          = Math.max( state.stats.dirs_found || 0, d.stats.dirs_found || 0 );
        state.stats.total_files_in_dir  = Math.max( state.stats.total_files_in_dir || 0, d.stats.total_files_in_dir || 0 );
        if ( !state.stats.sample_files || !state.stats.sample_files.length ) {
          state.stats.sample_files = d.stats.sample_files || [];
        }
        state.stats.expected_dir = state.stats.expected_dir || d.stats.expected_dir || '';
        state.stats.dir_exists   = state.stats.dir_exists || d.stats.dir_exists || false;
        state.stats.sample_key   = state.stats.sample_key || d.stats.sample_key || '';
        if ( d.stats.missing_images && d.stats.missing_images.length ) {
          state.messages.missing_images = state.messages.missing_images.concat( d.stats.missing_images );
        }
        if ( d.stats.skipped_messages && d.stats.skipped_messages.length ) {
          state.messages.skipped = state.messages.skipped.concat( d.stats.skipped_messages );
        }
        if ( d.stats.errors && d.stats.errors.length ) {
          state.messages.errors = state.messages.errors.concat( d.stats.errors );
        }
        updateStatDisplay();
        renderDetails();

        const pct = d.total > 0 ? Math.round( ( d.done / d.total ) * 100 ) : 100;
        $progressBar.css( 'width', pct + '%' );
        $progressPct.text( pct + '%' );
        $progressText.text( d.done + ' / ' + d.total + ' processed' );

        if ( d.finished ) {
          finishImport( true );
        } else {
          state.offset = d.done;
          setTimeout( runBatch, 100 );
        }
      },
      error( xhr, status, err ) {
        let detail = 'HTTP ' + xhr.status + ' — ' + escHtml( err );
        if ( xhr.responseText ) {
          const plain = xhr.responseText.replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().substring( 0, 600 );
          detail += '<br><pre style="font-size:11px;white-space:pre-wrap;margin:8px 0 0;opacity:.8">' + escHtml( plain ) + '</pre>';
        }
        finishImport( false, detail );
      },
    } );
  }

  function finishImport ( success, errorMsg ) {
    state.importing = false;
    clearBtnLoading( $btnImport );
    $btnPreview.prop( 'disabled', false );

    if ( success ) {
      const s = state.stats;
      let diskMsg = '';
      if ( s.disk_files_found > 0 ) {
        diskMsg = '<br>Files found on disk: <strong>' + s.disk_files_found + '</strong>';
      } else {
        const expectedDir = s.expected_dir || 'wp-content/uploads/cpi-imports/images/';
        const dirInfo = s.dirs_found > 0
          ? ' (scanned ' + s.total_files_in_dir + ' image files in ' + s.dirs_found + ' director' + (s.dirs_found > 1 ? 'ies' : 'y') + ')'
          : ' (image directory not found — expected at <code>' + escHtml(expectedDir) + '</code>, dir_exists=' + (s.dir_exists ? 'true' : 'false') + ')';
        const sampleInfo = s.sample_files && s.sample_files.length
          ? '<br>Sample files found: <code>' + s.sample_files.map(escHtml).join('</code>, <code>') + '</code>'
          : '';
        const keyInfo = s.sample_key ? '<br>First product MPN tried: <code>' + escHtml(s.sample_key) + '</code>' : '';
        diskMsg = '<br><span style="color:#d97706">⚠ No matching files found on disk.' + dirInfo + '</span>' + sampleInfo + keyInfo;
        diskMsg += '<br><small style="color:#9ca3af">Filenames must start with the <code>product_mpn</code> value, e.g. <code>TQB1-0002(1).jpg</code> for MPN <code>TQB1-0002</code></small>';
      }
      showResult( 'success',
        '<strong>Import complete!</strong><br>' +
        'Imported: <strong>' + s.imported + '</strong> &nbsp;·&nbsp; ' +
        'Updated: <strong>' + s.updated + '</strong> &nbsp;·&nbsp; ' +
        'Skipped: <strong>' + s.skipped + '</strong> &nbsp;·&nbsp; ' +
        'Errors: <strong>' + s.errors + '</strong><br>' +
        'Products with images: <strong>' + s.images_assigned + '</strong> &nbsp;·&nbsp; ' +
        'Total images assigned: <strong>' + s.total_images + '</strong>' +
        diskMsg
      );
    } else {
      showResult( 'error', errorMsg || CPI.i18n.error );
    }
  }

  function updateDeleteCategoryButtonState () {
    if ( ! $btnDeleteCategory.length ) {
      return;
    }
    $btnDeleteCategory.prop( 'disabled', !$deleteCategorySelect.val() );
  }

  // ── Delete by category ────────────────────────────────────────────────────
  if ( $deleteCategorySelect.length ) {
    $deleteCategorySelect.on( 'change', updateDeleteCategoryButtonState );

    $btnDeleteCategory.on( 'click', function () {
      const termId   = $deleteCategorySelect.val();
      const termName = $deleteCategorySelect.find( 'option:selected' ).text().trim();

      if ( ! termId ) {
        alert( CPI.i18n.select_category );
        return;
      }

      const msg = ( CPI.i18n.confirm_delete_category || 'Delete all products in "%s"?' )
        .replace( '%s', termName );

      if ( ! confirm( msg ) ) {
        return;
      }

      const deleteState = { deleted: 0, total: 0, firstBatch: true };

      setBtnLoading( $btnDeleteCategory, CPI.i18n.deleting_category || 'Deleting…' );
      $btnClear.prop( 'disabled', true );
      $progressWrap.show();
      $progressBar.css( 'width', '0%' );
      $progressPct.text( '0%' );

      function runDeleteBatch () {
        $.post( CPI.ajaxurl, {
          action:      'cpi_delete_products_by_category',
          security:    CPI.security,
          term_id:     termId,
          batch_size:  CPI.batch_size,
          reset_total: deleteState.firstBatch ? 1 : 0,
        }, function ( res ) {
          deleteState.firstBatch = false;
          if ( ! res.success ) {
            finishCategoryDelete( false, ( res.data && res.data.message ) ? res.data.message : CPI.i18n.error );
            return;
          }

          const d = res.data;
          if ( deleteState.total === 0 && d.total ) {
            deleteState.total = d.total;
          }
          deleteState.deleted += d.deleted || 0;

          const total = deleteState.total || deleteState.deleted;
          const pct   = total > 0 ? Math.min( 100, Math.round( ( deleteState.deleted / total ) * 100 ) ) : 100;
          $progressBar.css( 'width', pct + '%' );
          $progressPct.text( pct + '%' );
          $progressText.text( deleteState.deleted + ' / ' + total + ' deleted' );

          if ( d.finished ) {
            const successMsg = 'Deleted <strong>' + deleteState.deleted + '</strong> products in <strong>' +
              escHtml( d.term_name || termName ) + '</strong>.';
            finishCategoryDelete( true, successMsg );
          } else {
            setTimeout( runDeleteBatch, 100 );
          }
        } ).fail( function ( xhr, status, err ) {
          finishCategoryDelete( false, 'HTTP ' + xhr.status + ' — ' + escHtml( err ) );
        } );
      }

      function finishCategoryDelete ( success, message ) {
        clearBtnLoading( $btnDeleteCategory );
        $btnClear.prop( 'disabled', false );
        if ( success ) {
          showResult( 'success', message );
          resetStats();
        } else {
          showResult( 'error', escHtml( message ) );
        }
      }

      hideResult();
      runDeleteBatch();
    } );

    updateDeleteCategoryButtonState();
  }

  // ── Import target settings (post type / taxonomy) ─────────────────────────
  if ( $btnSaveSettings.length ) {
    function filterTaxonomies () {
      const postType = String( $settingPostType.val() || '' );
      let firstMatch = '';

      $settingTaxonomy.find( 'option' ).each( function () {
        const $opt  = $( this );
        const types = ( $opt.attr( 'data-post-types' ) || '' ).split( ',' ).filter( Boolean );

        // "Disabled" and site-wide taxonomies stay available for every post type.
        if ( ! $opt.val() || types.length === 0 ) {
          return;
        }

        const match = types.indexOf( postType ) !== -1;
        $opt.prop( 'disabled', !match ).prop( 'hidden', !match );

        if ( match && ! firstMatch ) {
          firstMatch = String( $opt.val() );
        }
      } );

      // Never leave a taxonomy selected that is not attached to the post type.
      const current = String( $settingTaxonomy.val() || '' );
      if ( current && $settingTaxonomy.find( 'option' ).filter( function () {
        return String( $( this ).val() ) === current;
      } ).prop( 'disabled' ) ) {
        $settingTaxonomy.val( firstMatch );
      }
    }

    $settingPostType.on( 'change', filterTaxonomies );
    filterTaxonomies();

    $btnSaveSettings.on( 'click', function () {
      setBtnLoading( $btnSaveSettings, CPI.i18n.saving_settings || 'Saving…' );
      $settingsStatus.text( '' );

      $.post( CPI.ajaxurl, {
        action:          'cpi_save_settings',
        security:        CPI.security,
        post_type:       $settingPostType.val(),
        taxonomy:        $settingTaxonomy.val(),
        taxonomy_column: $settingTaxColumn.val(),
      }, function ( res ) {
        if ( res && res.success ) {
          $settingsStatus.text( ( res.data && res.data.message ) || CPI.i18n.settings_saved || 'Saved.' );
          // Reload so the category dropdown, danger zone and column reference all refresh.
          setTimeout( function () { window.location.reload(); }, 700 );
          return;
        }

        clearBtnLoading( $btnSaveSettings );
        $settingsStatus.text( ( res && res.data && res.data.message ) ? res.data.message : CPI.i18n.error );
      } ).fail( function ( xhr ) {
        clearBtnLoading( $btnSaveSettings );
        $settingsStatus.text( CPI.i18n.error + ' (HTTP ' + xhr.status + ')' );
      } );
    } );
  }

  // ── Purge ghost media ─────────────────────────────────────────────────────
  $btnPurgeOrphans.on( 'click', function () {
    if ( ! confirm( CPI.i18n.confirm_purge_orphans ) ) return;

    const purgeState = { deleted: 0, skipped: 0, total: 0, lastId: 0, firstBatch: true };

    setBtnLoading( $btnPurgeOrphans, CPI.i18n.purging_orphans || 'Scanning media…' );
    $btnClear.prop( 'disabled', true );
    $progressWrap.show();
    $progressBar.css( 'width', '0%' );
    $progressPct.text( '0%' );
    $progressText.text( '' );
    hideResult();

    function runPurgeBatch () {
      $.post( CPI.ajaxurl, {
        action:     'cpi_purge_orphan_attachments',
        security:   CPI.security,
        batch_size: 100,
        last_id:    purgeState.lastId,
      }, function ( res ) {
        if ( ! res.success ) {
          finishPurge( false, ( res.data && res.data.message ) ? res.data.message : CPI.i18n.error );
          return;
        }

        const d = res.data;

        if ( purgeState.firstBatch && d.total ) {
          purgeState.total = d.total;
          purgeState.firstBatch = false;
        }

        purgeState.deleted += d.deleted || 0;
        purgeState.skipped += d.skipped || 0;
        purgeState.lastId   = d.last_id  || purgeState.lastId;

        const processed = purgeState.deleted + purgeState.skipped;
        const total     = purgeState.total || processed;
        const pct       = total > 0 ? Math.min( 100, Math.round( ( processed / total ) * 100 ) ) : 100;

        $progressBar.css( 'width', pct + '%' );
        $progressPct.text( pct + '%' );
        $progressText.text( 'Checked ' + processed + ' / ' + total + ' · Deleted ' + purgeState.deleted );

        if ( d.finished ) {
          const msg = 'Removed <strong>' + purgeState.deleted + '</strong> ghost attachment' +
            ( purgeState.deleted !== 1 ? 's' : '' ) + '. ' +
            '<span style="opacity:.7">(' + purgeState.skipped + ' had valid files and were kept.)</span>';
          finishPurge( true, msg );
        } else {
          setTimeout( runPurgeBatch, 100 );
        }
      } ).fail( function ( xhr, status, err ) {
        finishPurge( false, 'HTTP ' + xhr.status + ' — ' + escHtml( err ) );
      } );
    }

    function finishPurge ( success, message ) {
      clearBtnLoading( $btnPurgeOrphans );
      $btnClear.prop( 'disabled', false );
      if ( success ) {
        showResult( 'success', message );
      } else {
        showResult( 'error', escHtml( message ) );
      }
    }

    runPurgeBatch();
  } );

  // ── Sync Product Images ───────────────────────────────────────────────────
  if ( $btnSyncImages.length ) {
    $btnSyncImages.on( 'click', function () {
      setBtnLoading( $btnSyncImages, CPI.i18n.syncing_images || 'Syncing images…' );
      hideResult();

      $.post( CPI.ajaxurl, { action: 'cpi_sync_images', security: CPI.security }, function ( res ) {
        clearBtnLoading( $btnSyncImages );
        if ( res.success ) {
          const d = res.data;
          showResult( 'success', 'Image sync complete! Checked <strong>' + d.total + '</strong> products and synced images.' );
        } else {
          const msg = ( res.data && res.data.message ) ? res.data.message : JSON.stringify( res.data );
          showResult( 'error', escHtml( msg ) );
        }
      } ).fail( function ( xhr, status, err ) {
        clearBtnLoading( $btnSyncImages );
        showResult( 'error', 'HTTP ' + xhr.status + ' — ' + escHtml( err ) );
      } );
    } );
  }

  // ── Clear ─────────────────────────────────────────────────────────────────
  $btnClear.on( 'click', function () {
    if ( ! confirm( CPI.i18n.confirm_clear ) ) return;

    setBtnLoading( $btnClear, 'Deleting…' );

    $.post( CPI.ajaxurl, { action: 'cpi_clear_products', security: CPI.security }, function ( res ) {
      clearBtnLoading( $btnClear );
      if ( res.success ) {
        showResult( 'success', 'Deleted <strong>' + res.data.deleted + '</strong> products.' );
        resetStats();
      } else {
        const msg = ( res.data && res.data.message ) ? res.data.message : JSON.stringify( res.data );
        showResult( 'error', escHtml( msg ) );
      }
    } ).fail( function ( xhr, status, err ) {
      clearBtnLoading( $btnClear );
      showResult( 'error', 'HTTP ' + xhr.status + ' — ' + escHtml( err ) );
    } );
  } );

  // ── Preview table render ──────────────────────────────────────────────────
  function renderPreview ( rows, headers ) {
    if ( ! rows || rows.length === 0 ) return;

    var cols = [ '_generated_title' ].concat( headers );

    var labels = CPI.column_labels || {};

    var thead = '<tr>';
    cols.forEach( function ( c ) {
      thead += '<th>' + escHtml( labels[ c ] || c ) + '</th>';
    } );
    thead += '</tr>';

    let tbody = '';
    rows.forEach( function( row ) {
      tbody += '<tr>';
      cols.forEach( function( c ) {
        const val  = ( ( row[c] || '' ) + '' ).replace( /\n/g, ', ' ).substring( 0, 80 );
        const cls  = c === '_generated_title' ? ' class="title-col"' : '';
        const full = escHtml( ( row[c] || '' ) + '' );
        tbody += '<td' + cls + ' title="' + full + '">' + escHtml( val ) + '</td>';
      } );
      tbody += '</tr>';
    } );

    $previewBody.html( tbody );
    $( '#cpi-preview-thead' ).html( thead );
    $previewSec.show();
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function setBtnLoading ( $btn, text ) {
    $btn.prop( 'disabled', true )
        .data( 'orig-html', $btn.html() )
        .html( '<span class="cpi-spinner"></span> ' + escHtml( text ) );
  }

  function clearBtnLoading ( $btn ) {
    var orig = $btn.data( 'orig-html' );
    $btn.prop( 'disabled', false ).html( orig || '' );
  }

  function showResult ( type, html ) {
    $result.removeClass( 'success error' ).addClass( type ).html( html ).show();
  }

  function hideResult () { $result.hide(); }

  function hideDetails () {
    $details.hide().empty();
  }

  function resetStats () {
    state.stats = { imported: 0, updated: 0, skipped: 0, errors: 0, images_assigned: 0, total_images: 0, disk_files_found: 0, dirs_found: 0, total_files_in_dir: 0, sample_files: [], expected_dir: '', dir_exists: false, sample_key: '' };
    state.messages = { skipped: [], errors: [], missing_images: [] };
    updateStatDisplay();
  }

  function updateStatDisplay () {
    $statImported.text( state.stats.imported );
    $statUpdated.text( state.stats.updated );
    $statSkipped.text( state.stats.skipped );
    $statErrors.text( state.stats.errors );
    $statImagesProducts.text( state.stats.images_assigned );
    $statImagesTotal.text( state.stats.total_images );
  }

  function escHtml ( str ) {
    return String( str )
      .replace( /&/g, '&amp;' )
      .replace( /</g, '&lt;' )
      .replace( />/g, '&gt;' )
      .replace( /"/g, '&quot;' );
  }

  function renderDetails () {
    const parts = [];

    if ( state.messages.skipped.length ) {
      parts.push(
        '<h3>Skipped Rows</h3><ul>' +
        state.messages.skipped.map( function ( msg ) {
          return '<li>' + escHtml( msg ) + '</li>';
        } ).join( '' ) +
        '</ul>'
      );
    }

    if ( state.messages.errors.length ) {
      parts.push(
        '<h3>Error Rows</h3><ul>' +
        state.messages.errors.map( function ( msg ) {
          return '<li>' + escHtml( msg ) + '</li>';
        } ).join( '' ) +
        '</ul>'
      );
    }

    if ( state.messages.missing_images.length ) {
      parts.push(
        '<h3>⚠ Products Missing Images</h3>' +
        '<p style="font-size:12px;color:var(--cpi-text-muted);margin-bottom:8px">Files were found on disk but could not be matched — the attachments may need to be re-registered.</p>' +
        '<ul>' +
        state.messages.missing_images.map( function ( msg ) {
          return '<li>' + escHtml( msg ) + '</li>';
        } ).join( '' ) +
        '</ul>'
      );
    }

    if ( parts.length ) {
      $details.removeClass( 'success' ).addClass( 'error' ).html( parts.join( '' ) ).show();
    } else {
      hideDetails();
    }
  }

} )( jQuery );
