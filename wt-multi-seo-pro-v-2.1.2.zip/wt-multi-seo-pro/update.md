# WT Multi SEO Pro — Update log

This file records notable plugin changes. New entries go at the top.

---

## Unreleased

### Admin: refresh sitemap routing + Polylang-off safety

**Files:** `admin/class-plseo-admin.php`, `admin/views/settings-sitemap.php`, `includes/class-plseo-sitemap.php`, `includes/class-plseo-robots.php`

- **WT SEO Pro → Sitemap:** New **“Refresh sitemap & permalinks”** button flushes rewrite rules, updates `plseo_rewrite_version`, and turns off `plseo_sitemap_per_language` when Polylang is not active (stale option caused `/sitemap-th-product.xml`-style links in the index that 404 after Polylang is removed).
- **`PLSEO_Sitemap::refresh_sitemap_routing()`** centralizes that logic; **Tools → Flush Rewrite Rules** now calls it too.
- **Sitemap `Cache-Control`:** Responses use `private, no-cache, must-revalidate, max-age=0` so CDNs are less likely to serve an old sitemap body for hours (purge may still be required on aggressive caches).
- **Index / robots:** Per-language sitemap entries and robots.txt `Sitemap:` lines for `sitemap-{lang}-*` only apply when Polylang is active **and** per-language sitemaps are enabled.

### Sitemap reliability (Google Search Console, large catalogs)

**Files:** `includes/class-plseo-sitemap.php`, `includes/class-plseo-activator.php`, `includes/class-plseo-robots.php`

#### `class-plseo-sitemap.php`

- **Output buffers:** Before serving any sitemap response, all active output buffers are discarded so stray PHP notices, BOM, or whitespace from other plugins/themes cannot appear before the XML declaration (which would make the document invalid and can lead to “0 pages discovered” in Google Search Console).
- **Resource limits:** Calls `wp_raise_memory_limit( 'admin' )` when available and raises `set_time_limit` to 300 seconds so very large product sitemaps are less likely to truncate mid-response.
- **Removed `nocache_headers()`** on sitemap requests to avoid mixing no-cache directives (`Pragma`, `Expires: 1984`) with later `Cache-Control: public, max-age=3600`, which can confuse proxies/CDNs.
- **`send_xml_headers()`**
  - Sends explicit HTTP `200` via `status_header( 200 )`.
  - Keeps `Content-Type: application/xml; charset=UTF-8` and `Cache-Control: public, max-age=3600`.
  - Removes `Pragma`, `Expires`, and `X-Robots-Tag` headers so earlier WordPress/plugin headers do not conflict. Sitemaps should not use `X-Robots-Tag: noindex` per Google guidance.
- **`maybe_flush()` + `REWRITE_VERSION`:** Rewrite rule freshness is now tracked via a `plseo_rewrite_version` option compared against the `REWRITE_VERSION` class constant (currently `'2'`). On the **very first page load** after deploying new code to production, the version mismatch triggers `flush_rewrite_rules()` automatically — no manual "Save Permalinks" needed. This replaces the old approach that only checked whether specific regex keys existed in the `rewrite_rules` option (which was fragile across plugin updates and could leave stale rules in the DB indefinitely).

#### `class-plseo-activator.php`

- **Activation rewrite rules aligned with runtime:** On plugin activation, registers the same rules as the live `PLSEO_Sitemap` class:
  - `sitemap-xsl.xsl`
  - Paginated pattern `^sitemap-([a-z0-9_-]+?)(?:-(\d+))?\.xml$` mapping to `plseo_sitemap` and `plseo_sitemap_page`
  - `add_rewrite_tag` for both `%plseo_sitemap%` and `%plseo_sitemap_page%`
- Previously, activation only added a non-paginated `sitemap-*.xml` rule, which could leave the database with rules that did not support paginated product/post sitemaps until permalinks were saved again.
- Activation now also stores `plseo_rewrite_version` so the runtime `maybe_flush()` knows the DB is current and does not re-flush on every page load.

#### `class-plseo-robots.php`

- **Per-language `Sitemap:` lines in robots.txt:** When “per-language sitemaps” is enabled, non-default Polylang languages are listed in `robots.txt`. The **default** language is skipped, because those URLs are already covered by the main sitemaps (`sitemap-posts.xml`, `sitemap-product.xml`, etc.), avoiding duplicate `Sitemap:` declarations for the same content.

#### Post-deploy checklist (site operators)

1. Rewrite rules flush automatically on the first page load after code update (version-based). Manual "Settings → Permalinks → Save" is only needed as a fallback if the automatic flush was blocked by an object-cache or full-page-cache layer.
2. **Purge any server/CDN cache** (LiteSpeed, Cloudflare, Nginx FastCGI, etc.) for sitemap URLs so the new paginated XML is served instead of a stale cached copy.
3. Re-submit `sitemap.xml` in Google Search Console and allow time for recrawl.

---

*End of documented updates.*
