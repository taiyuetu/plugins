<?php
/**
 * Main plugin class.
 *
 * @package NuclearReset
 */

namespace NuclearReset;

defined( 'ABSPATH' ) || exit;

/**
 * Class Plugin
 *
 * Bootstraps all sub-components and registers hooks.
 */
final class Plugin {

    /** @var self|null Singleton instance. */
    private static ?self $instance = null;

    /** Private constructor — use get_instance(). */
    private function __construct() {
        $this->load_textdomain();
        $this->register_hooks();
    }

    /**
     * Return (and lazily create) the singleton.
     */
    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Load plugin translations.
     */
    private function load_textdomain(): void {
        load_plugin_textdomain(
            'nuclear-reset',
            false,
            dirname( NUCLEAR_RESET_BASENAME ) . '/languages'
        );
    }

    /**
     * Register all WordPress hooks.
     */
    private function register_hooks(): void {
        // Repair broken role caps after a bad reset (admin bar works, wp-admin does not).
        add_action( 'init', [ $this, 'maybe_repair_roles' ], 0 );

        // Admin UI
        $admin = new Admin\Page();
        add_action( 'admin_menu',             [ $admin, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts',  [ $admin, 'enqueue_assets' ] );

        // AJAX handler (admin-only, nonce-protected)
        $handler = new Ajax\ResetHandler();
        add_action( 'wp_ajax_nuclear_reset_execute', [ $handler, 'handle' ] );

        // Plugin action link
        add_filter( 'plugin_action_links_' . NUCLEAR_RESET_BASENAME, [ $this, 'action_links' ] );
    }

    /**
     * If {prefix}user_roles is missing or has an empty administrator capability
     * map, rebuild it. This recovers sites left unable to open /wp-admin/ after
     * an older Nuclear Reset run, as soon as the fixed plugin is deployed.
     */
    public function maybe_repair_roles(): void {
        global $wpdb, $wp_roles;

        $roles_key = $wpdb->get_blog_prefix() . 'user_roles';
        $roles     = get_option( $roles_key );

        if ( is_array( $roles ) && ! empty( $roles['administrator']['capabilities'] ) ) {
            return;
        }

        if ( ! function_exists( 'populate_roles' ) ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            if ( ! function_exists( 'populate_roles' ) ) {
                ob_start();
                require_once ABSPATH . 'wp-admin/includes/schema.php';
                ob_end_clean();
            }
        }

        if ( ! function_exists( 'populate_roles' ) ) {
            return;
        }

        populate_roles();

        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        } else {
            $wp_roles->for_site( get_current_blog_id() );
        }
    }

    /**
     * Add a quick "Settings" link on the Plugins screen.
     *
     * @param string[] $links Existing action links.
     * @return string[]
     */
    public function action_links( array $links ): array {
        $url  = admin_url( 'tools.php?page=nuclear-reset' );
        $link = sprintf(
            '<a href="%s" style="color:#c9302c;font-weight:700;">%s</a>',
            esc_url( $url ),
            esc_html__( 'Launch', 'nuclear-reset' )
        );
        array_unshift( $links, $link );
        return $links;
    }
}
