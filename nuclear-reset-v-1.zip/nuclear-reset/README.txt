=== Nuclear Reset ===
Contributors:       yourname
Tags:               reset, database, development, staging, tools
Requires at least:  6.0
Tested up to:       6.7
Requires PHP:       8.0
Stable tag:         1.0.0
License:            GPL-2.0-or-later
License URI:        https://www.gnu.org/licenses/gpl-2.0.html

Restore WordPress to its original out-of-the-box state with a single click.

== Description ==

**Nuclear Reset** gives administrators a safe, confirmed, UI-driven way to wipe a WordPress site back to factory defaults. It is designed for **development and staging environments** where you need to iterate quickly.

**What it does:**

* 🗑️ **Deletes all content** — posts, pages, custom post types, media records, comments, terms, and non-admin users
* 🗄️ **Resets the database** — drops all plugin/custom tables, truncates core tables, and re-seeds WordPress defaults (Hello World, Sample Page, default categories)
* 🔌 **Deactivates all plugins** — every plugin except Nuclear Reset itself is deactivated (files are not deleted)
* 🎨 **Activates the default theme** — switches to the newest bundled WordPress default theme (Twenty Twenty-Five and below)
* ⚙️ **Resets site options** — clears widgets, menus, transients, and rewrite rules; preserves site URL, title, and admin credentials

**Safety features:**

* Requires typing `RESET` in a confirmation field before the button is enabled
* Two-step confirmation (typed phrase + browser `confirm()` dialog)
* Current administrator account and credentials are always preserved
* `wp-config.php` and uploaded/plugin files are never touched
* Granular checkboxes — choose exactly which steps to run
* Full colour-coded log output after every reset

== Installation ==

1. Upload the `nuclear-reset` folder to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** screen
3. Navigate to **Tools → Nuclear Reset**

⚠️ **Only install on development or staging sites. Never on production.**

== Frequently Asked Questions ==

= Will this delete my theme or plugin files? =
No. Only database records are modified. Your uploaded files, theme folders, and plugin folders are untouched.

= Can I undo a reset? =
No. There is no undo. Take a full backup before running this tool.

= What happens to my admin account? =
Your current administrator account is always preserved, including its username, password, and email.

= Is this safe for production? =
**No.** This plugin is intended exclusively for local, development, and staging environments.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
