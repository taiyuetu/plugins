<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles AJAX requests for CSV preview and batch import.
 */
class CPI_Ajax {

    public static function hooks(): void {
        add_action( 'wp_ajax_cpi_preview_csv',           [ __CLASS__, 'preview_csv' ] );
        add_action( 'wp_ajax_cpi_import_batch',          [ __CLASS__, 'import_batch' ] );
        add_action( 'wp_ajax_cpi_clear_products',                 [ __CLASS__, 'clear_products' ] );
        add_action( 'wp_ajax_cpi_get_category_options',           [ __CLASS__, 'get_category_options' ] );
        add_action( 'wp_ajax_cpi_delete_products_by_category',    [ __CLASS__, 'delete_products_by_category' ] );
        add_action( 'wp_ajax_cpi_purge_orphan_attachments',       [ __CLASS__, 'purge_orphan_attachments' ] );
    }

    // ------------------------------------------------------------------ //
    //  Preview                                                             //
    // ------------------------------------------------------------------ //

    public static function preview_csv(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $file_path = self::get_uploaded_file();
            $parsed    = CPI_CSV_Parser::parse( $file_path );

            wp_send_json_success( [
                'total'   => count( $parsed['rows'] ),
                'errors'  => $parsed['errors'],
                'preview' => array_slice( $parsed['rows'], 0, 10 ),
                'headers' => $parsed['headers'],
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() . ' (line ' . $e->getLine() . ' in ' . basename( $e->getFile() ) . ')' ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Batch Import                                                        //
    // ------------------------------------------------------------------ //

    public static function import_batch(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $duplicate         = sanitize_text_field( $_POST['duplicate']   ?? 'skip' );
            $post_status       = sanitize_text_field( $_POST['post_status'] ?? 'publish' );
            $default_term_id   = (int) ( $_POST['product_category'] ?? 0 );
            $offset            = (int) ( $_POST['offset']     ?? 0 );
            $batch_size        = (int) ( $_POST['batch_size'] ?? 50 );

            $transient_key = 'cpi_import_' . get_current_user_id();
            $rows = get_transient( $transient_key );

            if ( false === $rows ) {
                $file_path = self::get_uploaded_file();
                $parsed    = CPI_CSV_Parser::parse( $file_path );

                if ( ! empty( $parsed['errors'] ) && empty( $parsed['rows'] ) ) {
                    wp_send_json_error( [ 'message' => implode( ' | ', $parsed['errors'] ) ] );
                }

                $rows = $parsed['rows'];
                set_transient( $transient_key, $rows, HOUR_IN_SECONDS );
            }

            $stats = CPI_Importer::import_batch(
                $rows,
                $duplicate,
                $post_status,
                $offset,
                $batch_size,
                $default_term_id
            );
            $total = count( $rows );
            $done  = min( $offset + $batch_size, $total );

            if ( $done >= $total ) {
                delete_transient( $transient_key );
            }

            wp_send_json_success( [
                'stats'    => $stats,
                'total'    => $total,
                'done'     => $done,
                'finished' => $done >= $total,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() . ' (line ' . $e->getLine() . ' in ' . basename( $e->getFile() ) . ')' ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Category options (Polylang language filter)                         //
    // ------------------------------------------------------------------ //

    public static function get_category_options(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $options = CPI_Config::get_taxonomy_term_options();

        wp_send_json_success( [ 'options' => $options ] );
    }

    // ------------------------------------------------------------------ //
    //  Clear Products                                                      //
    // ------------------------------------------------------------------ //

    public static function clear_products(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $posts = get_posts( [
                'post_type'      => CPI_Config::POST_TYPE,
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ] );

            $deleted = 0;
            foreach ( $posts as $id ) {
                if ( self::delete_product_with_images( $id ) ) {
                    $deleted++;
                }
            }

            wp_send_json_success( [ 'deleted' => $deleted ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    /**
     * Delete products assigned to a product_category term (batched).
     */
    public static function delete_products_by_category(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        if ( ! CPI_Config::taxonomy_enabled() ) {
            wp_send_json_error( [ 'message' => __( 'Product category taxonomy is not available.', 'csv-product-importer' ) ] );
        }

        $term_id    = (int) ( $_POST['term_id'] ?? 0 );
        $batch_size = max( 1, min( 100, (int) ( $_POST['batch_size'] ?? 50 ) ) );

        if ( $term_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Please select a product category.', 'csv-product-importer' ) ] );
        }

        $term = get_term( $term_id, CPI_Config::TAXONOMY );
        if ( ! $term || is_wp_error( $term ) ) {
            wp_send_json_error( [ 'message' => __( 'Category not found.', 'csv-product-importer' ) ] );
        }

        try {
            $tax_query = [ [
                'taxonomy'         => CPI_Config::TAXONOMY,
                'field'            => 'term_id',
                'terms'            => $term_id,
                'include_children' => true,
            ] ];

            $count_key = 'cpi_delete_cat_total_' . get_current_user_id() . '_' . $term_id;

            if ( ! empty( $_POST['reset_total'] ) ) {
                delete_transient( $count_key );
            }

            $total = (int) get_transient( $count_key );

            if ( ! $total ) {
                $count_query = new WP_Query( self::products_in_category_query_args(
                    $tax_query,
                    1,
                    false
                ) );
                $total = (int) $count_query->found_posts;
                set_transient( $count_key, $total, HOUR_IN_SECONDS );
            }

            $query_args = self::products_in_category_query_args( $tax_query, $batch_size, true );
            $query      = new WP_Query( $query_args );

            $deleted = 0;
            foreach ( $query->posts as $post_id ) {
                if ( self::delete_product_with_images( (int) $post_id ) ) {
                    $deleted++;
                }
            }

            $remaining = max( 0, $total - $deleted );
            if ( $remaining > 0 && $deleted > 0 ) {
                set_transient( $count_key, $remaining, HOUR_IN_SECONDS );
            } else {
                delete_transient( $count_key );
            }

            $finished = $deleted < $batch_size || $remaining <= 0;

            wp_send_json_success( [
                'deleted'   => $deleted,
                'total'     => $total,
                'remaining' => $finished ? 0 : $remaining,
                'finished'  => $finished,
                'term_name' => $term->name,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    /**
     * WP_Query args for products in a category.
     *
     * @param array $tax_query
     * @param int   $posts_per_page
     * @param bool  $no_found_rows
     * @return array<string, mixed>
     */
    private static function products_in_category_query_args(
        array $tax_query,
        int $posts_per_page,
        bool $no_found_rows
    ): array {
        return [
            'post_type'      => CPI_Config::POST_TYPE,
            'post_status'    => 'any',
            'posts_per_page' => $posts_per_page,
            'fields'         => 'ids',
            'no_found_rows'  => $no_found_rows,
            'tax_query'      => $tax_query,
        ];
    }

    /**
     * Purge unattached image attachments whose physical file is missing from disk.
     *
     * Only attachment posts with post_parent = 0 (unattached to any other post) and a
     * missing file are removed. Attachments whose file still exists are left untouched.
     * Runs in cursor-based batches so it is safe for large media libraries.
     */
    public static function purge_orphan_attachments(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        $batch_size = max( 1, min( 200, (int) ( $_POST['batch_size'] ?? 100 ) ) );
        $last_id    = max( 0, (int) ( $_POST['last_id']    ?? 0 ) );

        try {
            global $wpdb;

            $count_key = 'cpi_orphan_total_' . get_current_user_id();

            if ( 0 === $last_id ) {
                delete_transient( $count_key );
            }

            $total = (int) get_transient( $count_key );

            if ( ! $total && 0 === $last_id ) {
                $total = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts}
                     WHERE post_type   = 'attachment'
                       AND post_parent = 0
                       AND post_mime_type LIKE %s",
                    'image/%'
                ) );
                set_transient( $count_key, max( 1, $total ), HOUR_IN_SECONDS );
            }

            $ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_type   = 'attachment'
                   AND post_parent = 0
                   AND post_mime_type LIKE %s
                   AND ID > %d
                 ORDER BY ID ASC
                 LIMIT %d",
                'image/%',
                $last_id,
                $batch_size
            ) );

            $deleted  = 0;
            $skipped  = 0;
            $new_last = $last_id;

            foreach ( $ids as $attach_id ) {
                $attach_id = (int) $attach_id;
                $new_last  = $attach_id;

                $file = get_attached_file( $attach_id );
                if ( ! $file || ! file_exists( $file ) ) {
                    wp_delete_attachment( $attach_id, true );
                    $deleted++;
                } else {
                    $skipped++;
                }
            }

            $finished = count( $ids ) < $batch_size;

            if ( $finished ) {
                delete_transient( $count_key );
            }

            wp_send_json_success( [
                'deleted'  => $deleted,
                'skipped'  => $skipped,
                'total'    => $total,
                'last_id'  => $new_last,
                'finished' => $finished,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    /**
     * Delete a product post and all of its associated media attachments.
     *
     * Removes the featured image (_thumbnail_id) and every image in the
     * product_gallery meta before permanently deleting the post, so that
     * no orphaned attachments are left in the media library.
     */
    private static function delete_product_with_images( int $post_id ): bool {
        $attachment_ids = [];

        $thumbnail_id = (int) get_post_meta( $post_id, '_thumbnail_id', true );
        if ( $thumbnail_id > 0 ) {
            $attachment_ids[] = $thumbnail_id;
        }

        $gallery_raw = (string) get_post_meta( $post_id, CPI_Polylang_Sync::GALLERY_KEY, true );
        if ( '' !== $gallery_raw ) {
            foreach ( explode( ',', $gallery_raw ) as $gid ) {
                $gid = (int) trim( $gid );
                if ( $gid > 0 ) {
                    $attachment_ids[] = $gid;
                }
            }
        }

        foreach ( array_unique( $attachment_ids ) as $attach_id ) {
            wp_delete_attachment( $attach_id, true );
        }

        return (bool) wp_delete_post( $post_id, true );
    }

    private static function verify_nonce( string $action ): void {
        if ( ! check_ajax_referer( $action, 'security', false ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed. Please refresh the page and try again.' ], 403 );
            exit;
        }
    }

    private static function check_capability(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient permissions.' ], 403 );
            exit;
        }
    }

    private static function get_uploaded_file(): string {
        // Use cached file for subsequent batch calls
        if ( empty( $_FILES['csv_file']['tmp_name'] ) ) {
            $saved = get_transient( 'cpi_upload_' . get_current_user_id() );
            if ( $saved && file_exists( $saved ) ) {
                return $saved;
            }
            wp_send_json_error( [ 'message' => 'No CSV file provided. Please re-upload your file.' ] );
            exit;
        }

        $file = $_FILES['csv_file'];

        // Check for upload errors
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds the upload_max_filesize directive in php.ini.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds the MAX_FILE_SIZE directive in the HTML form.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
                UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
            ];
            $msg = $upload_errors[ $file['error'] ] ?? 'Unknown upload error (code ' . $file['error'] . ').';
            wp_send_json_error( [ 'message' => $msg ] );
            exit;
        }

        // Validate extension
        if ( strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) ) !== 'csv' ) {
            wp_send_json_error( [ 'message' => 'Only .csv files are allowed. Uploaded: ' . esc_html( $file['name'] ) ] );
            exit;
        }

        // Move to a persistent location so batch calls can reuse it
        $upload_dir = wp_upload_dir();
        if ( ! empty( $upload_dir['error'] ) ) {
            wp_send_json_error( [ 'message' => 'WordPress uploads directory error: ' . $upload_dir['error'] ] );
            exit;
        }

        $dest_dir = $upload_dir['basedir'] . '/cpi-imports/';
        if ( ! wp_mkdir_p( $dest_dir ) ) {
            wp_send_json_error( [ 'message' => 'Could not create upload directory: ' . $dest_dir ] );
            exit;
        }

        $dest = $dest_dir . sanitize_file_name( $file['name'] );

        if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) {
            wp_send_json_error( [ 'message' => 'Failed to move uploaded file to: ' . $dest . '. Check folder permissions.' ] );
            exit;
        }

        set_transient( 'cpi_upload_' . get_current_user_id(), $dest, HOUR_IN_SECONDS );
        return $dest;
    }
}
