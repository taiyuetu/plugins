# CSV Product Importer Pro — Update Log

## Version 2.4.2

### Large-import performance (CSV + image archive)

- **Files are uploaded once, not twice.** Preview already saves the CSV and image archive to `wp-content/uploads/cpi-imports/`; the batch import now reuses those server-side files instead of re-uploading everything. With thousands of images this cuts total upload time in half.
- **Image directory scanned once per request.** `count_disk_files()` and `maybe_register_disk_images()` previously ran `scandir()` over the image folders for every product row (thousands of rows × thousands of files = millions of filesystem calls). A request-level disk listing cache (`CPI_Importer::$disk_listing_cache`) is now built once and reused.
- **Media-library filename lookup cached per request.** `get_registered_filenames()` no longer runs a full `postmeta` query for every product row.
- **Bigger batches, longer time limit.** Default batch size raised 50 → 100 (server accepts 5–200; filter `cpi_import_batch_size`), and each batch gets `set_time_limit(300)` plus a raised memory limit so image-heavy batches don't hit PHP limits.
- **Real upload progress.** The Preview upload now shows the live upload percentage (`xhr.upload.onprogress`) instead of an indefinite spinner.

### Layout fix

- The preview table no longer stretches the admin page — grid columns use `minmax(0, 1fr)`, grid children have `min-width: 0`, and the table scrolls horizontally inside its card.

> **Usage note:** Import must follow a Preview in the same session — Import reuses the files uploaded during Preview. If more than 1 hour elapses between the two steps, click Preview again (the server asks for a re-upload).

## Version 2.3.1

### Image matching fix for large media libraries

- `find_attachments_by_mpn()` now loads the full attachment list **once** into a static cache (keyed by lowercased basename), then performs O(n) lookups per product instead of re-querying the database for every product row.
- This fixes image assignment failures when the media library has thousands of images — previously the per-product query caused extreme slowness and potential PHP execution timeouts.
- Added `count_disk_files()` diagnostic — before registering or matching images, the plugin now counts how many files on disk match each `product_mpn` value.
- Import result panel now shows **disk files found** and per-product diagnostics when files exist on disk but fail to match in the media library.
- `set_product_images()` now receives the full CSV row for proper MPN fallback handling.

---

## Version 2.3.0

### Unique key changed to `product_mpn`

- Duplicate detection now uses the **`product_mpn`** column instead of `oem_num`.
- `product_mpn` is now the only **required** CSV column.
- `IMAGE_KEY` mirrors `UNIQUE_KEY` by default — both use `product_mpn`.
- Configure in `includes/class-cpi-config.php`: `UNIQUE_KEY` and `IMAGE_KEY`.

### Title formula revised

- **New title formula:** `cross_ref` + `type` + `for` + `car_brand` + `car_application`.
- Example: `DACF301344071L2 front wheel hub unit for BAIC Huansu S2 S3 H3 1.5L`.
- The old formula was `car_brand` + `car_application` + `type` + `cross_ref` (space-separated, no connector).
- Configure in `includes/class-cpi-config.php`: `TITLE_FORMULA`.

### Image assignment stats in the import panel

- Two new live counters in the right sidebar: **"With Images"** and **"Total Images"**.
- Update in real time during batch import.
- Final success message includes image summary.
- Backend: `set_product_images()`, `persist_product_data()`, and `process_row()` now return image assignment counts.

### Backward compatibility

- `update_image_assignments()` batch sync retains an `oem_num` fallback so older products (imported before v2.3.0) still get their images matched.

---

## Version 2.0.0

### Post title generation

- **Title formula (v2.0):** `car_brand` + `car_application` + `type` + `cross_ref` (space-separated).
- All four columns are saved as post meta as well (no “title only” column).
- Configure in `includes/class-cpi-config.php`: `TITLE_FORMULA`.

### Dynamic meta field mapping

- **Every CSV column header** is saved as a post meta field with the **same name** (lowercased).
- No hardcoded `META_MAP` — add or remove columns in the CSV without editing the plugin.
- Missing meta keys are created automatically via `update_post_meta()`.
- Internal keys (`_generated_title`, etc.) and the taxonomy column are not stored as meta.

### Product images (upload + gallery)

- Images are read from **`wp-content/uploads/cpi-imports/images/`** on the server (same area as uploaded CSVs under `cpi-imports/`).
- Matched to products by the **`product_mpn`** CSV value.
- **Case-insensitive** filenames: `tqb3-0001(1).jpg`, `TQB3-0001(1).jpg`, and `Tqb3-0001(2).JPG` all match the same product.
- Supported patterns: `{mpn}(1).jpg`, `{mpn}(2).png`, `{mpn}-1.jpg`, `{mpn}.jpg` (single file = sequence 1).
- **`{mpn}(1).jpg`** (or first in sequence) → **featured image** (`_thumbnail_id`).
- All matched images → **`product_gallery`** meta as comma-separated attachment IDs (e.g. `"18048,18049,18050,18051"`).
- Files are registered into the Media Library on import if not already present.
- Admin UI includes a note with the images folder path.

### Polylang (multilingual sites)

- Meta is always written to **base keys only** (`product_gallery`, not `product_gallery_en`).
- **Language selector removed** from import settings and danger zone.
- If Polylang is active, new posts use the **default language** automatically.
- After import, base meta can still be pushed to translation posts via `push_to_translations()`.

### Case-insensitive matching

- CSV headers are normalized to **lowercase** at parse time.
- Post meta keys are stored in **lowercase**.
- Image filename matching is **fully case-insensitive** (disk scan + media library query).

### Admin & import behavior

- Only **`oem_num`** is strictly required in the CSV (unique key for duplicates).
- Removed Polylang language dropdown and delete-by-language filter.
- Delete by category works without selecting a language.
- Preview table shows all columns including `type`.

### Sample CSV

- `sample.csv` updated; removed `thumbnail_url` (images come from the images folder).

---

## Version 1.1.0

### Product category assignment (`product_category`)

- Assign imported products to the **`product_category`** custom taxonomy (theme-registered).
- **Admin default:** In **Import settings → Default product category**, choose a term applied to every row when the CSV category column is empty.
- **Per-row CSV column:** Optional `product_category` column — value can be term **slug**, **name**, or numeric **ID**.
- **Multiple terms:** Separate with comma, pipe, or semicolon (e.g. `wheel-hub-bearings, other-slug`).
- Per-row values override the admin default.
- Works on **insert** and **update**; respects **Polylang** (category dropdown refreshes when language changes).
- Configure in `includes/class-cpi-config.php`: `TAXONOMY`, `TAXONOMY_COLUMN`.

### Chinese / mixed-encoding CSV support

- Fixes **“Content, title, and excerpt are empty”** when Chinese text in `type` / `car_brand` breaks title sanitization but `oem_num` is still valid.
- **UTF-8 BOM** stripped from file start and header row.
- **GBK / GB2312** cell values converted to UTF-8 when detected.
- **Robust title resolution:** Falls back to `oem_num`, then `product_mpn`, if the generated title is emptied by `sanitize_text_field()`.
- Generated titles normalized at parse time so preview and import stay consistent.

### Image / gallery sync fixes

- Broader filename matching (not only `{mpn}(1).jpg`):
  - `TQB2-0001(1).jpg`, `TQB2-0001(2).png` — recommended
  - `TQB2-0001-1.jpg`, `TQB2-0001_2.png` — alternate separators
  - `TQB2-0001.jpg` — single image (counts as sequence 1)
- Featured image: uses sequence `(1)` when present; otherwise the **first** matched image.
- Sets both `set_post_thumbnail()` and `_thumbnail_id`.
- Saves `product_gallery` as comma-separated attachment IDs (WP Rapid Fields format).
- Images must already be in the **Media Library** (plugin does not upload files).
- Re-import existing products with **“Update with new data”** to apply gallery fixes to posts already imported.

### Polylang meta sync on import (automatic)

- New `CPI_Polylang_Sync` class mirrors **WP Rapid Fields** + theme `pll_sync_push_default_to_lang_keys()` behavior.
- **Default language import** (e.g. English):
  - Writes **base** keys (`product_mpn`, `oem_num`, `product_gallery`, …) **and** suffixed keys (`product_mpn_en`, `product_gallery_en`, …).
  - If Polylang translations exist, pushes base values to **every** linked post as `key_{lang}` on all languages (same as manual bulk sync).
- **Non-default language import** (e.g. Chinese):
  - Writes **suffixed keys only** (`product_mpn_zh`, `product_gallery_zh`, …) — matches theme admin expectations.
- Uses theme `pll_sync_get_default_keys()` when available; otherwise syncs `META_MAP` fields + `product_gallery`.
- Language is assigned **before** meta is saved.
- Duplicate detection searches both `oem_num` and `oem_num_{lang}` when a language is selected.
- **Tip:** Select the import language in settings; re-import with **Update** to fix posts imported before this fix.

### Danger zone: delete products by category

- **Delete products in category** — remove all products in a selected `product_category` term (includes child categories).
- Batched deletion with progress bar (50 per request).
- Separate from **Delete all products** (site-wide).

### Danger zone: delete by category + language (multilingual)

- When **Polylang** is active, choose **language** and **category** before deleting.
- Only products in that **category and language** are removed; other languages are untouched.
- Category dropdown refreshes when language changes.
- Language is required on multilingual sites.

### Sample CSV

- `sample.csv` includes optional `product_category` column example.

---

## CSV requirements (quick reference) — v2.3.0

| Column | Required | Notes |
|--------|----------|--------|
| `product_mpn` | **Yes** | Unique key for duplicate detection + image filename matching |
| `cross_ref` | No | Used in title formula + saved as meta |
| `type` | No | Used in title formula + saved as meta |
| `car_brand` | No | Used in title formula + saved as meta |
| `car_application` | No | Used in title formula + saved as meta |
| `oem_num` | No | Optional OEM number, saved as meta |
| `product_category` | No | Slug, name, or term ID (taxonomy) |
| *any other column* | No | Auto-mapped to post meta (same name, lowercase) |

**Headers:** English slugs recommended (`product_mpn`); headers are matched **case-insensitively** after lowercasing.

**Encoding:** Save as **CSV UTF-8** (BOM supported) when using Chinese text.

**Title formula:** `cross_ref` + `type` + `for` + `car_brand` + `car_application`.

**Images:** Place files in `wp-content/uploads/cpi-imports/images/` before or during import.

---

## Files changed in 2.3.0

- `csv-product-importer.php` — version 2.3.0
- `includes/class-cpi-config.php` — `UNIQUE_KEY` = `product_mpn`; new `TITLE_FORMULA`; added `image_key()` helper
- `includes/class-cpi-importer.php` — image stats returned from `set_product_images()` / `persist_product_data()` / `process_row()` / `import_batch()`
- `includes/class-cpi-meta-fields.php` — updated `oem_num` description
- `templates/admin-page.php` — added "With Images" and "Total Images" stat cards
- `admin/js/admin.js` — image stats in state, display, and result messages
- `admin/css/admin.css` — `.cpi-stat.images` styling
- `README.md` — updated unique key, title formula, image key docs
- `CHANGELOG.md` — 2.3.0 entries
- `update.md` — this file

---

## Files changed in 2.0.0

- `csv-product-importer.php` — version 2.0.0
- `includes/class-cpi-config.php` — new title formula; removed `META_MAP` / `TITLE_ONLY_COLUMN`
- `includes/class-cpi-polylang-sync.php` — dynamic row meta; base keys only; simplified gallery save
- `includes/class-cpi-importer.php` — `cpi-imports/images/` upload; case-insensitive images; no language param
- `includes/class-cpi-csv-parser.php` — only `oem_num` required
- `includes/class-cpi-ajax.php` — removed language from import/delete
- `templates/admin-page.php` — removed language UI; images folder note; column reference
- `admin/class-cpi-admin.php` — removed Polylang JS flags
- `admin/js/admin.js` — removed language handlers
- `admin/css/admin.css` — images note styles
- `sample.csv` — aligned with v2 format

---

## Files changed in 1.1.0

- `csv-product-importer.php` — loads `class-cpi-polylang-sync.php`
- `includes/class-cpi-config.php` — taxonomy constants and term helpers
- `includes/class-cpi-polylang-sync.php` — **new** Polylang meta write + translation push
- `includes/class-cpi-importer.php` — category, title, gallery, `persist_product_data()`, suffixed duplicate lookup
- `includes/class-cpi-csv-parser.php` — UTF-8 / encoding handling
- `includes/class-cpi-ajax.php` — category options, import category param, delete by category (+ language)
- `templates/admin-page.php` — import category dropdown, danger-zone delete UI, column reference
- `admin/class-cpi-admin.php` — Polylang i18n strings, `has_polylang` flag
- `admin/js/admin.js` — category import, delete-by-category batches, language filter
- `admin/css/admin.css` — taxonomy badge, danger-zone layout
- `sample.csv` — `product_category` example column

---

## Version 1.0.0

- CSV upload and batch import for `product` post type
- Smart title generation from configurable columns
- Meta field mapping via `META_MAP`
- Duplicate handling: skip, update, or duplicate
- Polylang language assignment
- Media Library image matching by `product_mpn` filename pattern
- Admin preview (first 10 rows) and import statistics
