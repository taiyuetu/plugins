<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles inserting / updating WordPress product posts.
 *
 * All CSV columns are saved as post meta (column name = meta key, lowercased).
 * Images are sourced from the "images" folder alongside the uploaded CSV
 * (wp-content/uploads/cpi-imports/images/) and matched to products via
 * the IMAGE_KEY column value (case-insensitive).
 */
class CPI_Importer {

    /**
     * Import a batch of parsed rows.
     *
     * @param array  $rows
     * @param string $duplicate       'skip' | 'update' | 'duplicate'
     * @param string $post_status     'publish' | 'draft' | 'pending'
     * @param int    $batch_offset
     * @param int    $batch_size
     * @param int    $default_term_id Default product_category term ID when CSV column is empty.
     *
     * @return array{imported:int, updated:int, skipped:int, error_count:int, errors:string[], skipped_messages:string[]}
     */
    public static function import_batch(
        array $rows,
        string $duplicate = 'skip',
        string $post_status = 'publish',
        int $batch_offset = 0,
        int $batch_size = 50,
        int $default_term_id = 0
    ): array {
        $stats = [
            'imported'           => 0,
            'updated'            => 0,
            'skipped'            => 0,
            'error_count'        => 0,
            'errors'             => [],
            'skipped_messages'   => [],
            'images_assigned'    => 0,
            'total_images'       => 0,
            'disk_files_found'   => 0,
            'missing_images'     => [],
            'dirs_found'         => 0,
            'total_files_in_dir' => 0,
            'sample_files'       => [],
            'expected_dir'       => '',
            'dir_exists'         => false,
            'sample_key'         => '',
        ];

        foreach ( array_slice( $rows, $batch_offset, $batch_size ) as $row ) {
            $result = self::process_row( $row, $duplicate, $post_status, $default_term_id );
            if ( $result['action'] === 'errors' ) {
                $stats['error_count']++;
            } else {
                $stats[ $result['action'] ]++;
            }
            if ( ! empty( $result['error'] ) ) {
                $stats['errors'][] = $result['error'];
            }
            if ( ! empty( $result['skip_message'] ) ) {
                $stats['skipped_messages'][] = $result['skip_message'];
            }

            $img = $result['images'] ?? null;
            if ( $img ) {
                $stats['disk_files_found']    += $img['disk_files'] ?? 0;
                $stats['dirs_found']           = max( $stats['dirs_found'], $img['dirs_found'] ?? 0 );
                $stats['total_files_in_dir']   = max( $stats['total_files_in_dir'], $img['total_files_in_dir'] ?? 0 );
                $stats['expected_dir']          = $stats['expected_dir'] ?: ( $img['expected_dir'] ?? '' );
                $stats['dir_exists']            = $stats['dir_exists'] || ( $img['dir_exists'] ?? false );
                $stats['sample_key']             = $stats['sample_key'] ?: ( $img['sample_key'] ?? '' );
                if ( empty( $stats['sample_files'] ) && ! empty( $img['sample_files'] ) ) {
                    $stats['sample_files'] = $img['sample_files'];
                }
                if ( ! empty( $img['gallery_count'] ) ) {
                    $stats['images_assigned']++;
                    $stats['total_images'] += $img['gallery_count'];
                } elseif ( $img['disk_files'] > 0 && ! in_array( $result['action'], [ 'skipped', 'errors' ], true ) ) {
                    // Disk files exist but none matched — diagnostic
                    $unique_val = trim( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? '' ) );
                    $stats['missing_images'][] = sprintf(
                        '%s: %d file(s) on disk for key "%s" but none matched in media library',
                        $unique_val ?: 'unknown',
                        $img['disk_files'],
                        $img['key_used'] ?: 'N/A'
                    );
                }
            }
        }

        // Cap missing_images diagnostic messages
        if ( count( $stats['missing_images'] ) > 20 ) {
            $stats['missing_images'] = array_slice( $stats['missing_images'], 0, 20 );
            $stats['missing_images'][] = '… and more (capped at 20 messages)';
        }

        return $stats;
    }

    /**
     * Public entry point for gallery sync on a single post.
     *
     * @return array{thumbnail:bool, gallery_count:int}
     */
    public static function sync_images_for_post( int $post_id, string $mpn ): array {
        return self::set_product_images( $post_id, $mpn );
    }

    // -------------------------------------------------------------------------

    private static function process_row(
        array $row,
        string $duplicate,
        string $post_status,
        int $default_term_id = 0
    ): array {
        $unique_key = CPI_Config::UNIQUE_KEY;
        $raw_unique = trim( (string) ( $row[ $unique_key ] ?? '' ) );
        $unique_val = sanitize_text_field( $raw_unique );
        if ( '' === $unique_val && '' !== $raw_unique ) {
            $unique_val = wp_strip_all_tags( $raw_unique );
        }

        $title      = self::resolve_post_title( $row, $unique_val );
        $identifier = $unique_val ?: $title;

        $existing_id = self::find_existing( $unique_val );

        if ( $existing_id ) {
            if ( 'skip' === $duplicate ) {
                return [
                    'action'       => 'skipped',
                    'error'        => '',
                    'skip_message' => sprintf(
                        'Skipped existing product: %s (post ID %d).',
                        $identifier,
                        $existing_id
                    ),
                ];
            }

            if ( 'update' === $duplicate ) {
                $post_id = wp_update_post( [
                    'ID'           => $existing_id,
                    'post_title'   => $title,
                    'post_status'  => $post_status,
                    'post_content' => CPI_Config::build_post_content( $row, $title ),
                ], true );

                if ( is_wp_error( $post_id ) ) {
                    return [
                        'action'       => 'errors',
                        'error'        => sprintf( 'Failed updating %s: %s', $identifier, $post_id->get_error_message() ),
                        'skip_message' => '',
                    ];
                }

                $img_stats = self::persist_product_data( $post_id, $row, $default_term_id );
                return [ 'action' => 'updated', 'error' => '', 'skip_message' => '', 'images' => $img_stats ];
            }
        }

        $post_id = wp_insert_post( [
            'post_title'   => $title,
            'post_type'    => CPI_Config::post_type(),
            'post_status'  => $post_status,
            'post_content' => CPI_Config::build_post_content( $row, $title ),
        ], true );

        if ( is_wp_error( $post_id ) ) {
            return [
                'action'       => 'errors',
                'error'        => sprintf( 'Failed inserting %s: %s', $identifier, $post_id->get_error_message() ),
                'skip_message' => '',
            ];
        }

        $img_stats = self::persist_product_data( $post_id, $row, $default_term_id );
        return [ 'action' => 'imported', 'error' => '', 'skip_message' => '', 'images' => $img_stats ];
    }

    /**
     * Assign language (default if Polylang active), save meta, images, taxonomy,
     * then sync to Polylang translations.
     */
    /**
     * @return array{thumbnail:bool, gallery_count:int} Image stats from set_product_images.
     */
    private static function persist_product_data(
        int $post_id,
        array $row,
        int $default_term_id
    ): array {
        self::set_post_language( $post_id );
        CPI_Polylang_Sync::save_row_meta( $post_id, $row );
        $img_stats = self::set_product_images( $post_id, $row[ CPI_Config::IMAGE_KEY ] ?? '', $row );
        self::assign_taxonomy( $post_id, $row, $default_term_id );
        CPI_Polylang_Sync::push_to_translations( $post_id );
        return $img_stats;
    }

    /**
     * Resolve a post title that survives WordPress sanitization.
     */
    private static function resolve_post_title( array $row, string $unique_val ): string {
        $generated = trim( (string) ( $row['_generated_title'] ?? CPI_CSV_Parser::build_title( $row ) ) );

        $candidates = array_filter( [
            $generated,
            $unique_val,
            trim( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? '' ) ),
            trim( (string) ( $row['product_mpn'] ?? '' ) ),
        ], static fn( $v ) => '' !== $v );

        foreach ( $candidates as $candidate ) {
            $sanitized = sanitize_text_field( $candidate );
            if ( '' !== $sanitized ) {
                return $sanitized;
            }
        }

        foreach ( $candidates as $candidate ) {
            $stripped = trim( wp_strip_all_tags( $candidate ) );
            if ( '' !== $stripped ) {
                return mb_substr( $stripped, 0, 200 );
            }
        }

        return 'product-' . wp_generate_password( 8, false, false );
    }

    /**
     * Assign the Polylang default language to a post.
     * If Polylang is not active, does nothing.
     */
    private static function set_post_language( int $post_id ): void {
        if ( ! function_exists( 'pll_set_post_language' ) || ! function_exists( 'pll_default_language' ) ) {
            return;
        }
        $default = pll_default_language( 'slug' );
        if ( '' !== $default ) {
            pll_set_post_language( $post_id, $default );
        }
    }

    /**
     * Assign product_category terms from the CSV column or admin default.
     */
    private static function assign_taxonomy(
        int $post_id,
        array $row,
        int $default_term_id
    ): void {
        if ( ! CPI_Config::taxonomy_enabled() ) {
            return;
        }

        $raw = '';
        foreach ( CPI_Config::taxonomy_columns() as $col ) {
            $value = trim( (string) ( $row[ $col ] ?? '' ) );
            if ( '' !== $value ) {
                $raw = $value;
                break;
            }
        }

        if ( '' !== $raw ) {
            $term_ids = self::resolve_term_ids( $raw );
        } elseif ( $default_term_id > 0 ) {
            $term_ids = [ $default_term_id ];
        } else {
            return;
        }

        $term_ids = array_values( array_filter( array_unique( array_map( 'intval', $term_ids ) ) ) );
        if ( empty( $term_ids ) ) {
            return;
        }

        wp_set_object_terms( $post_id, $term_ids, CPI_Config::taxonomy(), false );
    }

    /**
     * @return int[]
     */
    private static function resolve_term_ids( string $raw ): array {
        $tokens = preg_split( '/[|,;]+/', $raw ) ?: [];
        $ids    = [];

        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }

            $term_id = self::resolve_single_term( $token );
            if ( $term_id > 0 ) {
                $ids[] = $term_id;
            }
        }

        return $ids;
    }

    private static function resolve_single_term( string $value ): int {
        $taxonomy = CPI_Config::taxonomy();

        if ( ctype_digit( $value ) ) {
            $term = get_term( (int) $value, $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                return (int) $term->term_id;
            }
            return 0;
        }

        $args = [
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
            'number'     => 1,
        ];

        $args['slug'] = sanitize_title( $value );
        $terms        = get_terms( $args );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            return (int) $terms[0]->term_id;
        }

        unset( $args['slug'] );
        $args['name'] = $value;
        $terms        = get_terms( $args );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            return (int) $terms[0]->term_id;
        }

        return 0;
    }

    // -------------------------------------------------------------------------
    // Image handling
    // -------------------------------------------------------------------------

    /**
     * Public entry point to scan disk & sync images for all existing product posts.
     *
     * @return array{total:int, updated:int}
     */
    public static function sync_all_product_images(): array {
        self::clear_attachment_cache();

        $posts = get_posts( [
            'post_type'      => CPI_Config::post_type(),
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ] );

        $updated = 0;
        foreach ( $posts as $post_id ) {
            $post_id = (int) $post_id;
            $mpn     = get_post_meta( $post_id, CPI_Config::IMAGE_KEY, true );
            if ( empty( $mpn ) ) {
                $mpn = get_post_meta( $post_id, 'oem_num', true );
            }
            if ( ! empty( $mpn ) ) {
                self::set_product_images( $post_id, (string) $mpn );
                $updated++;
            }
        }

        return [
            'total'   => count( $posts ),
            'updated' => $updated,
        ];
    }

    // -------------------------------------------------------------------------
    // Image handling
    // -------------------------------------------------------------------------

    /**
     * Helper to get candidate upload directories for product images.
     *
     * @return array<string, string> Rel path => Abs path
     */
    private static function get_image_directories(): array {
        $upload_dir = wp_upload_dir();
        $basedir    = trailingslashit( $upload_dir['basedir'] );

        $dirs = [
            'cpi-imports/images/' => $basedir . 'cpi-imports/images/',
            'cpi-imports/'        => $basedir . 'cpi-imports/',
        ];

        $valid = [];
        foreach ( $dirs as $rel => $abs ) {
            if ( ! is_dir( $abs ) ) {
                wp_mkdir_p( $abs );
            }
            if ( is_dir( $abs ) ) {
                $valid[ $rel ] = $abs;
            }
        }

        return $valid;
    }

    /**
     * Count how many files on disk match the given key value (cheap scan).
     *
     * @return array{count:int, dirs_found:int, total_files:int, sample_files:array}
     */
    /**
     * Request-level cache of all image files on disk (scanned once per request,
     * then reused for every product row — avoids rescanning the directory per row).
     *
     * @var array<int, array{filename:string, ext:string, rel_dir:string, abs_dir:string}>|null
     */
    private static $disk_listing_cache = null;

    /** Request-level cache of filenames already registered in the media library. */
    private static $registered_files_cache = null;

    /**
     * Build (once per request) the flat list of image files in the image dirs.
     */
    private static function get_disk_listing(): array {
        if ( null !== self::$disk_listing_cache ) {
            return self::$disk_listing_cache;
        }

        $image_exts = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'avif' ];
        $listing    = [];

        foreach ( self::get_image_directories() as $rel_dir => $abs_dir ) {
            $files = scandir( $abs_dir );
            if ( ! $files ) {
                continue;
            }
            foreach ( $files as $filename ) {
                if ( in_array( $filename, [ '.', '..' ], true ) ) {
                    continue;
                }
                $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
                if ( ! in_array( $ext, $image_exts, true ) ) {
                    continue;
                }
                $listing[] = [
                    'filename' => $filename,
                    'ext'      => $ext,
                    'rel_dir'  => $rel_dir,
                    'abs_dir'  => $abs_dir,
                ];
            }
        }

        self::$disk_listing_cache = $listing;
        return $listing;
    }

    private static function count_disk_files( string $key_value ): array {
        $upload_dir = wp_upload_dir();
        $expected   = trailingslashit( $upload_dir['basedir'] ) . 'cpi-imports/images/';
        $exists     = is_dir( $expected );

        $result = [
            'count'        => 0,
            'dirs_found'   => 0,
            'total_files'  => 0,
            'sample_files' => [],
            'expected_dir' => str_replace( ABSPATH, '', $expected ),
            'dir_exists'   => $exists,
        ];

        $listing = self::get_disk_listing();
        if ( empty( $listing ) ) {
            return $result;
        }

        $result['dirs_found'] = count( array_unique( array_column( $listing, 'rel_dir' ) ) );

        foreach ( $listing as $entry ) {
            $result['total_files']++;
            // Collect up to 5 sample filenames from the first product scanned
            if ( count( $result['sample_files'] ) < 5 ) {
                $result['sample_files'][] = $entry['filename'];
            }
            if ( null !== self::parse_mpn_image_sequence( $entry['filename'], $key_value ) ) {
                $result['count']++;
            }
        }

        return $result;
    }

    /**
     * Find matching images and assign them as thumbnail + gallery.
     *
     * @return array{thumbnail:bool, gallery_count:int, disk_files:int, key_used:string}
     */
    private static function set_product_images( int $post_id, string $key_value, array $row = [] ): array {
        $result = [ 'thumbnail' => false, 'gallery_count' => 0, 'disk_files' => 0, 'key_used' => '', 'dirs_found' => 0, 'total_files_in_dir' => 0, 'sample_files' => [], 'expected_dir' => '', 'dir_exists' => false, 'sample_key' => '' ];

        $key_value = trim( $key_value );
        if ( '' === $key_value && ! empty( $row ) ) {
            $key_value = trim( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? $row['oem_num'] ?? '' ) );
        }

        if ( '' === $key_value ) {
            return $result;
        }

        $result['key_used'] = $key_value;
        $disk_info = self::count_disk_files( $key_value );
        $result['disk_files']         = $disk_info['count'];
        $result['dirs_found']         = $disk_info['dirs_found'];
        $result['total_files_in_dir'] = $disk_info['total_files'];
        $result['sample_files']       = $disk_info['sample_files'];
        $result['expected_dir']       = $disk_info['expected_dir'];
        $result['dir_exists']         = $disk_info['dir_exists'];
        $result['sample_key']         = $key_value;

        self::maybe_register_disk_images( $key_value );

        $matched = self::find_attachments_by_mpn( $key_value );
        if ( empty( $matched ) ) {
            return $result;
        }

        usort( $matched, static fn( $a, $b ) => $a['sequence'] !== $b['sequence']
            ? $a['sequence'] <=> $b['sequence']
            : $a['id'] <=> $b['id']
        );

        $gallery_ids  = array_column( $matched, 'id' );
        $thumbnail_id = 0;

        foreach ( $matched as $attachment ) {
            if ( 1 === $attachment['sequence'] ) {
                $thumbnail_id = $attachment['id'];
                break;
            }
        }

        if ( ! $thumbnail_id ) {
            $thumbnail_id = $gallery_ids[0];
        }

        set_post_thumbnail( $post_id, $thumbnail_id );
        update_post_meta( $post_id, '_thumbnail_id', $thumbnail_id );

        CPI_Polylang_Sync::save_gallery( $post_id, $gallery_ids );

        $result['thumbnail']     = true;
        $result['gallery_count'] = count( $gallery_ids );
        return $result;
    }

    /**
     * Scan image folders for files matching the MPN key and register
     * any that are not already in the WordPress media library.
     */
    private static function maybe_register_disk_images( string $key_value ): void {
        $listing = self::get_disk_listing();
        if ( empty( $listing ) ) {
            return;
        }

        if ( null === self::$registered_files_cache ) {
            self::$registered_files_cache = self::get_registered_filenames();
        }
        $registered_lower = array_map( 'strtolower', self::$registered_files_cache );

        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        foreach ( $listing as $entry ) {
            $filename = $entry['filename'];
            $ext      = $entry['ext'];

            if ( preg_match( '/-\d+x\d+\.[^.]+$/i', $filename ) ) {
                continue;
            }

            $sequence = self::parse_mpn_image_sequence( $filename, $key_value );
            if ( null === $sequence ) {
                continue;
            }

            $name_lower = strtolower( $filename );
            if ( in_array( $name_lower, $registered_lower, true ) ) {
                continue;
            }

            $file_path = $entry['abs_dir'] . $filename;
            if ( ! is_readable( $file_path ) ) {
                continue;
            }

            $filetype = wp_check_filetype( $filename );
            $mime     = $filetype['type'] ?? '';
            if ( empty( $mime ) ) {
                $mime_map = [
                    'webp' => 'image/webp',
                    'jpg'  => 'image/jpeg',
                    'jpeg' => 'image/jpeg',
                    'png'  => 'image/png',
                    'gif'  => 'image/gif',
                    'svg'  => 'image/svg+xml',
                    'avif' => 'image/avif',
                ];
                $mime = $mime_map[ $ext ] ?? 'image/' . $ext;
            }

            $relative_path = wp_normalize_path( $entry['rel_dir'] . $filename );

            $attachment = [
                'post_mime_type' => $mime,
                'post_title'     => preg_replace( '/\.[^.]+$/', '', $filename ),
                'post_content'   => '',
                'post_status'    => 'inherit',
            ];

            $attach_id = wp_insert_attachment( $attachment, $file_path );

            if ( is_wp_error( $attach_id ) || ! $attach_id ) {
                continue;
            }

            $metadata = wp_generate_attachment_metadata( $attach_id, $file_path );
            if ( ! empty( $metadata ) && ! is_wp_error( $metadata ) ) {
                wp_update_attachment_metadata( $attach_id, $metadata );
            }

            update_post_meta( $attach_id, '_wp_attached_file', $relative_path );
            $registered_lower[]             = $name_lower;
            self::$registered_files_cache[] = $filename;

            if ( null !== self::$attachment_cache ) {
                self::$attachment_cache[ $name_lower ][] = [
                    'id'       => (int) $attach_id,
                    'filename' => $name_lower,
                ];
            }
        }
    }

    /**
     * Reset attachment in-memory cache.
     */
    public static function clear_attachment_cache(): void {
        self::$attachment_cache = null;
    }

    /**
     * Returns filenames already registered as attachments in WordPress.
     *
     * @return string[]
     */
    private static function get_registered_filenames(): array {
        global $wpdb;

        $rows = $wpdb->get_col(
            "SELECT meta_value
             FROM {$wpdb->postmeta}
             WHERE meta_key = '_wp_attached_file'",
            0
        );

        if ( empty( $rows ) ) {
            return [];
        }

        $filenames = [];
        foreach ( (array) $rows as $meta_val ) {
            $normalized  = str_replace( '\\', '/', (string) $meta_val );
            $filenames[] = wp_basename( $normalized );
        }

        return array_values( array_filter( array_unique( $filenames ) ) );
    }

    /**
     * Cached attachment list: [ basename_lower => [ 'id' => int, 'filename' => string ] ]
     * @var array<string, array<int, array{id:int, filename:string}>>|null
     */
    private static $attachment_cache = null;

    /**
     * Load all media-library attachments into a static cache keyed by lowercased basename.
     */
    private static function load_attachment_cache(): void {
        if ( null !== self::$attachment_cache ) {
            return;
        }

        global $wpdb;
        self::$attachment_cache = [];

        $attachments = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value AS attached_file
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm
                ON pm.post_id = p.ID
               AND pm.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment'",
            OBJECT
        );

        if ( empty( $attachments ) ) {
            return;
        }

        foreach ( $attachments as $att ) {
            $id         = (int) $att->ID;
            $raw_path   = (string) $att->attached_file;
            $normalized = str_replace( '\\', '/', $raw_path );
            $basename   = strtolower( wp_basename( $normalized ) );

            if ( '' === $basename ) {
                continue;
            }

            self::$attachment_cache[ $basename ][] = [
                'id'       => $id,
                'filename' => $basename,
            ];
        }
    }

    /**
     * Find all media-library attachments whose filename matches the MPN key
     * (cross-platform path safe, handles Windows backslashes & case-insensitive).
     *
     * Uses a static cache so the attachment list is loaded once per request.
     *
     * @return array<int, array{id:int, sequence:int}>
     */
    private static function find_attachments_by_mpn( string $key_value ): array {
        self::load_attachment_cache();

        if ( empty( self::$attachment_cache ) ) {
            return [];
        }

        $key_value = trim( $key_value );
        if ( '' === $key_value ) {
            return [];
        }

        $norm_key = self::normalize_mpn_string( $key_value );
        if ( '' === $norm_key ) {
            return [];
        }

        $matched = [];

        foreach ( self::$attachment_cache as $basename_lower => $entries ) {
            $base_name = preg_replace( '/\.[^.]+$/', '', $basename_lower );
            $norm_base = self::normalize_mpn_string( $base_name );

            if ( ! str_starts_with( $norm_base, $norm_key ) ) {
                continue;
            }

            foreach ( $entries as $entry ) {
                $sequence = self::parse_mpn_image_sequence( $entry['filename'], $key_value );
                if ( null === $sequence ) {
                    continue;
                }
                $matched[] = [
                    'id'       => $entry['id'],
                    'sequence' => $sequence,
                ];
            }
        }

        return $matched;
    }

    /**
     * Normalize strings for MPN matching (replaces spaces, hyphens, underscores, dots with single dash).
     */
    private static function normalize_mpn_string( string $str ): string {
        $str = strtolower( trim( $str ) );
        return preg_replace( '/[\s\-_.]+/u', '-', $str );
    }

    /**
     * Parse image sequence number from filename against the MPN key.
     * Image filename must strictly match the product_mpn value (case-insensitive & separator-normalized).
     */
    private static function parse_mpn_image_sequence( string $filename, string $key_value ): ?int {
        $filename  = trim( $filename );
        $key_value = trim( $key_value );

        if ( '' === $filename || '' === $key_value ) {
            return null;
        }

        $base_name = preg_replace( '/\.[^.]+$/', '', $filename );
        $norm_key  = self::normalize_mpn_string( $key_value );

        if ( '' === $norm_key || '' === $base_name ) {
            return null;
        }

        // 1. Check parenthesized sequence suffix e.g. "TQB2-0046(3)" or "TQB2-0046( 1 )"
        if ( preg_match( '/\(\s*(\d+)\s*\)$/', $base_name, $m ) ) {
            $seq      = (int) $m[1];
            $mpn_part = preg_replace( '/\(\s*\d+\s*\)$/', '', $base_name );
            if ( self::normalize_mpn_string( $mpn_part ) === $norm_key ) {
                return $seq;
            }
        }

        // 2. Check delimited sequence suffix e.g. "TQB2-0046_3", "TQB2-0046-3", "TQB2-0046.3"
        if ( preg_match( '/[\s\-_.]+(\d+)$/', $base_name, $m ) ) {
            $seq      = (int) $m[1];
            $mpn_part = preg_replace( '/[\s\-_.]+\d+$/', '', $base_name );
            if ( self::normalize_mpn_string( $mpn_part ) === $norm_key ) {
                return $seq;
            }
        }

        // 3. Check exact match without sequence suffix e.g. "TQB2-0046"
        if ( self::normalize_mpn_string( $base_name ) === $norm_key ) {
            return 1;
        }

        return null;
    }

    /**
     * Look up an existing post by the UNIQUE_KEY meta value.
     */
    private static function find_existing( string $value ): int {
        if ( empty( $value ) ) {
            return 0;
        }

        $unique_key = CPI_Config::UNIQUE_KEY;

        $args = [
            'post_type'      => CPI_Config::post_type(),
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ [
                'key'     => $unique_key,
                'value'   => $value,
                'compare' => '=',
            ] ],
        ];

        $query = new WP_Query( $args );
        return ! empty( $query->posts ) ? (int) $query->posts[0] : 0;
    }
}
