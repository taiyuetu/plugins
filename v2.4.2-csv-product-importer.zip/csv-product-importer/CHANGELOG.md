# Changelog

All notable changes to CSV Product Importer Pro are documented here.

## [2.4.2] – 2026-09-21

### Changed
- **Import performance at scale** — several fixes for large imports (thousands of products + image archive):
  - The CSV and image files are no longer uploaded twice. Preview persists them server-side (`wp-content/uploads/cpi-imports/`) and the batch import now reuses the saved files instead of re-uploading the whole archive. Upload time is cut in half.
  - `CPI_Importer` now scans the image directories **once per request** (new request-level `$disk_listing_cache`) instead of once per product row (`count_disk_files()` and `maybe_register_disk_images()` each scanned on every row). Previously thousands of rows × thousands of files meant millions of filesystem calls.
  - `get_registered_filenames()` (the media-library filename lookup) is now cached once per request instead of being re-queried for every product row.
  - Default import batch size raised from 50 to 100 rows (cap 200, override with the `cpi_import_batch_size` filter). Each batch now runs with `set_time_limit(300)` and a raised memory limit so image-heavy batches don't time out.
- **Real upload progress** — the Preview request now shows the actual upload percentage via `xhr.upload.onprogress`, so large image ZIP uploads no longer look frozen.

### Fixed
- **Preview table breaking the admin layout** — the preview table's `white-space: nowrap` cells expanded the CSS grid's `1fr` column (grid children default to `min-width: auto`), stretching the whole page. Grid columns now use `minmax(0, 1fr)`, grid children have `min-width: 0`, and the table wrapper scrolls horizontally inside the card.

> **Note:** since 2.4.2 the Preview → Import flow requires Preview to run first in the same session (Import reuses the files uploaded during Preview). If more than an hour passes between the two steps, the server asks for a re-upload — simply click Preview again.

## [2.4.1] – 2026-09-21

### Fixed
- **Preview table stretched the page layout** — after clicking "Preview CSV", the preview table with long `nowrap` cells pushed the `.cpi-left` grid column wider than the viewport, breaking the admin page structure. Fixed with `minmax(0, 1fr)` grid tracks, `min-width: 0` on grid children/card bodies, and horizontal scrolling inside `.cpi-table-wrap`.
- Plugin version constant bumped to bust cached CSS/JS.

## [2.4.0] – 2026-09-21

### Added
- **Admin "Import target" panel** — post type, category taxonomy and the category CSV column can now be chosen from the plugin page and are persisted in the `cpi_settings` option. No more editing `class-cpi-config.php` for every change.
- `CPI_Config::settings()`, `post_type()`, `taxonomy()`, `taxonomy_column()`, `save()`, `reset()`, `available_post_types()`, `available_taxonomies()` — runtime accessors that replace the old `POST_TYPE` / `TAXONOMY` / `TAXONOMY_COLUMN` constants.
- New AJAX action `cpi_save_settings`.
- Taxonomy dropdown is filtered client-side to the taxonomies attached to the selected post type.

### Changed
- `POST_TYPE`, `TAXONOMY` and `TAXONOMY_COLUMN` constants renamed to `DEFAULT_POST_TYPE`, `DEFAULT_TAXONOMY` and `DEFAULT_TAXONOMY_COLUMN`. They are now fallbacks only; the saved settings take precedence.
- `CPI_Config::taxonomy_columns()` returns no columns when the category CSV column is empty, so disabling per-row assignment also ignores the `product_cat` alias.

### Fixed
- **Danger zone "Delete products in category" missing** — the taxonomy was hardcoded to WooCommerce's `product_cat`, which does not exist on sites without WooCommerce, so `taxonomy_enabled()` returned false and the whole block (plus the default-category dropdown) was silently skipped. Missing defaults are now auto-detected (`product_cat` → `product_category` → `category`).

## [2.3.2] – 2026-06-19

### Fixed
- **Granular directory diagnostics** — `count_disk_files()` now reports whether the images directory was found, how many total image files are in it, and sample filenames. This surfaces the exact reason images aren't matching in the import result message.

## [2.3.1] – 2026-06-19

### Fixed
- **Image matching at scale** — `find_attachments_by_mpn()` now uses a static cache so the media library is queried once per import instead of once per product. Previously, with 5,000+ images, the query ran for every product row causing massive slowdown and potential timeouts that silently prevented image assignment.
- Added `count_disk_files()` diagnostic to detect mismatches between disk files and media library registrations.
- `set_product_images()` now receives the full `$row` as a third parameter, enabling the MPN fallback chain.
- Import stats now include `disk_files_found` and per-product `missing_images` diagnostics visible in the details panel.

## [2.3.0] – 2026-06-19

### Changed
- **Unique key switched to `product_mpn`** — duplicate detection now uses the `product_mpn` column instead of `oem_num`. The `product_mpn` column is now the only required CSV column.
- **Title formula revised** — titles are now assembled as `cross_ref` + `type` + `for` + `car_brand` + `car_application` (e.g. "DACF301344071L2 front wheel hub unit for BAIC Huansu S2 S3 H3 1.5L"). The old formula was `car_brand` + `car_application` + `type` + `cross_ref` without a connector.
- **`IMAGE_KEY` now mirrors `UNIQUE_KEY`** — both default to `product_mpn`. Image matching and duplicate detection use the same column.

### Added
- **Image assignment stats in the import panel** — the right-side statistics now show **"With Images"** (how many products received image assignments) and **"Total Images"** (sum of all gallery images assigned). These update live during batch import and appear in the final success message.
- `set_product_images()` now returns `['thumbnail' => bool, 'gallery_count' => int]` for tracking.
- `persist_product_data()` returns image stats so `process_row()` and `import_batch()` can aggregate them.

### Fixed
- `update_image_assignments()` batch function retains `oem_num` fallback for backwards compatibility with older products.

## [2.1.0] – 2026-05-19

### Added
- **Post content generation** — each imported product post is now populated with a structured body built from its CSV meta fields. The format is:
  ```
  {Post Title}        ← wrapped in <h2>
  OEM Number: {oem_num}
  Car Application: {car_application}
  Diameter: {outer_diameter}
  Weight: {weight}
  ```
  Fields with no value in the CSV row are omitted automatically.
- `CPI_Config::CONTENT_FORMULA` constant — a simple array that controls which meta columns appear in the post content and their human-readable labels. Add, remove, or reorder entries without touching importer logic.
- `CPI_Config::build_post_content( array $row, string $title ): string` — static helper that assembles and HTML-escapes the post body from a CSV row.
- Post content is written on both **insert** (new products) and **update** (existing products in "update" duplicate mode).

### Changed
- Post content title is wrapped in `<h2>` tags.
- All field labels in the post content are wrapped in `<strong>` tags.

### Fixed
- **Chinese character garbling in GBK/GB2312 CSV files** — encoding detection is now performed on the entire file content rather than per cell value. Short GBK byte pairs (e.g. `系` = `0xCF 0xB5`) are accidentally valid UTF-8 sequences (`ϵ`), causing per-value `mb_check_encoding()` to return a false positive and skip conversion. Whole-file detection via `mb_detect_encoding()` in strict mode eliminates these false positives and correctly converts GBK, GB18030, BIG5, and other Chinese encodings to UTF-8 before parsing.

---

## [2.0.0] – Initial release

- Import products from CSV into a configurable WordPress post type.
- Auto-generates post titles from a configurable column formula (`TITLE_FORMULA`).
- Saves every CSV column as post meta (key = lowercased column header).
- Automatic thumbnail and gallery assignment by matching image filenames against a configurable `IMAGE_KEY` column.
- Per-row taxonomy (product category) assignment via `TAXONOMY_COLUMN`.
- Polylang integration — sets default language and pushes meta / gallery to translations.
- Batch import with configurable batch size and offset.
- Duplicate handling modes: skip, update, or allow duplicates.
- Admin UI with CSV preview, import progress, and per-batch AJAX processing.
