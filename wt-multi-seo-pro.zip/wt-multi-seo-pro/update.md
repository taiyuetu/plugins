# WT Multi SEO Pro — Update log

This file records notable plugin changes. New entries go at the top.

---

## Unreleased

### Sitemap reliability (Google Search Console, large catalogs)

**Files:** `includes/class-plseo-sitemap.php`, `includes/class-plseo-activator.php`, `includes/class-plseo-robots.php`

#### `class-plseo-sitemap.php`

- **Output buffers:** Before serving any sitemap response, all active output buffers are discarded so stray PHP notices, BOM, or whitespace from other plugins/themes cannot appear before the XML declaration (which would make the document invalid and can lead to “0 pages discovered” in Google Search Console).
- **Resource limits:** Calls `wp_raise_memory_limit( 'admin' )` when available and raises `set_time_limit` to 300 seconds so very large product sitemaps are less likely to truncate mid-response.
- **Removed `nocache_headers()`** on sitemap requests to avoid mixing no-cache directives (`Pragma`, `Expires: 1984`) with later `Cache-Control: public, max-age=3600`, which can confuse proxies/CDNs.
- **`send_xml_headers()`**
  - Sends explicit HTTP `200` via `status_header( 200 )`.
  - Keeps `Content-Type: application/xml; charset=UTF-8` and `Cache-Control: public, max-age=3600`.
  - Removes `Pragma`, `Expires`, and `X-Robots-Tag` headers so earlier WordPress/plugin headers do not conflict. Sitemaps should not use `X-Robots-Tag: noindex` per Google guidance.
- **`maybe_flush()`** now also checks that the paginated sitemap rewrite rule exists in the stored `rewrite_rules` option (`^sitemap-([a-z0-9_-]+?)(?:-(\d+))?\.xml$`). If it is missing (e.g. after an old activation), rewrite rules are flushed so URLs like `sitemap-product-2.xml` resolve correctly.

#### `class-plseo-activator.php`

- **Activation rewrite rules aligned with runtime:** On plugin activation, registers the same rules as the live `PLSEO_Sitemap` class:
  - `sitemap-xsl.xsl`
  - Paginated pattern `^sitemap-([a-z0-9_-]+?)(?:-(\d+))?\.xml$` mapping to `plseo_sitemap` and `plseo_sitemap_page`
  - `add_rewrite_tag` for both `%plseo_sitemap%` and `%plseo_sitemap_page%`
- Previously, activation only added a non-paginated `sitemap-*.xml` rule, which could leave the database with rules that did not support paginated product/post sitemaps until permalinks were saved again.

#### `class-plseo-robots.php`

- **Per-language `Sitemap:` lines in robots.txt:** When “per-language sitemaps” is enabled, non-default Polylang languages are listed in `robots.txt`. The **default** language is skipped, because those URLs are already covered by the main sitemaps (`sitemap-posts.xml`, `sitemap-product.xml`, etc.), avoiding duplicate `Sitemap:` declarations for the same content.

#### Post-deploy checklist (site operators)

1. **Settings → Permalinks → Save** once to flush rewrite rules if the site never picked up the new rules automatically.
2. Re-submit `sitemap.xml` in Google Search Console and allow time for recrawl.

---

*End of documented updates.*
