<?php
defined( 'ABSPATH' ) || exit;

/**
 * Polylang-aware meta storage and translation sync for CSV imports.
 *
 * Mirrors WP Rapid Fields + theme pll_sync behavior:
 *  - Default language: base key + key_{lang}
 *  - Other languages: key_{lang} only
 *  - After default-language import: push base values to all translation posts
 */
class CPI_Polylang_Sync {

    /** Meta key for product gallery (not in META_MAP). */
    public const GALLERY_KEY = 'product_gallery';

    public static function is_active(): bool {
        return function_exists( 'pll_languages_list' );
    }

    public static function default_language(): string {
        return function_exists( 'pll_default_language' ) ? (string) pll_default_language( 'slug' ) : '';
    }

    public static function is_default_language( string $lang_slug ): bool {
        if ( ! self::is_active() || '' === $lang_slug ) {
            return true;
        }
        return $lang_slug === self::default_language();
    }

    /**
     * Keys synced across translations (uses theme list when available).
     *
     * @return string[]
     */
    public static function get_default_keys(): array {
        if ( function_exists( 'pll_sync_get_default_keys' ) ) {
            return pll_sync_get_default_keys();
        }

        $keys = array_values( CPI_Config::META_MAP );
        $keys[] = self::GALLERY_KEY;

        return array_values( array_unique( $keys ) );
    }

    /**
     * Save all CSV meta fields for the import language.
     */
    public static function save_row_meta( int $post_id, array $row, string $lang_slug ): void {
        foreach ( CPI_Config::META_MAP as $col => $meta_key ) {
            $value = sanitize_textarea_field( $row[ $col ] ?? '' );
            self::write_meta( $post_id, $meta_key, $value, $lang_slug );
        }
    }

    /**
     * Save product gallery attachment IDs.
     */
    public static function save_gallery( int $post_id, array $gallery_ids, string $lang_slug ): void {
        $gallery_ids = array_values( array_filter( array_map( 'intval', $gallery_ids ) ) );
        if ( empty( $gallery_ids ) ) {
            return;
        }

        self::write_meta( $post_id, self::GALLERY_KEY, implode( ',', $gallery_ids ), $lang_slug );
    }

    /**
     * Write one meta value using the correct key(s) for the language.
     */
    public static function write_meta( int $post_id, string $meta_key, string $value, string $lang_slug ): void {
        if ( '' === $meta_key ) {
            return;
        }

        // Allow "0" and other falsy-but-valid stored values; only skip empty strings.
        if ( '' === $value ) {
            return;
        }

        if ( ! self::is_active() || '' === $lang_slug ) {
            update_post_meta( $post_id, $meta_key, $value );
            return;
        }

        if ( self::is_default_language( $lang_slug ) ) {
            update_post_meta( $post_id, $meta_key, $value );
            update_post_meta( $post_id, $meta_key . '_' . $lang_slug, $value );
            return;
        }

        update_post_meta( $post_id, $meta_key . '_' . $lang_slug, $value );
    }

    /**
     * Push default meta keys from a default-language post to all translations.
     * Uses theme pll_sync_push_default_to_lang_keys() when present.
     */
    public static function push_to_translations( int $post_id ): void {
        if ( ! self::is_active() ) {
            return;
        }

        if ( ! function_exists( 'pll_get_post_language' ) || ! function_exists( 'pll_get_post_translations' ) ) {
            return;
        }

        $default_lang = self::default_language();
        if ( '' === $default_lang ) {
            return;
        }

        $post_lang = pll_get_post_language( $post_id );
        if ( $post_lang !== $default_lang ) {
            return;
        }

        if ( function_exists( 'pll_sync_push_default_to_lang_keys' ) ) {
            pll_sync_push_default_to_lang_keys( $post_id, $default_lang );
            return;
        }

        self::push_default_to_lang_keys( $post_id, $default_lang );
    }

    /**
     * Built-in fallback matching theme pll_sync_push_default_to_lang_keys().
     */
    public static function push_default_to_lang_keys( int $source_post_id, string $default_lang ): void {
        if ( ! function_exists( 'pll_get_post_translations' ) ) {
            return;
        }

        $translations = pll_get_post_translations( $source_post_id );
        if ( empty( $translations ) ) {
            return;
        }

        foreach ( self::get_default_keys() as $default_key ) {
            $value = get_post_meta( $source_post_id, $default_key, true );

            if ( '' === $value || false === $value ) {
                continue;
            }

            foreach ( $translations as $lang => $translated_post_id ) {
                update_post_meta( (int) $translated_post_id, $default_key . '_' . $lang, $value );
            }
        }
    }
}
