# CSV Product Importer Pro — Update Log

## Version 1.1.0

### Product category assignment (`product_category`)

- Assign imported products to the **`product_category`** custom taxonomy (theme-registered).
- **Admin default:** In **Import settings → Default product category**, choose a term applied to every row when the CSV category column is empty.
- **Per-row CSV column:** Optional `product_category` column — value can be term **slug**, **name**, or numeric **ID**.
- **Multiple terms:** Separate with comma, pipe, or semicolon (e.g. `wheel-hub-bearings, other-slug`).
- Per-row values override the admin default.
- Works on **insert** and **update**; respects **Polylang** (category dropdown refreshes when language changes).
- Configure in `includes/class-cpi-config.php`: `TAXONOMY`, `TAXONOMY_COLUMN`.

### Chinese / mixed-encoding CSV support

- Fixes **“Content, title, and excerpt are empty”** when Chinese text in `type` / `car_brand` breaks title sanitization but `oem_num` is still valid.
- **UTF-8 BOM** stripped from file start and header row.
- **GBK / GB2312** cell values converted to UTF-8 when detected.
- **Robust title resolution:** Falls back to `oem_num`, then `product_mpn`, if the generated title is emptied by `sanitize_text_field()`.
- Generated titles normalized at parse time so preview and import stay consistent.

### Image / gallery sync fixes

- Broader filename matching (not only `{mpn}(1).jpg`):
  - `TQB2-0001(1).jpg`, `TQB2-0001(2).png` — recommended
  - `TQB2-0001-1.jpg`, `TQB2-0001_2.png` — alternate separators
  - `TQB2-0001.jpg` — single image (counts as sequence 1)
- Featured image: uses sequence `(1)` when present; otherwise the **first** matched image.
- Sets both `set_post_thumbnail()` and `_thumbnail_id`.
- Saves `product_gallery` as comma-separated attachment IDs (WP Rapid Fields format).
- Images must already be in the **Media Library** (plugin does not upload files).
- Re-import existing products with **“Update with new data”** to apply gallery fixes to posts already imported.

### Polylang meta sync on import (automatic)

- New `CPI_Polylang_Sync` class mirrors **WP Rapid Fields** + theme `pll_sync_push_default_to_lang_keys()` behavior.
- **Default language import** (e.g. English):
  - Writes **base** keys (`product_mpn`, `oem_num`, `product_gallery`, …) **and** suffixed keys (`product_mpn_en`, `product_gallery_en`, …).
  - If Polylang translations exist, pushes base values to **every** linked post as `key_{lang}` on all languages (same as manual bulk sync).
- **Non-default language import** (e.g. Chinese):
  - Writes **suffixed keys only** (`product_mpn_zh`, `product_gallery_zh`, …) — matches theme admin expectations.
- Uses theme `pll_sync_get_default_keys()` when available; otherwise syncs `META_MAP` fields + `product_gallery`.
- Language is assigned **before** meta is saved.
- Duplicate detection searches both `oem_num` and `oem_num_{lang}` when a language is selected.
- **Tip:** Select the import language in settings; re-import with **Update** to fix posts imported before this fix.

### Danger zone: delete products by category

- **Delete products in category** — remove all products in a selected `product_category` term (includes child categories).
- Batched deletion with progress bar (50 per request).
- Separate from **Delete all products** (site-wide).

### Danger zone: delete by category + language (multilingual)

- When **Polylang** is active, choose **language** and **category** before deleting.
- Only products in that **category and language** are removed; other languages are untouched.
- Category dropdown refreshes when language changes.
- Language is required on multilingual sites.

### Sample CSV

- `sample.csv` includes optional `product_category` column example.

---

## CSV requirements (quick reference)

| Column | Required | Notes |
|--------|----------|--------|
| `type` | Yes | Title only (not saved as meta) |
| `product_mpn` | Yes | Also used for image filename matching |
| `oem_num` | Yes | Unique key for duplicate detection |
| `cross_ref` | Yes | |
| `car_brand` | Yes | Used in title formula |
| `car_application` | Yes | |
| `outer_diameter` | Yes | |
| `weight` | Yes | |
| `product_category` | No | Slug, name, or term ID |

**Headers must be English** (`oem_num`, not 原厂号).

**Encoding:** Save as **CSV UTF-8** from Excel when using Chinese in `type` or `car_brand`.

**Title formula:** `oem_num` + `type` + `for` + `car_brand` (see `TITLE_FORMULA` in config).

---

## Files changed in 1.1.0

- `csv-product-importer.php` — loads `class-cpi-polylang-sync.php`
- `includes/class-cpi-config.php` — taxonomy constants and term helpers
- `includes/class-cpi-polylang-sync.php` — **new** Polylang meta write + translation push
- `includes/class-cpi-importer.php` — category, title, gallery, `persist_product_data()`, suffixed duplicate lookup
- `includes/class-cpi-csv-parser.php` — UTF-8 / encoding handling
- `includes/class-cpi-ajax.php` — category options, import category param, delete by category (+ language)
- `templates/admin-page.php` — import category dropdown, danger-zone delete UI, column reference
- `admin/class-cpi-admin.php` — Polylang i18n strings, `has_polylang` flag
- `admin/js/admin.js` — category import, delete-by-category batches, language filter
- `admin/css/admin.css` — taxonomy badge, danger-zone layout
- `sample.csv` — `product_category` example column

---

## Version 1.0.0

- CSV upload and batch import for `product` post type
- Smart title generation from configurable columns
- Meta field mapping via `META_MAP`
- Duplicate handling: skip, update, or duplicate
- Polylang language assignment
- Media Library image matching by `product_mpn` filename pattern
- Admin preview (first 10 rows) and import statistics
