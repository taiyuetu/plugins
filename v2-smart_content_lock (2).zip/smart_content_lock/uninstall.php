<?php
/**
 * Uninstall Smart Content Lock.
 *
 * @package Smart_Content_Lock
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'scl_emails' );
