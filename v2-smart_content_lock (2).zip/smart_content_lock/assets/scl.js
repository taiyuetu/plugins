/**
 * Smart Content Lock — front-end behavior
 */
(function ($) {
	'use strict';

	var STORAGE_PREFIX = 'scl_unlocked_';

	function getPageScrollPercent() {
		var doc = $(document);
		var win = $(window);
		var scrollable = doc.height() - win.height();
		if (scrollable <= 0) {
			return 100;
		}
		return (win.scrollTop() / scrollable) * 100;
	}

	function unlockContent($container) {
		var key = $container.attr('data-storage-key');
		if (!key) {
			return;
		}
		$container.addClass('scl-unlocked');
		$container.find('.scl-content').attr('aria-hidden', 'false');
		try {
			localStorage.setItem(STORAGE_PREFIX + key, '1');
		} catch (e) {
			/* private mode or quota */
		}
	}

	function updateScrollLocks() {
		var pct = getPageScrollPercent();
		$('.scl-container[data-type="scroll"]').not('.scl-unlocked').each(function () {
			var $c = $(this);
			var need = parseInt($c.attr('data-scroll'), 10) || 50;
			$c.find('.scl-progress-bar').css('width', Math.min(pct, 100) + '%');
			if (pct >= need) {
				unlockContent($c);
			}
		});
		if (!$('.scl-container[data-type="scroll"]').not('.scl-unlocked').length) {
			$(window).off('scroll.sclSmartLock');
		}
	}

	function bindScrollUnlock() {
		if (!$('.scl-container[data-type="scroll"]').not('.scl-unlocked').length) {
			return;
		}
		$(window).off('scroll.sclSmartLock').on('scroll.sclSmartLock', updateScrollLocks);
	}

	function handleEmail($container) {
		$container.find('.scl-email-form').on('submit', function (e) {
			e.preventDefault();
			var email = $(this).find('input[type="email"]').val();
			$.post(
				scl_ajax.ajax_url,
				{
					action: 'scl_email_unlock',
					email: email,
					nonce: scl_ajax.nonce,
				},
				function (response) {
					if (response && response.success) {
						unlockContent($container);
					} else {
						var msg =
							response && response.data && response.data.message
								? response.data.message
								: typeof scl_ajax.i18n_error === 'string'
									? scl_ajax.i18n_error
									: 'Request failed.';
						window.alert(msg);
					}
				}
			).fail(function () {
				var msg = typeof scl_ajax.i18n_error === 'string' ? scl_ajax.i18n_error : 'Request failed.';
				window.alert(msg);
			});
		});
	}

	function handleSocial($container) {
		$container.find('.scl-social-btn').on('click', function () {
			window.setTimeout(function () {
				unlockContent($container);
			}, 2000);
		});
	}

	function handleTimer($container) {
		var timer = parseInt($container.attr('data-timer'), 10) || 30;
		var $countdown = $container.find('.scl-countdown');
		var interval = window.setInterval(function () {
			timer -= 1;
			$countdown.text(timer);
			if (timer <= 0) {
				window.clearInterval(interval);
				unlockContent($container);
			}
		}, 1000);
	}

	$(function () {
		var needsScrollListener = false;

		$('.scl-container').each(function () {
			var $container = $(this);
			var type = $container.data('type');
			var key = $container.attr('data-storage-key');

			if (key) {
				try {
					if (localStorage.getItem(STORAGE_PREFIX + key)) {
						$container.addClass('scl-unlocked');
						$container.find('.scl-content').attr('aria-hidden', 'false');
						return;
					}
				} catch (e) {
					/* ignore */
				}
			}

			switch (type) {
				case 'scroll':
					needsScrollListener = true;
					break;
				case 'email':
					handleEmail($container);
					break;
				case 'social':
					handleSocial($container);
					break;
				case 'timer':
					handleTimer($container);
					break;
				default:
					break;
			}
		});

		updateScrollLocks();
		if (needsScrollListener) {
			bindScrollUnlock();
		}
	});
})(jQuery);
