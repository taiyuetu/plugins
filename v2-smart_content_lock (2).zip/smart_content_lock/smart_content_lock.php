<?php
/**
 * Plugin Name:       Smart Content Lock
 * Description:       Lock content until the visitor scrolls, waits, shares, or subscribes by email.
 * Version:           1.1.0
 * Author:            Pro WordPress Developer
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       smart-content-lock
 * Domain Path:       /languages
 *
 * @package Smart_Content_Lock
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SCL_VERSION', '1.1.0' );
define( 'SCL_PLUGIN_FILE', __FILE__ );
define( 'SCL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class.
 */
class Smart_Content_Lock {

	/**
	 * Shortcode and internal prefix.
	 *
	 * @var string
	 */
	private $prefix = 'scl';

	/**
	 * CSS class prefix.
	 *
	 * @var string
	 */
	private $css_prefix = 'scl';

	/**
	 * Per-request counter for default storage keys (stable for the same page order).
	 *
	 * @var int
	 */
	private static $shortcode_instance = 0;

	/**
	 * Whether front assets should load this request.
	 *
	 * @var bool
	 */
	private static $should_enqueue_assets = false;

	/**
	 * Whether front scripts/styles were enqueued (guards duplicate localize).
	 *
	 * @var bool
	 */
	private static $front_assets_enqueued = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_from_main_query' ), 20 );
		add_filter( 'the_posts', array( $this, 'flag_enqueue_from_posts' ), 10, 2 );
		add_action( 'wp_ajax_scl_email_unlock', array( $this, 'handle_email_unlock' ) );
		add_action( 'wp_ajax_nopriv_scl_email_unlock', array( $this, 'handle_email_unlock' ) );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
	}

	/**
	 * Register shortcode on init (after textdomain).
	 */
	public function register_shortcode() {
		load_plugin_textdomain( 'smart-content-lock', false, dirname( plugin_basename( SCL_PLUGIN_FILE ) ) . '/languages' );
		add_shortcode( $this->prefix . '_lock', array( $this, 'content_lock_shortcode' ) );
	}

	/**
	 * Detect shortcode in post content so scripts load only when needed.
	 *
	 * @param WP_Post[] $posts    Posts.
	 * @param WP_Query  $query Query.
	 * @return WP_Post[]
	 */
	public function flag_enqueue_from_posts( $posts, $query ) {
		if ( ! $query->is_main_query() || is_admin() || empty( $posts ) ) {
			return $posts;
		}
		$tag = $this->prefix . '_lock';
		foreach ( $posts as $post ) {
			if ( $post instanceof WP_Post && has_shortcode( $post->post_content, $tag ) ) {
				self::$should_enqueue_assets = true;
				break;
			}
		}
		return $posts;
	}

	/**
	 * Shortcode callback may run outside the_posts (widgets, etc.).
	 *
	 * @param array  $atts    Shortcode attributes.
	 * @param string $content Enclosed content.
	 * @return string
	 */
	public function content_lock_shortcode( $atts, $content = '' ) {
		if ( is_feed() ) {
			return do_shortcode( $content );
		}
		$this->enqueue_front_assets();
		return $this->render_content_lock( $atts, $content );
	}

	/**
	 * Early enqueue when the main query post content contains the shortcode.
	 */
	public function maybe_enqueue_from_main_query() {
		if ( ! self::$should_enqueue_assets ) {
			return;
		}
		$this->enqueue_front_assets();
	}

	/**
	 * Register front-end script and style (safe to call from shortcode after wp_enqueue_scripts).
	 */
	private function enqueue_front_assets() {
		if ( self::$front_assets_enqueued ) {
			return;
		}
		self::$front_assets_enqueued = true;

		$css_path = SCL_PLUGIN_DIR . 'assets/scl.css';
		$js_path  = SCL_PLUGIN_DIR . 'assets/scl.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : SCL_VERSION;
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : SCL_VERSION;

		wp_enqueue_script(
			'scl-script',
			SCL_PLUGIN_URL . 'assets/scl.js',
			array( 'jquery' ),
			$js_ver,
			true
		);
		wp_enqueue_style(
			'scl-style',
			SCL_PLUGIN_URL . 'assets/scl.css',
			array(),
			$css_ver
		);

		wp_localize_script(
			'scl-script',
			'scl_ajax',
			array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'scl_nonce' ),
				'i18n_error' => __( 'Something went wrong. Please try again.', 'smart-content-lock' ),
			)
		);
	}

	/**
	 * Render locked content markup.
	 *
	 * @param array  $atts    Attributes.
	 * @param string $content Inner content.
	 * @return string
	 */
	private function render_content_lock( $atts, $content = '' ) {
		$atts = shortcode_atts(
			array(
				'type'           => 'scroll',
				'scroll_percent' => '50',
				'timer'          => '30',
				'social'         => 'twitter,facebook,linkedin',
				'title'          => __( 'Unlock content', 'smart-content-lock' ),
				'description'    => __( 'Complete the action below to unlock this content.', 'smart-content-lock' ),
				'lock_key'       => '',
			),
			$atts,
			$this->prefix . '_lock'
		);

		$type = sanitize_key( $atts['type'] );
		if ( ! in_array( $type, array( 'scroll', 'email', 'social', 'timer' ), true ) ) {
			$type = 'scroll';
		}

		$scroll_percent = max( 1, min( 100, absint( $atts['scroll_percent'] ) ) );
		$timer          = max( 1, min( 3600, absint( $atts['timer'] ) ) );

		self::$shortcode_instance++;

		$post_id = (int) get_the_ID();

		$storage_key = $this->build_storage_key( $atts['lock_key'], $type, $content, $post_id );

		$dom_id = function_exists( 'wp_unique_id' )
			? wp_unique_id( 'scl-lock-' )
			: 'scl-lock-' . wp_generate_password( 8, false, false );

		$social_networks = array_filter(
			array_map(
				'sanitize_key',
				array_map( 'trim', explode( ',', (string) $atts['social'] ) )
			)
		);

		$social_links = array();
		foreach ( $social_networks as $network ) {
			$share_url = $this->get_share_url( $network );
			if ( '#' !== $share_url ) {
				$social_links[] = array(
					'network'   => $network,
					'share_url' => $share_url,
				);
			}
		}

		$title       = $atts['title'];
		$description = $atts['description'];

		ob_start();
		?>
		<div
			class="<?php echo esc_attr( $this->css_prefix ); ?>-container"
			id="<?php echo esc_attr( $dom_id ); ?>"
			data-type="<?php echo esc_attr( $type ); ?>"
			data-scroll="<?php echo esc_attr( (string) $scroll_percent ); ?>"
			data-timer="<?php echo esc_attr( (string) $timer ); ?>"
			data-storage-key="<?php echo esc_attr( $storage_key ); ?>"
		>
			<div class="<?php echo esc_attr( $this->css_prefix ); ?>-overlay">
				<div class="<?php echo esc_attr( $this->css_prefix ); ?>-lock-box">
					<h3><?php echo esc_html( $title ); ?></h3>
					<p><?php echo esc_html( $description ); ?></p>

					<?php if ( 'email' === $type ) : ?>
						<form class="<?php echo esc_attr( $this->css_prefix ); ?>-email-form" novalidate>
							<label class="<?php echo esc_attr( $this->css_prefix ); ?>-sr-only" for="<?php echo esc_attr( $dom_id ); ?>-email">
								<?php esc_html_e( 'Email address', 'smart-content-lock' ); ?>
							</label>
							<input
								id="<?php echo esc_attr( $dom_id ); ?>-email"
								type="email"
								name="scl_email"
								autocomplete="email"
								placeholder="<?php esc_attr_e( 'Enter your email', 'smart-content-lock' ); ?>"
								required
							>
							<button type="submit"><?php esc_html_e( 'Unlock content', 'smart-content-lock' ); ?></button>
						</form>
					<?php elseif ( 'social' === $type ) : ?>
						<?php if ( empty( $social_links ) ) : ?>
							<p><?php esc_html_e( 'No supported social networks were configured for this lock.', 'smart-content-lock' ); ?></p>
						<?php else : ?>
							<div class="<?php echo esc_attr( $this->css_prefix ); ?>-social-buttons">
								<?php
								foreach ( $social_links as $item ) :
									$network   = $item['network'];
									$share_url = $item['share_url'];
									/* translators: %s: social network name */
									$label = sprintf( __( 'Share on %s', 'smart-content-lock' ), ucfirst( $network ) );
									?>
									<a
										href="<?php echo esc_url( $share_url ); ?>"
										class="<?php echo esc_attr( $this->css_prefix . '-social-btn ' . $this->css_prefix . '-' . $network ); ?>"
										target="_blank"
										rel="noopener noreferrer"
									><?php echo esc_html( $label ); ?></a>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					<?php elseif ( 'scroll' === $type ) : ?>
						<p>
							<?php
							echo esc_html(
								sprintf(
									/* translators: %d: scroll percentage */
									__( 'Scroll down %d%% of the page to unlock.', 'smart-content-lock' ),
									$scroll_percent
								)
							);
							?>
						</p>
						<div class="<?php echo esc_attr( $this->css_prefix ); ?>-progress">
							<div class="<?php echo esc_attr( $this->css_prefix ); ?>-progress-bar"></div>
						</div>
					<?php elseif ( 'timer' === $type ) : ?>
						<p>
							<?php esc_html_e( 'Wait', 'smart-content-lock' ); ?>
							<span class="<?php echo esc_attr( $this->css_prefix ); ?>-countdown"><?php echo esc_html( (string) $timer ); ?></span>
							<?php esc_html_e( 'seconds', 'smart-content-lock' ); ?>
						</p>
					<?php endif; ?>
				</div>
			</div>
			<div class="<?php echo esc_attr( $this->css_prefix ); ?>-content" style="display:none;" aria-hidden="true">
				<?php echo do_shortcode( $content ); ?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Stable key for localStorage (survives refresh). Use lock_key for full control.
	 *
	 * @param string $lock_key_attr User-defined key.
	 * @param string $type          Lock type.
	 * @param string $content       Shortcode inner content.
	 * @param int    $post_id       Post ID.
	 * @return string
	 */
	private function build_storage_key( $lock_key_attr, $type, $content, $post_id ) {
		$user_key = sanitize_key( (string) $lock_key_attr );
		if ( '' !== $user_key ) {
			return substr( $user_key, 0, 64 );
		}

		$base = (string) $post_id . '|' . (string) self::$shortcode_instance . '|' . $type . '|' . wp_hash( $content );
		return 'auto_' . substr( md5( $base ), 0, 32 );
	}

	/**
	 * Share URL for a known network.
	 *
	 * @param string $network Network slug.
	 * @return string URL or "#" if unknown.
	 */
	private function get_share_url( $network ) {
		$url   = rawurlencode( (string) $this->get_share_context_url() );
		$title = rawurlencode( (string) $this->get_share_context_title() );

		switch ( $network ) {
			case 'twitter':
				return 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title;
			case 'facebook':
				return 'https://www.facebook.com/sharer/sharer.php?u=' . $url;
			case 'linkedin':
				return 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url;
			default:
				return '#';
		}
	}

	/**
	 * URL used in share links (single post preferred, else current request).
	 *
	 * @return string
	 */
	private function get_share_context_url() {
		if ( is_singular() ) {
			$permalink = get_permalink();
			if ( $permalink ) {
				return $permalink;
			}
		}
		$canonical = wp_get_canonical_url();
		if ( is_string( $canonical ) && '' !== $canonical ) {
			return $canonical;
		}
		global $wp;
		if ( isset( $wp->request ) && is_string( $wp->request ) && '' !== $wp->request ) {
			return home_url( user_trailingslashit( $wp->request ) );
		}
		return home_url( '/' );
	}

	/**
	 * Title for share text.
	 *
	 * @return string
	 */
	private function get_share_context_title() {
		if ( is_singular() ) {
			$t = get_the_title();
			if ( $t ) {
				return $t;
			}
		}
		return wp_get_document_title();
	}

	/**
	 * AJAX: validate email and record opt-in.
	 */
	public function handle_email_unlock() {
		check_ajax_referer( 'scl_nonce', 'nonce' );

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $email ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please enter a valid email address.', 'smart-content-lock' ),
				),
				400
			);
		}

		$stored = get_option( 'scl_emails', array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$stored[] = $email;
		$stored   = array_values( array_unique( array_filter( $stored, 'is_email' ) ) );

		$max = (int) apply_filters( 'scl_max_stored_emails', 5000 );
		if ( $max > 0 && count( $stored ) > $max ) {
			$stored = array_slice( $stored, -$max );
		}

		update_option( 'scl_emails', $stored, false );

		wp_send_json_success(
			array(
				'message' => __( 'Content unlocked.', 'smart-content-lock' ),
			)
		);
	}

	/**
	 * Settings / usage page under Settings.
	 */
	public function admin_menu() {
		add_options_page(
			__( 'Smart Content Lock', 'smart-content-lock' ),
			__( 'Content Lock', 'smart-content-lock' ),
			'manage_options',
			'smart-content-lock',
			array( $this, 'admin_page' )
		);
	}

	/**
	 * Admin usage + collected emails.
	 */
	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$emails = get_option( 'scl_emails', array() );
		if ( ! is_array( $emails ) ) {
			$emails = array();
		}
		$emails = array_values( array_unique( array_filter( $emails, 'is_email' ) ) );
		$tag    = esc_html( $this->prefix . '_lock' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Smart Content Lock', 'smart-content-lock' ); ?></h1>
			<p><?php esc_html_e( 'Use the shortcode below in posts, pages, or block editor (Shortcode block).', 'smart-content-lock' ); ?></p>

			<h2><?php esc_html_e( 'Usage examples', 'smart-content-lock' ); ?></h2>
			<p>
				<code>[<?php echo $tag; ?> type="scroll" scroll_percent="70"]<?php esc_html_e( 'Your locked content here', 'smart-content-lock' ); ?>[/<?php echo $tag; ?>]</code>
			</p>
			<p>
				<code>[<?php echo $tag; ?> type="email" lock_key="lead-magnet-1" title="Subscribe to unlock"]<?php esc_html_e( 'Premium content', 'smart-content-lock' ); ?>[/<?php echo $tag; ?>]</code>
			</p>
			<p>
				<code>[<?php echo $tag; ?> type="social" social="twitter,facebook"]<?php esc_html_e( 'Exclusive content', 'smart-content-lock' ); ?>[/<?php echo $tag; ?>]</code>
			</p>
			<p>
				<code>[<?php echo $tag; ?> type="timer" timer="60"]<?php esc_html_e( 'Time-locked content', 'smart-content-lock' ); ?>[/<?php echo $tag; ?>]</code>
			</p>

			<h2><?php echo esc_html( sprintf( /* translators: %d: email count */ __( 'Collected emails (%d)', 'smart-content-lock' ), count( $emails ) ) ); ?></h2>
			<?php if ( ! empty( $emails ) ) : ?>
				<label for="scl-email-export" class="screen-reader-text"><?php esc_html_e( 'Collected email addresses', 'smart-content-lock' ); ?></label>
				<textarea id="scl-email-export" readonly class="large-text code" rows="10"><?php echo esc_textarea( implode( "\n", $emails ) ); ?></textarea>
			<?php else : ?>
				<p><?php esc_html_e( 'No emails collected yet.', 'smart-content-lock' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}

new Smart_Content_Lock();

/**
 * On activation, ensure assets directory exists (files ship with the plugin).
 */
register_activation_hook(
	SCL_PLUGIN_FILE,
	function () {
		$assets_dir = SCL_PLUGIN_DIR . 'assets';
		if ( ! file_exists( $assets_dir ) ) {
			wp_mkdir_p( $assets_dir );
		}
	}
);
