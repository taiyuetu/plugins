/**
 * DeepSeek Translation meta box — single post translate button.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var box = document.getElementById( 'dsap-translation-box' );
		if ( ! box ) {
			return;
		}

		var btn      = document.getElementById( 'dsap-translate-btn' );
		var select   = document.getElementById( 'dsap-target-lang' );
		var statusEl = document.getElementById( 'dsap-status' );
		var postId   = parseInt( box.dataset.postId, 10 );

		if ( ! btn || ! select || ! statusEl || ! postId ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			var targetLang = select.value;
			if ( ! targetLang ) {
				return;
			}

			setLoading( true );
			showStatus( 'info', DsapTranslation.i18n.translating );

			fetch( DsapTranslation.restUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce':   DsapTranslation.nonce,
				},
				body: JSON.stringify( {
					post_id:         postId,
					target_language: targetLang,
				} ),
			} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					if ( ! response.ok ) {
						throw new Error( data.message || response.statusText );
					}
					return data;
				} );
			} )
			.then( function ( data ) {
				var message  = data.is_new
					? DsapTranslation.i18n.success
					: DsapTranslation.i18n.updated;
				var editLink = ' <a href="' + escHtml( data.edit_url ) + '" target="_blank" rel="noopener">'
					+ DsapTranslation.i18n.editLink + ' &rarr;</a>';
				showStatus( 'success', message + editLink );
			} )
			.catch( function ( err ) {
				showStatus( 'error', DsapTranslation.i18n.error + escHtml( err.message ) );
			} )
			.finally( function () {
				setLoading( false );
			} );
		} );

		function setLoading( loading ) {
			btn.disabled = loading;
			btn.classList.toggle( 'dsap-is-loading', loading );
		}

		function showStatus( type, html ) {
			statusEl.className = 'dsap-status dsap-status--' + type;
			statusEl.innerHTML = html;
		}

		function escHtml( str ) {
			var d = document.createElement( 'div' );
			d.appendChild( document.createTextNode( String( str ) ) );
			return d.innerHTML;
		}
	} );
}() );
