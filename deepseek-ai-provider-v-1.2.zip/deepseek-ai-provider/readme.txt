=== DeepSeek AI Provider ===
Contributors: sanjiewp
Tags: deepseek, ai, translation, polylang, bulk-translate
Requires at least: 6.9
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

DeepSeek AI provider for the WordPress AI Client SDK with full Polylang bulk translation support.

== Description ==

**DeepSeek AI Provider** connects DeepSeek's powerful AI models to WordPress through the native AI Client SDK and Connectors framework. It also adds a complete Polylang translation workflow — translate individual posts from the editor or bulk-translate hundreds of posts, products, and categories with one click.

= Features =

* **WordPress AI Client Integration** — Registers DeepSeek as a first-class AI provider so all WordPress AI features (Suggest Tags, Summarization, etc.) can use DeepSeek models.
* **Native Connector Support** — Works with WordPress Settings → Connectors for secure API key management.
* **Single Post Translation** — "DeepSeek Translation" meta box in the post editor: pick a target language and translate instantly.
* **Bulk Translation** — Dedicated admin page (Tools → Bulk Translate) to scan and translate all untranslated:
  * Posts
  * Pages
  * WooCommerce Products
  * Custom Post Types
  * Categories, Tags, and Custom Taxonomies
* **Polylang Integration** — Automatically links translations, copies taxonomy terms, syncs meta fields, and preserves featured images.
* **Race-Condition Safe** — Uses MySQL GET_LOCK for concurrent translation safety.
* **HTML Preservation** — Translates visible text while preserving all HTML, block comments, and shortcodes.

= Requirements =

* WordPress 6.9+ (with AI Client SDK)
* PHP 7.4+
* [Polylang](https://wordpress.org/plugins/polylang/) for translation features
* A [DeepSeek API key](https://platform.deepseek.com)

== Installation ==

1. Upload the `deepseek-ai-provider` folder to `/wp-content/plugins/`.
2. Activate through the Plugins menu.
3. Go to **Settings → Connectors** and add your DeepSeek API key.
4. For bulk translation, go to **Tools → Bulk Translate**.

== Changelog ==

= 1.0.0 =
* Initial release.
* WordPress AI Client SDK provider registration.
* Single post translation via meta box.
* Bulk translation page for posts, products, and taxonomy terms.
* Full Polylang integration with taxonomy sync and meta sync.
