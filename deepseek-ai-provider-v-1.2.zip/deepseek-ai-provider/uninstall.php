<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package DeepSeekAiProvider
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	die;
}

delete_option( 'dsap_deepseek_api_key' );
