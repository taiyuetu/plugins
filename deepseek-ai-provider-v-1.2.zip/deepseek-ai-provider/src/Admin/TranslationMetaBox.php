<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Admin;

use DeepSeekAiProvider\Translation\PolylangHelper;
use DeepSeekAiProvider\Translation\PostTranslator;

/**
 * "DeepSeek Translation" meta box in the post editor sidebar.
 */
class TranslationMetaBox {

	public function register(): void {
		add_action( 'add_meta_boxes', array( $this, 'addMetaBox' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueueAssets' ) );
	}

	public function addMetaBox(): void {
		if ( ! PolylangHelper::isActive() ) {
			return;
		}

		$post_types = get_post_types( array( 'public' => true ) );

		foreach ( $post_types as $post_type ) {
			add_meta_box(
				'dsap_translation',
				__( 'DeepSeek Translation', 'deepseek-ai-provider' ),
				array( $this, 'renderMetaBox' ),
				$post_type,
				'side',
				'default'
			);
		}
	}

	public function renderMetaBox( \WP_Post $post ): void {
		if ( ! PostTranslator::isAvailable() ) {
			$connectors_url = admin_url( 'options-general.php?page=wp-connectors' );
			echo '<p class="dsap-notice dsap-notice--warning">' .
				sprintf(
					esc_html__( 'DeepSeek is not configured. Add your API key at %s.', 'deepseek-ai-provider' ),
					'<a href="' . esc_url( $connectors_url ) . '">' . esc_html__( 'Settings > Connectors', 'deepseek-ai-provider' ) . '</a>'
				) .
				'</p>';
			return;
		}

		$all_languages = PolylangHelper::getLanguages();
		$source_lang   = PolylangHelper::getPostLanguage( $post->ID );

		$target_languages = array();
		foreach ( $all_languages as $slug => $name ) {
			if ( $slug !== $source_lang ) {
				$target_languages[ $slug ] = $name;
			}
		}

		if ( empty( $target_languages ) ) {
			echo '<p class="dsap-notice">' . esc_html__( 'Add more languages in Polylang to enable translation.', 'deepseek-ai-provider' ) . '</p>';
			return;
		}

		if ( empty( $source_lang ) ) {
			echo '<p class="dsap-notice dsap-notice--warning">' . esc_html__( 'Set a language for this post in Polylang first.', 'deepseek-ai-provider' ) . '</p>';
		}
		?>
		<div id="dsap-translation-box" data-post-id="<?php echo esc_attr( (string) $post->ID ); ?>">

			<?php if ( ! empty( $source_lang ) && isset( $all_languages[ $source_lang ] ) ) : ?>
			<p class="dsap-source-lang">
				<span class="dsap-label"><?php esc_html_e( 'Source language', 'deepseek-ai-provider' ); ?></span>
				<strong><?php echo esc_html( $all_languages[ $source_lang ] ); ?></strong>
			</p>
			<?php endif; ?>

			<label class="dsap-label" for="dsap-target-lang">
				<?php esc_html_e( 'Translate to', 'deepseek-ai-provider' ); ?>
			</label>
			<select id="dsap-target-lang" name="dsap_target_lang" class="widefat">
				<?php foreach ( $target_languages as $slug => $name ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
				<?php endforeach; ?>
			</select>

			<p class="dsap-hint">
				<?php esc_html_e( 'Save the post before translating to ensure the latest content is used.', 'deepseek-ai-provider' ); ?>
			</p>

			<button type="button" id="dsap-translate-btn" class="button button-primary dsap-translate-btn">
				<span class="dsap-btn-label"><?php esc_html_e( 'Translate with DeepSeek', 'deepseek-ai-provider' ); ?></span>
				<span class="dsap-spinner" aria-hidden="true"></span>
			</button>

			<div id="dsap-status" role="status" aria-live="polite"></div>
		</div>
		<?php
	}

	public function enqueueAssets( string $hook ): void {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		if ( ! PolylangHelper::isActive() ) {
			return;
		}

		wp_enqueue_style(
			'dsap-translation',
			DSAP_PLUGIN_URL . 'assets/css/translation.css',
			array(),
			DSAP_VERSION
		);

		wp_enqueue_script(
			'dsap-translation',
			DSAP_PLUGIN_URL . 'assets/js/translation.js',
			array(),
			DSAP_VERSION,
			true
		);

		wp_localize_script(
			'dsap-translation',
			'DsapTranslation',
			array(
				'restUrl' => esc_url_raw( rest_url( 'deepseek-ai-provider/v1/translate' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'translating' => __( 'Translating... this may take up to a minute for long posts.', 'deepseek-ai-provider' ),
					'success'     => __( 'Translation published successfully!', 'deepseek-ai-provider' ),
					'updated'     => __( 'Existing translation updated!', 'deepseek-ai-provider' ),
					'editLink'    => __( 'Edit translated post', 'deepseek-ai-provider' ),
					'error'       => __( 'Translation failed: ', 'deepseek-ai-provider' ),
				),
			)
		);
	}
}
