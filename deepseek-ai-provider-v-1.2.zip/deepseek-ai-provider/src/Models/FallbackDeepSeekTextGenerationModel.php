<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Models;

use DeepSeekAiProvider\Provider\DeepSeekProvider;
use WordPress\AiClient\Common\Exception\RuntimeException;
use WordPress\AiClient\Messages\DTO\Message;
use WordPress\AiClient\Messages\DTO\MessagePart;
use WordPress\AiClient\Messages\DTO\ModelMessage;
use WordPress\AiClient\Providers\DTO\ProviderMetadata;
use WordPress\AiClient\Providers\Http\Contracts\WithHttpTransporterInterface;
use WordPress\AiClient\Providers\Http\Contracts\WithRequestAuthenticationInterface;
use WordPress\AiClient\Providers\Http\DTO\Request;
use WordPress\AiClient\Providers\Http\DTO\RequestOptions;
use WordPress\AiClient\Providers\Http\Enums\HttpMethodEnum;
use WordPress\AiClient\Providers\Http\Traits\WithHttpTransporterTrait;
use WordPress\AiClient\Providers\Http\Traits\WithRequestAuthenticationTrait;
use WordPress\AiClient\Providers\Http\Util\ResponseUtil;
use WordPress\AiClient\Providers\Models\Contracts\ModelInterface;
use WordPress\AiClient\Providers\Models\DTO\ModelConfig;
use WordPress\AiClient\Providers\Models\DTO\ModelMetadata;
use WordPress\AiClient\Providers\Models\TextGeneration\Contracts\TextGenerationModelInterface;
use WordPress\AiClient\Results\DTO\Candidate;
use WordPress\AiClient\Results\DTO\GenerativeAiResult;
use WordPress\AiClient\Results\DTO\TokenUsage;
use WordPress\AiClient\Results\Enums\FinishReasonEnum;

/**
 * Fallback for WordPress installations without AbstractOpenAiCompatibleTextGenerationModel.
 */
class FallbackDeepSeekTextGenerationModel implements
	ModelInterface,
	TextGenerationModelInterface,
	WithHttpTransporterInterface,
	WithRequestAuthenticationInterface {

	use WithHttpTransporterTrait;
	use WithRequestAuthenticationTrait;

	private ModelMetadata $modelMetadata;
	private ProviderMetadata $providerMetadata;
	private ModelConfig $config;
	private ?RequestOptions $requestOptions = null;

	public function __construct( ModelMetadata $modelMetadata, ProviderMetadata $providerMetadata ) {
		$this->modelMetadata    = $modelMetadata;
		$this->providerMetadata = $providerMetadata;
		$this->config           = ModelConfig::fromArray( array() );
	}

	public function metadata(): ModelMetadata {
		return $this->modelMetadata;
	}

	public function providerMetadata(): ProviderMetadata {
		return $this->providerMetadata;
	}

	public function setConfig( ModelConfig $config ): void {
		$this->config = $config;
	}

	public function getConfig(): ModelConfig {
		return $this->config;
	}

	public function setRequestOptions( RequestOptions $requestOptions ): void {
		$this->requestOptions = $requestOptions;
	}

	public function getRequestOptions(): ?RequestOptions {
		return $this->requestOptions;
	}

	public function generateTextResult( array $prompt ): GenerativeAiResult {
		$params  = $this->buildRequestParams( $prompt );
		$request = new Request(
			HttpMethodEnum::POST(),
			DeepSeekProvider::url( 'chat/completions' ),
			array( 'Content-Type' => 'application/json' ),
			$params,
			$this->requestOptions
		);

		$request  = $this->getRequestAuthentication()->authenticateRequest( $request );
		$response = $this->getHttpTransporter()->send( $request );

		ResponseUtil::throwIfNotSuccessful( $response );

		$data = $response->getData();

		if ( ! isset( $data['choices'][0]['message']['content'] ) ) {
			throw new RuntimeException( 'DeepSeek API returned an unexpected response format.' );
		}

		$text         = (string) $data['choices'][0]['message']['content'];
		$finishReason = $data['choices'][0]['finish_reason'] ?? 'stop';
		$usage        = $data['usage'] ?? array();

		$candidate = new Candidate(
			new ModelMessage( array( new MessagePart( $text ) ) ),
			$this->mapFinishReason( (string) $finishReason )
		);

		$tokenUsage = new TokenUsage(
			(int) ( $usage['prompt_tokens'] ?? 0 ),
			(int) ( $usage['completion_tokens'] ?? 0 ),
			(int) ( $usage['total_tokens'] ?? 0 )
		);

		return new GenerativeAiResult(
			(string) ( $data['id'] ?? uniqid( 'deepseek_', true ) ),
			array( $candidate ),
			$tokenUsage,
			$this->providerMetadata,
			$this->modelMetadata
		);
	}

	private function buildRequestParams( array $prompt ): array {
		$config   = $this->config;
		$messages = array();

		$systemInstruction = $config->getSystemInstruction();
		if ( $systemInstruction !== null ) {
			$messages[] = array(
				'role'    => 'system',
				'content' => $systemInstruction,
			);
		}

		foreach ( $prompt as $message ) {
			$role    = $message->getRole()->isModel() ? 'assistant' : 'user';
			$content = $this->extractTextFromParts( $message->getParts() );
			if ( '' !== $content ) {
				$messages[] = array(
					'role'    => $role,
					'content' => $content,
				);
			}
		}

		$params = array(
			'model'    => $this->modelMetadata->getId(),
			'messages' => $messages,
		);

		if ( $config->getTemperature() !== null ) {
			$params['temperature'] = $config->getTemperature();
		}
		if ( $config->getMaxTokens() !== null ) {
			$params['max_tokens'] = $config->getMaxTokens();
		}
		if ( $config->getTopP() !== null ) {
			$params['top_p'] = $config->getTopP();
		}
		if ( $config->getStopSequences() !== null ) {
			$params['stop'] = $config->getStopSequences();
		}
		if ( $config->getPresencePenalty() !== null ) {
			$params['presence_penalty'] = $config->getPresencePenalty();
		}
		if ( $config->getFrequencyPenalty() !== null ) {
			$params['frequency_penalty'] = $config->getFrequencyPenalty();
		}
		if ( $config->getLogprobs() !== null ) {
			$params['logprobs'] = $config->getLogprobs();
		}
		if ( $config->getTopLogprobs() !== null ) {
			$params['top_logprobs'] = $config->getTopLogprobs();
		}
		if ( $config->getCandidateCount() !== null ) {
			$params['n'] = $config->getCandidateCount();
		}
		if ( $config->getOutputMimeType() === 'application/json' ) {
			$params['response_format'] = array( 'type' => 'json_object' );
		}

		$customOptions = $config->getCustomOptions();
		if ( ! empty( $customOptions ) ) {
			$params = array_merge( $params, $customOptions );
		}

		return $params;
	}

	private function extractTextFromParts( array $parts ): string {
		$text = '';
		foreach ( $parts as $part ) {
			$partText = $part->getText();
			if ( $partText !== null ) {
				$text .= $partText;
			}
		}
		return $text;
	}

	private function mapFinishReason( string $reason ): FinishReasonEnum {
		switch ( $reason ) {
			case 'length':
				return FinishReasonEnum::length();
			case 'content_filter':
				return FinishReasonEnum::contentFilter();
			case 'tool_calls':
				return FinishReasonEnum::toolCalls();
			default:
				return FinishReasonEnum::stop();
		}
	}
}
