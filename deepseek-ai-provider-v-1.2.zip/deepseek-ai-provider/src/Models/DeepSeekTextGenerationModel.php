<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Models;

use DeepSeekAiProvider\Provider\DeepSeekProvider;
use WordPress\AiClient\Providers\Http\DTO\Request;
use WordPress\AiClient\Providers\Http\Enums\HttpMethodEnum;
use WordPress\AiClient\Providers\OpenAiCompatibleImplementation\AbstractOpenAiCompatibleTextGenerationModel;

class DeepSeekTextGenerationModel extends AbstractOpenAiCompatibleTextGenerationModel {

	protected function createRequest( HttpMethodEnum $method, string $path, array $headers = array(), $data = null ): Request {
		return new Request(
			$method,
			DeepSeekProvider::url( $path ),
			$headers,
			$data,
			$this->getRequestOptions()
		);
	}

	/**
	 * DeepSeek does not support "json_schema" — always use "json_object".
	 */
	protected function prepareResponseFormatParam( ?array $outputSchema ): array {
		return array( 'type' => 'json_object' );
	}

	/**
	 * DeepSeek requires the word "json" in the prompt when using
	 * response_format json_object. Inject it into the system message.
	 */
	protected function prepareGenerateTextParams( array $prompt ): array {
		$params = parent::prepareGenerateTextParams( $prompt );

		if ( ! isset( $params['response_format'] ) ) {
			return $params;
		}

		$schema = $this->getConfig()->getOutputSchema();
		$suffix = "\n\nYou MUST respond with valid JSON.";
		if ( is_array( $schema ) ) {
			$suffix .= ' Use this exact JSON schema: ' . wp_json_encode( $schema );
		}

		$injected = false;
		foreach ( $params['messages'] as &$msg ) {
			if ( ! isset( $msg['role'] ) || 'system' !== $msg['role'] || ! isset( $msg['content'] ) ) {
				continue;
			}

			$content_str = is_array( $msg['content'] )
				? wp_json_encode( $msg['content'] )
				: $msg['content'];

			if ( stripos( $content_str, 'json' ) === false ) {
				if ( is_array( $msg['content'] ) ) {
					$msg['content'][] = array(
						'type' => 'text',
						'text' => $suffix,
					);
				} else {
					$msg['content'] .= $suffix;
				}
			}

			$injected = true;
			break;
		}
		unset( $msg );

		if ( ! $injected ) {
			array_unshift(
				$params['messages'],
				array(
					'role'    => 'system',
					'content' => trim( $suffix ),
				)
			);
		}

		return $params;
	}
}
