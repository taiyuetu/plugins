<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Metadata;

use DeepSeekAiProvider\Provider\DeepSeekProvider;
use WordPress\AiClient\Messages\Enums\ModalityEnum;
use WordPress\AiClient\Providers\Http\DTO\Request;
use WordPress\AiClient\Providers\Http\DTO\Response;
use WordPress\AiClient\Providers\Http\Enums\HttpMethodEnum;
use WordPress\AiClient\Providers\Http\Exception\ResponseException;
use WordPress\AiClient\Providers\Models\DTO\ModelMetadata;
use WordPress\AiClient\Providers\Models\DTO\SupportedOption;
use WordPress\AiClient\Providers\Models\Enums\CapabilityEnum;
use WordPress\AiClient\Providers\Models\Enums\OptionEnum;
use WordPress\AiClient\Providers\OpenAiCompatibleImplementation\AbstractOpenAiCompatibleModelMetadataDirectory;

class DeepSeekModelMetadataDirectory extends AbstractOpenAiCompatibleModelMetadataDirectory {

	protected function createRequest( HttpMethodEnum $method, string $path, array $headers = array(), $data = null ): Request {
		return new Request(
			$method,
			DeepSeekProvider::url( $path ),
			$headers,
			$data
		);
	}

	protected function parseResponseToModelMetadataList( Response $response ): array {
		$response_data = $response->getData();
		if ( ! isset( $response_data['data'] ) || empty( $response_data['data'] ) ) {
			throw ResponseException::fromMissingData( 'DeepSeek', 'data' );
		}

		$base_text_options = array(
			new SupportedOption( OptionEnum::systemInstruction() ),
			new SupportedOption( OptionEnum::maxTokens() ),
			new SupportedOption( OptionEnum::temperature() ),
			new SupportedOption( OptionEnum::topP() ),
			new SupportedOption( OptionEnum::stopSequences() ),
			new SupportedOption( OptionEnum::presencePenalty() ),
			new SupportedOption( OptionEnum::frequencyPenalty() ),
			new SupportedOption( OptionEnum::logprobs() ),
			new SupportedOption( OptionEnum::topLogprobs() ),
			new SupportedOption( OptionEnum::outputMimeType(), array( 'text/plain', 'application/json' ) ),
			new SupportedOption( OptionEnum::outputSchema() ),
			new SupportedOption( OptionEnum::customOptions() ),
			new SupportedOption( OptionEnum::inputModalities(), array( array( ModalityEnum::text() ) ) ),
			new SupportedOption( OptionEnum::outputModalities(), array( array( ModalityEnum::text() ) ) ),
		);

		$models_data = (array) $response_data['data'];

		$models = array_map(
			function ( array $model_data ) use ( $base_text_options ): ModelMetadata {
				$model_id = $model_data['id'];

				$options = $base_text_options;
				if ( str_contains( $model_id, 'chat' ) ) {
					$options[] = new SupportedOption( OptionEnum::functionDeclarations() );
				}

				return new ModelMetadata(
					$model_id,
					self::formatDisplayName( $model_id ),
					array( CapabilityEnum::textGeneration(), CapabilityEnum::chatHistory() ),
					$options
				);
			},
			$models_data
		);

		usort( $models, array( $this, 'modelSortCallback' ) );

		return $models;
	}

	private static function formatDisplayName( string $id ): string {
		$map = array(
			'deepseek-chat'     => 'DeepSeek-V3 (Chat)',
			'deepseek-reasoner' => 'DeepSeek-R1 (Reasoner)',
		);

		return $map[ $id ] ?? ucwords( str_replace( array( '-', '_' ), ' ', $id ) );
	}

	protected function modelSortCallback( ModelMetadata $a, ModelMetadata $b ): int {
		$priority = array(
			'deepseek-chat'     => 1,
			'deepseek-reasoner' => 2,
		);

		$a_priority = $priority[ $a->getId() ] ?? 99;
		$b_priority = $priority[ $b->getId() ] ?? 99;

		if ( $a_priority !== $b_priority ) {
			return $a_priority <=> $b_priority;
		}

		return strcmp( $a->getId(), $b->getId() );
	}
}
