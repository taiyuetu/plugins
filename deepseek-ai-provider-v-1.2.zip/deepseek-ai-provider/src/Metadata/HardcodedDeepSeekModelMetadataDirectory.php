<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Metadata;

use WordPress\AiClient\Common\Exception\InvalidArgumentException;
use WordPress\AiClient\Messages\Enums\ModalityEnum;
use WordPress\AiClient\Providers\Contracts\ModelMetadataDirectoryInterface;
use WordPress\AiClient\Providers\Models\DTO\ModelMetadata;
use WordPress\AiClient\Providers\Models\DTO\SupportedOption;
use WordPress\AiClient\Providers\Models\Enums\CapabilityEnum;
use WordPress\AiClient\Providers\Models\Enums\OptionEnum;

/**
 * Hardcoded fallback when the SDK is too old for the OpenAI-compatible directory.
 */
class HardcodedDeepSeekModelMetadataDirectory implements ModelMetadataDirectoryInterface {

	private ?array $models = null;

	private function getModels(): array {
		if ( null !== $this->models ) {
			return $this->models;
		}

		$base_options = array(
			new SupportedOption( OptionEnum::systemInstruction() ),
			new SupportedOption( OptionEnum::maxTokens() ),
			new SupportedOption( OptionEnum::temperature() ),
			new SupportedOption( OptionEnum::topP() ),
			new SupportedOption( OptionEnum::stopSequences() ),
			new SupportedOption( OptionEnum::presencePenalty() ),
			new SupportedOption( OptionEnum::frequencyPenalty() ),
			new SupportedOption( OptionEnum::logprobs() ),
			new SupportedOption( OptionEnum::topLogprobs() ),
			new SupportedOption( OptionEnum::outputMimeType(), array( 'text/plain', 'application/json' ) ),
			new SupportedOption( OptionEnum::outputSchema() ),
			new SupportedOption( OptionEnum::customOptions() ),
			new SupportedOption( OptionEnum::inputModalities(), array( array( ModalityEnum::text() ) ) ),
			new SupportedOption( OptionEnum::outputModalities(), array( array( ModalityEnum::text() ) ) ),
		);

		$chat_options = array_merge(
			$base_options,
			array( new SupportedOption( OptionEnum::functionDeclarations() ) )
		);

		$capabilities = array( CapabilityEnum::textGeneration(), CapabilityEnum::chatHistory() );

		$this->models = array(
			'deepseek-chat'     => new ModelMetadata(
				'deepseek-chat',
				'DeepSeek-V3 (Chat)',
				$capabilities,
				$chat_options
			),
			'deepseek-reasoner' => new ModelMetadata(
				'deepseek-reasoner',
				'DeepSeek-R1 (Reasoner)',
				$capabilities,
				$base_options
			),
		);

		return $this->models;
	}

	public function listModelMetadata(): array {
		return array_values( $this->getModels() );
	}

	public function hasModelMetadata( string $modelId ): bool {
		return isset( $this->getModels()[ $modelId ] );
	}

	public function getModelMetadata( string $modelId ): ModelMetadata {
		$models = $this->getModels();

		if ( ! isset( $models[ $modelId ] ) ) {
			throw new InvalidArgumentException(
				sprintf( 'No model with ID %s was found in the DeepSeek provider.', $modelId )
			);
		}

		return $models[ $modelId ];
	}
}
