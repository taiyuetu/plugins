<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Translation;

use WordPress\AiClient\Providers\Http\DTO\RequestOptions;

/**
 * Translates content via WordPress AI Client -> DeepSeek.
 *
 * Long or complex posts are automatically split into smaller chunks,
 * translated individually, then reassembled — preventing token-limit
 * truncation and JSON parse failures.
 */
class PostTranslator {

	/**
	 * Approximate character threshold per chunk. DeepSeek's context window
	 * is large, but the *output* token limit is the bottleneck: the model
	 * must reproduce all HTML/block markup in its response. Keeping chunks
	 * under ~3 000 characters of source text leaves plenty of headroom.
	 */
	const CHUNK_CHAR_LIMIT = 3000;

	public static function isAvailable(): bool {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return false;
		}

		return wp_ai_client_prompt( 'test' )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->is_supported_for_text_generation();
	}

	/**
	 * Translate a post's title and content.
	 *
	 * Short posts are sent in a single request. Long posts are
	 * automatically chunked, translated piece-by-piece, and reassembled.
	 *
	 * @return array{title: string, content: string}|\WP_Error
	 */
	public function translate( string $title, string $content, string $source_language, string $target_language ) {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new \WP_Error( 'no_ai_client', __( 'The WordPress AI Client is not available.', 'deepseek-ai-provider' ) );
		}

		// ── Step 1: Translate the title (always a single, short call) ──
		$translated_title = $this->translatePlainText( $title, $source_language, $target_language );
		if ( is_wp_error( $translated_title ) ) {
			return $translated_title;
		}

		// ── Step 2: If content is short enough, translate in one shot ──
		$content_trimmed = trim( $content );
		if ( $content_trimmed === '' ) {
			return array( 'title' => $translated_title, 'content' => '' );
		}

		if ( mb_strlen( $content_trimmed ) <= self::CHUNK_CHAR_LIMIT ) {
			$translated_content = $this->translateContentChunk( $content_trimmed, $source_language, $target_language );
			if ( is_wp_error( $translated_content ) ) {
				return $translated_content;
			}

			return array( 'title' => $translated_title, 'content' => $translated_content );
		}

		// ── Step 3: Split long content into chunks and translate each ──
		$chunks = $this->splitContent( $content_trimmed );

		$translated_chunks = array();
		foreach ( $chunks as $i => $chunk ) {
			$result = $this->translateContentChunk( $chunk, $source_language, $target_language );

			if ( is_wp_error( $result ) ) {
				// Retry once — sometimes a transient API glitch
				$result = $this->translateContentChunk( $chunk, $source_language, $target_language );
			}

			if ( is_wp_error( $result ) ) {
				return new \WP_Error(
					'chunk_translate_failed',
					sprintf(
						/* translators: 1: chunk number, 2: total chunks, 3: error message */
						__( 'Failed to translate chunk %1$d of %2$d: %3$s', 'deepseek-ai-provider' ),
						$i + 1,
						count( $chunks ),
						$result->get_error_message()
					)
				);
			}

			$translated_chunks[] = $result;
		}

		// ── Step 4: Reassemble ──
		$translated_content = implode( "\n\n", $translated_chunks );

		return array(
			'title'   => $translated_title,
			'content' => $translated_content,
		);
	}

	/**
	 * Translate a short plain-text string (e.g. post title).
	 *
	 * @return string|\WP_Error
	 */
	private function translatePlainText( string $text, string $source_language, string $target_language ) {
		if ( trim( $text ) === '' ) {
			return '';
		}

		$system_instruction = sprintf(
			'You are a professional translator. Translate the following text from %1$s to %2$s. ' .
			'Respond with ONLY the translated text — no quotes, no explanation, no markup.',
			$source_language,
			$target_language
		);

		$raw = wp_ai_client_prompt( $text )
			->using_system_instruction( $system_instruction )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->using_temperature( 0.2 )
			->using_max_tokens( 1024 )
			->using_request_options(
				RequestOptions::fromArray( array( 'timeout' => 60.0 ) )
			)
			->generate_text();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$result = trim( (string) $raw );

		// Strip wrapping quotes the model sometimes adds
		if ( preg_match( '/^"(.+)"$/s', $result, $m ) ) {
			$result = $m[1];
		}

		return $result;
	}

	/**
	 * Translate a single chunk of HTML/block content.
	 *
	 * The prompt asks for plain translated HTML back (not JSON), which is
	 * far more reliable for the model — no risk of broken JSON escaping.
	 *
	 * @return string|\WP_Error  Translated HTML string, or WP_Error.
	 */
	private function translateContentChunk( string $html, string $source_language, string $target_language ) {
		$system_instruction = sprintf(
			'You are a professional translator. ' .
			'Translate the following HTML content from %1$s to %2$s. ' .
			'RULES: ' .
			'1. Preserve every HTML tag, attribute, CSS class, WordPress block comment (<!-- wp:xxx -->), and shortcode EXACTLY as-is. ' .
			'2. Translate ONLY the visible human-readable text. ' .
			'3. Do NOT add, remove, or reorder any HTML tags or block comments. ' .
			'4. Respond with ONLY the translated HTML — no explanations, no markdown fences, no wrapping.',
			$source_language,
			$target_language
		);

		$raw = wp_ai_client_prompt( $html )
			->using_system_instruction( $system_instruction )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->using_temperature( 0.2 )
			->using_max_tokens( 8192 )
			->using_request_options(
				RequestOptions::fromArray( array( 'timeout' => 120.0 ) )
			)
			->generate_text();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$result = trim( (string) $raw );

		// Strip markdown code fences the model sometimes wraps around HTML
		$result = preg_replace( '/^```(?:html)?\s*\n?/i', '', $result );
		$result = preg_replace( '/\n?```\s*$/', '', $result );

		if ( trim( $result ) === '' ) {
			return new \WP_Error( 'empty_translation', __( 'The AI returned an empty translation for this chunk.', 'deepseek-ai-provider' ) );
		}

		return trim( $result );
	}

	/**
	 * Split post content into translatable chunks.
	 *
	 * Strategy (in priority order):
	 *   1. Split on WordPress block boundaries (<!-- /wp:xxx -->)
	 *   2. Split on <hr>, </section>, </div> closing tags at root level
	 *   3. Split on double newlines (paragraph boundaries)
	 *   4. Split on single newlines as last resort
	 *
	 * Adjacent small pieces are merged until they approach CHUNK_CHAR_LIMIT.
	 *
	 * @return string[] Array of content chunks.
	 */
	private function splitContent( string $content ): array {
		// Try block-level splitting first (Gutenberg posts)
		$pieces = $this->splitByBlocks( $content );

		if ( count( $pieces ) <= 1 ) {
			// Classic editor or no blocks — split on double newlines
			$pieces = preg_split( '/\n\s*\n/', $content );
			if ( ! is_array( $pieces ) || count( $pieces ) <= 1 ) {
				// Very long single paragraph — split on <br>, </p>, </div>, </li>
				$pieces = preg_split( '/(?<=<\/p>|<\/div>|<\/li>|<\/h[1-6]>|<br\s*\/?>)/i', $content );
			}
		}

		if ( ! is_array( $pieces ) ) {
			$pieces = array( $content );
		}

		// Filter out empty pieces
		$pieces = array_values( array_filter( $pieces, function ( $p ) {
			return trim( $p ) !== '';
		} ) );

		// Merge small adjacent pieces into chunks up to the limit
		return $this->mergeIntoChunks( $pieces );
	}

	/**
	 * Split content on Gutenberg block boundaries.
	 *
	 * Each top-level block (from <!-- wp:xxx --> to <!-- /wp:xxx -->)
	 * becomes one piece. Self-closing blocks are kept intact.
	 *
	 * @return string[]
	 */
	private function splitByBlocks( string $content ): array {
		// Match closing block comments as split points
		$parts = preg_split(
			'/(<!-- \/wp:[a-z][a-z0-9\-]*\/?\s*-->)/i',
			$content,
			-1,
			PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY
		);

		if ( ! is_array( $parts ) || count( $parts ) <= 1 ) {
			return array( $content );
		}

		// Re-attach closing comments to the preceding piece
		$blocks = array();
		$buffer = '';

		foreach ( $parts as $part ) {
			if ( preg_match( '/^<!-- \/wp:/i', $part ) ) {
				$buffer .= $part;
				$blocks[] = $buffer;
				$buffer   = '';
			} else {
				$buffer .= $part;
			}
		}

		// Remainder (content after the last closing block comment)
		if ( trim( $buffer ) !== '' ) {
			$blocks[] = $buffer;
		}

		return $blocks;
	}

	/**
	 * Merge small pieces into chunks that stay under the character limit.
	 *
	 * @param  string[] $pieces Individual content pieces.
	 * @return string[] Merged chunks.
	 */
	private function mergeIntoChunks( array $pieces ): array {
		$chunks       = array();
		$current      = '';

		foreach ( $pieces as $piece ) {
			$piece_len   = mb_strlen( $piece );
			$current_len = mb_strlen( $current );

			// If a single piece exceeds the limit, it becomes its own chunk
			if ( $piece_len > self::CHUNK_CHAR_LIMIT ) {
				if ( $current !== '' ) {
					$chunks[] = $current;
					$current  = '';
				}
				// If this single piece is extremely long, force-split it
				if ( $piece_len > self::CHUNK_CHAR_LIMIT * 2 ) {
					$sub_pieces = $this->forceSplit( $piece );
					foreach ( $sub_pieces as $sp ) {
						$chunks[] = $sp;
					}
				} else {
					$chunks[] = $piece;
				}
				continue;
			}

			// Would adding this piece exceed the limit?
			if ( $current_len + $piece_len > self::CHUNK_CHAR_LIMIT && $current !== '' ) {
				$chunks[] = $current;
				$current  = $piece;
			} else {
				$current .= ( $current !== '' ? "\n\n" : '' ) . $piece;
			}
		}

		if ( $current !== '' ) {
			$chunks[] = $current;
		}

		return $chunks;
	}

	/**
	 * Force-split an extremely long piece by sentence or tag boundaries.
	 *
	 * @return string[]
	 */
	private function forceSplit( string $text ): array {
		// Try splitting on sentence-ending tags or periods
		$parts = preg_split(
			'/(?<=<\/p>|<\/div>|<\/li>|<\/h[1-6]>|\.\s)/i',
			$text,
			-1,
			PREG_SPLIT_NO_EMPTY
		);

		if ( ! is_array( $parts ) || count( $parts ) <= 1 ) {
			// Absolute last resort: split by character count at whitespace
			$parts = array();
			$len   = mb_strlen( $text );
			$pos   = 0;

			while ( $pos < $len ) {
				$end = min( $pos + self::CHUNK_CHAR_LIMIT, $len );

				// Try to find a whitespace near the cut point
				if ( $end < $len ) {
					$space_pos = mb_strrpos( mb_substr( $text, $pos, $end - $pos ), ' ' );
					if ( $space_pos !== false && $space_pos > self::CHUNK_CHAR_LIMIT * 0.5 ) {
						$end = $pos + $space_pos + 1;
					}
				}

				$parts[] = mb_substr( $text, $pos, $end - $pos );
				$pos     = $end;
			}
		}

		return $this->mergeIntoChunks( $parts );
	}

	/**
	 * Translate a term's name and description.
	 *
	 * @return array{name: string, slug: string, description: string}|\WP_Error
	 */
	public function translateTerm( string $name, string $description, string $source_language, string $target_language ) {
		if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
			return new \WP_Error( 'no_ai_client', __( 'The WordPress AI Client is not available.', 'deepseek-ai-provider' ) );
		}

		$system_instruction = sprintf(
			'You are a professional translator. ' .
			'The user will send a JSON object with "name" and "description" keys. ' .
			'Translate both values from %1$s to %2$s. ' .
			'Also generate a URL-safe "slug" for the translated name (lowercase, hyphens, no special characters). ' .
			'Respond with ONLY a raw JSON object: {"name":"...","slug":"...","description":"..."}',
			$source_language,
			$target_language
		);

		$user_message = wp_json_encode( array(
			'name'        => $name,
			'description' => $description,
		) );

		$raw = wp_ai_client_prompt( $user_message )
			->using_system_instruction( $system_instruction )
			->using_model_preference( 'deepseek-chat', 'deepseek-reasoner' )
			->using_temperature( 0.2 )
			->using_max_tokens( 2048 )
			->using_request_options(
				RequestOptions::fromArray( array( 'timeout' => 60.0 ) )
			)
			->generate_text();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$translated = self::decodeJsonResponse( (string) $raw );

		if ( null === $translated || ! isset( $translated['name'] ) ) {
			return new \WP_Error( 'deepseek_parse_error', __( 'Could not parse the term translation response.', 'deepseek-ai-provider' ) );
		}

		return array(
			'name'        => (string) $translated['name'],
			'slug'        => (string) ( $translated['slug'] ?? sanitize_title( $translated['name'] ) ),
			'description' => (string) ( $translated['description'] ?? '' ),
		);
	}

	/**
	 * Decode JSON, stripping optional markdown fences.
	 */
	private static function decodeJsonResponse( string $raw ): ?array {
		$decoded = json_decode( $raw, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}

		$cleaned = preg_replace( '/^```(?:json)?\s*/m', '', $raw );
		$cleaned = preg_replace( '/```\s*$/m', '', (string) $cleaned );
		$decoded = json_decode( trim( (string) $cleaned ), true );

		return is_array( $decoded ) ? $decoded : null;
	}
}
