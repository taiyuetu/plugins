<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\Provider;

use DeepSeekAiProvider\Metadata\DeepSeekModelMetadataDirectory;
use DeepSeekAiProvider\Metadata\HardcodedDeepSeekModelMetadataDirectory;
use DeepSeekAiProvider\Models\DeepSeekTextGenerationModel;
use DeepSeekAiProvider\Models\FallbackDeepSeekTextGenerationModel;
use WordPress\AiClient\AiClient;
use WordPress\AiClient\Common\Exception\RuntimeException;
use WordPress\AiClient\Providers\ApiBasedImplementation\AbstractApiProvider;
use WordPress\AiClient\Providers\ApiBasedImplementation\ListModelsApiBasedProviderAvailability;
use WordPress\AiClient\Providers\OpenAiCompatibleImplementation\AbstractOpenAiCompatibleModelMetadataDirectory;
use WordPress\AiClient\Providers\OpenAiCompatibleImplementation\AbstractOpenAiCompatibleTextGenerationModel;
use WordPress\AiClient\Providers\Contracts\ModelMetadataDirectoryInterface;
use WordPress\AiClient\Providers\Contracts\ProviderAvailabilityInterface;
use WordPress\AiClient\Providers\DTO\ProviderMetadata;
use WordPress\AiClient\Providers\Enums\ProviderTypeEnum;
use WordPress\AiClient\Providers\Http\Enums\RequestAuthenticationMethod;
use WordPress\AiClient\Providers\Models\Contracts\ModelInterface;
use WordPress\AiClient\Providers\Models\DTO\ModelMetadata;

class DeepSeekProvider extends AbstractApiProvider {

	protected static function baseUrl(): string {
		return 'https://api.deepseek.com/v1';
	}

	protected static function createModel(
		ModelMetadata $model_metadata,
		ProviderMetadata $provider_metadata
	): ModelInterface {
		$capabilities = $model_metadata->getSupportedCapabilities();

		foreach ( $capabilities as $capability ) {
			if ( $capability->isTextGeneration() ) {
				if ( class_exists( AbstractOpenAiCompatibleTextGenerationModel::class ) ) {
					return new DeepSeekTextGenerationModel( $model_metadata, $provider_metadata );
				}
				return new FallbackDeepSeekTextGenerationModel( $model_metadata, $provider_metadata );
			}
		}

		throw new RuntimeException(
			'Unsupported model capabilities: ' . implode( ', ', $capabilities )
		);
	}

	protected static function createProviderMetadata(): ProviderMetadata {
		$args = array(
			'deepseek',
			'DeepSeek',
			ProviderTypeEnum::cloud(),
			'https://platform.deepseek.com',
			RequestAuthenticationMethod::apiKey(),
		);

		if ( version_compare( AiClient::VERSION, '1.2.0', '>=' ) ) {
			$args[] = function_exists( '__' )
				? __( 'Text generation with DeepSeek AI models.', 'deepseek-ai-provider' )
				: 'Text generation with DeepSeek AI models.';
		}

		if ( version_compare( AiClient::VERSION, '1.3.0', '>=' ) ) {
			$args[] = DSAP_PLUGIN_DIR . 'assets/images/deepseek.svg';
		}

		return new ProviderMetadata( ...$args );
	}

	protected static function createProviderAvailability(): ProviderAvailabilityInterface {
		if ( class_exists( ListModelsApiBasedProviderAvailability::class ) ) {
			return new ListModelsApiBasedProviderAvailability(
				static::modelMetadataDirectory()
			);
		}

		return new class() implements ProviderAvailabilityInterface {
			public function isConfigured(): bool {
				return true;
			}
		};
	}

	protected static function createModelMetadataDirectory(): ModelMetadataDirectoryInterface {
		if ( class_exists( AbstractOpenAiCompatibleModelMetadataDirectory::class ) ) {
			return new DeepSeekModelMetadataDirectory();
		}

		return new HardcodedDeepSeekModelMetadataDirectory();
	}
}
