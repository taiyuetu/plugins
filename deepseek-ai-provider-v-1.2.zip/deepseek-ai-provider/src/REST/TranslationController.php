<?php

declare(strict_types=1);

namespace DeepSeekAiProvider\REST;

use DeepSeekAiProvider\Translation\PolylangHelper;
use DeepSeekAiProvider\Translation\PostTranslator;

/**
 * REST endpoint for single post translation (used by the meta box).
 *
 * POST /wp-json/deepseek-ai-provider/v1/translate
 */
class TranslationController {

	const REST_NAMESPACE = 'deepseek-ai-provider/v1';
	const REST_ROUTE     = '/translate';

	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'registerRoutes' ) );
	}

	public function registerRoutes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'permissionCheck' ),
				'args'                => array(
					'post_id'         => array(
						'required'          => true,
						'type'              => 'integer',
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					),
					'target_language' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	public function permissionCheck(): bool {
		return current_user_can( 'edit_posts' );
	}

	public function handle( \WP_REST_Request $request ) {
		$post_id         = (int) $request->get_param( 'post_id' );
		$target_language = (string) $request->get_param( 'target_language' );

		$post = get_post( $post_id );
		if ( ! ( $post instanceof \WP_Post ) ) {
			return new \WP_Error( 'not_found', __( 'Post not found.', 'deepseek-ai-provider' ), array( 'status' => 404 ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'forbidden', __( 'Insufficient permissions.', 'deepseek-ai-provider' ), array( 'status' => 403 ) );
		}

		if ( ! PostTranslator::isAvailable() ) {
			return new \WP_Error(
				'ai_unavailable',
				__( 'DeepSeek is not available. Configure it at Settings > Connectors.', 'deepseek-ai-provider' ),
				array( 'status' => 400 )
			);
		}

		if ( ! PolylangHelper::isActive() ) {
			return new \WP_Error( 'polylang_inactive', __( 'Polylang is not active.', 'deepseek-ai-provider' ), array( 'status' => 400 ) );
		}

		$source_lang = PolylangHelper::getPostLanguage( $post_id );
		if ( empty( $source_lang ) ) {
			return new \WP_Error( 'no_source_lang', __( 'Set a language for this post in Polylang first.', 'deepseek-ai-provider' ), array( 'status' => 400 ) );
		}

		if ( $source_lang === $target_language ) {
			return new \WP_Error( 'same_language', __( 'Target language must differ from the source.', 'deepseek-ai-provider' ), array( 'status' => 400 ) );
		}

		$existing_id = ( function_exists( 'pll_get_post' ) )
			? (int) pll_get_post( $post_id, $target_language )
			: 0;

		$source_language_name = PolylangHelper::getLanguageName( $source_lang );
		$target_language_name = PolylangHelper::getLanguageName( $target_language );

		$translator = new PostTranslator();
		$result     = $translator->translate(
			$post->post_title,
			$post->post_content,
			$source_language_name,
			$target_language_name
		);

		if ( is_wp_error( $result ) ) {
			return new \WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => 500 ) );
		}

		$new_post_id = PolylangHelper::saveTranslation(
			$post_id,
			$target_language,
			$result['title'],
			$result['content']
		);

		if ( is_wp_error( $new_post_id ) ) {
			return new \WP_Error( $new_post_id->get_error_code(), $new_post_id->get_error_message(), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array(
			'success'       => true,
			'post_id'       => $new_post_id,
			'is_new'        => ( 0 === $existing_id ),
			'language'      => $target_language_name,
			'language_slug' => $target_language,
			'edit_url'      => get_edit_post_link( $new_post_id, 'raw' ),
		) );
	}
}
