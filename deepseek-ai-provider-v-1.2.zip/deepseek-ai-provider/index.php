<?php
/**
 * Silence is golden.
 *
 * @package DeepSeekAiProvider
 */

if ( ! defined( 'ABSPATH' ) ) {
	die;
}
