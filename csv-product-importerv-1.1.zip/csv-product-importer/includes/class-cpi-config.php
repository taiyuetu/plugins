<?php
defined( 'ABSPATH' ) || exit;

/**
 * Central configuration for CSV Product Importer Pro.
 *
 * To adapt this importer for a different product type, edit ONLY this file:
 *
 *  POST_TYPE          – target WordPress post type
 *  DESCRIPTION        – subtitle shown in the admin header
 *  TITLE_ONLY_COLUMN  – column used in title generation but not saved as meta
 *  TITLE_FORMULA      – how the post title is assembled from column values
 *  UNIQUE_KEY         – column used for duplicate detection (must be in META_MAP)
 *  IMAGE_KEY          – column whose value is matched against media library filenames
 *  META_MAP           – CSV column → WordPress meta key
 *  COLUMN_LABELS      – human-readable preview table column headings
 */
class CPI_Config {

    /** WordPress post type to import into. */
    public const POST_TYPE = 'product';

    /** Subtitle shown in the admin page header. */
    public const DESCRIPTION = 'Import hub-bearing products from CSV — smart title generation & meta mapping';

    /**
     * CSV column used in title generation but NOT saved as post meta.
     * Set to '' if every column should be stored as meta.
     */
    public const TITLE_ONLY_COLUMN = 'type';

    /**
     * Title assembly formula.
     *
     *  prefix    – columns joined with a space, placed first.
     *  connector – word inserted between prefix and suffix (e.g. "for").
     *              Set to '' to omit.
     *  suffix    – columns joined with a space, placed last.
     *              Set to [] to omit.
     *
     * Example output: "DAC255242 rear wheel hub bearing for Changan Automobile"
     */
    public const TITLE_FORMULA = [
        'prefix'    => [ 'oem_num', 'type' ],
        'connector' => 'for',
        'suffix'    => [ 'car_brand' ],
    ];

    /**
     * The meta key (= CSV column name) used to identify duplicate posts.
     * Must be a key present in META_MAP.
     */
    public const UNIQUE_KEY = 'oem_num';

    /**
     * Column whose value is matched against media-library filenames
     * for automatic thumbnail / gallery assignment.
     * Set to '' to disable image matching.
     */
    public const IMAGE_KEY = 'product_mpn';

    /**
     * CSV column → WordPress meta key map.
     *
     * Add a column : 'csv_column' => 'meta_key'
     * Remove a column : delete its entry.
     * TITLE_ONLY_COLUMN should NOT appear here.
     */
    public const META_MAP = [
        'product_mpn'     => 'product_mpn',
        'oem_num'         => 'oem_num',
        'cross_ref'       => 'cross_ref',
        'car_brand'       => 'car_brand',
        'car_application' => 'car_application',
        'outer_diameter'  => 'outer_diameter',
        'weight'          => 'weight',
    ];

    /**
     * Human-readable labels for the CSV preview table.
     * Columns not listed here fall back to the raw column name.
     */
    public const COLUMN_LABELS = [
        'type'            => 'Type',
        'product_mpn'     => 'MPN',
        'oem_num'         => 'OEM #',
        'cross_ref'       => 'Cross Ref',
        'car_brand'       => 'Car Brand',
        'car_application' => 'Application',
        'outer_diameter'  => 'Ø Diameter',
        'weight'          => 'Weight',
    ];

    // -------------------------------------------------------------------------
    // Derived helpers — read-only, driven by the constants above.
    // -------------------------------------------------------------------------

    /**
     * Returns every required CSV column name: meta columns + title-only column.
     *
     * @return string[]
     */
    public static function required_headers(): array {
        $cols = array_keys( self::META_MAP );
        $title_col = self::TITLE_ONLY_COLUMN;
        if ( '' !== $title_col && ! in_array( $title_col, $cols, true ) ) {
            $cols[] = $title_col;
        }
        return $cols;
    }

    /**
     * Builds a readable string representing the title formula.
     * Example: oem_num + type + "for" + car_brand
     *
     * @return string
     */
    public static function title_formula_display(): string {
        $formula   = self::TITLE_FORMULA;
        $tokens    = $formula['prefix'] ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix'] ?? [];

        if ( '' !== $connector ) {
            $tokens[] = '"' . $connector . '"';
        }
        $tokens = array_merge( $tokens, $suffix );

        return implode( ' + ', $tokens );
    }

    /**
     * Column labels merged with the generated-title pseudo-column,
     * ready to pass to JavaScript.
     *
     * @return array<string,string>
     */
    public static function js_column_labels(): array {
        return array_merge(
            [ '_generated_title' => '🏷️ Generated Title' ],
            self::COLUMN_LABELS
        );
    }
}
