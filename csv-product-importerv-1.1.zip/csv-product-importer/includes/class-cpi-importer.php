<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles inserting / updating WordPress posts.
 *
 * All field configuration (post type, meta map, unique key, image key) is
 * sourced from CPI_Config — edit that file to adapt for a different product type.
 */
class CPI_Importer {

    /**
     * Backward-compatible reference to the meta map.
     * Reads directly from CPI_Config; no need to edit this class.
     */
    public const META_MAP = CPI_Config::META_MAP;

    /**
     * Import a batch of parsed rows.
     *
     * @param array  $rows
     * @param string $duplicate   'skip' | 'update' | 'duplicate'
     * @param string $post_status 'publish' | 'draft' | 'pending'
     * @param string $lang_slug   Polylang language slug, e.g. 'en', 'zh'. Empty = no assignment.
     * @param int    $batch_offset
     * @param int    $batch_size
     *
     * @return array{imported:int, updated:int, skipped:int, error_count:int, errors:string[], skipped_messages:string[]}
     */
    public static function import_batch(
        array $rows,
        string $duplicate = 'skip',
        string $post_status = 'publish',
        string $lang_slug = '',
        int $batch_offset = 0,
        int $batch_size = 50
    ): array {
        $stats = [
            'imported'         => 0,
            'updated'          => 0,
            'skipped'          => 0,
            'error_count'      => 0,
            'errors'           => [],
            'skipped_messages' => [],
        ];

        foreach ( array_slice( $rows, $batch_offset, $batch_size ) as $row ) {
            $result = self::process_row( $row, $duplicate, $post_status, $lang_slug );
            if ( $result['action'] === 'errors' ) {
                $stats['error_count']++;
            } else {
                $stats[ $result['action'] ]++;
            }
            if ( ! empty( $result['error'] ) ) {
                $stats['errors'][] = $result['error'];
            }
            if ( ! empty( $result['skip_message'] ) ) {
                $stats['skipped_messages'][] = $result['skip_message'];
            }
        }

        return $stats;
    }

    // -------------------------------------------------------------------------

    private static function process_row( array $row, string $duplicate, string $post_status, string $lang_slug = '' ): array {
        $title      = $row['_generated_title'] ?? CPI_CSV_Parser::build_title( $row );
        $unique_key = CPI_Config::UNIQUE_KEY;
        $unique_val = sanitize_text_field( $row[ $unique_key ] ?? '' );
        $identifier = $unique_val ?: $title;

        $existing_id = self::find_existing( $unique_val, $lang_slug );

        if ( $existing_id ) {
            if ( 'skip' === $duplicate ) {
                return [
                    'action'       => 'skipped',
                    'error'        => '',
                    'skip_message' => sprintf(
                        'Skipped existing product: %s (post ID %d).',
                        $identifier,
                        $existing_id
                    ),
                ];
            }

            if ( 'update' === $duplicate ) {
                $post_id = wp_update_post( [
                    'ID'          => $existing_id,
                    'post_title'  => sanitize_text_field( $title ),
                    'post_status' => $post_status,
                ], true );

                if ( is_wp_error( $post_id ) ) {
                    return [
                        'action'       => 'errors',
                        'error'        => sprintf( 'Failed updating %s: %s', $identifier, $post_id->get_error_message() ),
                        'skip_message' => '',
                    ];
                }

                self::save_meta( $post_id, $row );
                self::set_post_language( $post_id, $lang_slug );
                self::set_product_images( $post_id, $row[ CPI_Config::IMAGE_KEY ] ?? '' );
                return [ 'action' => 'updated', 'error' => '', 'skip_message' => '' ];
            }
            // 'duplicate' falls through to insert
        }

        $post_id = wp_insert_post( [
            'post_title'   => sanitize_text_field( $title ),
            'post_type'    => CPI_Config::POST_TYPE,
            'post_status'  => $post_status,
            'post_content' => '',
        ], true );

        if ( is_wp_error( $post_id ) ) {
            return [
                'action'       => 'errors',
                'error'        => sprintf( 'Failed inserting %s: %s', $identifier, $post_id->get_error_message() ),
                'skip_message' => '',
            ];
        }

        self::save_meta( $post_id, $row );
        self::set_post_language( $post_id, $lang_slug );
        self::set_product_images( $post_id, $row[ CPI_Config::IMAGE_KEY ] ?? '' );
        return [ 'action' => 'imported', 'error' => '', 'skip_message' => '' ];
    }

    /**
     * Assign a Polylang language to a post.
     * Does nothing if Polylang is not active or no language is specified.
     */
    private static function set_post_language( int $post_id, string $lang_slug ): void {
        if ( '' !== $lang_slug && function_exists( 'pll_set_post_language' ) ) {
            pll_set_post_language( $post_id, $lang_slug );
        }
    }

    /**
     * Save meta fields using the META_MAP from CPI_Config.
     */
    private static function save_meta( int $post_id, array $row ): void {
        foreach ( CPI_Config::META_MAP as $col => $meta_key ) {
            $value = $row[ $col ] ?? '';
            update_post_meta( $post_id, $meta_key, sanitize_textarea_field( $value ) );
        }
    }

    /**
     * Finds images in the media library by IMAGE_KEY value and sets thumbnail/gallery.
     * Set CPI_Config::IMAGE_KEY to '' to disable.
     */
    private static function set_product_images( int $post_id, string $key_value ): void {
        if ( '' === CPI_Config::IMAGE_KEY ) {
            return;
        }

        $key_value = trim( $key_value );
        if ( '' === $key_value ) {
            return;
        }

        global $wpdb;

        $like = $wpdb->esc_like( $key_value ) . '(%';

        $attachments = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, pm.meta_value AS attached_file
             FROM $wpdb->posts p
             INNER JOIN $wpdb->postmeta pm
                ON pm.post_id = p.ID
               AND pm.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment'
               AND p.post_mime_type LIKE 'image/%%'
               AND SUBSTRING_INDEX(pm.meta_value, '/', -1) LIKE %s",
            $like
        ) );

        if ( empty( $attachments ) ) {
            return;
        }

        $matched = [];
        foreach ( $attachments as $attachment ) {
            $id       = (int) $attachment->ID;
            $filename = wp_basename( (string) $attachment->attached_file );

            if ( ! preg_match( '/^' . preg_quote( $key_value, '/' ) . '\((\d+)\)\.[^.]+$/i', $filename, $matches ) ) {
                continue;
            }

            $matched[] = [
                'id'       => $id,
                'filename' => $filename,
                'sequence' => (int) $matches[1],
            ];
        }

        if ( empty( $matched ) ) {
            return;
        }

        usort( $matched, static fn( $a, $b ) => $a['sequence'] !== $b['sequence']
            ? $a['sequence'] <=> $b['sequence']
            : $a['id'] <=> $b['id']
        );

        $gallery_ids  = array_column( $matched, 'id' );
        $thumbnail_id = 0;

        foreach ( $matched as $attachment ) {
            if ( 1 === $attachment['sequence'] ) {
                $thumbnail_id = $attachment['id'];
                break;
            }
        }

        if ( $thumbnail_id ) {
            set_post_thumbnail( $post_id, $thumbnail_id );
        }

        update_post_meta( $post_id, 'product_gallery', implode( ',', $gallery_ids ) );
    }

    /**
     * Look up an existing post by the UNIQUE_KEY meta value.
     * When a Polylang language slug is given, the search is scoped to that
     * language so the same product can exist independently in multiple languages.
     */
    private static function find_existing( string $value, string $lang_slug = '' ): int {
        if ( empty( $value ) ) {
            return 0;
        }

        $args = [
            'post_type'      => CPI_Config::POST_TYPE,
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [ [
                'key'     => CPI_Config::UNIQUE_KEY,
                'value'   => $value,
                'compare' => '=',
            ] ],
        ];

        // When a specific language is targeted, restrict the search to that
        // language so the same OEM number can coexist across languages.
        if ( '' !== $lang_slug && function_exists( 'pll_languages_list' ) ) {
            $args['lang'] = $lang_slug;
        }

        $query = new WP_Query( $args );
        return ! empty( $query->posts ) ? (int) $query->posts[0] : 0;
    }
}
