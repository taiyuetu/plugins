<?php
defined( 'ABSPATH' ) || exit;

/**
 * Handles AJAX requests for CSV preview and batch import.
 */
class CPI_Ajax {

    public static function hooks(): void {
        add_action( 'wp_ajax_cpi_preview_csv',    [ __CLASS__, 'preview_csv' ] );
        add_action( 'wp_ajax_cpi_import_batch',   [ __CLASS__, 'import_batch' ] );
        add_action( 'wp_ajax_cpi_clear_products', [ __CLASS__, 'clear_products' ] );
    }

    // ------------------------------------------------------------------ //
    //  Preview                                                             //
    // ------------------------------------------------------------------ //

    public static function preview_csv(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $file_path = self::get_uploaded_file();
            $parsed    = CPI_CSV_Parser::parse( $file_path );

            wp_send_json_success( [
                'total'   => count( $parsed['rows'] ),
                'errors'  => $parsed['errors'],
                'preview' => array_slice( $parsed['rows'], 0, 10 ),
                'headers' => $parsed['headers'],
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() . ' (line ' . $e->getLine() . ' in ' . basename( $e->getFile() ) . ')' ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Batch Import                                                        //
    // ------------------------------------------------------------------ //

    public static function import_batch(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $duplicate   = sanitize_text_field( $_POST['duplicate']   ?? 'skip' );
            $post_status = sanitize_text_field( $_POST['post_status'] ?? 'publish' );
            $lang_slug   = sanitize_key( $_POST['language'] ?? '' );
            $offset      = (int) ( $_POST['offset']     ?? 0 );
            $batch_size  = (int) ( $_POST['batch_size'] ?? 50 );

            $transient_key = 'cpi_import_' . get_current_user_id();
            $rows = get_transient( $transient_key );

            if ( false === $rows ) {
                $file_path = self::get_uploaded_file();
                $parsed    = CPI_CSV_Parser::parse( $file_path );

                if ( ! empty( $parsed['errors'] ) && empty( $parsed['rows'] ) ) {
                    wp_send_json_error( [ 'message' => implode( ' | ', $parsed['errors'] ) ] );
                }

                $rows = $parsed['rows'];
                set_transient( $transient_key, $rows, HOUR_IN_SECONDS );
            }

            $stats = CPI_Importer::import_batch( $rows, $duplicate, $post_status, $lang_slug, $offset, $batch_size );
            $total = count( $rows );
            $done  = min( $offset + $batch_size, $total );

            if ( $done >= $total ) {
                delete_transient( $transient_key );
            }

            wp_send_json_success( [
                'stats'    => $stats,
                'total'    => $total,
                'done'     => $done,
                'finished' => $done >= $total,
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() . ' (line ' . $e->getLine() . ' in ' . basename( $e->getFile() ) . ')' ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Clear Products                                                      //
    // ------------------------------------------------------------------ //

    public static function clear_products(): void {
        self::verify_nonce( 'cpi_nonce' );
        self::check_capability();

        try {
            $posts = get_posts( [
                'post_type'      => 'product',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ] );

            $deleted = 0;
            foreach ( $posts as $id ) {
                if ( wp_delete_post( $id, true ) ) {
                    $deleted++;
                }
            }

            wp_send_json_success( [ 'deleted' => $deleted ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    private static function verify_nonce( string $action ): void {
        if ( ! check_ajax_referer( $action, 'security', false ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed. Please refresh the page and try again.' ], 403 );
            exit;
        }
    }

    private static function check_capability(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient permissions.' ], 403 );
            exit;
        }
    }

    private static function get_uploaded_file(): string {
        // Use cached file for subsequent batch calls
        if ( empty( $_FILES['csv_file']['tmp_name'] ) ) {
            $saved = get_transient( 'cpi_upload_' . get_current_user_id() );
            if ( $saved && file_exists( $saved ) ) {
                return $saved;
            }
            wp_send_json_error( [ 'message' => 'No CSV file provided. Please re-upload your file.' ] );
            exit;
        }

        $file = $_FILES['csv_file'];

        // Check for upload errors
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds the upload_max_filesize directive in php.ini.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds the MAX_FILE_SIZE directive in the HTML form.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
                UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
            ];
            $msg = $upload_errors[ $file['error'] ] ?? 'Unknown upload error (code ' . $file['error'] . ').';
            wp_send_json_error( [ 'message' => $msg ] );
            exit;
        }

        // Validate extension
        if ( strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) ) !== 'csv' ) {
            wp_send_json_error( [ 'message' => 'Only .csv files are allowed. Uploaded: ' . esc_html( $file['name'] ) ] );
            exit;
        }

        // Move to a persistent location so batch calls can reuse it
        $upload_dir = wp_upload_dir();
        if ( ! empty( $upload_dir['error'] ) ) {
            wp_send_json_error( [ 'message' => 'WordPress uploads directory error: ' . $upload_dir['error'] ] );
            exit;
        }

        $dest_dir = $upload_dir['basedir'] . '/cpi-imports/';
        if ( ! wp_mkdir_p( $dest_dir ) ) {
            wp_send_json_error( [ 'message' => 'Could not create upload directory: ' . $dest_dir ] );
            exit;
        }

        $dest = $dest_dir . sanitize_file_name( $file['name'] );

        if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) {
            wp_send_json_error( [ 'message' => 'Failed to move uploaded file to: ' . $dest . '. Check folder permissions.' ] );
            exit;
        }

        set_transient( 'cpi_upload_' . get_current_user_id(), $dest, HOUR_IN_SECONDS );
        return $dest;
    }
}
