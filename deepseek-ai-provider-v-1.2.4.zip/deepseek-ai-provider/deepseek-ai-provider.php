<?php
/**
 * Plugin Name:       DeepSeek AI Provider
 * Plugin URI:        https://wpdev.com.cn
 * Description:       DeepSeek AI provider for the WordPress AI Client SDK with full Polylang translation support — translate posts, pages, products, and categories in bulk with one click.
 * Version:           1.2.4
 * Requires at least: 6.9
 * Requires PHP:      7.4
 * Author:            sanjie wp
 * Author URI:        https://wpdev.com.cn
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       deepseek-ai-provider
 * Domain Path:       /languages
 */

declare(strict_types=1);

namespace DeepSeekAiProvider;

use WordPress\AiClient\AiClient;
use DeepSeekAiProvider\Admin\TranslationMetaBox;
use DeepSeekAiProvider\Admin\BulkTranslatePage;
use DeepSeekAiProvider\Provider\DeepSeekProvider;
use DeepSeekAiProvider\REST\TranslationController;
use DeepSeekAiProvider\REST\BulkTranslationController;

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

define( 'DSAP_VERSION', '1.2.4' );
define( 'DSAP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'DSAP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Autoloader.
spl_autoload_register(
	function ( string $class ): void {
		$prefix   = 'DeepSeekAiProvider\\';
		$base_dir = DSAP_PLUGIN_DIR . 'src/';

		if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class, strlen( $prefix ) );
		$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

/**
 * Register DeepSeek as a provider in the WordPress AI Client.
 */
function register_provider(): void {
	if ( ! class_exists( AiClient::class ) ) {
		return;
	}

	$registry = AiClient::defaultRegistry();

	if ( $registry->hasProvider( DeepSeekProvider::class ) ) {
		return;
	}

	$registry->registerProvider( DeepSeekProvider::class );
}

add_action( 'init', __NAMESPACE__ . '\\register_provider', 5 );

/**
 * Associate the DeepSeek connector with this plugin file so the
 * Settings > Connectors admin screen displays correct status.
 */
function register_connector_plugin_file( \WP_Connector_Registry $registry ): void {
	if ( ! $registry->is_registered( 'deepseek' ) ) {
		return;
	}

	$connector                   = $registry->unregister( 'deepseek' );
	$connector['plugin']['file'] = 'deepseek-ai-provider/deepseek-ai-provider.php';
	$registry->register( 'deepseek', $connector );
}

add_action( 'wp_connectors_init', __NAMESPACE__ . '\\register_connector_plugin_file' );

/**
 * Add DeepSeek models to the preferred text-generation model list
 * used by the WordPress AI plugin's abilities.
 */
function add_preferred_text_models( array $models ): array {
	$models[] = array( 'deepseek', 'deepseek-chat' );
	$models[] = array( 'deepseek', 'deepseek-reasoner' );
	return $models;
}

add_filter( 'wpai_preferred_text_models', __NAMESPACE__ . '\\add_preferred_text_models' );

/**
 * Add DeepSeek models to the preferred vision model list.
 */
function add_preferred_vision_models( array $models ): array {
	$models[] = array( 'deepseek', 'deepseek-chat' );
	return $models;
}

add_filter( 'wpai_preferred_vision_models', __NAMESPACE__ . '\\add_preferred_vision_models' );

/**
 * Increase the default AI Client HTTP request timeout.
 */
function increase_ai_request_timeout( float $timeout ): float {
	return max( $timeout, 180.0 );
}

add_filter( 'wp_ai_client_default_request_timeout', __NAMESPACE__ . '\\increase_ai_request_timeout' );

/**
 * Register the native WordPress core AI connector (fallback for
 * WordPress installations that use the filter-based connector system).
 */
function register_native_core_connector( array $connectors ): array {
	if ( isset( $connectors['deepseek'] ) ) {
		return $connectors;
	}

	$connectors['deepseek'] = array(
		'label'        => 'DeepSeek AI',
		'icon'         => 'dashicons-translation',
		'capabilities' => array( 'text-generation', 'code-completion' ),
		'models'       => array(
			'deepseek-chat'     => 'DeepSeek V3 (Chat)',
			'deepseek-reasoner' => 'DeepSeek R1 (Reasoner)',
		),
	);

	return $connectors;
}

add_filter( 'wp_ai_registered_connectors', __NAMESPACE__ . '\\register_native_core_connector' );

/**
 * Handle native WordPress core AI routing to DeepSeek.
 */
function handle_native_core_routing( $response, array $args ) {
	$api_key = get_option( 'dsap_deepseek_api_key', '' );
	if ( empty( $api_key ) ) {
		return new \WP_Error( 'missing_api_key', 'DeepSeek API key is not configured.' );
	}

	$body = array(
		'model'       => $args['model'] ?? 'deepseek-chat',
		'messages'    => $args['messages'] ?? array(),
		'temperature' => $args['temperature'] ?? 0.7,
		'stream'      => false,
	);

	$request = wp_remote_post( 'https://api.deepseek.com/chat/completions', array(
		'headers' => array(
			'Authorization' => 'Bearer ' . $api_key,
			'Content-Type'  => 'application/json',
		),
		'body'            => wp_json_encode( $body ),
		'timeout'         => 180,
		'connect_timeout' => 45,
	) );

	if ( is_wp_error( $request ) ) {
		return $request;
	}

	$parsed = json_decode( wp_remote_retrieve_body( $request ), true );

	return array(
		'text'         => $parsed['choices'][0]['message']['content'] ?? '',
		'raw_response' => $parsed,
		'usage'        => $parsed['usage'] ?? array(),
	);
}

add_filter( 'wp_ai_execute_request_deepseek', __NAMESPACE__ . '\\handle_native_core_routing', 10, 2 );

/**
 * Boot the translation features (meta box, bulk page, REST endpoints).
 */
function boot_translation_features(): void {
	( new TranslationMetaBox() )->register();
	( new TranslationController() )->register();
	( new BulkTranslationController() )->register();
	( new BulkTranslatePage() )->register();
}

add_action( 'plugins_loaded', __NAMESPACE__ . '\\boot_translation_features' );
