<?php
/**
 * Plugin Name: Bulk Content Replacer
 * Plugin URI:  https://example.com/
 * Description: Safely find & replace text (including CJK/Unicode, e.g. 轴承 → bearing) across post titles, content and excerpts, with a dry-run preview before committing anything.
 * Version:     1.0.0
 * Author:      Your Name
 * License:     GPL v2 or later
 * Text Domain: bulk-content-replacer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

class BCR_Bulk_Content_Replacer {

	const CAP           = 'manage_options';
	const NONCE_ACTION  = 'bcr_replace_action';
	const NONCE_NAME    = 'bcr_nonce';
	const PAGE_SLUG     = 'bcr-bulk-replace';
	const TRANSIENT_KEY = 'bcr_results_';
	const DEFAULT_LIMIT = 200;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_bcr_run', array( $this, 'handle_run' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/* ---------------------------------------------------------------
	 * Menu / assets
	 * ------------------------------------------------------------- */

	public function add_menu() {
		add_management_page(
			__( 'Bulk Content Replacer', 'bulk-content-replacer' ),
			__( 'Bulk Replace', 'bulk-content-replacer' ),
			self::CAP,
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( strpos( $hook, self::PAGE_SLUG ) === false ) {
			return;
		}
		wp_add_inline_style( 'common', '
			.bcr-wrap { max-width: 1100px; }
			.bcr-card { background:#fff;border:1px solid #ccd0d4;padding:20px;margin-top:20px; }
			.bcr-field-row { margin-bottom: 16px; }
			.bcr-field-row label { font-weight:600; display:block; margin-bottom:4px; }
			.bcr-inline label { font-weight:400; margin-right:16px; display:inline-block; }
			.bcr-help { color:#666; font-size:12px; margin-top:4px; }
			table.bcr-results { border-collapse: collapse; width:100%; margin-top:16px; }
			table.bcr-results th, table.bcr-results td { border:1px solid #e0e0e0; padding:8px; text-align:left; vertical-align:top; }
			table.bcr-results th { background:#f6f7f7; }
			.bcr-old { background:#ffecec; text-decoration:line-through; }
			.bcr-new { background:#eaffea; }
			.bcr-count-badge { background:#2271b1;color:#fff;border-radius:10px;padding:1px 8px;font-size:12px; }
			.bcr-summary { font-size:14px; padding:10px 14px; border-left:4px solid #2271b1; background:#f0f6fc; margin-top:16px; }
		' );
	}

	/* ---------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------- */

	public function render_page() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'bulk-content-replacer' ) );
		}

		$user_id = get_current_user_id();
		$results = get_transient( self::TRANSIENT_KEY . $user_id );
		if ( $results ) {
			delete_transient( self::TRANSIENT_KEY . $user_id );
		}

		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		?>
		<div class="wrap bcr-wrap">
			<h1><?php esc_html_e( 'Bulk Content Replacer', 'bulk-content-replacer' ); ?></h1>
			<p><?php esc_html_e( 'Find and replace text across your posts. Works with any language, including Chinese/CJK text. Always run "Preview" first before executing a real replacement.', 'bulk-content-replacer' ); ?></p>

			<?php if ( $results ) : ?>
				<?php $this->render_results( $results ); ?>
			<?php endif; ?>

			<div class="bcr-card">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>
					<input type="hidden" name="action" value="bcr_run" />

					<div class="bcr-field-row">
						<label for="bcr_search"><?php esc_html_e( 'Find (search text)', 'bulk-content-replacer' ); ?></label>
						<input type="text" id="bcr_search" name="bcr_search" class="large-text" required
							value="<?php echo isset( $_POST['bcr_search'] ) ? esc_attr( wp_unslash( $_POST['bcr_search'] ) ) : ''; ?>"
							placeholder="<?php esc_attr_e( 'e.g. 轴承', 'bulk-content-replacer' ); ?>" />
					</div>

					<div class="bcr-field-row">
						<label for="bcr_replace"><?php esc_html_e( 'Replace with', 'bulk-content-replacer' ); ?></label>
						<input type="text" id="bcr_replace" name="bcr_replace" class="large-text"
							placeholder="<?php esc_attr_e( 'e.g. bearing', 'bulk-content-replacer' ); ?>" />
						<p class="bcr-help"><?php esc_html_e( 'Leave empty to delete all matches.', 'bulk-content-replacer' ); ?></p>
					</div>

					<div class="bcr-field-row">
						<label><?php esc_html_e( 'Post types', 'bulk-content-replacer' ); ?></label>
						<div class="bcr-inline">
							<?php foreach ( $post_types as $pt ) : ?>
								<label>
									<input type="checkbox" name="bcr_post_types[]" value="<?php echo esc_attr( $pt->name ); ?>" <?php checked( $pt->name === 'post' || $pt->name === 'product' ); ?> />
									<?php echo esc_html( $pt->labels->singular_name ); ?>
								</label>
							<?php endforeach; ?>
						</div>
					</div>

					<div class="bcr-field-row">
						<label><?php esc_html_e( 'Fields to search', 'bulk-content-replacer' ); ?></label>
						<div class="bcr-inline">
							<label><input type="checkbox" name="bcr_fields[]" value="post_title" checked /> <?php esc_html_e( 'Title', 'bulk-content-replacer' ); ?></label>
							<label><input type="checkbox" name="bcr_fields[]" value="post_content" checked /> <?php esc_html_e( 'Content', 'bulk-content-replacer' ); ?></label>
							<label><input type="checkbox" name="bcr_fields[]" value="post_excerpt" /> <?php esc_html_e( 'Excerpt', 'bulk-content-replacer' ); ?></label>
						</div>
					</div>

					<div class="bcr-field-row">
						<label><?php esc_html_e( 'Post status', 'bulk-content-replacer' ); ?></label>
						<select name="bcr_status">
							<option value="any"><?php esc_html_e( 'Any', 'bulk-content-replacer' ); ?></option>
							<option value="publish" selected><?php esc_html_e( 'Published', 'bulk-content-replacer' ); ?></option>
							<option value="draft"><?php esc_html_e( 'Draft', 'bulk-content-replacer' ); ?></option>
							<option value="pending"><?php esc_html_e( 'Pending', 'bulk-content-replacer' ); ?></option>
							<option value="private"><?php esc_html_e( 'Private', 'bulk-content-replacer' ); ?></option>
						</select>
					</div>

					<div class="bcr-field-row">
						<label><?php esc_html_e( 'Options', 'bulk-content-replacer' ); ?></label>
						<div class="bcr-inline">
							<label><input type="checkbox" name="bcr_case_sensitive" value="1" /> <?php esc_html_e( 'Case sensitive', 'bulk-content-replacer' ); ?></label>
							<label><input type="checkbox" name="bcr_whole_word" value="1" /> <?php esc_html_e( 'Whole word only', 'bulk-content-replacer' ); ?></label>
							<label><input type="checkbox" name="bcr_regex" value="1" /> <?php esc_html_e( 'Treat "Find" as a regular expression (advanced)', 'bulk-content-replacer' ); ?></label>
						</div>
						<p class="bcr-help"><?php esc_html_e( '"Whole word" uses Unicode word boundaries; for CJK text without spaces this has little effect, so leave it unchecked for Chinese/Japanese/Korean.', 'bulk-content-replacer' ); ?></p>
					</div>

					<div class="bcr-field-row">
						<label for="bcr_limit"><?php esc_html_e( 'Max posts to process per run', 'bulk-content-replacer' ); ?></label>
						<input type="number" id="bcr_limit" name="bcr_limit" min="1" max="2000" value="<?php echo (int) self::DEFAULT_LIMIT; ?>" />
						<p class="bcr-help"><?php esc_html_e( 'Keeps each run fast and avoids timeouts. Run again to continue with remaining posts.', 'bulk-content-replacer' ); ?></p>
					</div>

					<p class="submit">
						<button type="submit" name="bcr_mode" value="preview" class="button button-secondary">
							<?php esc_html_e( 'Preview (dry run — no changes saved)', 'bulk-content-replacer' ); ?>
						</button>
						<button type="submit" name="bcr_mode" value="execute" class="button button-primary"
							onclick="return confirm('<?php echo esc_js( __( 'This will permanently update your posts. Have you previewed the changes first? Continue?', 'bulk-content-replacer' ) ); ?>');">
							<?php esc_html_e( 'Run replacement now', 'bulk-content-replacer' ); ?>
						</button>
					</p>
				</form>
			</div>
		</div>
		<?php
	}

	private function render_results( $results ) {
		$mode      = $results['mode'];
		$search    = $results['search'];
		$replace   = $results['replace'];
		$rows      = $results['rows'];
		$scanned   = $results['scanned_count'];
		$matched   = count( $rows );
		$total_hit = array_sum( wp_list_pluck( $rows, 'count' ) );

		echo '<div class="bcr-summary">';
		if ( 'execute' === $mode ) {
			printf(
				/* translators: 1: matched posts 2: total occurrences 3: search 4: replace */
				esc_html__( '✅ Done. Updated %1$d post(s), replacing %2$d occurrence(s) of "%3$s" with "%4$s".', 'bulk-content-replacer' ),
				(int) $matched,
				(int) $total_hit,
				esc_html( $search ),
				esc_html( $replace )
			);
		} else {
			printf(
				/* translators: 1: scanned 2: matched posts 3: total occurrences */
				esc_html__( '🔍 Preview only — nothing was saved. Scanned %1$d post(s); %2$d post(s) contain %3$d matching occurrence(s).', 'bulk-content-replacer' ),
				(int) $scanned,
				(int) $matched,
				(int) $total_hit
			);
		}
		echo '</div>';

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'No matches found.', 'bulk-content-replacer' ) . '</p>';
			return;
		}

		echo '<table class="bcr-results"><thead><tr>
			<th>' . esc_html__( 'Post', 'bulk-content-replacer' ) . '</th>
			<th>' . esc_html__( 'Field', 'bulk-content-replacer' ) . '</th>
			<th>' . esc_html__( 'Matches', 'bulk-content-replacer' ) . '</th>
			<th>' . esc_html__( 'Before / After (snippet)', 'bulk-content-replacer' ) . '</th>
		</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$edit_link = get_edit_post_link( $row['post_id'] );
			echo '<tr>';
			echo '<td>';
			if ( $edit_link ) {
				echo '<a href="' . esc_url( $edit_link ) . '" target="_blank">' . esc_html( $row['post_title'] ) . '</a>';
			} else {
				echo esc_html( $row['post_title'] );
			}
			echo '<br><small>#' . (int) $row['post_id'] . '</small>';
			echo '</td>';
			echo '<td>' . esc_html( $row['field'] ) . '</td>';
			echo '<td><span class="bcr-count-badge">' . (int) $row['count'] . '</span></td>';
			echo '<td><span class="bcr-old">' . esc_html( $row['snippet_before'] ) . '</span><br>→<br><span class="bcr-new">' . esc_html( $row['snippet_after'] ) . '</span></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/* ---------------------------------------------------------------
	 * Handling submission
	 * ------------------------------------------------------------- */

	public function handle_run() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'bulk-content-replacer' ) );
		}

		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );

		$search         = isset( $_POST['bcr_search'] ) ? wp_unslash( $_POST['bcr_search'] ) : '';
		$replace        = isset( $_POST['bcr_replace'] ) ? wp_unslash( $_POST['bcr_replace'] ) : '';
		$post_types     = isset( $_POST['bcr_post_types'] ) ? array_map( 'sanitize_key', (array) $_POST['bcr_post_types'] ) : array();
		$fields         = isset( $_POST['bcr_fields'] ) ? array_map( 'sanitize_key', (array) $_POST['bcr_fields'] ) : array();
		$status         = isset( $_POST['bcr_status'] ) ? sanitize_key( $_POST['bcr_status'] ) : 'publish';
		$case_sensitive = ! empty( $_POST['bcr_case_sensitive'] );
		$whole_word     = ! empty( $_POST['bcr_whole_word'] );
		$use_regex      = ! empty( $_POST['bcr_regex'] );
		$limit          = isset( $_POST['bcr_limit'] ) ? max( 1, min( 2000, (int) $_POST['bcr_limit'] ) ) : self::DEFAULT_LIMIT;
		$mode           = isset( $_POST['bcr_mode'] ) && 'execute' === $_POST['bcr_mode'] ? 'execute' : 'preview';

		$allowed_fields = array( 'post_title', 'post_content', 'post_excerpt' );
		$fields         = array_values( array_intersect( $fields, $allowed_fields ) );

		$redirect_back = add_query_arg(
			array( 'page' => self::PAGE_SLUG ),
			admin_url( 'tools.php' )
		);

		if ( '' === trim( $search ) || empty( $post_types ) || empty( $fields ) ) {
			wp_safe_redirect( $redirect_back );
			exit;
		}

		// Build a fast SQL pre-filter, unless doing a full regex search (SQL can't evaluate PCRE).
		global $wpdb;
		$post_type_placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		if ( 'any' === $status ) {
			$status_sql = "post_status != 'trash'";
			$status_params = array();
		} else {
			$status_sql = 'post_status = %s';
			$status_params = array( $status );
		}

		if ( $use_regex ) {
			// Can't pre-filter by LIKE for a regex; just filter by type/status and scan in PHP.
			$sql = "SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts}
				WHERE post_type IN ($post_type_placeholders) AND $status_sql
				ORDER BY ID DESC LIMIT %d";
			$params = array_merge( $post_types, $status_params, array( $limit ) );
		} else {
			$like_clauses = array();
			$like_params  = array();
			foreach ( $fields as $field ) {
				$like_clauses[] = "$field LIKE %s";
				$like_params[]  = '%' . $wpdb->esc_like( $search ) . '%';
			}
			$like_sql = implode( ' OR ', $like_clauses );

			$sql = "SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts}
				WHERE post_type IN ($post_type_placeholders) AND $status_sql AND ($like_sql)
				ORDER BY ID DESC LIMIT %d";
			$params = array_merge( $post_types, $status_params, $like_params, array( $limit ) );
		}

		$prepared = $wpdb->prepare( $sql, $params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$posts    = $wpdb->get_results( $prepared );

		$rows = array();

		foreach ( $posts as $p ) {
			foreach ( $fields as $field ) {
				$original = $p->$field;
				if ( '' === $original ) {
					continue;
				}

				list( $updated, $count ) = $this->do_replace( $original, $search, $replace, $case_sensitive, $whole_word, $use_regex );

				if ( $count > 0 ) {
					$rows[] = array(
						'post_id'        => $p->ID,
						'post_title'     => $p->post_title,
						'field'          => $field,
						'count'          => $count,
						'snippet_before' => $this->make_snippet( $original, $search, $use_regex, $case_sensitive ),
						'snippet_after'  => $this->make_snippet( $updated, $replace ? $replace : '', false, $case_sensitive, true ),
						'new_value'      => $updated,
					);

					if ( 'execute' === $mode ) {
						$this->apply_update( $p->ID, $field, $updated );
					}
				}
			}
		}

		set_transient(
			self::TRANSIENT_KEY . get_current_user_id(),
			array(
				'mode'          => $mode,
				'search'        => $search,
				'replace'       => $replace,
				'rows'          => $rows,
				'scanned_count' => count( $posts ),
			),
			5 * MINUTE_IN_SECONDS
		);

		wp_safe_redirect( $redirect_back );
		exit;
	}

	/**
	 * Apply the update for a single post field via wp_update_post(),
	 * so revisions and standard hooks (save_post, etc.) still fire.
	 */
	private function apply_update( $post_id, $field, $new_value ) {
		$args = array( 'ID' => $post_id );
		$args[ $field ] = $new_value;

		// Avoid wp_update_post() re-triggering content filters that could mangle raw text.
		remove_filter( 'content_save_pre', 'wp_filter_post_kses' );
		wp_update_post( $args );
		add_filter( 'content_save_pre', 'wp_filter_post_kses' );

		clean_post_cache( $post_id );
	}

	/**
	 * Perform the actual text replacement. Unicode-safe (works correctly with
	 * CJK text such as 轴承) because it operates with the 'u' PCRE modifier.
	 *
	 * @return array [ $new_string, $match_count ]
	 */
	private function do_replace( $subject, $search, $replace, $case_sensitive, $whole_word, $use_regex ) {
		if ( $use_regex ) {
			$modifiers = 'u' . ( $case_sensitive ? '' : 'i' );
			$pattern   = '/' . $search . '/' . $modifiers;
			$count     = 0;
			$result    = @preg_replace( $pattern, $replace, $subject, -1, $count ); // phpcs:ignore
			if ( null === $result ) {
				// Invalid regex — treat as no match rather than fatal.
				return array( $subject, 0 );
			}
			return array( $result, $count );
		}

		$quoted = preg_quote( $search, '/' );

		if ( $whole_word ) {
			// Unicode-aware word boundary (works well for Latin scripts; limited value for CJK).
			$quoted = '(?<![\p{L}\p{N}_])' . $quoted . '(?![\p{L}\p{N}_])';
		}

		$modifiers = 'u' . ( $case_sensitive ? '' : 'i' );
		$pattern   = '/' . $quoted . '/' . $modifiers;

		$count  = 0;
		$result = preg_replace_callback(
			$pattern,
			function ( $matches ) use ( $replace, &$count ) {
				$count++;
				return $replace;
			},
			$subject
		);

		if ( null === $result ) {
			return array( $subject, 0 );
		}

		return array( $result, $count );
	}

	/**
	 * Build a short, human-readable snippet around the first match for the preview table.
	 */
	private function make_snippet( $text, $needle, $use_regex, $case_sensitive, $is_after = false ) {
		$plain = wp_strip_all_tags( $text );

		if ( '' === $needle ) {
			return mb_substr( $plain, 0, 80 ) . ( mb_strlen( $plain ) > 80 ? '…' : '' );
		}

		if ( $use_regex ) {
			$pos = false; // Can't reliably locate a regex match position simply; fall back to start.
		} else {
			$pos = $case_sensitive ? mb_strpos( $plain, $needle ) : mb_stripos( $plain, $needle );
		}

		if ( false === $pos ) {
			return mb_substr( $plain, 0, 80 ) . ( mb_strlen( $plain ) > 80 ? '…' : '' );
		}

		$start = max( 0, $pos - 30 );
		$len   = mb_strlen( $needle ) + 60;
		$snip  = mb_substr( $plain, $start, $len );

		return ( $start > 0 ? '…' : '' ) . $snip . ( ( $start + $len ) < mb_strlen( $plain ) ? '…' : '' );
	}
}

new BCR_Bulk_Content_Replacer();
