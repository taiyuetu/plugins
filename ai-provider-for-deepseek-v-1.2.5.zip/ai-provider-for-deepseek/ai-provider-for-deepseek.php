<?php
/**
 * The plugin bootstrap file.
 *
 * Plugin Name:       AI Provider For DeepSeek
 * Plugin URI:        https://wpdev.com.cn
 * Description:       DeepSeek AI provider for the PHP AI Client SDK, with Polylang post translation support.
 * Version:           1.2.5
 * Requires at least: 6.9
 * Requires PHP:      7.4
 * Author:            sanjie wp
 * Author URI:        https://wpdev.com.cn
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ai-provider-for-deepseek
 * Domain Path:       /languages
 * 
 * -fixed the translation post not in the same category issue 
 * -fixed the sdk compatibility issue
 */

declare(strict_types=1);

namespace Sajjad67\AiProviderForDeepSeek;

use WordPress\AiClient\AiClient;
use Sajjad67\AiProviderForDeepSeek\Admin\TranslationMetaBox;
use Sajjad67\AiProviderForDeepSeek\Provider\DeepSeekProvider;
use Sajjad67\AiProviderForDeepSeek\REST\TranslationController;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

// Plugin constants.
define( 'AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_VERSION', '1.1.0' );
define( 'AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Autoloader.
spl_autoload_register(
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.classFound
	function ( string $class ): void {
		$prefix   = 'Sajjad67\AiProviderForDeepSeek\\';
		$base_dir = AIPRFD_AI_PROVIDER_FOR_DEEPSEEK_PLUGIN_DIR . 'src/';

		if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class, strlen( $prefix ) );
		$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

/**
 * Registers the AI Provider for DeepSeek with the AI Client.
 *
 * @since  1.0.0
 * @return void
 */
function register_provider(): void {
	if ( ! class_exists( AiClient::class ) ) {
		return;
	}

	$registry = AiClient::defaultRegistry();

	if ( $registry->hasProvider( DeepSeekProvider::class ) ) {
		return;
	}

	$registry->registerProvider( DeepSeekProvider::class );
}

add_action( 'init', __NAMESPACE__ . '\\register_provider', 5 );

/**
 * Associates the DeepSeek connector with this plugin file so the
 * Settings → Connectors admin screen can display the correct
 * install / activate status.
 *
 * @since  1.2.0
 * @param  \WP_Connector_Registry $registry Connector registry.
 * @return void
 */
function register_connector_plugin_file( \WP_Connector_Registry $registry ): void {
	if ( ! $registry->is_registered( 'deepseek' ) ) {
		return;
	}

	$connector                    = $registry->unregister( 'deepseek' );
	$connector['plugin']['file']  = 'ai-provider-for-deepseek/ai-provider-for-deepseek.php';
	$registry->register( 'deepseek', $connector );
}

add_action( 'wp_connectors_init', __NAMESPACE__ . '\\register_connector_plugin_file' );

/**
 * Adds DeepSeek models to the preferred text-generation model list used by
 * the WordPress AI plugin's abilities (Suggest Tags, Summarization, etc.).
 *
 * Without this, those features only look for Anthropic / Google / OpenAI
 * models and will report "no connected provider" even when DeepSeek is
 * fully configured.
 *
 * @since  1.2.0
 * @param  array $models Current preferred models list.
 * @return array
 */
function add_deepseek_preferred_text_models( array $models ): array {
	$models[] = array( 'deepseek', 'deepseek-chat' );
	$models[] = array( 'deepseek', 'deepseek-reasoner' );
	return $models;
}

add_filter( 'wpai_preferred_text_models', __NAMESPACE__ . '\\add_deepseek_preferred_text_models' );

/**
 * Adds DeepSeek models to the preferred vision model list.
 *
 * @since  1.2.0
 * @param  array $models Current preferred models list.
 * @return array
 */
function add_deepseek_preferred_vision_models( array $models ): array {
	$models[] = array( 'deepseek', 'deepseek-chat' );
	return $models;
}

add_filter( 'wpai_preferred_vision_models', __NAMESPACE__ . '\\add_deepseek_preferred_vision_models' );

/**
 * Increases the default AI Client HTTP request timeout.
 *
 * The WordPress default is 30 s which is too short for DeepSeek,
 * especially for complex prompts and translation of long content.
 *
 * @since  1.2.0
 * @param  float $timeout Current default timeout in seconds.
 * @return float
 */
function increase_ai_request_timeout( float $timeout ): float {
	return max( $timeout, 60.0 );
}

add_filter( 'wp_ai_client_default_request_timeout', __NAMESPACE__ . '\\increase_ai_request_timeout' );

/**
 * Boots the translation feature (meta box + REST endpoint).
 *
 * @since  1.1.0
 * @return void
 */
function boot_translation_feature(): void {
	( new TranslationMetaBox() )->register();
	( new TranslationController() )->register();
}

add_action( 'plugins_loaded', __NAMESPACE__ . '\\boot_translation_feature' );
