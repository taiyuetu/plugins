# Changelog

All notable changes to CSV Product Importer Pro are documented here.

## [2.1.0] – 2026-05-19

### Added
- **Post content generation** — each imported product post is now populated with a structured body built from its CSV meta fields. The format is:
  ```
  {Post Title}
  OEM Number: {oem_num}
  Car Application: {car_application}
  Diameter: {outer_diameter}
  Weight: {weight}
  ```
  Fields with no value in the CSV row are omitted automatically.
- `CPI_Config::CONTENT_FORMULA` constant — a simple array that controls which meta columns appear in the post content and their human-readable labels. Add, remove, or reorder entries without touching importer logic.
- `CPI_Config::build_post_content( array $row, string $title ): string` — static helper that assembles and HTML-escapes the post body from a CSV row.
- Post content is written on both **insert** (new products) and **update** (existing products in "update" duplicate mode).

---

## [2.0.0] – Initial release

- Import products from CSV into a configurable WordPress post type.
- Auto-generates post titles from a configurable column formula (`TITLE_FORMULA`).
- Saves every CSV column as post meta (key = lowercased column header).
- Automatic thumbnail and gallery assignment by matching image filenames against a configurable `IMAGE_KEY` column.
- Per-row taxonomy (product category) assignment via `TAXONOMY_COLUMN`.
- Polylang integration — sets default language and pushes meta / gallery to translations.
- Batch import with configurable batch size and offset.
- Duplicate handling modes: skip, update, or allow duplicates.
- Admin UI with CSV preview, import progress, and per-batch AJAX processing.
