<?php
defined( 'ABSPATH' ) || exit;

/**
 * Parses a CSV file into structured product rows.
 *
 * All CSV column headers become post meta keys (lowercased).
 * Only the unique-key column is strictly required.
 */
class CPI_CSV_Parser {

    /**
     * Parse the uploaded CSV file.
     *
     * @param string $file_path Absolute path to the uploaded CSV.
     * @return array{headers: string[], rows: array[], errors: string[]}
     */
    public static function parse( string $file_path ): array {
        $result = [
            'headers' => [],
            'rows'    => [],
            'errors'  => [],
        ];

        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            $result['errors'][] = __( 'File not found or not readable.', 'csv-product-importer' );
            return $result;
        }

        $handle = self::open_csv_handle( $file_path );
        if ( ! $handle ) {
            $result['errors'][] = __( 'Could not open file.', 'csv-product-importer' );
            return $result;
        }

        // Read header row
        $raw_headers = fgetcsv( $handle, 0, ',' );
        if ( empty( $raw_headers ) ) {
            $result['errors'][] = __( 'CSV file appears to be empty or malformed.', 'csv-product-importer' );
            fclose( $handle );
            return $result;
        }

        $headers = array_map(
            static fn( $h ) => trim( strtolower( self::ensure_utf8( ltrim( (string) $h, "\xEF\xBB\xBF" ) ) ) ),
            $raw_headers
        );
        $result['headers'] = $headers;

        // Only the unique-key column is strictly required
        $unique_key = strtolower( CPI_Config::UNIQUE_KEY );
        if ( ! in_array( $unique_key, $headers, true ) ) {
            $result['errors'][] = sprintf(
                __( 'Missing required column: %s', 'csv-product-importer' ),
                $unique_key
            );
            fclose( $handle );
            return $result;
        }

        $col_index = array_flip( $headers );
        $row_num   = 1;

        while ( ( $data = fgetcsv( $handle, 0, ',' ) ) !== false ) {
            $row_num++;

            // Skip completely empty rows
            if ( empty( array_filter( $data, static fn( $v ) => trim( $v ) !== '' ) ) ) {
                continue;
            }

            // Pad short rows
            while ( count( $data ) < count( $headers ) ) {
                $data[] = '';
            }

            $row = [];
            foreach ( $headers as $i => $key ) {
                $row[ $key ] = self::clean_value( $data[ $i ] ?? '' );
            }

            // Require the unique-key column to have a value
            $unique_key = CPI_Config::UNIQUE_KEY;
            if ( empty( $row[ $unique_key ] ) ) {
                $result['errors'][] = sprintf(
                    /* translators: 1: row number, 2: column name */
                    __( 'Row %1$d skipped — %2$s is empty.', 'csv-product-importer' ),
                    $row_num,
                    $unique_key
                );
                continue;
            }

            // Build the generated title from CPI_Config::TITLE_FORMULA
            $row['_generated_title'] = self::build_title( $row );
            $row['_generated_title'] = self::sanitize_title_for_import( $row['_generated_title'], $row );

            $result['rows'][] = $row;
        }

        fclose( $handle );
        return $result;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Sanitize a raw CSV cell value.
     * Strips the garbled £¬ (encoded comma) sequences that appear in some exports.
     */
    private static function clean_value( string $value ): string {
        $value = str_replace( [ "\xa3\xac", "\xc2\xa3\xc2\xac" ], "\n", $value );
        $value = self::ensure_utf8( $value );
        return trim( $value );
    }

    /**
     * Open CSV with UTF-8 BOM stripped from the start of the file.
     *
     * @return resource|false
     */
    private static function open_csv_handle( string $file_path ) {
        $handle = fopen( $file_path, 'r' );
        if ( ! $handle ) {
            return false;
        }

        $bom = fread( $handle, 3 );
        if ( "\xEF\xBB\xBF" !== $bom ) {
            rewind( $handle );
        }

        return $handle;
    }

    /**
     * Convert common Chinese export encodings (GBK / GB2312) to UTF-8.
     */
    private static function ensure_utf8( string $value ): string {
        if ( '' === $value || mb_check_encoding( $value, 'UTF-8' ) ) {
            return $value;
        }

        if ( function_exists( 'mb_convert_encoding' ) ) {
            $converted = @mb_convert_encoding( $value, 'UTF-8', 'GBK, GB2312, BIG5, Windows-1252, ISO-8859-1' );
            if ( is_string( $converted ) && mb_check_encoding( $converted, 'UTF-8' ) ) {
                return $converted;
            }
        }

        return wp_check_invalid_utf8( $value, true );
    }

    /**
     * Ensure the stored generated title will not be emptied on wp_insert_post().
     */
    private static function sanitize_title_for_import( string $title, array $row ): string {
        $sanitized = sanitize_text_field( $title );
        if ( '' !== $sanitized ) {
            return $sanitized;
        }

        $fallback = sanitize_text_field( (string) ( $row[ CPI_Config::UNIQUE_KEY ] ?? '' ) );
        if ( '' !== $fallback ) {
            return $fallback;
        }

        $stripped = trim( wp_strip_all_tags( $title ) );
        return '' !== $stripped ? mb_substr( $stripped, 0, 200 ) : $title;
    }

    /**
     * Build the post title from CPI_Config::TITLE_FORMULA.
     *
     * Formula: prefix columns joined by space, optional connector word,
     * then suffix columns joined by space.
     *
     * @param array $row Parsed CSV row (keyed by column name).
     * @return string
     */
    public static function build_title( array $row ): string {
        $formula   = CPI_Config::TITLE_FORMULA;
        $prefix    = $formula['prefix']    ?? [];
        $connector = $formula['connector'] ?? '';
        $suffix    = $formula['suffix']    ?? [];

        $prefix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $prefix )
        );
        $suffix_parts = array_filter(
            array_map( static fn( $col ) => trim( $row[ $col ] ?? '' ), $suffix )
        );

        $title = implode( ' ', $prefix_parts );

        if ( ! empty( $suffix_parts ) ) {
            $suffix_str = implode( ' ', $suffix_parts );
            $title .= ( '' !== $connector ? ' ' . $connector : '' ) . ' ' . $suffix_str;
        }

        return trim( $title );
    }
}
