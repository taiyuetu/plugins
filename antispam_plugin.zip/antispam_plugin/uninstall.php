<?php
/**
 * Uninstall Anti-Spam Comments Pro.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('antispam_comments_pro_options');
delete_option('antispam_log');
