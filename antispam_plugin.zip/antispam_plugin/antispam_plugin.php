<?php
/**
 * Plugin Name: Anti-Spam Comments Pro
 * Description: Lightweight spam comment protection with honeypot, timing, link limits, and configurable rules.
 * Version: 1.1.0
 * Author: wayne shen
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: antispam-comments-pro
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ANTISPAM_COMMENTS_PRO_OPTION', 'antispam_comments_pro_options');
define('ANTISPAM_COMMENTS_PRO_LOG', 'antispam_log');

final class AntiSpamCommentsPro {

    /** @var array<string, mixed> */
    private $options = [];

    private $default_keywords = ['viagra', 'casino', 'loan', 'mortgage', 'pharmacy', 'replica'];

    private $default_suspicious_patterns = [
        '/https?:\/\//i',
        '/\[url=/i',
        '/\[link=/i',
    ];

    public function __construct() {
        $this->options = $this->get_options();
        add_action('init', [$this, 'register_hooks']);
        add_action('admin_init', [$this, 'handle_admin_actions']);
    }

    /**
     * @return array<string, mixed>
     */
    private function get_options(): array {
        $defaults = [
            'spam_keywords' => $this->default_keywords,
            'min_submit_seconds' => 3,
            'max_links' => 3,
            'min_comment_length' => 10,
            'min_word_count' => 3,
            'uniqueness_ratio' => 0.5,
            'disposable_domains' => ['tempmail.org', '10minutemail.com', 'guerrillamail.com', 'mailinator.com'],
            'block_scraper_ua_on_comments' => false,
            'scraper_ua_substrings' => ['semrush', 'ahrefs', 'mj12bot'],
            'enable_logging' => true,
            'log_max_entries' => 100,
            'admin_list_limit' => 20,
        ];

        $stored = get_option(ANTISPAM_COMMENTS_PRO_OPTION, []);
        if (!is_array($stored)) {
            $stored = [];
        }

        return array_merge($defaults, $stored);
    }

    public function register_hooks(): void {
        add_filter('pre_comment_approved', [$this, 'check_spam'], 10, 2);
        add_action('comment_form', [$this, 'add_honeypot']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('wp_footer', [$this, 'output_comment_timing_script'], 20);
    }

    public function handle_admin_actions(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_POST['antispam_comments_pro_save']) && check_admin_referer('antispam_comments_pro_save', 'antispam_comments_pro_nonce')) {
            $this->save_settings_from_post();
            add_settings_error('antispam_comments_pro', 'settings_saved', __('Settings saved.', 'antispam-comments-pro'), 'success');
        }

        if (isset($_GET['antispam_clear_log']) && $_GET['antispam_clear_log'] === '1') {
            check_admin_referer('antispam_comments_pro_clear_log');
            delete_option(ANTISPAM_COMMENTS_PRO_LOG);
            wp_safe_redirect(remove_query_arg('antispam_clear_log', wp_get_referer() ?: admin_url('options-general.php?page=antispam-comments')));
            exit;
        }
    }

    private function save_settings_from_post(): void {
        $keywords_raw = isset($_POST['spam_keywords']) ? sanitize_textarea_field(wp_unslash($_POST['spam_keywords'])) : '';
        $keywords = array_filter(array_map('strtolower', array_map('trim', preg_split('/[\r\n,]+/', $keywords_raw))));

        $disposable_raw = isset($_POST['disposable_domains']) ? sanitize_textarea_field(wp_unslash($_POST['disposable_domains'])) : '';
        $disposable = array_filter(array_map('strtolower', array_map('trim', preg_split('/[\r\n,]+/', $disposable_raw))));

        $ua_raw = isset($_POST['scraper_ua_substrings']) ? sanitize_textarea_field(wp_unslash($_POST['scraper_ua_substrings'])) : '';
        $ua_subs = array_filter(array_map('strtolower', array_map('trim', preg_split('/[\r\n,]+/', $ua_raw))));

        $this->options = array_merge($this->options, [
            'spam_keywords' => $keywords ?: $this->default_keywords,
            'min_submit_seconds' => max(0, (int) ($_POST['min_submit_seconds'] ?? 3)),
            'max_links' => max(0, (int) ($_POST['max_links'] ?? 3)),
            'min_comment_length' => max(1, (int) ($_POST['min_comment_length'] ?? 10)),
            'min_word_count' => max(1, (int) ($_POST['min_word_count'] ?? 3)),
            'uniqueness_ratio' => min(1, max(0, (float) ($_POST['uniqueness_ratio'] ?? 0.5))),
            'disposable_domains' => $disposable ?: ['tempmail.org', '10minutemail.com', 'guerrillamail.com', 'mailinator.com'],
            'block_scraper_ua_on_comments' => !empty($_POST['block_scraper_ua_on_comments']),
            'scraper_ua_substrings' => $ua_subs ?: ['semrush', 'ahrefs', 'mj12bot'],
            'enable_logging' => !empty($_POST['enable_logging']),
            'log_max_entries' => max(10, min(500, (int) ($_POST['log_max_entries'] ?? 100))),
            'admin_list_limit' => max(5, min(100, (int) ($_POST['admin_list_limit'] ?? 20))),
        ]);

        update_option(ANTISPAM_COMMENTS_PRO_OPTION, $this->options, false);
    }

    /**
     * @param int|string|float $approved
     * @param array<string, mixed> $commentdata
     * @return int|string|float
     */
    public function check_spam($approved, $commentdata) {
        if (current_user_can('edit_posts')) {
            return $approved;
        }

        if (!empty($this->options['block_scraper_ua_on_comments']) && $this->user_agent_matches_scraper_list()) {
            $this->log_spam(__('Blocked user agent on comment submission', 'antispam-comments-pro'));
            return 'spam';
        }

        $content = strtolower((string) ($commentdata['comment_content'] ?? ''));
        $author = strtolower((string) ($commentdata['comment_author'] ?? ''));
        $email = (string) ($commentdata['comment_author_email'] ?? '');

        if (!empty($_POST['website_url'])) {
            $this->log_spam(__('Honeypot triggered', 'antispam-comments-pro'));
            return 'spam';
        }

        if ($this->is_too_fast()) {
            $this->log_spam(__('Comment submitted too fast', 'antispam-comments-pro'));
            return 'spam';
        }

        $keywords = is_array($this->options['spam_keywords'] ?? null) ? $this->options['spam_keywords'] : $this->default_keywords;
        foreach ($keywords as $keyword) {
            $keyword = (string) $keyword;
            if ($keyword === '') {
                continue;
            }
            if (strpos($content, $keyword) !== false || strpos($author, $keyword) !== false) {
                $this->log_spam(sprintf(
                    /* translators: %s: matched keyword */
                    __('Spam keyword detected: %s', 'antispam-comments-pro'),
                    $keyword
                ));
                return 'spam';
            }
        }

        $link_count = $this->count_suspicious_links($content);
        $max_links = (int) ($this->options['max_links'] ?? 3);
        if ($max_links > 0 && $link_count > $max_links) {
            $this->log_spam(sprintf(
                /* translators: 1: link count, 2: max allowed */
                __('Too many links or URL patterns (%1$d > %2$d)', 'antispam-comments-pro'),
                $link_count,
                $max_links
            ));
            return 'spam';
        }

        if (!is_email($email) || $this->is_disposable_email($email)) {
            $this->log_spam(__('Invalid or disposable email', 'antispam-comments-pro'));
            return 'spam';
        }

        $min_len = (int) ($this->options['min_comment_length'] ?? 10);
        if (strlen($content) < $min_len || $this->low_quality_content($content)) {
            $this->log_spam(__('Low quality content', 'antispam-comments-pro'));
            return 'spam';
        }

        if ($this->is_duplicate($commentdata)) {
            $this->log_spam(__('Duplicate comment', 'antispam-comments-pro'));
            return 'spam';
        }

        return $approved;
    }

    private function user_agent_matches_scraper_list(): bool {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower((string) $_SERVER['HTTP_USER_AGENT']) : '';
        if ($ua === '') {
            return false;
        }
        $needles = is_array($this->options['scraper_ua_substrings'] ?? null) ? $this->options['scraper_ua_substrings'] : [];
        foreach ($needles as $needle) {
            $needle = strtolower((string) $needle);
            if ($needle !== '' && strpos($ua, $needle) !== false) {
                return true;
            }
        }
        return false;
    }

    private function count_suspicious_links(string $content): int {
        $max = 0;
        $patterns = is_array($this->options['suspicious_patterns'] ?? null)
            ? $this->options['suspicious_patterns']
            : $this->default_suspicious_patterns;

        foreach ($patterns as $pattern) {
            if (!is_string($pattern) || $pattern === '') {
                continue;
            }
            if (@preg_match_all($pattern, $content, $m) !== false) {
                $max = max($max, count($m[0] ?? []));
            }
        }
        return $max;
    }

    public function add_honeypot(): void {
        echo '<p class="antispam-hp" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true">';
        echo '<label for="website_url_antispam">' . esc_html__('Leave this empty', 'antispam-comments-pro') . '</label>';
        echo '<input type="text" name="website_url" id="website_url_antispam" tabindex="-1" autocomplete="off" value="">';
        echo '</p>';
    }

    public function output_comment_timing_script(): void {
        if (!is_singular() || !comments_open() || post_password_required()) {
            return;
        }
        ?>
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            var form = document.getElementById('commentform');
            if (!form || form.querySelector('input[name="start_time"]')) {
                return;
            }
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'start_time';
            input.value = String(Date.now());
            form.appendChild(input);
        });
        </script>
        <?php
    }

    private function is_too_fast(): bool {
        $min_ms = max(0, (int) ($this->options['min_submit_seconds'] ?? 3)) * 1000;
        if ($min_ms === 0) {
            return false;
        }

        if (!isset($_POST['start_time'])) {
            return false;
        }

        $start = (int) $_POST['start_time'];
        if ($start <= 0) {
            return false;
        }

        $now_ms = (int) round(microtime(true) * 1000);
        $elapsed = $now_ms - $start;

        // Reject implausible client clocks (far future or ancient).
        if ($elapsed < 0 || $elapsed > 1000 * 60 * 60 * 24) {
            return false;
        }

        return $elapsed < $min_ms;
    }

    private function is_disposable_email(string $email): bool {
        $at = strrpos($email, '@');
        if ($at === false) {
            return true;
        }
        $domain = strtolower(substr($email, $at + 1));
        $list = is_array($this->options['disposable_domains'] ?? null) ? $this->options['disposable_domains'] : [];
        return in_array($domain, array_map('strtolower', $list), true);
    }

    private function low_quality_content(string $content): bool {
        $words = $this->count_words_unicode($content);
        $min_words = (int) ($this->options['min_word_count'] ?? 3);
        if ($words < $min_words) {
            return true;
        }

        $parts = preg_split('/\s+/u', trim($content), -1, PREG_SPLIT_NO_EMPTY);
        if (!$parts) {
            return true;
        }
        $unique = count(array_unique(array_map('strtolower', $parts)));
        $ratio = (float) ($this->options['uniqueness_ratio'] ?? 0.5);
        return ($unique / max(1, $words)) < $ratio;
    }

    private function count_words_unicode(string $content): int {
        $parts = preg_split('/\s+/u', trim($content), -1, PREG_SPLIT_NO_EMPTY);
        return is_array($parts) ? count($parts) : 0;
    }

    /**
     * @param array<string, mixed> $commentdata
     */
    private function is_duplicate(array $commentdata): bool {
        global $wpdb;

        $content = isset($commentdata['comment_content']) ? (string) $commentdata['comment_content'] : '';
        $email = isset($commentdata['comment_author_email']) ? (string) $commentdata['comment_author_email'] : '';

        $duplicate = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT comment_ID FROM {$wpdb->comments}
                 WHERE comment_content = %s
                 AND comment_author_email = %s
                 AND comment_date_gmt > UTC_TIMESTAMP() - INTERVAL 1 DAY
                 LIMIT 1",
                $content,
                $email
            )
        );

        return !empty($duplicate);
    }

    private function log_spam(string $reason): void {
        if (empty($this->options['enable_logging'])) {
            return;
        }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : 'unknown';
        $ip = preg_replace('/[^0-9a-fA-F:.,]/', '', $ip) ?: 'unknown';

        $log_entry = [
            'time' => current_time('mysql'),
            'ip' => $ip,
            'reason' => $reason,
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 512) : 'unknown',
        ];

        $existing_log = get_option(ANTISPAM_COMMENTS_PRO_LOG, []);
        if (!is_array($existing_log)) {
            $existing_log = [];
        }
        array_unshift($existing_log, $log_entry);

        $max = (int) ($this->options['log_max_entries'] ?? 100);
        if (count($existing_log) > $max) {
            $existing_log = array_slice($existing_log, 0, $max);
        }

        update_option(ANTISPAM_COMMENTS_PRO_LOG, $existing_log, false);
    }

    public function admin_menu(): void {
        add_options_page(
            __('Anti-Spam Comments', 'antispam-comments-pro'),
            __('Anti-Spam Comments', 'antispam-comments-pro'),
            'manage_options',
            'antispam-comments',
            [$this, 'admin_page']
        );
    }

    public function admin_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        settings_errors('antispam_comments_pro');
        $this->options = $this->get_options();
        $spam_log = get_option(ANTISPAM_COMMENTS_PRO_LOG, []);
        if (!is_array($spam_log)) {
            $spam_log = [];
        }
        $total_blocked = count($spam_log);
        $list_limit = (int) ($this->options['admin_list_limit'] ?? 20);

        $keywords_text = implode("\n", array_map('strval', (array) ($this->options['spam_keywords'] ?? [])));
        $disposable_text = implode("\n", array_map('strval', (array) ($this->options['disposable_domains'] ?? [])));
        $ua_text = implode("\n", array_map('strval', (array) ($this->options['scraper_ua_substrings'] ?? [])));

        $clear_url = wp_nonce_url(
            add_query_arg('antispam_clear_log', '1', admin_url('options-general.php?page=antispam-comments')),
            'antispam_comments_pro_clear_log'
        );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Anti-Spam Comments Pro', 'antispam-comments-pro'); ?></h1>

            <form method="post" action="">
                <?php wp_nonce_field('antispam_comments_pro_save', 'antispam_comments_pro_nonce'); ?>
                <h2 class="title"><?php esc_html_e('Rules', 'antispam-comments-pro'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="spam_keywords"><?php esc_html_e('Spam keywords (one per line)', 'antispam-comments-pro'); ?></label></th>
                        <td><textarea class="large-text code" rows="6" name="spam_keywords" id="spam_keywords"><?php echo esc_textarea($keywords_text); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="min_submit_seconds"><?php esc_html_e('Minimum seconds before submit', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="min_submit_seconds" id="min_submit_seconds" type="number" min="0" step="1" value="<?php echo esc_attr((string) ($this->options['min_submit_seconds'] ?? 3)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="max_links"><?php esc_html_e('Max URL / BBCode link patterns in body', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="max_links" id="max_links" type="number" min="0" step="1" value="<?php echo esc_attr((string) ($this->options['max_links'] ?? 3)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="min_comment_length"><?php esc_html_e('Minimum comment length (characters)', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="min_comment_length" id="min_comment_length" type="number" min="1" step="1" value="<?php echo esc_attr((string) ($this->options['min_comment_length'] ?? 10)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="min_word_count"><?php esc_html_e('Minimum word count', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="min_word_count" id="min_word_count" type="number" min="1" step="1" value="<?php echo esc_attr((string) ($this->options['min_word_count'] ?? 3)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="uniqueness_ratio"><?php esc_html_e('Minimum unique-word ratio (0–1)', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="uniqueness_ratio" id="uniqueness_ratio" type="number" min="0" max="1" step="0.05" value="<?php echo esc_attr((string) ($this->options['uniqueness_ratio'] ?? 0.5)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="disposable_domains"><?php esc_html_e('Disposable email domains (one per line)', 'antispam-comments-pro'); ?></label></th>
                        <td><textarea class="large-text code" rows="5" name="disposable_domains" id="disposable_domains"><?php echo esc_textarea($disposable_text); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Comment-only scraper UA block', 'antispam-comments-pro'); ?></th>
                        <td>
                            <label><input type="checkbox" name="block_scraper_ua_on_comments" value="1" <?php checked(!empty($this->options['block_scraper_ua_on_comments'])); ?>>
                                <?php esc_html_e('Reject comments when User-Agent matches the list below (off by default; does not affect normal browsing).', 'antispam-comments-pro'); ?></label>
                            <p class="description"><?php esc_html_e('Avoid broad terms like “bot” — they cause false positives.', 'antispam-comments-pro'); ?></p>
                            <textarea class="large-text code" rows="4" name="scraper_ua_substrings" id="scraper_ua_substrings"><?php echo esc_textarea($ua_text); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Logging', 'antispam-comments-pro'); ?></th>
                        <td>
                            <label><input type="checkbox" name="enable_logging" value="1" <?php checked(!empty($this->options['enable_logging'])); ?>>
                                <?php esc_html_e('Log blocked attempts (stores IP and user agent).', 'antispam-comments-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="log_max_entries"><?php esc_html_e('Max log entries to keep', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="log_max_entries" id="log_max_entries" type="number" min="10" max="500" step="1" value="<?php echo esc_attr((string) ($this->options['log_max_entries'] ?? 100)); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="admin_list_limit"><?php esc_html_e('Rows to show in dashboard table', 'antispam-comments-pro'); ?></label></th>
                        <td><input name="admin_list_limit" id="admin_list_limit" type="number" min="5" max="100" step="1" value="<?php echo esc_attr((string) ($this->options['admin_list_limit'] ?? 20)); ?>"></td>
                    </tr>
                </table>
                <?php submit_button(__('Save settings', 'antispam-comments-pro'), 'primary', 'antispam_comments_pro_save'); ?>
            </form>

            <hr>
            <p>
                <?php
                printf(
                    /* translators: %d: number of log entries */
                    esc_html__('Total logged events: %d', 'antispam-comments-pro'),
                    (int) $total_blocked
                );
                ?>
                <?php if ($total_blocked > 0) : ?>
                    &nbsp;|&nbsp;<a class="button" href="<?php echo esc_url($clear_url); ?>"><?php esc_html_e('Clear log', 'antispam-comments-pro'); ?></a>
                <?php endif; ?>
            </p>

            <?php if (!empty($spam_log)) : ?>
                <h2><?php esc_html_e('Recent log entries', 'antispam-comments-pro'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                    <tr>
                        <th><?php esc_html_e('Time', 'antispam-comments-pro'); ?></th>
                        <th><?php esc_html_e('IP', 'antispam-comments-pro'); ?></th>
                        <th><?php esc_html_e('Reason', 'antispam-comments-pro'); ?></th>
                        <th><?php esc_html_e('User agent', 'antispam-comments-pro'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach (array_slice($spam_log, 0, $list_limit) as $entry) : ?>
                        <?php
                        if (!is_array($entry)) {
                            continue;
                        }
                        $ua = isset($entry['user_agent']) ? (string) $entry['user_agent'] : '';
                        $ua_short = strlen($ua) > 80 ? substr($ua, 0, 80) . '…' : $ua;
                        ?>
                        <tr>
                            <td><?php echo esc_html((string) ($entry['time'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) ($entry['ip'] ?? '')); ?></td>
                            <td><?php echo esc_html((string) ($entry['reason'] ?? '')); ?></td>
                            <td><?php echo esc_html($ua_short); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
}

register_activation_hook(__FILE__, static function (): void {
    if (get_option(ANTISPAM_COMMENTS_PRO_OPTION) === false) {
        add_option(ANTISPAM_COMMENTS_PRO_OPTION, [], '', false);
    }
});

new AntiSpamCommentsPro();
